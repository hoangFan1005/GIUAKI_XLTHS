# Thuật toán 2 — gói nộp

`main.py` cố định TT2. Giải nén ZIP, bổ sung dữ liệu gốc vào `data/train/` và `data/test/`, rồi chạy:

```powershell
python -m pip install -r requirements.txt
python main.py
python main.py --file phone_F2.wav
python main.py --no-show
python main.py --evaluate-all
```

Cần Python ≥ 3.10, có Tkinter để mở cửa sổ. Mặc định chạy 4 test, frame 25 ms/hop 10 ms; HIGH xác nhận, LOW duy trì; nối silence < 200 ms, bỏ speech < 100 ms. MAE chỉ dùng START/END của FINAL regions.

TT2 chỉ Histogram Energy; không dùng Spectral Centroid. W = 20 chung; W nguyên 1–50 đồng tối ưu trên 4 test. LAB test tham gia chọn W, nên kết quả là test-tuned.

`GIAI_THICH_THUAT_TOAN.md` giải thích riêng thuật toán này bằng tiếng Việt. PPTX/PDF gồm 7 slide tiếng Anh, biểu đồ/bảng chỉnh sửa được trong PPTX. `evidence/` chứa kết quả 4 test. ZIP không có WAV.

Tên/MSSV còn chờ bổ sung. Trước nộp đổi tên thư mục thành `MaTheSV-HoTen` và thay thông tin pending trên slide đầu. Thuyết trình khoảng 3 phút, demo 1 phút.

Module chung có cả ba thuật toán do pipeline cần import; sinh viên chạy phần mình bằng main cố định. Link tài liệu trong ZIP dùng đường dẫn tương đối để đọc trên máy khác.
