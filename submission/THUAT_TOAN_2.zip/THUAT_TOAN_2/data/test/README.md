Đặt 4 WAV và 4 LAB cùng tên của tập test tại đây. ZIP không chứa WAV theo quy định nộp bài.
