from pathlib import Path
import csv
notice='''
## Hai chế độ endpoint (07/10/2026)

Mặc định `enhanced`: ngưỡng native tạo seed; noise TRAIN và HIGH/LOW xác nhận, giữ speech; nối gap support dưới 200 ms và lọc span dưới 100 ms. `core` giữ quyết định native và chỉ nối gap support dưới 200 ms, không lọc duration hoặc padding FINAL; LOW/HIGH là null. Gap ước lượng đúng 200 ms được giữ riêng. TT1 dùng STE ≥ T, TT2 dùng Energy > T, TT3 giữ hướng high/low của Gaussian native. Đây là hai chế độ endpoint của cùng ba thuật toán; enhanced là phần bổ sung của dự án.

```powershell
python main_tt1.py --endpoint-mode core
python main.py --evaluate-all --compare-endpoint-modes
```

Mỗi mode fit và khóa model độc lập trên bốn TRAIN trước đọc TEST. Kết quả mới ở `outputs/endpoint_modes/core/` và `outputs/endpoint_modes/enhanced/`; bảng so sánh ở `outputs/endpoint_modes/comparison/tables/`. Model schema 3 giữ policy/digest, metric schema 2 tiếp tục `mae_ms`/`rmse_ms`. Thiếu/thừa vùng làm primary mean toàn bộ file undefined; `valid_files_*` là thống kê subset riêng. TEST có `historical_test_exposure=true`, không phải holdout độc lập. Không chọn mode tốt hơn riêng cho từng WAV.

Notebook dùng `MODE="enhanced"` mặc định cho bốn TEST figure và một illustration; luôn fit/khóa `MODELS` cả hai mode trước TEST, xuất 16 dòng tám WAV/mode và bảng bốn TEST/mode. TT2 có 200 TRAIN sweep rows mỗi mode. Core plot native T; Energy TT2 được chuẩn hóa chỉ ở bước hiển thị. Source digest và model lock digests độc lập kiểm tra nguồn/outputs và model; Restart Kernel → Run All → Save vẫn chạy độc lập.

PPTX/PDF và ZIP Python cũ giữ nguyên previous version. Các bảng, noise và ví dụ HIGH/LOW bên dưới mô tả enhanced; không phải công thức quyết định FINAL của core. Xem [báo cáo hai mode](reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md).
'''
for name in ('README.md','notebooks/README.md','tools/README.md','outputs/README.md','reports/TT1_BINARY_SEARCH_GIAI_THICH.md','reports/TT2_HISTOGRAM_GIAI_THICH.md','reports/TT3_GAUSSIAN_GIAI_THICH.md'):
    p=Path(name);s=p.read_text(encoding='utf-8-sig');local=notice
    if name!='README.md':local=local.replace('(reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md)','(../reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md)')
    if name.startswith('reports/'):
        local=local.replace('(../reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md)','(KET_QUA_ENDPOINT_MODES_2026_10_07.md)')
        s=s.replace('../outputs/models/','../outputs/endpoint_modes/enhanced/models/').replace('../outputs/tables/','../outputs/endpoint_modes/enhanced/tables/').replace('../outputs/figures/','../outputs/endpoint_modes/enhanced/figures/').replace('../outputs/diagnostics/','../outputs/endpoint_modes/enhanced/diagnostics/')
    first=s.index('\n');s=s[:first]+ '\n'+local+s[first:]
    s=s.replace("FINAL HIGH/LOW hiện yêu cầu `speech_direction='high'`", "Enhanced FINAL HIGH/LOW yêu cầu `speech_direction='high'`; core giữ hướng native")
    s=s.replace('FINAL energy HIGH/LOW chỉ hỗ trợ', 'Enhanced FINAL energy HIGH/LOW chỉ hỗ trợ')
    s=s.replace('Model schema 2 ghi','Model schema 3 với metric schema 2 ghi')
    p.write_text(s,encoding='utf-8')
p=Path('algorithms/tt2_histogram.py');s=p.read_text(encoding='utf-8-sig').replace('FINAL endpoints use raw STE hysteresis without padding.','Enhanced FINAL uses raw STE hysteresis without final padding; core FINAL uses native Energy decisions and support-gap merging.');p.write_text(s,encoding='utf-8')
root=Path('outputs/endpoint_modes/comparison/tables')
def rows(name):
    with (root/name).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
content='# Kết quả endpoint core và enhanced — 07/10/2026\n\nCùng ba thuật toán và hai policy được fit TRAIN độc lập trước TEST. Không chọn mode theo từng bản ghi. TEST từng được xem trong lịch sử; protocol `train_selected_reused_test`, `historical_test_exposure=true`. Gaussian vẫn là xấp xỉ theo đề. TT1 cân bằng diện tích nhầm lẫn, TT3 giải equal-density; sigma đơn lẻ không suy ra T3 > T1.\n\n'
for title,name in [('Bốn TEST (12 kết quả mỗi mode)','test_summary.csv'),('Tám WAV TRAIN + TEST (24 kết quả mỗi mode)','all_summary.csv')]:
    content+='## '+title+'\n\n| Algorithm | Mode | Mean FINAL-region endpoint MAE ms | Valid-only mean ms | Counts correct | Max defined MAE ms |\n|---|---|---|---|---|---|\n'
    for r in rows(name):
        fmt=lambda key:f"{float(r[key]):.6f}" if r[key] else 'undefined'
        content+=f"| {r['algorithm']} | {r['endpoint_mode']} | {fmt('mean_file_mae_ms')} | {fmt('valid_files_mean_file_mae_ms')} | {r['region_count_correct_files']}/{r['files']} | {fmt('max_file_mae_ms')} |\n"
    content+='\n'
content+='Primary MAE/RMSE cần đúng số vùng trên mọi file. Mean subset chỉ nằm ở valid-only; lỗi lớn vẫn được giữ. Counts sai của core TT1/TT2 không được thay bằng metric các vùng đã ghép. Core TT3 và enhanced TT3 cho cùng endpoints trên dataset này; đây không phải bảo đảm cho dữ liệu khác.\n\n## Từng WAV và từng mode\n\n| Split | WAV | Algorithm | Mode | GT / prediction regions | START s | END s | MAE ms | RMSE ms | Status |\n|---|---|---|---|---|---|---|---|---|---|\n'
for r in rows('all_metrics.csv'):
    content+=f"| {r['split']} | {r['file']} | {r['algorithm']} | {r['endpoint_mode']} | {r['ground_truth_region_count']} / {r['predicted_region_count']} | {r['predicted_start_s']} | {r['predicted_end_s']} | {r['mae_ms'] or 'undefined'} | {r['rmse_ms'] or 'undefined'} | {r['status']} |\n"
content+='\nCác START/END scalar là envelope hỗ trợ đọc nhanh; khi nhiều vùng, diagnostic JSON chứa toàn bộ FINAL regions và primary metric chấm mọi cặp START/END theo thứ tự. Core LOW/HIGH null; native T nằm trong threshold diagnostics. Timing 25/10 ms dùng nearest samples/ties-to-even (44.1 kHz: 1102/441 samples); actual timing có trong metrics. Gap support <200 ms mới nối; exact200 ms giữ. Slides và ZIP Python cũ là previous version và được giữ nguyên.\n'
Path('reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md').write_text(content,encoding='utf-8')
