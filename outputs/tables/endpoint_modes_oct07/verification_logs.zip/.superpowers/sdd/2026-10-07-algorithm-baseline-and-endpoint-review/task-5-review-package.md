# Task5 review — 27dc471..b38d640
b38d640 Integrate core and enhanced modes across CLI and notebooks
 README.md                                          |    22 +-
 algorithms/tt2_histogram.py                        |     2 +-
 app/cli.py                                         |     4 +-
 app/config.py                                      |     7 +
 app/pipeline.py                                    |   301 +-
 app/plotting.py                                    |    29 +-
 app/weight_selection.py                            |     2 +
 notebooks/README.md                                |    20 +-
 notebooks/THUAT_TOAN_1.ipynb                       |  4074 +++-
 notebooks/THUAT_TOAN_2.ipynb                       | 19632 +++++++++++++++++--
 notebooks/THUAT_TOAN_3.ipynb                       |  4100 +++-
 outputs/README.md                                  |    18 +-
 .../endpoint_modes/comparison/artifact_audit.json  |    59 +
 .../comparison/tables/all_metrics.csv              |    49 +
 .../comparison/tables/all_summary.csv              |     7 +
 .../comparison/tables/test_metrics.csv             |    25 +
 .../comparison/tables/test_summary.csv             |     7 +
 .../core/diagnostics/tt1/phone_F1.json             |    63 +
 .../core/diagnostics/tt1/phone_F2.json             |    55 +
 .../core/diagnostics/tt1/phone_M1.json             |    43 +
 .../core/diagnostics/tt1/phone_M2.json             |    35 +
 .../core/diagnostics/tt1/studio_F1.json            |    35 +
 .../core/diagnostics/tt1/studio_F2.json            |    35 +
 .../core/diagnostics/tt1/studio_M1.json            |    35 +
 .../core/diagnostics/tt1/studio_M2.json            |    31 +
 .../core/diagnostics/tt2/phone_F1.json             |   110 +
 .../core/diagnostics/tt2/phone_F2.json             |   100 +
 .../core/diagnostics/tt2/phone_M1.json             |   106 +
 .../core/diagnostics/tt2/phone_M2.json             |    98 +
 .../core/diagnostics/tt2/studio_F1.json            |    98 +
 .../core/diagnostics/tt2/studio_F2.json            |    80 +
 .../core/diagnostics/tt2/studio_M1.json            |    88 +
 .../core/diagnostics/tt2/studio_M2.json            |    78 +
 .../core/diagnostics/tt3/phone_F1.json             |    51 +
 .../core/diagnostics/tt3/phone_F2.json             |    51 +
 .../core/diagnostics/tt3/phone_M1.json             |    35 +
 .../core/diagnostics/tt3/phone_M2.json             |    43 +
 .../core/diagnostics/tt3/studio_F1.json            |    39 +
 .../core/diagnostics/tt3/studio_F2.json            |    35 +
 .../core/diagnostics/tt3/studio_M1.json            |    35 +
 .../core/diagnostics/tt3/studio_M2.json            |    35 +
 .../core/figures/comparison/phone_F1.png           |   Bin 0 -> 572576 bytes
 .../core/figures/comparison/phone_F2.png           |   Bin 0 -> 490260 bytes
 .../core/figures/comparison/phone_M1.png           |   Bin 0 -> 588846 bytes
 .../core/figures/comparison/phone_M2.png           |   Bin 0 -> 594801 bytes
 .../core/figures/comparison/studio_F1.png          |   Bin 0 -> 553766 bytes
 .../core/figures/comparison/studio_F2.png          |   Bin 0 -> 494145 bytes
 .../core/figures/comparison/studio_M1.png          |   Bin 0 -> 434966 bytes
 .../core/figures/comparison/studio_M2.png          |   Bin 0 -> 583707 bytes
 .../figures/training/gaussian_distributions.png    |   Bin 0 -> 94318 bytes
 .../endpoint_modes/core/figures/tt1/phone_F1.png   |   Bin 0 -> 209579 bytes
 .../endpoint_modes/core/figures/tt1/phone_F2.png   |   Bin 0 -> 178832 bytes
 .../endpoint_modes/core/figures/tt1/phone_M1.png   |   Bin 0 -> 215957 bytes
 .../endpoint_modes/core/figures/tt1/phone_M2.png   |   Bin 0 -> 216761 bytes
 .../endpoint_modes/core/figures/tt1/studio_F1.png  |   Bin 0 -> 203186 bytes
 .../endpoint_modes/core/figures/tt1/studio_F2.png  |   Bin 0 -> 183739 bytes
 .../endpoint_modes/core/figures/tt1/studio_M1.png  |   Bin 0 -> 161452 bytes
 .../endpoint_modes/core/figures/tt1/studio_M2.png  |   Bin 0 -> 212945 bytes
 .../endpoint_modes/core/figures/tt2/phone_F1.png   |   Bin 0 -> 210514 bytes
 .../endpoint_modes/core/figures/tt2/phone_F2.png   |   Bin 0 -> 177022 bytes
 .../endpoint_modes/core/figures/tt2/phone_M1.png   |   Bin 0 -> 216280 bytes
 .../endpoint_modes/core/figures/tt2/phone_M2.png   |   Bin 0 -> 218509 bytes
 .../endpoint_modes/core/figures/tt2/studio_F1.png  |   Bin 0 -> 204318 bytes
 .../endpoint_modes/core/figures/tt2/studio_F2.png  |   Bin 0 -> 183530 bytes
 .../endpoint_modes/core/figures/tt2/studio_M1.png  |   Bin 0 -> 160473 bytes
 .../endpoint_modes/core/figures/tt2/studio_M2.png  |   Bin 0 -> 212779 bytes
 .../endpoint_modes/core/figures/tt3/phone_F1.png   |   Bin 0 -> 209392 bytes
 .../endpoint_modes/core/figures/tt3/phone_F2.png   |   Bin 0 -> 176480 bytes
 .../endpoint_modes/core/figures/tt3/phone_M1.png   |   Bin 0 -> 216271 bytes
 .../endpoint_modes/core/figures/tt3/phone_M2.png   |   Bin 0 -> 217017 bytes
 .../endpoint_modes/core/figures/tt3/studio_F1.png  |   Bin 0 -> 202800 bytes
 .../endpoint_modes/core/figures/tt3/studio_F2.png  |   Bin 0 -> 183406 bytes
 .../endpoint_modes/core/figures/tt3/studio_M1.png  |   Bin 0 -> 160794 bytes
 .../endpoint_modes/core/figures/tt3/studio_M2.png  |   Bin 0 -> 212223 bytes
 outputs/endpoint_modes/core/models/tt1.json        |    42 +
 outputs/endpoint_modes/core/models/tt2.json        |   717 +
 outputs/endpoint_modes/core/models/tt3.json        |    47 +
 .../core/predictions/tt1/phone_F1.csv              |     4 +
 .../core/predictions/tt1/phone_F2.csv              |     8 +
 .../core/predictions/tt1/phone_M1.csv              |     4 +
 .../core/predictions/tt1/phone_M2.csv              |     4 +
 .../core/predictions/tt1/studio_F1.csv             |     4 +
 .../core/predictions/tt1/studio_F2.csv             |     4 +
 .../core/predictions/tt1/studio_M1.csv             |     4 +
 .../core/predictions/tt1/studio_M2.csv             |     4 +
 .../core/predictions/tt2/phone_F1.csv              |     6 +
 .../core/predictions/tt2/phone_F2.csv              |     6 +
 .../core/predictions/tt2/phone_M1.csv              |     4 +
 .../core/predictions/tt2/phone_M2.csv              |     4 +
 .../core/predictions/tt2/studio_F1.csv             |     4 +
 .../core/predictions/tt2/studio_F2.csv             |     4 +
 .../core/predictions/tt2/studio_M1.csv             |     4 +
 .../core/predictions/tt2/studio_M2.csv             |     4 +
 .../core/predictions/tt3/phone_F1.csv              |     4 +
 .../core/predictions/tt3/phone_F2.csv              |     4 +
 .../core/predictions/tt3/phone_M1.csv              |     4 +
 .../core/predictions/tt3/phone_M2.csv              |     4 +
 .../core/predictions/tt3/studio_F1.csv             |     4 +
 .../core/predictions/tt3/studio_F2.csv             |     4 +
 .../core/predictions/tt3/studio_M1.csv             |     4 +
 .../core/predictions/tt3/studio_M2.csv             |     4 +
 outputs/endpoint_modes/core/tables/all/summary.csv |     4 +
 .../core/tables/all/test_metrics.csv               |    13 +
 .../core/tables/all_all_dataset/run_config.json    |    48 +
 .../core/tables/all_all_dataset/summary.csv        |     4 +
 .../core/tables/all_all_dataset/test_metrics.csv   |    25 +
 .../tables/all_all_dataset/test_thresholds.csv     |    25 +
 .../core/tables/dataset_statistics.csv             |    13 +
 .../endpoint_modes/core/tables/training_frames.csv |  1292 ++
 .../core/tables/tt2_w_selection/best_by_file.csv   |     5 +
 .../core/tables/tt2_w_selection/selection.json     |   634 +
 .../core/tables/tt2_w_selection/summary.csv        |    51 +
 .../core/tables/tt2_w_selection/sweep.csv          |   201 +
 .../enhanced/diagnostics/tt1/phone_F1.json         |    71 +
 .../enhanced/diagnostics/tt1/phone_F2.json         |    55 +
 .../enhanced/diagnostics/tt1/phone_M1.json         |    51 +
 .../enhanced/diagnostics/tt1/phone_M2.json         |    43 +
 .../enhanced/diagnostics/tt1/studio_F1.json        |    43 +
 .../enhanced/diagnostics/tt1/studio_F2.json        |    43 +
 .../enhanced/diagnostics/tt1/studio_M1.json        |    43 +
 .../enhanced/diagnostics/tt1/studio_M2.json        |    39 +
 .../enhanced/diagnostics/tt2/phone_F1.json         |    86 +
 .../enhanced/diagnostics/tt2/phone_F2.json         |    76 +
 .../enhanced/diagnostics/tt2/phone_M1.json         |    86 +
 .../enhanced/diagnostics/tt2/phone_M2.json         |    78 +
 .../enhanced/diagnostics/tt2/studio_F1.json        |    86 +
 .../enhanced/diagnostics/tt2/studio_F2.json        |    72 +
 .../enhanced/diagnostics/tt2/studio_M1.json        |    80 +
 .../enhanced/diagnostics/tt2/studio_M2.json        |    78 +
 .../enhanced/diagnostics/tt3/phone_F1.json         |    59 +
 .../enhanced/diagnostics/tt3/phone_F2.json         |    59 +
 .../enhanced/diagnostics/tt3/phone_M1.json         |    43 +
 .../enhanced/diagnostics/tt3/phone_M2.json         |    51 +
 .../enhanced/diagnostics/tt3/studio_F1.json        |    47 +
 .../enhanced/diagnostics/tt3/studio_F2.json        |    43 +
 .../enhanced/diagnostics/tt3/studio_M1.json        |    43 +
 .../enhanced/diagnostics/tt3/studio_M2.json        |    43 +
 .../enhanced/figures/comparison/phone_F1.png       |   Bin 0 -> 576309 bytes
 .../enhanced/figures/comparison/phone_F2.png       |   Bin 0 -> 492262 bytes
 .../enhanced/figures/comparison/phone_M1.png       |   Bin 0 -> 592586 bytes
 .../enhanced/figures/comparison/phone_M2.png       |   Bin 0 -> 597914 bytes
 .../enhanced/figures/comparison/studio_F1.png      |   Bin 0 -> 555792 bytes
 .../enhanced/figures/comparison/studio_F2.png      |   Bin 0 -> 496950 bytes
 .../enhanced/figures/comparison/studio_M1.png      |   Bin 0 -> 438811 bytes
 .../enhanced/figures/comparison/studio_M2.png      |   Bin 0 -> 587499 bytes
 .../figures/training/gaussian_distributions.png    |   Bin 0 -> 94318 bytes
 .../enhanced/figures/tt1/phone_F1.png              |   Bin 0 -> 210613 bytes
 .../enhanced/figures/tt1/phone_F2.png              |   Bin 0 -> 177839 bytes
 .../enhanced/figures/tt1/phone_M1.png              |   Bin 0 -> 216936 bytes
 .../enhanced/figures/tt1/phone_M2.png              |   Bin 0 -> 218113 bytes
 .../enhanced/figures/tt1/studio_F1.png             |   Bin 0 -> 203862 bytes
 .../enhanced/figures/tt1/studio_F2.png             |   Bin 0 -> 184308 bytes
 .../enhanced/figures/tt1/studio_M1.png             |   Bin 0 -> 161890 bytes
 .../enhanced/figures/tt1/studio_M2.png             |   Bin 0 -> 214282 bytes
 .../enhanced/figures/tt2/phone_F1.png              |   Bin 0 -> 211137 bytes
 .../enhanced/figures/tt2/phone_F2.png              |   Bin 0 -> 178406 bytes
 .../enhanced/figures/tt2/phone_M1.png              |   Bin 0 -> 217945 bytes
 .../enhanced/figures/tt2/phone_M2.png              |   Bin 0 -> 218911 bytes
 .../enhanced/figures/tt2/studio_F1.png             |   Bin 0 -> 204066 bytes
 .../enhanced/figures/tt2/studio_F2.png             |   Bin 0 -> 184382 bytes
 .../enhanced/figures/tt2/studio_M1.png             |   Bin 0 -> 162298 bytes
 .../enhanced/figures/tt2/studio_M2.png             |   Bin 0 -> 213644 bytes
 .../enhanced/figures/tt3/phone_F1.png              |   Bin 0 -> 210895 bytes
 .../enhanced/figures/tt3/phone_F2.png              |   Bin 0 -> 178591 bytes
 .../enhanced/figures/tt3/phone_M1.png              |   Bin 0 -> 217701 bytes
 .../enhanced/figures/tt3/phone_M2.png              |   Bin 0 -> 218874 bytes
 .../enhanced/figures/tt3/studio_F1.png             |   Bin 0 -> 204676 bytes
 .../enhanced/figures/tt3/studio_F2.png             |   Bin 0 -> 184958 bytes
 .../enhanced/figures/tt3/studio_M1.png             |   Bin 0 -> 162727 bytes
 .../enhanced/figures/tt3/studio_M2.png             |   Bin 0 -> 214192 bytes
 outputs/endpoint_modes/enhanced/models/tt1.json    |    50 +
 outputs/endpoint_modes/enhanced/models/tt2.json    |   899 +
 outputs/endpoint_modes/enhanced/models/tt3.json    |    55 +
 .../enhanced/predictions/tt1/phone_F1.csv          |     4 +
 .../enhanced/predictions/tt1/phone_F2.csv          |     4 +
 .../enhanced/predictions/tt1/phone_M1.csv          |     4 +
 .../enhanced/predictions/tt1/phone_M2.csv          |     4 +
 .../enhanced/predictions/tt1/studio_F1.csv         |     4 +
 .../enhanced/predictions/tt1/studio_F2.csv         |     4 +
 .../enhanced/predictions/tt1/studio_M1.csv         |     4 +
 .../enhanced/predictions/tt1/studio_M2.csv         |     4 +
 .../enhanced/predictions/tt2/phone_F1.csv          |     4 +
 .../enhanced/predictions/tt2/phone_F2.csv          |     4 +
 .../enhanced/predictions/tt2/phone_M1.csv          |     4 +
 .../enhanced/predictions/tt2/phone_M2.csv          |     4 +
 .../enhanced/predictions/tt2/studio_F1.csv         |     4 +
 .../enhanced/predictions/tt2/studio_F2.csv         |     4 +
 .../enhanced/predictions/tt2/studio_M1.csv         |     4 +
 .../enhanced/predictions/tt2/studio_M2.csv         |     4 +
 .../enhanced/predictions/tt3/phone_F1.csv          |     4 +
 .../enhanced/predictions/tt3/phone_F2.csv          |     4 +
 .../enhanced/predictions/tt3/phone_M1.csv          |     4 +
 .../enhanced/predictions/tt3/phone_M2.csv          |     4 +
 .../enhanced/predictions/tt3/studio_F1.csv         |     4 +
 .../enhanced/predictions/tt3/studio_F2.csv         |     4 +
 .../enhanced/predictions/tt3/studio_M1.csv         |     4 +
 .../enhanced/predictions/tt3/studio_M2.csv         |     4 +
 .../endpoint_modes/enhanced/tables/all/summary.csv |     4 +
 .../enhanced/tables/all/test_metrics.csv           |    13 +
 .../tables/all_all_dataset/run_config.json         |    48 +
 .../enhanced/tables/all_all_dataset/summary.csv    |     4 +
 .../tables/all_all_dataset/test_metrics.csv        |    25 +
 .../tables/all_all_dataset/test_thresholds.csv     |    25 +
 .../enhanced/tables/dataset_statistics.csv         |    13 +
 .../enhanced/tables/training_frames.csv            |  1292 ++
 .../tables/tt2_w_selection/best_by_file.csv        |     5 +
 .../enhanced/tables/tt2_w_selection/selection.json |   808 +
 .../enhanced/tables/tt2_w_selection/summary.csv    |    51 +
 .../enhanced/tables/tt2_w_selection/sweep.csv      |   201 +
 reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md       |    82 +
 reports/TT1_BINARY_SEARCH_GIAI_THICH.md            |    26 +-
 reports/TT2_HISTOGRAM_GIAI_THICH.md                |    28 +-
 reports/TT3_GAUSSIAN_GIAI_THICH.md                 |    30 +-
 submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip         |   Bin 1644686 -> 1729909 bytes
 tests/test_endpoint_mode_integration.py            |   106 +
 tests/test_framing.py                              |     4 +-
 tests/test_notebook_protocol.py                    |    35 +-
 tests/test_training_protocol.py                    |    10 +-
 tools/README.md                                    |    16 +
 tools/build_notebooks.py                           |    88 +-
 tools/run_notebooks.py                             |    74 +-
 221 files changed, 35843 insertions(+), 2660 deletions(-)
diff --git a/README.md b/README.md
index 1a29a34..9dc6b58 100644
--- a/README.md
+++ b/README.md
@@ -1,13 +1,29 @@
 # Giữa kỳ XLTHS — phân đoạn tiếng nói và khoảng lặng
 
-Ba thuật toán Python: **TT1 Binary Search**, **TT2 Histogram chỉ Energy**, **TT3 Gaussian**. Đặc trưng, ngưỡng và metrics được tự tính; Matplotlib dùng để vẽ. Cấu hình chung: frame **25 ms**, hop **10 ms**; **200 ms** đo khoảng trống ước lượng giữa các support khung hoạt động; **100 ms** lọc theo span vùng support. Hai quy tắc này là heuristic, không bảo đảm khoảng lặng vật lý 200 ms hoặc tiếng nói thực 100 ms vì các khung có thể chồng lấn. Không tính F0.
+## Hai chế độ endpoint (07/10/2026)
+
+Mặc định `enhanced`: ngưỡng native tạo seed; noise TRAIN và HIGH/LOW xác nhận, giữ speech; nối gap support dưới 200 ms và lọc span dưới 100 ms. `core` giữ quyết định native và chỉ nối gap support dưới 200 ms, không lọc duration hoặc padding FINAL; LOW/HIGH là null. Gap ước lượng đúng 200 ms được giữ riêng. TT1 dùng STE ≥ T, TT2 dùng Energy > T, TT3 giữ hướng high/low của Gaussian native. Đây là hai chế độ endpoint của cùng ba thuật toán; enhanced là phần bổ sung của dự án.
+
+```powershell
+python main_tt1.py --endpoint-mode core
+python main.py --evaluate-all --compare-endpoint-modes
+```
+
+Mỗi mode fit và khóa model độc lập trên bốn TRAIN trước đọc TEST. Kết quả mới ở `outputs/endpoint_modes/core/` và `outputs/endpoint_modes/enhanced/`; bảng so sánh ở `outputs/endpoint_modes/comparison/tables/`. Model schema 3 giữ policy/digest, metric schema 2 tiếp tục `mae_ms`/`rmse_ms`. Thiếu/thừa vùng làm primary mean toàn bộ file undefined; `valid_files_*` là thống kê subset riêng. TEST có `historical_test_exposure=true`, không phải holdout độc lập. Không chọn mode tốt hơn riêng cho từng WAV.
+
+Notebook dùng `MODE="enhanced"` mặc định cho bốn TEST figure và một illustration; luôn fit/khóa `MODELS` cả hai mode trước TEST, xuất 16 dòng tám WAV/mode và bảng bốn TEST/mode. TT2 có 200 TRAIN sweep rows mỗi mode. Core plot native T; Energy TT2 được chuẩn hóa chỉ ở bước hiển thị. Source digest và model lock digests độc lập kiểm tra nguồn/outputs và model; Restart Kernel → Run All → Save vẫn chạy độc lập.
+
+PPTX/PDF và ZIP Python cũ giữ nguyên previous version. Các bảng, noise và ví dụ HIGH/LOW bên dưới mô tả enhanced; không phải công thức quyết định FINAL của core. Xem [báo cáo hai mode](reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md).
+
+
+Ba thuật toán Python: **TT1 Binary Search**, **TT2 Histogram chỉ Energy**, **TT3 Gaussian**. Đặc trưng, ngưỡng và metrics được tự tính; Matplotlib dùng để vẽ. Cấu hình chung: frame **25 ms**, hop **10 ms**; **200 ms** đo khoảng trống ước lượng giữa các support khung hoạt động; **100 ms** chỉ lọc theo span vùng support trong enhanced. Hai quy tắc này là heuristic, không bảo đảm khoảng lặng vật lý 200 ms hoặc tiếng nói thực 100 ms vì các khung có thể chồng lấn. Không tính F0.
 
 ## Mã nguồn Jupyter theo yêu cầu bổ sung
 
 Mỗi sinh viên có một notebook riêng, chứa toàn bộ code và kết quả đã chạy:
 
 - [TT1 — Binary Search](notebooks/THUAT_TOAN_1.ipynb)
 - [TT2 — Histogram Energy](notebooks/THUAT_TOAN_2.ipynb)
 - [TT3 — Gaussian](notebooks/THUAT_TOAN_3.ipynb)
 
 [Hướng dẫn mở/chạy notebook](notebooks/README.md) · [ZIP chỉ chứa 3 notebook](submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip).
@@ -46,23 +62,23 @@ Khi chuyển máy, sao chép main tương ứng, `app/`, `algorithms/`, `core/`,
 Mỗi tài liệu gồm ý tưởng, ví dụ tính tay, công thức, các hàm Python, High/Low, biên cuối và MAE:
 
 | Thuật toán | Tài liệu |
 |---|---|
 | TT1 Binary Search | [Giải thích TT1](reports/TT1_BINARY_SEARCH_GIAI_THICH.md) |
 | TT2 Histogram Energy-only | [Giải thích TT2](reports/TT2_HISTOGRAM_GIAI_THICH.md) |
 | TT3 Gaussian | [Giải thích TT3](reports/TT3_GAUSSIAN_GIAI_THICH.md) |
 
 [Kết quả hiện tại và giới hạn](reports/KET_QUA_HIEN_TAI.md) tổng hợp 4 test và toàn bộ 8 WAV. [Báo cáo sửa lỗi ngày 06/10, nghiệm thu 07/10](reports/KET_QUA_SUA_LOI_2026_10_06.md) ghi hai sửa TT3, khảo sát timing/TRAIN, 133 tests và hồi quy 24 trường hợp không đổi.
 
-TT2 chỉ dùng **Energy**, không Centroid/F0. W20 chọn trên bốn TRAIN FINAL, khảo sát W1–50 với tie preference cố định 20; tất cả 50 W hòa trong TRAIN hiện tại (mean 13.747165532879801 ms). Candidate frame-F1 đề xuất W1 riêng. Mọi model/noise/W fit TRAIN trước TEST. Schema 2 ghi `train_selected_reused_test` và `historical_test_exposure=true`: TEST có lịch sử được xem, không khẳng định độc lập.
+TT2 chỉ dùng **Energy**, không Centroid/F0. Trong enhanced, W20 chọn trên bốn TRAIN FINAL, khảo sát W1–50 với tie preference cố định 20; tất cả 50 W hòa trong TRAIN hiện tại (mean 13.747165532879801 ms). Candidate frame-F1 đề xuất W1 riêng. Mọi model/noise/W fit TRAIN trước TEST. Model schema 3 và metric schema 2 ghi `train_selected_reused_test` và `historical_test_exposure=true`: TEST có lịch sử được xem, không khẳng định độc lập.
 
-TT3 giải giao điểm Gaussian bằng tọa độ được dịch tâm/chia scale, sigma floor `1e-9`, nghiệm quadratic ổn định và kiểm tra log-density. Hàm Gaussian thô `fit`/`predict` vẫn hỗ trợ hướng `low`; FINAL HIGH/LOW hiện yêu cầu `speech_direction='high'`. Model `low` hoặc hướng không hợp lệ bị từ chối rõ ràng khi fit model FINAL và khi detect, thay vì âm thầm mất vùng nói.
+TT3 giải giao điểm Gaussian bằng tọa độ được dịch tâm/chia scale, sigma floor `1e-9`, nghiệm quadratic ổn định và kiểm tra log-density. Hàm Gaussian thô `fit`/`predict` vẫn hỗ trợ hướng `low`; Enhanced FINAL HIGH/LOW yêu cầu `speech_direction='high'`; core giữ hướng native. Enhanced từ chối model `low` hoặc hướng không hợp lệ khi fit/detect FINAL; core dùng hướng high/low native đã học.
 
 ## 3. Bố trí thư mục
 
 ```text
 GIUAKI_XLTHS/
   main.py, main_tt1.py, main_tt2.py, main_tt3.py
   README.md, requirements.txt, .gitignore
   algorithms/       Ba thuật toán
   app/              CLI, pipeline, vẽ, chọn W
   core/             WAV/LAB, đặc trưng, endpoints, metrics
diff --git a/algorithms/tt2_histogram.py b/algorithms/tt2_histogram.py
index c5076de..72f77b4 100644
--- a/algorithms/tt2_histogram.py
+++ b/algorithms/tt2_histogram.py
@@ -1,16 +1,16 @@
 """Energy-only histogram VAD, as requested by the teacher on 05/10/2026.
 
 Reference: Giannakopoulos PDF pp.1–2 supplies the histogram threshold method.
 This assignment uses energy only, not the reference's two-feature AND rule.
 Assignment adaptation: 25/10 ms framing; retain 250 ms candidate padding each
-side as 25 hop steps. FINAL endpoints use raw STE hysteresis without padding.
+side as 25 hop steps. Enhanced FINAL uses raw STE hysteresis without final padding; core FINAL uses native Energy decisions and support-gap merging.
 The paper does not fix bin count, smoothing window, W or fallback behavior.
 These engineering choices are exposed as parameters and diagnostics.
 """
 from __future__ import annotations
 
 import math
 
 from app.config import FRAME_MS, HOP_MS, MIN_SILENCE_SECONDS, SAMPLE_ROUNDING
 
 PADDING_MS = 250.0
diff --git a/app/cli.py b/app/cli.py
index ffea4c2..d63581f 100644
--- a/app/cli.py
+++ b/app/cli.py
@@ -15,37 +15,39 @@ def parse_args(argv=None, fixed_algorithm=None):
     # Benchmark cần đủ bốn test; --file chỉ chọn một bản ghi để đánh giá.
     # Argparse xử lý cờ sai ngay tại CLI để tránh sinh bộ kết quả không hợp lệ.
     if fixed_algorithm not in (None, "tt1", "tt2", "tt3"):
         raise ValueError("Main riêng phải là tt1, tt2 hoặc tt3")
     parser = argparse.ArgumentParser(description="Chạy endpoint detection; học ngưỡng/noise và chọn TT2 W bằng FINAL MAE trên TRAIN, sau đó chấm điểm TEST đã dùng trong lịch sử.")
     if fixed_algorithm is None:
         parser.add_argument("--algorithm", choices=("all", "tt1", "tt2", "tt3", "tt2-context"), default="all",
                             help="all so sánh ba thuật toán; mỗi tt chạy thuật toán tương ứng.")
     else:
         parser.set_defaults(algorithm=fixed_algorithm)
+    parser.add_argument("--endpoint-mode", choices=("enhanced", "core"), default="enhanced", help="enhanced (default): TRAIN noise HIGH/LOW; core: native decisions and support gaps.")
+    parser.add_argument("--compare-endpoint-modes", action="store_true", help="Fit both modes on TRAIN before TEST; export headless comparison.")
     parser.add_argument("--file", metavar="WAV", default=None,
                         help="Tên WAV trong data/test hoặc data/train, hoặc đường dẫn WAV có LAB cùng tên.")
     parser.add_argument("--no-show", action="store_true", help="Chỉ xuất ảnh/CSV; không mở cửa sổ.")
     parser.add_argument('--evaluate-all',action='store_true',help='Chạy cả 8 WAV train+test, headless. Mọi tham số và TT2 W chọn trên TRAIN; chấm điểm TRAIN/TEST bằng model đã khóa.')
     parser.add_argument("--snr-study", action="store_true", help="Thêm khảo sát nhiễu tổng hợp 20/10/0 dB.")
     # Benchmark ngữ cảnh cần đủ 4 test, còn main riêng chỉ chạy thuật toán được giao.
     if fixed_algorithm is None:
         parser.add_argument("--compare-context", action="store_true",
                             help="Xuất thêm biến thể histogram STE và kiểm benchmark 4 WAV test.")
     else:
         parser.set_defaults(compare_context=False)
     parser.add_argument("--show-seconds", type=float, default=None,
                         help="Tự đóng cửa sổ sau số giây chỉ định khi kiểm tra demo.")
     args = parser.parse_args(argv)
     if args.evaluate_all and (args.file or args.compare_context):
         parser.error('--evaluate-all không kết hợp --file hoặc --compare-context.')
-    if args.evaluate_all:args.no_show=True
+    if args.evaluate_all or args.compare_endpoint_modes:args.no_show=True
     if args.file and args.compare_context:
         parser.error("--compare-context cần đủ 4 WAV test; hãy bỏ --file.")
     if args.show_seconds is not None and args.show_seconds <= 0:
         parser.error("--show-seconds phải lớn hơn 0.")
     return args
 
 
 def main(argv=None, fixed_algorithm=None):
     """Chọn backend Matplotlib rồi điều phối toàn bộ thực nghiệm.
 
diff --git a/app/config.py b/app/config.py
index 786fb58..29e683b 100644
--- a/app/config.py
+++ b/app/config.py
@@ -18,10 +18,17 @@ HISTOGRAM_W_TIE_PREFERENCE = 20.0
 BOUNDARY_TOLERANCE_SECONDS = 0.100
 NOISE_LEVELS_DB = (20, 10, 0)
 RANDOM_SEED = 20261001
 ALGORITHM_TITLES = {
     "tt1": "TT1 - Hodgkinson: binary search",
     "tt2": "TT2 - Histogram: energy only",
     "tt3": "TT3 - Gaussian distributions",
     "tt2-context": "Histogram STE - context report variant",
 }
 FILE_ORDER = ("phone_F2", "phone_M2", "studio_F2", "studio_M2")
+
+
+def endpoint_mode_root(endpoint_mode, output_dir=None):
+    """Return the isolated production root for a declared endpoint mode."""
+    if endpoint_mode not in ('core', 'enhanced', 'comparison'):
+        raise ValueError('Unknown endpoint_mode')
+    return (OUTPUT_DIR if output_dir is None else Path(output_dir)) / 'endpoint_modes' / endpoint_mode
diff --git a/app/pipeline.py b/app/pipeline.py
index b32024d..12b013a 100644
--- a/app/pipeline.py
+++ b/app/pipeline.py
@@ -5,20 +5,21 @@ import json
 import math
 import random
 import zlib
 from pathlib import Path
 
 import matplotlib.pyplot as plt
 
 from algorithms import tt1_hodgkinson as tt1
 from algorithms import tt2_histogram as tt2
 from algorithms import tt3_gaussian as tt3
+from app.config import endpoint_mode_root
 from app.config import (PROJECT_ROOT, TRAIN_DIR, TEST_DIR, OUTPUT_DIR, FILE_ORDER,
                         FRAME_MS, HOP_MS, SAMPLE_ROUNDING,
                         MIN_SILENCE_SECONDS, MIN_SPEECH_SECONDS, BOUNDARY_TOLERANCE_SECONDS,
                         HISTOGRAM_W_TIE_PREFERENCE,
                         NOISE_LEVELS_DB, RANDOM_SEED)
 from app.plotting import make_file_figure, show_figures, plot_gaussian_training
 from core.io_utils import read_wav, read_lab
 from core.features import compute_features
 from core.metrics import (frame_labels, frame_metrics, endpoint_metrics,
                           ground_truth_speech_envelope, ground_truth_boundaries,
@@ -258,20 +259,29 @@ def predict_and_score(algorithm, record, params):
                   gt_end_s=reference[1] if reference else None,
                   predicted_start_s=predicted[0] if predicted else None,
                   predicted_end_s=predicted[1] if predicted else None)
     # Imported historical JSON remains usable without relabeling its TEST W
     # calibration as TRAIN. Fresh fit_training_model outputs never have this key.
     legacy_test_tuned = algorithm == 'tt2' and 'W_selection_test' in params
     scores.update(metrics_schema_version=2, model_schema_version=params.get('schema_version', 1),
                   parameter_selection_set='test' if legacy_test_tuned else params.get('parameter_selection_set', 'train'),
                   evaluation_protocol='test_tuned_not_independent' if legacy_test_tuned else params.get('evaluation_protocol', 'train_selected_reused_test'),
                   historical_test_exposure=True if legacy_test_tuned else params.get('historical_test_exposure', True))
+    # Export the actual sampled timing and the locked mode policy beside metrics.
+    scores.update(endpoint_mode=params.get('endpoint_mode', 'enhanced'),
+                  boundary_convention=params.get('boundary_convention', diagnostic.get('geometry')),
+                  minimum_speech_ms=diagnostic.get('minimum_speech_ms'),
+                  minimum_silence_ms=diagnostic.get('minimum_silence_ms'),
+                  padding_stage=diagnostic.get('padding_stage'), final_padding_ms=diagnostic.get('final_padding_ms'),
+                  frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING,
+                  actual_frame_ms=record['features'].get('frame_ms'), actual_hop_ms=record['features'].get('hop_ms'),
+                  frame_samples=record['features'].get('frame_size'), hop_samples=record['features'].get('hop_size'))
     return dict(file=record["name"], algorithm=algorithm, mask=mask, metrics=scores,
                 final_regions=final_regions, ground_truth_regions=expected_regions,region_pairs=region_scores['region_pairs'],
                 predicted_boundaries=predicted_boundaries,
                 ground_truth_boundaries=expected_boundaries, diagnostic=diagnostic)
 
 
 def fit_training_model(algorithm, train_records, *, endpoint_mode='enhanced'):
     """Fit and lock parameters and FINAL W from supplied prepared TRAIN only.
 
     Input: prepared records with explicit split=train; array records need no
@@ -376,37 +386,41 @@ def data_statistics(records, split):
                          silence_power=powers[0], speech_plus_noise_power=powers[1],
                          snr_proxy_db=snr))
     return rows
 
 
 def summarize(metrics):
     """Tổng hợp metric từng thuật toán, phân biệt mean file và pooled RMSE.
 
     Input: metrics là rows endpoint/frame của từng file. Output: rows mean
     MAE/RMSE, pooled endpoint RMSE, F1 và số file có metric không xác định;
-    metric không xác định được loại khỏi mean và được đếm rõ.
+    primary mean chỉ xác định khi mọi file hợp lệ; mean subset được ghi riêng.
     """
     rows = []
-    for algorithm in dict.fromkeys(row["algorithm"] for row in metrics):
-        selected = [row for row in metrics if row["algorithm"] == algorithm]
-        valid = [row for row in selected if row["mae_ms"] is not None]
+    for algorithm, mode in dict.fromkeys((row["algorithm"], row.get("endpoint_mode", "enhanced")) for row in metrics):
+        selected = [row for row in metrics if row["algorithm"] == algorithm and row.get("endpoint_mode", "enhanced") == mode]
+        valid = [row for row in selected if row["mae_ms"] is not None
+                 and row.get("ground_truth_region_count") == row.get("predicted_region_count")]
         squared=sum(row.get('endpoint_squared_error_ms2',(row['rmse_ms']**2)*2) for row in valid)
         error_count=sum(row.get('endpoint_error_count',2) for row in valid)
         ordered=sorted(row['mae_ms'] for row in valid)
         median=(ordered[len(ordered)//2] if len(ordered)%2 else (ordered[len(ordered)//2-1]+ordered[len(ordered)//2])/2) if ordered else None
         count_correct=sum(row.get('ground_truth_region_count')==row.get('predicted_region_count') for row in selected)
-        rows.append(dict(algorithm=algorithm, metrics_schema_version=2,
+        rows.append(dict(algorithm=algorithm, endpoint_mode=mode, metrics_schema_version=2,
                          files=len(selected), evaluated_files=len(valid),
                          missing_speech_files=len(selected) - len(valid),
-                         mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,
-                         mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,
-                         pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,
+                         mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,
+                         valid_files_mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,
+                         mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,
+                         valid_files_mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,
+                         pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count and len(valid)==len(selected) else None,
+                         valid_files_pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,
                          median_file_mae_ms=median,min_file_mae_ms=min(ordered) if ordered else None,max_file_mae_ms=max(ordered) if ordered else None,
                          region_count_correct_files=count_correct,region_count_incorrect_files=len(selected)-count_correct,
                          top_mae_files='; '.join(f"{r['file']}:{r['mae_ms']:.2f}ms" for r in sorted(valid,key=lambda r:r['mae_ms'],reverse=True)[:3]),
                          parameter_selection_set=selected[0].get('parameter_selection_set','train'),
                          evaluation_protocol=selected[0].get('evaluation_protocol','train_selected_reused_test'),
                          historical_test_exposure=selected[0].get('historical_test_exposure', True),
                          mean_frame_f1=sum(row["frame_f1"] for row in selected) / len(selected)))
     return rows
 
 
@@ -488,147 +502,166 @@ def run_experiment(args):
     """
     file_argument = getattr(args, "file", None)
     input_path = resolve_input_file(file_argument) if file_argument else None
     audio_train = load_audio_folder(TRAIN_DIR)
     train_common = prepare_records(audio_train)
     selected = ["tt1", "tt2", "tt3"] if args.algorithm == "all" else [args.algorithm]
     if args.compare_context and "tt2-context" not in selected:
         selected.append("tt2-context")
 
     # Lock every model, including FINAL W and noise, before TEST WAV/LAB I/O.
-    models, sweeps = {}, {}
-    for key in selected:
-        models[key], sweeps[key] = fit_training_model(key, train_common)
+    modes = ('core', 'enhanced') if getattr(args, 'compare_endpoint_modes', False) else (getattr(args, 'endpoint_mode', 'enhanced'),)
+    locked_models, locked_sweeps = {}, {}
+    for mode in modes:
+        locked_models[mode], locked_sweeps[mode] = {}, {}
+        for key in selected:
+            locked_models[mode][key], locked_sweeps[mode][key] = fit_training_model(key, train_common, endpoint_mode=mode)
 
     evaluate_all=getattr(args,'evaluate_all',False)
     audio_test = [load_audio_file(input_path)] if input_path else audio_train+load_audio_folder(TEST_DIR) if evaluate_all else load_audio_folder(TEST_DIR)
     evaluated_names = [record["name"] for record in audio_test]
     display_order = [name for name in FILE_ORDER if name in evaluated_names]
     display_order.extend(name for name in evaluated_names if name not in display_order)
     evaluation_split = 'all_dataset' if evaluate_all else "train" if input_path and input_path.parent == TRAIN_DIR.resolve() else "external" if input_path and input_path.parent != TEST_DIR.resolve() else "test"
     test_common = prepare_records(audio_test)
     records_by_algorithm = {key: test_common for key in selected}
-    tables = OUTPUT_DIR / "tables"
-    figures_root = OUTPUT_DIR / "figures"
-    tables.mkdir(parents=True, exist_ok=True)
-    figures_root.mkdir(parents=True, exist_ok=True)
-    run_name = args.algorithm + ("_with_context" if args.compare_context else "")
-    if evaluate_all:run_name+='_all_dataset'
-    run_folder = tables / run_name
-    if input_path:
-        # Một lần thử file không ghi đè metric tổng hợp của batch bốn test.
-        run_folder = run_folder / "single" / input_path.stem
-        print(f"Chạy WAV: {input_path} | tập {evaluation_split}; ngưỡng/noise/W đã chọn trên 4 WAV TRAIN.")
-
-    # Export the already locked TRAIN models and calibration audit.
-    for key in selected:
-        model = models[key]
-        if key=='tt2':
-            selection, sweep_rows = model['W_selection_train'], sweeps[key]
-            audit=tables/'tt2_w_selection'
-            write_csv(audit/'sweep.csv',sweep_rows)
-            write_csv(audit/'summary.csv',selection['summaries'])
-            write_csv(audit/'best_by_file.csv',[dict(filename=name,**values) for name,values in selection['best_by_file'].items()])
-            write_json(audit/'selection.json',selection)
-            print(f"TT2 W={model['W']:g}: selected on four TRAIN LABs; TEST scoring reuses historically exposed data; "
-                  f"mean final MAE={selection['selected_summary']['mean_MAE_ms']} ms")
-        write_json(OUTPUT_DIR / "models" / f"{key}.json", model)
-
-    # Lưu dữ liệu thống kê giúp kiểm tra lại mean/std, normalization và LAB.
-    training_frames = []
-    for record in train_common:
-        for center, value, label in zip(record["features"]["centers"], record["features"]["ste_norm"], record["labels"]):
-            training_frames.append(dict(file=record["name"], center_s=center, ste_norm=value,
-                                        label="unlabeled" if label is None else "speech" if label else "silence"))
-    write_csv(tables / "training_frames.csv", training_frames)
-    statistics_path = run_folder / "dataset_statistics.csv" if input_path else tables / "dataset_statistics.csv"
-    write_csv(statistics_path, data_statistics(audio_train, "train") + data_statistics(audio_test, evaluation_split))
-    if "tt3" in models:
-        values_by_class = {0: [], 1: []}
+    all_mode_rows = []
+    for mode in modes:
+        models, sweeps = locked_models[mode], locked_sweeps[mode]
+        output_root = endpoint_mode_root(mode, OUTPUT_DIR)
+        tables = output_root / "tables"
+        figures_root = output_root / "figures"
+        tables.mkdir(parents=True, exist_ok=True)
+        figures_root.mkdir(parents=True, exist_ok=True)
+        run_name = args.algorithm + ("_with_context" if args.compare_context else "")
+        if evaluate_all:run_name+='_all_dataset'
+        run_folder = tables / run_name
+        if input_path:
+            # Một lần thử file không ghi đè metric tổng hợp của batch bốn test.
+            run_folder = run_folder / "single" / input_path.stem
+            print(f"Chạy WAV: {input_path} | tập {evaluation_split}; ngưỡng/noise/W đã chọn trên 4 WAV TRAIN.")
+
+        # Export the already locked TRAIN models and calibration audit.
+        for key in selected:
+            model = models[key]
+            if key=='tt2':
+                selection, sweep_rows = model['W_selection_train'], sweeps[key]
+                audit=tables/'tt2_w_selection'
+                write_csv(audit/'sweep.csv',sweep_rows)
+                write_csv(audit/'summary.csv',selection['summaries'])
+                write_csv(audit/'best_by_file.csv',[dict(filename=name,**values) for name,values in selection['best_by_file'].items()])
+                write_json(audit/'selection.json',selection)
+                print(f"TT2 W={model['W']:g}: selected on four TRAIN LABs; TEST scoring reuses historically exposed data; "
+                      f"mean final MAE={selection['selected_summary']['mean_MAE_ms']} ms")
+            write_json(output_root / "models" / f"{key}.json", model)
+
+        # Lưu dữ liệu thống kê giúp kiểm tra lại mean/std, normalization và LAB.
+        training_frames = []
         for record in train_common:
-            for value, label in zip(record["features"]["ste_norm"], record["labels"]):
-                if label is not None:
-                    values_by_class[label].append(value)
-        training_figures = figures_root / "training"
-        training_figures.mkdir(exist_ok=True)
-        plot_gaussian_training(values_by_class, models["tt3"], training_figures / "gaussian_distributions.png")
-
-    metric_rows, threshold_rows, results_by_file = [], [], {}
-    demo_figures, noise_rows = [], []
-    for key in selected:
-        folder = figures_root / key
-        folder.mkdir(exist_ok=True)
-        for record in records_by_algorithm[key]:
-            result = predict_and_score(key, record, models[key])
-            metric_rows.append(dict(file=record["name"],split=record.get('split',evaluation_split),algorithm=key, **result["metrics"]))
-            threshold_rows.append(dict(file=record["name"], algorithm=key,
-                                       **{name: value for name, value in result["diagnostic"].items() if not isinstance(value, (dict, list))}))
-            results_by_file.setdefault(record["name"], {})[key] = (record, result)
-            write_json(OUTPUT_DIR / "diagnostics" / key / f"{record['name']}.json", result["diagnostic"])
-            segments = mask_segments(result["mask"], record["features"]["starts"], record["duration"], frame_ends=record["features"]["ends"])
-            write_csv(OUTPUT_DIR / "predictions" / key / f"{record['name']}.csv",
-                      [dict(start_s=start, end_s=end, label="speech" if state else "sil") for start, end, state in segments])
-            figure = make_file_figure(record["name"], [(record, result)], folder / f"{record['name']}.png")
-            # Batch giữ 4 figure, --file chỉ giữ 1; các bản xuất phụ đóng ngay.
-            if args.algorithm != "all" and key == args.algorithm and not args.no_show:
-                demo_figures.append(figure)
-            else:
-                plt.close(figure)
-
-            if args.snr_study:
-                noise_rows.append(dict(file=record["name"], algorithm=key, added_snr_db="clean", **result["metrics"]))
-                for level in NOISE_LEVELS_DB:
-                    file_seed = FILE_ORDER.index(record["name"]) if record["name"] in FILE_ORDER else zlib.crc32(record["name"].encode("utf-8"))
-                    base_noisy = noisy_copy(record, level, RANDOM_SEED + file_seed * 100 + level)
-                    noisy = prepare_records([base_noisy], key == "tt2")[0]
-                    noisy_result = predict_and_score(key, noisy, models[key])
-                    noise_rows.append(dict(file=record["name"], algorithm=key, added_snr_db=level, **noisy_result["metrics"]))
-
-    # all có một figure so sánh ba hàng/file; subset chỉ vẽ các WAV đã chọn.
-    if args.algorithm == "all":
-        comparison_folder = figures_root / "comparison"
-        comparison_folder.mkdir(exist_ok=True)
-        for name in display_order:
-            figure = make_file_figure(name, [results_by_file[name][key] for key in ("tt1", "tt2", "tt3")], comparison_folder / f"{name}.png")
-            if args.no_show:
-                plt.close(figure)
-            else:
-                demo_figures.append(figure)
-    else:
-        demo_figures.sort(key=lambda figure: display_order.index(figure._suptitle.get_text()))
-
-    # Lưu từng run độc lập; demo một thuật toán không ghi đè bảng tổng hợp all.
-    write_csv(run_folder / "test_metrics.csv", metric_rows)
-    write_csv(run_folder / "summary.csv", summarize(metric_rows))
-    write_csv(run_folder / "test_thresholds.csv", threshold_rows)
-    if args.snr_study:
-        write_csv(run_folder / "snr_study.csv", noise_rows)
-    if args.compare_context:
-        write_csv(tables / "context_benchmark_check.csv", context_benchmark(test_common))
-    write_json(run_folder / "run_config.json", dict(algorithm=args.algorithm, selected=selected,
-               input_file=str(input_path) if input_path else None, evaluated_files=evaluated_names,
-               evaluation_split=evaluation_split,
-               schema_version=2, metrics_schema_version=2,
-               parameter_selection_set='train', evaluation_protocol='train_selected_reused_test',
-               historical_test_exposure=True, training_files=[record['name'] for record in train_common],
-               parameter_selection={key:model['evaluation_protocol'] for key,model in models.items()},
-               frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING,
-               minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000,minimum_speech_ms=MIN_SPEECH_SECONDS*1000,
-               snr_study=args.snr_study, normalization="per_recording_max", lab_center_convention="sample_exact_half_open",
-               boundary_convention="final confirmed regions; union of active frame supports", primary_metric="ordered final-region START/END MAE; unmatched regions explicitly undefined",
-               noise_seed=RANDOM_SEED))
-    print(f"Đã xuất kết quả: {OUTPUT_DIR}")
-    for row in summarize(metric_rows):
-        mae = f"{row['mean_file_mae_ms']:.2f}" if row["mean_file_mae_ms"] is not None else "N/A"
-        rmse = f"{row['mean_file_rmse_ms']:.2f}" if row["mean_file_rmse_ms"] is not None else "N/A"
-        print(f"{row['algorithm']}: mean endpoint MAE={mae} ms; "
-              f"mean per-file RMSE={rmse} ms; frame F1={row['mean_frame_f1']:.3f}")
-        print(f"  median={row['median_file_mae_ms']}; min={row['min_file_mae_ms']}; max={row['max_file_mae_ms']} ms; "
-              f"region counts correct={row['region_count_correct_files']}/{row['files']}; wrong={row['region_count_incorrect_files']}")
-        print(f"  highest MAE: {row['top_mae_files']}")
-    if not args.no_show:
-        positions = show_figures(demo_figures, args.show_seconds)
-        write_json(run_folder / "demo_layout.json", positions)
-        if len(demo_figures) == 4:
-            print(f"Demo đã bố trí {len(positions)} cửa sổ tại bốn góc.")
+            for center, value, label in zip(record["features"]["centers"], record["features"]["ste_norm"], record["labels"]):
+                training_frames.append(dict(file=record["name"], center_s=center, ste_norm=value,
+                                            label="unlabeled" if label is None else "speech" if label else "silence"))
+        write_csv(tables / "training_frames.csv", training_frames)
+        statistics_path = run_folder / "dataset_statistics.csv" if input_path else tables / "dataset_statistics.csv"
+        write_csv(statistics_path, data_statistics(audio_train, "train") + data_statistics(audio_test, evaluation_split))
+        if "tt3" in models:
+            values_by_class = {0: [], 1: []}
+            for record in train_common:
+                for value, label in zip(record["features"]["ste_norm"], record["labels"]):
+                    if label is not None:
+                        values_by_class[label].append(value)
+            training_figures = figures_root / "training"
+            training_figures.mkdir(exist_ok=True)
+            plot_gaussian_training(values_by_class, models["tt3"], training_figures / "gaussian_distributions.png")
+
+        metric_rows, threshold_rows, results_by_file = [], [], {}
+        demo_figures, noise_rows = [], []
+        for key in selected:
+            folder = figures_root / key
+            folder.mkdir(exist_ok=True)
+            for record in records_by_algorithm[key]:
+                result = predict_and_score(key, record, models[key])
+                metric_rows.append(dict(file=record["name"],split=record.get('split',evaluation_split),algorithm=key, **result["metrics"]))
+                threshold_rows.append(dict(file=record["name"], algorithm=key,
+                                           **{name: value for name, value in result["diagnostic"].items() if not isinstance(value, (dict, list))}))
+                results_by_file.setdefault(record["name"], {})[key] = (record, result)
+                write_json(output_root / "diagnostics" / key / f"{record['name']}.json", result["diagnostic"])
+                segments = mask_segments(result["mask"], record["features"]["starts"], record["duration"], frame_ends=record["features"]["ends"])
+                write_csv(output_root / "predictions" / key / f"{record['name']}.csv",
+                          [dict(start_s=start, end_s=end, label="speech" if state else "sil") for start, end, state in segments])
+                figure = make_file_figure(record["name"], [(record, result)], folder / f"{record['name']}.png")
+                # Batch giữ 4 figure, --file chỉ giữ 1; các bản xuất phụ đóng ngay.
+                if args.algorithm != "all" and key == args.algorithm and not args.no_show:
+                    demo_figures.append(figure)
+                else:
+                    plt.close(figure)
+
+                if args.snr_study:
+                    noise_rows.append(dict(file=record["name"], algorithm=key, added_snr_db="clean", **result["metrics"]))
+                    for level in NOISE_LEVELS_DB:
+                        file_seed = FILE_ORDER.index(record["name"]) if record["name"] in FILE_ORDER else zlib.crc32(record["name"].encode("utf-8"))
+                        base_noisy = noisy_copy(record, level, RANDOM_SEED + file_seed * 100 + level)
+                        noisy = prepare_records([base_noisy], key == "tt2")[0]
+                        noisy_result = predict_and_score(key, noisy, models[key])
+                        noise_rows.append(dict(file=record["name"], algorithm=key, added_snr_db=level, **noisy_result["metrics"]))
+
+        # all có một figure so sánh ba hàng/file; subset chỉ vẽ các WAV đã chọn.
+        if args.algorithm == "all":
+            comparison_folder = figures_root / "comparison"
+            comparison_folder.mkdir(exist_ok=True)
+            for name in display_order:
+                figure = make_file_figure(name, [results_by_file[name][key] for key in ("tt1", "tt2", "tt3")], comparison_folder / f"{name}.png")
+                if args.no_show:
+                    plt.close(figure)
+                else:
+                    demo_figures.append(figure)
         else:
-            print(f"Đã hiển thị {len(demo_figures)} figure cho WAV đã chọn.")
+            demo_figures.sort(key=lambda figure: display_order.index(figure._suptitle.get_text()))
+
+        # Lưu từng run độc lập; demo một thuật toán không ghi đè bảng tổng hợp all.
+        all_mode_rows.extend(metric_rows)
+        write_csv(run_folder / "test_metrics.csv", metric_rows)
+        if evaluate_all:
+            write_csv(tables / "all" / "test_metrics.csv", [row for row in metric_rows if row["split"]=="test"])
+            write_csv(tables / "all" / "summary.csv", summarize([row for row in metric_rows if row["split"]=="test"]))
+        write_csv(run_folder / "summary.csv", summarize(metric_rows))
+        write_csv(run_folder / "test_thresholds.csv", threshold_rows)
+        if args.snr_study:
+            write_csv(run_folder / "snr_study.csv", noise_rows)
+        if args.compare_context:
+            write_csv(tables / "context_benchmark_check.csv", context_benchmark(test_common))
+        write_json(run_folder / "run_config.json", dict(algorithm=args.algorithm, endpoint_mode=mode, selected=selected,
+                   input_file=str(input_path) if input_path else None, evaluated_files=evaluated_names,
+                   evaluation_split=evaluation_split,
+                   schema_version=2, metrics_schema_version=2,
+                   parameter_selection_set='train', evaluation_protocol='train_selected_reused_test',
+                   historical_test_exposure=True, training_files=[record['name'] for record in train_common],
+                   parameter_selection={key:model['evaluation_protocol'] for key,model in models.items()},
+                   frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING,
+                   minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000,minimum_speech_ms=0. if mode=="core" else MIN_SPEECH_SECONDS*1000,
+                   snr_study=args.snr_study, normalization="per_recording_max", lab_center_convention="sample_exact_half_open",
+                   boundary_convention="union of active frame supports", primary_metric="ordered final-region START/END MAE; unmatched regions explicitly undefined",
+                   noise_seed=RANDOM_SEED))
+        print(f"Đã xuất kết quả: {output_root}")
+        for row in summarize(metric_rows):
+            mae = f"{row['mean_file_mae_ms']:.2f}" if row["mean_file_mae_ms"] is not None else "N/A"
+            rmse = f"{row['mean_file_rmse_ms']:.2f}" if row["mean_file_rmse_ms"] is not None else "N/A"
+            print(f"{row['algorithm']} [{mode}]: mean FINAL-region endpoint MAE={mae} ms; "
+                  f"mean per-file RMSE={rmse} ms; frame F1={row['mean_frame_f1']:.3f}")
+            print(f"  median={row['median_file_mae_ms']}; min={row['min_file_mae_ms']}; max={row['max_file_mae_ms']} ms; "
+                  f"region counts correct={row['region_count_correct_files']}/{row['files']}; wrong={row['region_count_incorrect_files']}")
+            print(f"  highest MAE: {row['top_mae_files']}")
+        if not args.no_show:
+            positions = show_figures(demo_figures, args.show_seconds)
+            write_json(run_folder / "demo_layout.json", positions)
+            if len(demo_figures) == 4:
+                print(f"Demo đã bố trí {len(positions)} cửa sổ tại bốn góc.")
+            else:
+                print(f"Đã hiển thị {len(demo_figures)} figure cho WAV đã chọn.")
+
+    if len(modes) == 2:
+        comparison = endpoint_mode_root('comparison', OUTPUT_DIR) / 'tables'
+        write_csv(comparison / 'all_metrics.csv', all_mode_rows)
+        write_csv(comparison / 'all_summary.csv', summarize(all_mode_rows))
+        test_rows = [row for row in all_mode_rows if row['split']=='test']
+        write_csv(comparison / 'test_metrics.csv', test_rows)
+        write_csv(comparison / 'test_summary.csv', summarize(test_rows))
diff --git a/app/plotting.py b/app/plotting.py
index 5caa298..c337327 100644
--- a/app/plotting.py
+++ b/app/plotting.py
@@ -17,49 +17,60 @@ def _plot_axis(axis, record, result):
     # Tiêu đề dùng MAE các cặp START/END vùng đã ghép trong pipeline.
     # Nhãn legend được dựng riêng để vẫn đủ khi không phát hiện speech.
     # Thưa mẫu chỉ để hiển thị nhanh; phép tính vẫn dùng toàn bộ samples.
     samples, fs = record["samples"], record["sample_rate"]
     stride = max(1, len(samples) // 12000)
     axis.plot([i / fs for i in range(0, len(samples), stride)], samples[::stride],
               color="#555555", linewidth=.55, alpha=.4)
     energy_axis = axis.twinx()
     energy_axis.plot(record["features"]["centers"], record["features"]["ste_norm"],
                      color="#dd8b12", linewidth=1.6, alpha=.95)
-    # These are the exact thresholds used by detection, not plot-only lines.
-    low=result['diagnostic']['low_ste_threshold']
-    high=result['diagnostic']['high_ste_threshold']
-    energy_axis.axhline(high,color='#8E44AD',linestyle='-.',linewidth=1.2)
-    energy_axis.axhline(low,color='#148F77',linestyle=':',linewidth=1.2)
+    diagnostic = result['diagnostic']
+    mode = diagnostic.get('endpoint_mode', 'enhanced')
+    threshold_handles = []
+    if mode == 'core':
+        native = diagnostic['native_threshold']
+        if diagnostic['native_threshold_units'] == 'sum of squared samples':
+            peak = max(record['features']['energy'], default=0.)
+            native = native / peak if peak else 0.
+        energy_axis.axhline(native, color='#8E44AD', linestyle='-.', linewidth=1.2)
+        threshold_handles.append(Line2D([], [], color='#8E44AD', linestyle='-.', label=f'Native T ({diagnostic.get("native_threshold_units")}): {diagnostic["native_threshold"]:.5g}'))
+    else:
+        low, high = diagnostic['low_ste_threshold'], diagnostic['high_ste_threshold']
+        energy_axis.axhline(high,color='#8E44AD',linestyle='-.',linewidth=1.2)
+        energy_axis.axhline(low,color='#148F77',linestyle=':',linewidth=1.2)
+        threshold_handles.extend([Line2D([], [], color='#8E44AD',linestyle='-.',label=f'High STE: {high:.5g}'),
+                                  Line2D([], [], color='#148F77',linestyle=':',label=f'Low STE: {low:.5g}')])
     energy_axis.set_ylim(-.05, 1.1)
     energy_axis.set_ylabel("Normalized STE", color="#a2670a", fontsize=9)
     axis.set_ylabel("Amplitude", fontsize=9)
     axis.set_xlim(0, record["duration"])
     axis.grid(alpha=.18)
 
     # Candidate/debug points không được vẽ hoặc đưa vào metric chính.
     for boundary in result["ground_truth_boundaries"]:
         axis.axvline(boundary, color="#d62728", linewidth=1.45, alpha=.85)
     for boundary in result["predicted_boundaries"]:
         axis.axvline(boundary, color="#1766bd", linestyle="--", linewidth=1.35)
     mae = result["metrics"]["mae_ms"]
-    suffix = "Outer boundary MAE: N/A" if mae is None else f"Outer boundary MAE: {mae:.2f} ms"
-    axis.set_title(f"{record['name']} | {suffix} | {len(result['final_regions'])} speech region(s)", fontsize=10)
+    suffix = "FINAL-region endpoint MAE: N/A" if mae is None else f"FINAL-region endpoint MAE: {mae:.2f} ms"
+    axis.set_title(f"{record['name']} | {mode} | {suffix} | {len(result['final_regions'])} speech region(s)", fontsize=10)
     # Legend đủ nhãn kể cả không tìm được speech hoặc biên nội bộ.
     axis.legend(handles=[Line2D([], [], color="#555555", label="Waveform"),
                          Line2D([], [], color="#dd8b12", label="Normalized STE"),
-                         Line2D([], [], color='#8E44AD',linestyle='-.',label=f'High STE: {high:.5g}'),
-                         Line2D([], [], color='#148F77',linestyle=':',label=f'Low STE: {low:.5g}'),
+                         *threshold_handles,
                          Line2D([], [], color="#d62728", label="Ground truth"),
                          Line2D([], [], color="#1766bd", linestyle="--", label="Prediction")],
                 fontsize=8, ncol=3, loc="upper right")
 
 
+
 def make_file_figure(name, record_results, save_path):
     """Tạo và lưu một figure cho WAV với một hàng mỗi thuật toán.
 
     Đầu vào: name là tên WAV; record_results chứa cặp (record, result); save_path là đường dẫn PNG.
     Đầu ra: Figure Matplotlib để bố trí/hiển thị; ảnh PNG được ghi vào save_path.
     """
     # Mỗi cặp record/result được đặt lên một hàng độc lập.
     # Trục thời gian dùng chung để dễ so sánh biên giữa các thuật toán.
     # Số hàng quyết định chiều cao ảnh, tránh dồn ba kết quả vào một trục.
     # Lưu ảnh trước khi đưa Figure cho phần bố trí cửa sổ.
diff --git a/app/weight_selection.py b/app/weight_selection.py
index edb983d..39d7a6f 100644
--- a/app/weight_selection.py
+++ b/app/weight_selection.py
@@ -87,20 +87,22 @@ def sweep_final_weights(records,model,predictor,candidates=W_CANDIDATES,
         minimum_speech_ms=model.get('minimum_speech_ms',0. if mode=='core' else 100.),
         minimum_silence_ms=model.get('minimum_silence_ms',model.get('minimum_internal_silence_ms',200.)),
         padding_stage=model.get('padding_stage','excluded from core FINAL' if mode=='core' else 'candidate diagnostics only'))
     rows=[]
     for w in candidates:
         params=dict(model,W=float(w))
         for record in records:
             result=predictor('tt2',record,params);metrics=result['metrics'];diag=result['diagnostic']
             if diag.get('endpoint_mode','enhanced') != mode:
                 raise ValueError('Predictor endpoint_mode disagrees with calibration model')
+            if diag.get('geometry', policy['boundary_convention']) != policy['boundary_convention']:
+                raise ValueError('Predictor geometry disagrees with calibration boundary_convention')
             for key in ('minimum_speech_ms','minimum_silence_ms','padding_stage'):
                 if key in diag and diag[key] != policy[key]:
                     raise ValueError(f'Predictor {key} disagrees with calibration model')
             rows.append(dict(**policy,filename=record['name'],W=float(w),
                 ground_truth_region_count=metrics['ground_truth_region_count'],predicted_region_count=metrics['predicted_region_count'],
                 final_region_mae_ms=metrics['mae_ms'],status=metrics['status'],
                 start_error_ms=metrics['start_error_ms'],end_error_ms=metrics['end_error_ms'],
                 energy_threshold=diag['energy_threshold'],
                 low_ste_threshold=diag['low_ste_threshold'],high_ste_threshold=diag['high_ste_threshold'],
                 raw_speech_frames=diag['raw_speech_frames'],candidate_region_count=len(diag['candidate_regions']),
diff --git a/notebooks/README.md b/notebooks/README.md
index 624ef14..819f6f6 100644
--- a/notebooks/README.md
+++ b/notebooks/README.md
@@ -1,29 +1,45 @@
 # Mã nguồn nộp bài — Jupyter Notebook
 
+## Hai chế độ endpoint (07/10/2026)
+
+Mặc định `enhanced`: ngưỡng native tạo seed; noise TRAIN và HIGH/LOW xác nhận, giữ speech; nối gap support dưới 200 ms và lọc span dưới 100 ms. `core` giữ quyết định native và chỉ nối gap support dưới 200 ms, không lọc duration hoặc padding FINAL; LOW/HIGH là null. Gap ước lượng đúng 200 ms được giữ riêng. TT1 dùng STE ≥ T, TT2 dùng Energy > T, TT3 giữ hướng high/low của Gaussian native. Đây là hai chế độ endpoint của cùng ba thuật toán; enhanced là phần bổ sung của dự án.
+
+```powershell
+python main_tt1.py --endpoint-mode core
+python main.py --evaluate-all --compare-endpoint-modes
+```
+
+Mỗi mode fit và khóa model độc lập trên bốn TRAIN trước đọc TEST. Kết quả mới ở `outputs/endpoint_modes/core/` và `outputs/endpoint_modes/enhanced/`; bảng so sánh ở `outputs/endpoint_modes/comparison/tables/`. Model schema 3 giữ policy/digest, metric schema 2 tiếp tục `mae_ms`/`rmse_ms`. Thiếu/thừa vùng làm primary mean toàn bộ file undefined; `valid_files_*` là thống kê subset riêng. TEST có `historical_test_exposure=true`, không phải holdout độc lập. Không chọn mode tốt hơn riêng cho từng WAV.
+
+Notebook dùng `MODE="enhanced"` mặc định cho bốn TEST figure và một illustration; luôn fit/khóa `MODELS` cả hai mode trước TEST, xuất 16 dòng tám WAV/mode và bảng bốn TEST/mode. TT2 có 200 TRAIN sweep rows mỗi mode. Core plot native T; Energy TT2 được chuẩn hóa chỉ ở bước hiển thị. Source digest và model lock digests độc lập kiểm tra nguồn/outputs và model; Restart Kernel → Run All → Save vẫn chạy độc lập.
+
+PPTX/PDF và ZIP Python cũ giữ nguyên previous version. Các bảng, noise và ví dụ HIGH/LOW bên dưới mô tả enhanced; không phải công thức quyết định FINAL của core. Xem [báo cáo hai mode](../reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md).
+
+
 Theo yêu cầu bổ sung của thầy, mỗi sinh viên có một `.ipynb` riêng. Ba notebook chứa toàn bộ hàm tính toán cần thiết, chạy độc lập với các module `.py` của dự án:
 
 | Thành viên phụ trách | Notebook |
 |---|---|
 | TT1 — Binary Search | [THUAT_TOAN_1.ipynb](THUAT_TOAN_1.ipynb) |
 | TT2 — Histogram chỉ Energy | [THUAT_TOAN_2.ipynb](THUAT_TOAN_2.ipynb) |
 | TT3 — Thống kê Gaussian | [THUAT_TOAN_3.ipynb](THUAT_TOAN_3.ipynb) |
 
 ## Xem kết quả đã lưu
 
 Mở notebook bằng JupyterLab, VS Code hoặc trình xem notebook. Số liệu và ảnh kết quả được lưu trong chính notebook; không cần WAV/LAB để **xem** chúng. Giữ các outputs này khi nộp; không chọn “Clear All Outputs”.
 
 Notebook có các cell lần lượt: cấu hình → đọc WAV/LAB → chia khung/tính năng lượng thủ công → thuật toán riêng → High/Low và vùng nói cuối → học trên train → đánh giá → bảng và đồ thị. Bảng 4 test và bảng 8 file train + test được ghi rõ riêng.
 
-TT2 chỉ Energy, không F0/Centroid. Notebook fit mọi model/noise/W từ TRAIN trước TEST, chọn W1–50 trên TRAIN FINAL với `tie_preference_W=20`. TRAIN hiện tại hòa cả 50 W, chọn W20; candidate frame-F1 đề xuất W1 riêng (0.898698). Model schema 2 ghi `train_selected_reused_test`, `historical_test_exposure=true`; TEST được dùng lại sau lịch sử phát triển, không khẳng định độc lập. Model digest được khóa trước TEST và kiểm tra lại sau chấm. `--file` demo dùng model đã khóa. Metric chính `mae_ms`/`rmse_ms`, calibration `final_region_mae_ms`, diagnostic `tolerance_boundary_*` và `matched_boundary_mae_ms`.
+TT2 chỉ Energy, không F0/Centroid. Notebook fit mọi model/noise/W từ TRAIN trước TEST, chọn W1–50 trên TRAIN FINAL với `tie_preference_W=20`. Enhanced TRAIN hiện tại hòa cả 50 W với primary mean hợp lệ, chọn W20; core có count errors nên primary mean TRAIN undefined, valid-only được ghi riêng; candidate frame-F1 đề xuất W1 riêng (0.898698). Model schema 3 với metric schema 2 ghi `train_selected_reused_test`, `historical_test_exposure=true`; TEST được dùng lại sau lịch sử phát triển, không khẳng định độc lập. Model digest được khóa trước TEST và kiểm tra lại sau chấm. `--file` demo dùng model đã khóa. Metric chính `mae_ms`/`rmse_ms`, calibration `final_region_mae_ms`, diagnostic `tolerance_boundary_*` và `matched_boundary_mae_ms`.
 
-TT3 giải equal-density trong tọa độ dịch tâm/chia scale, với sigma floor `1e-9` và kiểm tra log-density. Gaussian thô `fit`/`predict` hỗ trợ hướng `low`; FINAL energy HIGH/LOW chỉ hỗ trợ `speech_direction='high'`, từ chối rõ ràng `low` hoặc hướng không hợp lệ lúc fit model FINAL và detect. Quy tắc 200 ms đo khoảng trống ước lượng giữa support khung hoạt động; 100 ms là heuristic lọc span support, không bảo đảm khoảng lặng vật lý hay độ dài voiced audio vì frame chồng lấn.
+TT3 giải equal-density trong tọa độ dịch tâm/chia scale, với sigma floor `1e-9` và kiểm tra log-density. Gaussian thô `fit`/`predict` hỗ trợ hướng `low`; Enhanced FINAL energy HIGH/LOW chỉ hỗ trợ `speech_direction='high'`, từ chối rõ ràng `low` hoặc hướng không hợp lệ lúc fit model FINAL và detect. Quy tắc 200 ms đo khoảng trống ước lượng giữa support khung hoạt động; 100 ms là heuristic lọc span support, không bảo đảm khoảng lặng vật lý hay độ dài voiced audio vì frame chồng lấn.
 
 ## Chạy lại trên máy này
 
 Từ thư mục gốc dự án:
 
 ```powershell
 .\.venv\Scripts\python.exe -m jupyterlab notebooks
 ```
 
 Chọn notebook và dùng **Restart Kernel and Run All Cells**, sau đó **Save** để xem và lưu kết quả mới. Notebook chạy độc lập, không cần module dự án hoặc script builder/runner. Người bảo trì dự án dùng runner bên dưới để làm mới evidence và gói CODE ZIP đã audit; yêu cầu đó dành cho audit/đóng gói của dự án. Môi trường `.venv` đã được chuẩn bị riêng cho dự án.
diff --git a/outputs/README.md b/outputs/README.md
index 943bdac..be92cd5 100644
--- a/outputs/README.md
+++ b/outputs/README.md
@@ -1,19 +1,35 @@
 # Kết quả hiện hành — nghiệm thu 07/10/2026
+
+## Hai chế độ endpoint (07/10/2026)
+
+Mặc định `enhanced`: ngưỡng native tạo seed; noise TRAIN và HIGH/LOW xác nhận, giữ speech; nối gap support dưới 200 ms và lọc span dưới 100 ms. `core` giữ quyết định native và chỉ nối gap support dưới 200 ms, không lọc duration hoặc padding FINAL; LOW/HIGH là null. Gap ước lượng đúng 200 ms được giữ riêng. TT1 dùng STE ≥ T, TT2 dùng Energy > T, TT3 giữ hướng high/low của Gaussian native. Đây là hai chế độ endpoint của cùng ba thuật toán; enhanced là phần bổ sung của dự án.
+
+```powershell
+python main_tt1.py --endpoint-mode core
+python main.py --evaluate-all --compare-endpoint-modes
+```
+
+Mỗi mode fit và khóa model độc lập trên bốn TRAIN trước đọc TEST. Kết quả mới ở `outputs/endpoint_modes/core/` và `outputs/endpoint_modes/enhanced/`; bảng so sánh ở `outputs/endpoint_modes/comparison/tables/`. Model schema 3 giữ policy/digest, metric schema 2 tiếp tục `mae_ms`/`rmse_ms`. Thiếu/thừa vùng làm primary mean toàn bộ file undefined; `valid_files_*` là thống kê subset riêng. TEST có `historical_test_exposure=true`, không phải holdout độc lập. Không chọn mode tốt hơn riêng cho từng WAV.
+
+Notebook dùng `MODE="enhanced"` mặc định cho bốn TEST figure và một illustration; luôn fit/khóa `MODELS` cả hai mode trước TEST, xuất 16 dòng tám WAV/mode và bảng bốn TEST/mode. TT2 có 200 TRAIN sweep rows mỗi mode. Core plot native T; Energy TT2 được chuẩn hóa chỉ ở bước hiển thị. Source digest và model lock digests độc lập kiểm tra nguồn/outputs và model; Restart Kernel → Run All → Save vẫn chạy độc lập.
+
+PPTX/PDF và ZIP Python cũ giữ nguyên previous version. Các bảng, noise và ví dụ HIGH/LOW bên dưới mô tả enhanced; không phải công thức quyết định FINAL của core. Xem [báo cáo hai mode](../reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md).
+
 
 - `models/`: ba model enhanced TT1/TT2/TT3 hiện tại, fit TRAIN và khóa trước TEST; TT2 Energy-only, W = 20. Chưa có model core riêng.
 - `tables/all/`: 4 test × 3 thuật toán.
 - `tables/all_all_dataset/`: 8 WAV × 3 thuật toán, gồm cả train nên không phải 8 test độc lập.
 - `tables/tt1/`, `tt2/`, `tt3/`: batch riêng.
 - `tables/tt2_w_selection/`: W nguyên 1–50 trên đủ 4 TRAIN (`phone_F1`, `phone_M1`, `studio_F1`, `studio_M1`), 200 trường hợp; chấm FINAL, chọn W20 bằng tie preference 20 khi hòa.
 - `tables/training_frames.csv`, `dataset_statistics.csv`: dữ liệu thống kê.
 - `figures/`: 4 test, hình so sánh và phân phối Gaussian train.
 - `diagnostics/`: candidate/final regions, ngưỡng và fallback của từng WAV.
 - `predictions/`: các đoạn speech/sil được xuất cho từng WAV.
 
 Metric schema 2 dùng MAE/RMSE chính `mae_ms` / `rmse_ms`. Thiếu/thừa vùng làm metric chính không xác định. `matched_boundary_mae_ms` chấm vùng ghép theo thứ tự; `tolerance_boundary_*` là diagnostic sự kiện trong dung sai 100 ms, không thay metric chính. Đọc [báo cáo kết quả](../reports/KET_QUA_HIEN_TAI.md) để phân biệt TRAIN/TEST, counts và bất thường.
 
-Model schema 2 ghi `parameter_selection_set=train`, `evaluation_protocol=train_selected_reused_test`, `historical_test_exposure=true`. TEST đã được xem trong phát triển và được dùng lại; không phải holdout mới độc lập. Model legacy hiệu chỉnh bằng TEST vẫn phải giữ provenance cũ.
+Model schema 3 với metric schema 2 ghi `parameter_selection_set=train`, `evaluation_protocol=train_selected_reused_test`, `historical_test_exposure=true`. TEST đã được xem trong phát triển và được dùng lại; không phải holdout mới độc lập. Model legacy hiệu chỉnh bằng TEST vẫn phải giữ provenance cũ.
 
 Nghiệm thu 07/10: **133/133 tests**, 24/24 trường hợp giữ nguyên và 0 regression; mean bốn TEST TT1/TT2/TT3 vẫn **20.00/13.75/12.50 ms**. Xem [bằng chứng nghiệm thu](tables/hotfix_oct06/verification.json). [Baseline khóa trước sửa tài liệu](tables/endpoint_modes_oct07/baseline.json) giữ ba model, 24 FINAL/masks/metrics/T/W/LOW/HIGH, đặc trưng, hashes và môi trường. Đợt khóa baseline không tái tạo bảng/model hoặc tuyên bố cải thiện số liệu; năm cờ END muộn vẫn còn.
 
 Chạy lại main cập nhật kết quả tương ứng. Các lượt `--file`, `--snr-study` hoặc `--compare-context` sinh thêm thư mục/bảng mới; bản dọn hiện tại chỉ giữ các batch chính.
diff --git a/reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md b/reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md
new file mode 100644
index 0000000..e186366
--- /dev/null
+++ b/reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md
@@ -0,0 +1,82 @@
+# Kết quả endpoint core và enhanced — 07/10/2026
+
+Cùng ba thuật toán và hai policy được fit TRAIN độc lập trước TEST. Không chọn mode theo từng bản ghi. TEST từng được xem trong lịch sử; protocol `train_selected_reused_test`, `historical_test_exposure=true`. Gaussian vẫn là xấp xỉ theo đề. TT1 cân bằng diện tích nhầm lẫn, TT3 giải equal-density; sigma đơn lẻ không suy ra T3 > T1.
+
+## Bốn TEST (12 kết quả mỗi mode)
+
+| Algorithm | Mode | Mean FINAL-region endpoint MAE ms | Valid-only mean ms | Counts correct | Max defined MAE ms |
+|---|---|---|---|---|---|
+| tt1 | core | undefined | 7.500000 | 3/4 | 12.500000 |
+| tt2 | core | undefined | 9.170446 | 3/4 | 17.505669 |
+| tt3 | core | 12.500000 | 12.500000 | 4/4 | 27.500000 |
+| tt1 | enhanced | 20.000000 | 20.000000 | 4/4 | 57.500000 |
+| tt2 | enhanced | 13.750000 | 13.750000 | 4/4 | 32.500000 |
+| tt3 | enhanced | 12.500000 | 12.500000 | 4/4 | 27.500000 |
+
+## Tám WAV TRAIN + TEST (24 kết quả mỗi mode)
+
+| Algorithm | Mode | Mean FINAL-region endpoint MAE ms | Valid-only mean ms | Counts correct | Max defined MAE ms |
+|---|---|---|---|---|---|
+| tt1 | core | undefined | 83.212666 | 7/8 | 297.500000 |
+| tt2 | core | undefined | 10.837113 | 6/8 | 27.505669 |
+| tt3 | core | 12.498583 | 12.498583 | 8/8 | 27.500000 |
+| tt1 | enhanced | 31.873583 | 31.873583 | 8/8 | 77.500000 |
+| tt2 | enhanced | 13.748583 | 13.748583 | 8/8 | 32.500000 |
+| tt3 | enhanced | 12.498583 | 12.498583 | 8/8 | 27.500000 |
+
+Primary MAE/RMSE cần đúng số vùng trên mọi file. Mean subset chỉ nằm ở valid-only; lỗi lớn vẫn được giữ. Counts sai của core TT1/TT2 không được thay bằng metric các vùng đã ghép. Core TT3 và enhanced TT3 cho cùng endpoints trên dataset này; đây không phải bảo đảm cho dữ liệu khác.
+
+## Từng WAV và từng mode
+
+| Split | WAV | Algorithm | Mode | GT / prediction regions | START s | END s | MAE ms | RMSE ms | Status |
+|---|---|---|---|---|---|---|---|---|---|
+| train | phone_F1 | tt1 | core | 1 / 1 | 0.53 | 3.235 | 242.49999999999994 | 342.9467888754755 | suspiciously high MAE |
+| train | phone_M1 | tt1 | core | 1 / 1 | 0.4 | 4.055 | 297.49999999999983 | 380.67374482619607 | suspiciously high MAE; boundary inside silence |
+| train | studio_F1 | tt1 | core | 1 / 1 | 0.66 | 2.164988662131519 | 17.494331065759596 | 17.67286044324514 | OK |
+| train | studio_M1 | tt1 | core | 1 / 1 | 0.87 | 2.0649886621315194 | 2.4943310657596918 | 3.5275168222458926 | OK |
+| test | phone_F2 | tt1 | core | 1 / 3 | 0.61 | 4.795 | undefined | undefined | extra predicted regions; boundary inside silence |
+| test | phone_M2 | tt1 | core | 1 / 1 | 0.52 | 2.535 | 12.500000000000068 | 12.747548783982039 | OK |
+| test | studio_F2 | tt1 | core | 1 / 1 | 0.76 | 2.3649886621315193 | 7.505668934240428 | 7.909282749784279 | OK |
+| test | studio_M2 | tt1 | core | 1 / 1 | 0.45 | 1.9349886621315193 | 2.4943310657596918 | 3.5275168222458926 | OK |
+| train | phone_F1 | tt2 | core | 1 / 2 | 0.54 | 2.745 | undefined | undefined | extra predicted regions |
+| train | phone_M1 | tt2 | core | 1 / 1 | 0.46 | 3.525 | 2.4999999999999467 | 3.5355339059326623 | OK |
+| train | studio_F1 | tt2 | core | 1 / 1 | 0.67 | 2.144988662131519 | 7.505668934240428 | 7.909282749784279 | OK |
+| train | studio_M1 | tt2 | core | 1 / 1 | 0.91 | 2.0449886621315194 | 27.505668934240333 | 30.21043085261847 | OK |
+| test | phone_F2 | tt2 | core | 1 / 2 | 1.05 | 4.015 | undefined | undefined | extra predicted regions |
+| test | phone_M2 | tt2 | core | 1 / 1 | 0.53 | 2.515 | 2.4999999999999467 | 3.5355339059326623 | OK |
+| test | studio_F2 | tt2 | core | 1 / 1 | 0.76 | 2.3449886621315192 | 17.505668934240436 | 19.046876672715992 | OK |
+| test | studio_M2 | tt2 | core | 1 / 1 | 0.46 | 1.9249886621315193 | 7.505668934240317 | 7.909282749784209 | OK |
+| train | phone_F1 | tt3 | core | 1 / 1 | 0.53 | 2.745 | 2.4999999999999467 | 3.5355339059326623 | OK |
+| train | phone_M1 | tt3 | core | 1 / 1 | 0.46 | 3.535 | 7.500000000000062 | 10.6066017177983 | OK |
+| train | studio_F1 | tt3 | core | 1 / 1 | 0.66 | 2.164988662131519 | 17.494331065759596 | 17.67286044324514 | OK |
+| train | studio_M1 | tt3 | core | 1 / 1 | 0.91 | 2.0649886621315194 | 22.49433106575971 | 28.503392340758833 | OK |
+| test | phone_F2 | tt3 | core | 1 / 1 | 1.01 | 4.085 | 27.499999999999968 | 32.59601202601319 | boundary inside silence |
+| test | phone_M2 | tt3 | core | 1 / 1 | 0.52 | 2.525 | 7.499999999999951 | 7.905694150420921 | OK |
+| test | studio_F2 | tt3 | core | 1 / 1 | 0.76 | 2.3649886621315193 | 7.505668934240428 | 7.909282749784279 | OK |
+| test | studio_M2 | tt3 | core | 1 / 1 | 0.46 | 1.9349886621315193 | 7.494331065759696 | 7.902112055091845 | OK |
+| train | phone_F1 | tt1 | enhanced | 1 / 1 | 0.53 | 2.865 | 57.50000000000011 | 81.31727983645311 | boundary inside silence |
+| train | phone_M1 | tt1 | enhanced | 1 / 1 | 0.45 | 3.665 | 77.50000000000001 | 102.77402395547234 | boundary inside silence |
+| train | studio_F1 | tt1 | enhanced | 1 / 1 | 0.66 | 2.164988662131519 | 17.494331065759596 | 17.67286044324514 | OK |
+| train | studio_M1 | tt1 | enhanced | 1 / 1 | 0.91 | 2.0649886621315194 | 22.49433106575971 | 28.503392340758833 | OK |
+| test | phone_F2 | tt1 | enhanced | 1 / 1 | 1.01 | 4.145 | 57.49999999999978 | 74.58216945088117 | boundary inside silence |
+| test | phone_M2 | tt1 | enhanced | 1 / 1 | 0.52 | 2.535 | 12.500000000000068 | 12.747548783982039 | OK |
+| test | studio_F2 | tt1 | enhanced | 1 / 1 | 0.76 | 2.3649886621315193 | 7.505668934240428 | 7.909282749784279 | OK |
+| test | studio_M2 | tt1 | enhanced | 1 / 1 | 0.45 | 1.9349886621315193 | 2.4943310657596918 | 3.5275168222458926 | OK |
+| train | phone_F1 | tt2 | enhanced | 1 / 1 | 0.53 | 2.745 | 2.4999999999999467 | 3.5355339059326623 | OK |
+| train | phone_M1 | tt2 | enhanced | 1 / 1 | 0.46 | 3.545 | 12.499999999999956 | 17.677669529663625 | OK |
+| train | studio_F1 | tt2 | enhanced | 1 / 1 | 0.66 | 2.164988662131519 | 17.494331065759596 | 17.67286044324514 | OK |
+| train | studio_M1 | tt2 | enhanced | 1 / 1 | 0.91 | 2.0649886621315194 | 22.49433106575971 | 28.503392340758833 | OK |
+| test | phone_F2 | tt2 | enhanced | 1 / 1 | 1.01 | 4.095 | 32.499999999999865 | 39.528470752104546 | boundary inside silence |
+| test | phone_M2 | tt2 | enhanced | 1 / 1 | 0.52 | 2.525 | 7.499999999999951 | 7.905694150420921 | OK |
+| test | studio_F2 | tt2 | enhanced | 1 / 1 | 0.76 | 2.3649886621315193 | 7.505668934240428 | 7.909282749784279 | OK |
+| test | studio_M2 | tt2 | enhanced | 1 / 1 | 0.46 | 1.9349886621315193 | 7.494331065759696 | 7.902112055091845 | OK |
+| train | phone_F1 | tt3 | enhanced | 1 / 1 | 0.53 | 2.745 | 2.4999999999999467 | 3.5355339059326623 | OK |
+| train | phone_M1 | tt3 | enhanced | 1 / 1 | 0.46 | 3.535 | 7.500000000000062 | 10.6066017177983 | OK |
+| train | studio_F1 | tt3 | enhanced | 1 / 1 | 0.66 | 2.164988662131519 | 17.494331065759596 | 17.67286044324514 | OK |
+| train | studio_M1 | tt3 | enhanced | 1 / 1 | 0.91 | 2.0649886621315194 | 22.49433106575971 | 28.503392340758833 | OK |
+| test | phone_F2 | tt3 | enhanced | 1 / 1 | 1.01 | 4.085 | 27.499999999999968 | 32.59601202601319 | boundary inside silence |
+| test | phone_M2 | tt3 | enhanced | 1 / 1 | 0.52 | 2.525 | 7.499999999999951 | 7.905694150420921 | OK |
+| test | studio_F2 | tt3 | enhanced | 1 / 1 | 0.76 | 2.3649886621315193 | 7.505668934240428 | 7.909282749784279 | OK |
+| test | studio_M2 | tt3 | enhanced | 1 / 1 | 0.46 | 1.9349886621315193 | 7.494331065759696 | 7.902112055091845 | OK |
+
+Các START/END scalar là envelope hỗ trợ đọc nhanh; khi nhiều vùng, diagnostic JSON chứa toàn bộ FINAL regions và primary metric chấm mọi cặp START/END theo thứ tự. Core LOW/HIGH null; native T nằm trong threshold diagnostics. Timing 25/10 ms dùng nearest samples/ties-to-even (44.1 kHz: 1102/441 samples); actual timing có trong metrics. Gap support <200 ms mới nối; exact200 ms giữ. Slides và ZIP Python cũ là previous version và được giữ nguyên.
diff --git a/reports/TT1_BINARY_SEARCH_GIAI_THICH.md b/reports/TT1_BINARY_SEARCH_GIAI_THICH.md
index bedfe03..c3f5a10 100644
--- a/reports/TT1_BINARY_SEARCH_GIAI_THICH.md
+++ b/reports/TT1_BINARY_SEARCH_GIAI_THICH.md
@@ -1,12 +1,28 @@
 # TT1 — Tìm ngưỡng bằng Binary Search: giải thích thuật toán và code
 
+## Hai chế độ endpoint (07/10/2026)
+
+Mặc định `enhanced`: ngưỡng native tạo seed; noise TRAIN và HIGH/LOW xác nhận, giữ speech; nối gap support dưới 200 ms và lọc span dưới 100 ms. `core` giữ quyết định native và chỉ nối gap support dưới 200 ms, không lọc duration hoặc padding FINAL; LOW/HIGH là null. Gap ước lượng đúng 200 ms được giữ riêng. TT1 dùng STE ≥ T, TT2 dùng Energy > T, TT3 giữ hướng high/low của Gaussian native. Đây là hai chế độ endpoint của cùng ba thuật toán; enhanced là phần bổ sung của dự án.
+
+```powershell
+python main_tt1.py --endpoint-mode core
+python main.py --evaluate-all --compare-endpoint-modes
+```
+
+Mỗi mode fit và khóa model độc lập trên bốn TRAIN trước đọc TEST. Kết quả mới ở `outputs/endpoint_modes/core/` và `outputs/endpoint_modes/enhanced/`; bảng so sánh ở `outputs/endpoint_modes/comparison/tables/`. Model schema 3 giữ policy/digest, metric schema 2 tiếp tục `mae_ms`/`rmse_ms`. Thiếu/thừa vùng làm primary mean toàn bộ file undefined; `valid_files_*` là thống kê subset riêng. TEST có `historical_test_exposure=true`, không phải holdout độc lập. Không chọn mode tốt hơn riêng cho từng WAV.
+
+Notebook dùng `MODE="enhanced"` mặc định cho bốn TEST figure và một illustration; luôn fit/khóa `MODELS` cả hai mode trước TEST, xuất 16 dòng tám WAV/mode và bảng bốn TEST/mode. TT2 có 200 TRAIN sweep rows mỗi mode. Core plot native T; Energy TT2 được chuẩn hóa chỉ ở bước hiển thị. Source digest và model lock digests độc lập kiểm tra nguồn/outputs và model; Restart Kernel → Run All → Save vẫn chạy độc lập.
+
+PPTX/PDF và ZIP Python cũ giữ nguyên previous version. Các bảng, noise và ví dụ HIGH/LOW bên dưới mô tả enhanced; không phải công thức quyết định FINAL của core. Xem [báo cáo hai mode](KET_QUA_ENDPOINT_MODES_2026_10_07.md).
+
+
 Cập nhật theo code hiện tại ngày 05/10/2026. Tài liệu này giải thích riêng TT1 để thành viên phụ trách có thể đọc, chạy và thuyết trình độc lập.
 
 ## Giao thức Stage1 và schema 2
 
 Mọi model, W và `endpoint_noise` được fit từ bốn TRAIN trước khi đọc TEST. Ba thuật toán dùng `schema_version=2`, `parameter_selection_set=train`, `evaluation_protocol=train_selected_reused_test`, `historical_test_exposure=true`. TEST đã được xem trong phát triển trước đây và được dùng lại để chấm; không gọi đây là holdout mới hoặc độc lập. Chạy một file (`--file`) vẫn fit TRAIN trước, không hiệu chỉnh bằng TEST.
 
 Hàm công khai [detect_regions()](../app/pipeline.py#L132) nhận `(algorithm, features, duration, params)`, không nhận LAB, nhãn hay filename; `endpoint_noise` phải được fit sẵn. [predict_and_score()](../app/pipeline.py#L174) gọi detector rồi chấm với LAB. CLI xuất metric vẫn yêu cầu WAV/LAB cùng tên.
 
 Schema 2 dùng `mae_ms`/`rmse_ms` làm metric chính. `final_region_mae_ms` là MAE của mỗi dòng calibration W trên TRAIN. Các sự kiện ghép trong dung sai dùng `tolerance_boundary_*`; `matched_boundary_mae_ms` là diagnostic ghép vùng theo thứ tự. Alias cũ `boundary_MAE_ms` đã bỏ để tránh hai cột chỉ khác hoa/thường.
 
@@ -140,21 +156,21 @@ Dừng khi **cả hai số đếm không thay đổi sau một lần cập nhậ
 | Đại lượng | Giá trị hiện tại |
 |---|---:|
 | Overlap low | 0.0000542396991 |
 | Overlap high | 0.0113686891974 |
 | Quan sát silence trong overlap | 253 |
 | Quan sát speech trong overlap | 178 |
 | Số vòng | 11 |
 | T1 | **0.0010293375196** |
 | A(T1) còn dư | khoảng 0.0000002448924 |
 
-Các giá trị lấy từ [model TT1](../outputs/models/tt1.json), không phải hằng ngưỡng gán sẵn trong code. Chạy lại trên cùng dữ liệu sẽ học lại mô hình.
+Các giá trị lấy từ [model TT1](../outputs/endpoint_modes/enhanced/models/tt1.json), không phải hằng ngưỡng gán sẵn trong code. Chạy lại trên cùng dữ liệu sẽ học lại mô hình.
 
 [predict()](../algorithms/tt1_hodgkinson.py#L131) tạo nhãn ứng viên `1 if z >= T1 else 0`. Nó không đọc LAB.
 
 ## 5. Từ ứng viên đến vùng nói cuối cùng
 
 Phần này nằm ngoài lõi Binary Search. Nó được dùng chung để tránh nhiễu làm xuất hiện nhiều endpoint và hỗ trợ nhiều phát ngôn trong một WAV.
 
 ### 5.1. Học nền nhiễu từ train
 
 [fit_noise_floor()](../core/endpoints.py#L4) lấy 497 khung `sil` của train, tự tính mean, population std và Q95:
@@ -252,20 +268,20 @@ Mở terminal tại thư mục gốc của dự án:
 
 ```powershell
 python main_tt1.py
 python main_tt1.py --file phone_F2.wav
 python main_tt1.py --no-show
 python main_tt1.py --evaluate-all
 ```
 
 Mặc định chạy bốn test. `--file` chọn một WAV có LAB cùng tên. `--no-show` chỉ xuất file; `--evaluate-all` chấm cả tám WAV train/test và tự tắt cửa sổ.
 
-- [Model học được](../outputs/models/tt1.json): ngưỡng, overlap, số vòng, noise.
-- [Bảng bốn test](../outputs/tables/tt1/test_metrics.csv): MAE, RMSE, số vùng và status.
-- [Ảnh phone_F2](../outputs/figures/tt1/phone_F2.png): waveform, STE, High/Low, GT và final prediction.
-- [Diagnostic phone_F2](../outputs/diagnostics/tt1/phone_F2.json): candidate và final được lưu riêng.
+- [Model học được](../outputs/endpoint_modes/enhanced/models/tt1.json): ngưỡng, overlap, số vòng, noise.
+- [Bảng bốn test](../outputs/endpoint_modes/enhanced/tables/tt1/test_metrics.csv): MAE, RMSE, số vùng và status.
+- [Ảnh phone_F2](../outputs/endpoint_modes/enhanced/figures/tt1/phone_F2.png): waveform, STE, High/Low, GT và final prediction.
+- [Diagnostic phone_F2](../outputs/endpoint_modes/enhanced/diagnostics/tt1/phone_F2.json): candidate và final được lưu riêng.
 
 ## 9. Cách giải thích ngắn khi thuyết trình
 
 “Em học một ngưỡng normalized STE từ các khung train có nhãn. Binary Search thu hẹp miền chồng lấn theo dấu của hiệu diện tích nhầm lẫn, dừng khi hai số đếm không đổi. Khi chạy test, ngưỡng tạo ứng viên; High/Low xác nhận và duy trì tiếng nói, nối gap dưới 200 ms, loại vùng dưới 100 ms. Biên cuối lấy theo support khung và MAE chỉ tính trên các vùng đã xác nhận.”
 
 Giới hạn cần hiểu: nguồn dùng MA còn project dùng STE; điều kiện dừng không giải diện tích chính xác; chuẩn hóa theo đỉnh mỗi WAV và noise train có thể hạn chế khả năng áp dụng sang môi trường nhiễu khác. Với bộ hiện tại, noise floor quyết định nhiều phần của biên cuối TT1.
diff --git a/reports/TT2_HISTOGRAM_GIAI_THICH.md b/reports/TT2_HISTOGRAM_GIAI_THICH.md
index 541f4ac..e17c4aa 100644
--- a/reports/TT2_HISTOGRAM_GIAI_THICH.md
+++ b/reports/TT2_HISTOGRAM_GIAI_THICH.md
@@ -1,12 +1,28 @@
 # TT2 — Histogram chỉ dùng Energy: giải thích thuật toán và code
 
+## Hai chế độ endpoint (07/10/2026)
+
+Mặc định `enhanced`: ngưỡng native tạo seed; noise TRAIN và HIGH/LOW xác nhận, giữ speech; nối gap support dưới 200 ms và lọc span dưới 100 ms. `core` giữ quyết định native và chỉ nối gap support dưới 200 ms, không lọc duration hoặc padding FINAL; LOW/HIGH là null. Gap ước lượng đúng 200 ms được giữ riêng. TT1 dùng STE ≥ T, TT2 dùng Energy > T, TT3 giữ hướng high/low của Gaussian native. Đây là hai chế độ endpoint của cùng ba thuật toán; enhanced là phần bổ sung của dự án.
+
+```powershell
+python main_tt1.py --endpoint-mode core
+python main.py --evaluate-all --compare-endpoint-modes
+```
+
+Mỗi mode fit và khóa model độc lập trên bốn TRAIN trước đọc TEST. Kết quả mới ở `outputs/endpoint_modes/core/` và `outputs/endpoint_modes/enhanced/`; bảng so sánh ở `outputs/endpoint_modes/comparison/tables/`. Model schema 3 giữ policy/digest, metric schema 2 tiếp tục `mae_ms`/`rmse_ms`. Thiếu/thừa vùng làm primary mean toàn bộ file undefined; `valid_files_*` là thống kê subset riêng. TEST có `historical_test_exposure=true`, không phải holdout độc lập. Không chọn mode tốt hơn riêng cho từng WAV.
+
+Notebook dùng `MODE="enhanced"` mặc định cho bốn TEST figure và một illustration; luôn fit/khóa `MODELS` cả hai mode trước TEST, xuất 16 dòng tám WAV/mode và bảng bốn TEST/mode. TT2 có 200 TRAIN sweep rows mỗi mode. Core plot native T; Energy TT2 được chuẩn hóa chỉ ở bước hiển thị. Source digest và model lock digests độc lập kiểm tra nguồn/outputs và model; Restart Kernel → Run All → Save vẫn chạy độc lập.
+
+PPTX/PDF và ZIP Python cũ giữ nguyên previous version. Các bảng, noise và ví dụ HIGH/LOW bên dưới mô tả enhanced; không phải công thức quyết định FINAL của core. Xem [báo cáo hai mode](KET_QUA_ENDPOINT_MODES_2026_10_07.md).
+
+
 Cập nhật theo code hiện tại ngày 05/10/2026. TT2 đã bỏ Spectral Centroid theo yêu cầu của thầy. Ba main hiện không tính FFT/Centroid trong đường chạy thực nghiệm.
 
 ## Giao thức Stage1 và schema 2
 
 Mọi model, W và `endpoint_noise` được fit từ bốn TRAIN trước khi đọc TEST. Ba thuật toán dùng `schema_version=2`, `parameter_selection_set=train`, `evaluation_protocol=train_selected_reused_test`, `historical_test_exposure=true`. TEST đã được xem trong phát triển trước đây và được dùng lại để chấm; không gọi đây là holdout mới hoặc độc lập. Chạy một file (`--file`) vẫn fit TRAIN trước, không hiệu chỉnh bằng TEST.
 
 Hàm công khai [detect_regions()](../app/pipeline.py#L132) nhận `(algorithm, features, duration, params)`, không nhận LAB, nhãn hay filename; `endpoint_noise` phải được fit sẵn. [predict_and_score()](../app/pipeline.py#L174) gọi detector rồi chấm với LAB. CLI xuất metric vẫn yêu cầu WAV/LAB cùng tên.
 
 Schema 2 dùng `mae_ms`/`rmse_ms` làm metric chính. `final_region_mae_ms` là MAE của mỗi dòng calibration W trên TRAIN. Các sự kiện ghép trong dung sai dùng `tolerance_boundary_*`; `matched_boundary_mae_ms` là diagnostic ghép vùng theo thứ tự. Alias cũ `boundary_MAE_ms` đã bỏ để tránh hai cột chỉ khác hoa/thường.
 
@@ -195,21 +211,21 @@ Pipeline fit TRAIN trước TEST; thử mọi W nguyên **1–50** trên `phone_
 
 [sweep_final_weights()](../app/weight_selection.py#L67) chạy pipeline thật cho mỗi W. [select_final_weight()](../app/weight_selection.py#L11) ưu tiên:
 
 1. Ít file có số vùng sai hoặc MAE không xác định nhất.
 2. Nhỏ nhất mức thiệt hại tệ nhất so với W tốt nhất riêng của từng file.
 3. Nhỏ nhất MAE trung bình các file hợp lệ.
 4. Nếu vẫn hòa, giữ W đang ưu tiên từ cấu hình; nếu không có thì chọn W nhỏ nhất.
 
 “Thiệt hại” ở đây là `MAE(file,W) - min_W MAE(file,W)`, không phải một công thức ngưỡng mới.
 
-TT2 đề xuất candidate **W1** bằng TRAIN frame F1 (0.898698, không phải F1 của FINAL W20). Sau đó [fit_training_model()](../app/pipeline.py#L229) khảo sát W nguyên **1–50** trên FINAL regions của `phone_F1`, `phone_M1`, `studio_F1`, `studio_M1`: 200 dòng TRAIN. Kết quả lưu hiện tại: cả 50 W đồng tối ưu; mean FINAL MAE TRAIN **13.747165532879801 ms**. Chọn **W20** bằng `tie_preference_W=20` cố định. Đây là kết quả của TRAIN hiện tại, không phải giả định mọi dataset đều hòa. Manifest `W_selection_train` ghi `selection_set=train`, `evaluation_protocol=train_final_calibration` và tên TRAIN đã chấm.
+Trong enhanced, TT2 đề xuất candidate **W1** bằng TRAIN frame F1 (0.898698, không phải F1 của FINAL W20). Sau đó [fit_training_model()](../app/pipeline.py#L229) khảo sát W nguyên **1–50** trên FINAL regions của `phone_F1`, `phone_M1`, `studio_F1`, `studio_M1`: 200 dòng TRAIN. Kết quả enhanced lưu hiện tại: cả 50 W đồng tối ưu; mean FINAL MAE TRAIN **13.747165532879801 ms**. Chọn **W20** bằng `tie_preference_W=20` cố định. Đây là kết quả của TRAIN hiện tại, không phải giả định mọi dataset đều hòa. Manifest `W_selection_train` ghi `selection_set=train`, `evaluation_protocol=train_final_calibration` và tên TRAIN đã chấm.
 
 `candidate_frame_selected_W`, `candidate_frame_f1`, `candidate_frame_selection_scores`, `candidate_cleanup_records` chỉ mô tả bước candidate. `W`/`finalW` và manifest TRAIN mô tả lựa chọn FINAL; không gán candidate F1 cho W20. Không có W riêng theo filename. W20 không phải tối ưu duy nhất; chưa khảo sát số thực ngoài miền W nguyên 1–50.
 
 ## 6. Padding ứng viên và High/Low tạo biên cuối
 
 ### 6.1. Padding không phải endpoint cuối
 
 [pad_speech()](../algorithms/tt2_histogram.py#L112) mở rộng mask ứng viên 25 hop ở mỗi phía, tức 250 ms. Nó đọc mask gốc để padding không tự lan tiếp.
 
 Mask này còn phục vụ đề xuất W bằng train-F1 và diagnostic. Nhưng [detect_regions()](../app/pipeline.py#L132) **tạo lại seed bằng raw `E > TE`**, không dùng mask padding để quyết định START/END cuối.
@@ -313,21 +329,21 @@ Tại thư mục gốc của dự án:
 
 ```powershell
 python main_tt2.py
 python main_tt2.py --file phone_F2.wav
 python main_tt2.py --no-show
 python main_tt2.py --evaluate-all
 ```
 
 Mặc định bốn test; `--file` chọn một WAV có LAB cùng tên; `--evaluate-all` chấm tám WAV và không mở cửa sổ. Chế độ một file fit bốn TRAIN trước khi đọc file đã chọn; không nạp bốn TEST để calibration.
 
-- [Model TT2](../outputs/models/tt2.json): W train, W cuối, cấu hình histogram, noise.
-- [Bảng metric](../outputs/tables/tt2/test_metrics.csv).
-- [Khảo sát W](../outputs/tables/tt2_w_selection/sweep.csv): 200 lần chấm final regions.
-- [Diagnostic phone_F2](../outputs/diagnostics/tt2/phone_F2.json): M1/M2, TE, High/Low, candidate/final.
-- [Ảnh phone_F2](../outputs/figures/tt2/phone_F2.png).
+- [Model TT2](../outputs/endpoint_modes/enhanced/models/tt2.json): W train, W cuối, cấu hình histogram, noise.
+- [Bảng metric](../outputs/endpoint_modes/enhanced/tables/tt2/test_metrics.csv).
+- [Khảo sát W](../outputs/endpoint_modes/enhanced/tables/tt2_w_selection/sweep.csv): 200 lần chấm final regions.
+- [Diagnostic phone_F2](../outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_F2.json): M1/M2, TE, High/Low, candidate/final.
+- [Ảnh phone_F2](../outputs/endpoint_modes/enhanced/figures/tt2/phone_F2.png).
 
 ## 10. Cách giải thích ngắn và giới hạn
 
 “Em tính Energy từng khung 25 ms, tạo histogram 64 bin, làm trơn số đếm bằng tối đa 5 bin và lấy hai đỉnh đầu theo chiều năng lượng tăng. Ngưỡng là `(20*M1+M2)/21`. Bản này chỉ dùng Energy theo yêu cầu thầy. Sau khi tạo ứng viên, em dùng High/Low STE và điều kiện 200/100 ms để tạo final regions; chỉ các biên cuối mới được chấm MAE.”
 
 Energy-only nhẹ và dễ giải thích hơn, nhưng không có đặc trưng phổ để loại một số loại nhiễu. Histogram một đỉnh phải dùng fallback; hai đỉnh đầu có thể không đại diện đúng hai lớp. W20 không duy nhất trong khảo sát hiện tại. High/Low là phần cải tiến chung, còn 100 ms là tham số bổ sung; TEST có historical exposure và được dùng lại để đánh giá, nên cần trình bày giới hạn này.
diff --git a/reports/TT3_GAUSSIAN_GIAI_THICH.md b/reports/TT3_GAUSSIAN_GIAI_THICH.md
index 85331dd..86ab433 100644
--- a/reports/TT3_GAUSSIAN_GIAI_THICH.md
+++ b/reports/TT3_GAUSSIAN_GIAI_THICH.md
@@ -1,12 +1,28 @@
 # TT3 — Thống kê phân phối chuẩn Gaussian: giải thích thuật toán và code
 
+## Hai chế độ endpoint (07/10/2026)
+
+Mặc định `enhanced`: ngưỡng native tạo seed; noise TRAIN và HIGH/LOW xác nhận, giữ speech; nối gap support dưới 200 ms và lọc span dưới 100 ms. `core` giữ quyết định native và chỉ nối gap support dưới 200 ms, không lọc duration hoặc padding FINAL; LOW/HIGH là null. Gap ước lượng đúng 200 ms được giữ riêng. TT1 dùng STE ≥ T, TT2 dùng Energy > T, TT3 giữ hướng high/low của Gaussian native. Đây là hai chế độ endpoint của cùng ba thuật toán; enhanced là phần bổ sung của dự án.
+
+```powershell
+python main_tt1.py --endpoint-mode core
+python main.py --evaluate-all --compare-endpoint-modes
+```
+
+Mỗi mode fit và khóa model độc lập trên bốn TRAIN trước đọc TEST. Kết quả mới ở `outputs/endpoint_modes/core/` và `outputs/endpoint_modes/enhanced/`; bảng so sánh ở `outputs/endpoint_modes/comparison/tables/`. Model schema 3 giữ policy/digest, metric schema 2 tiếp tục `mae_ms`/`rmse_ms`. Thiếu/thừa vùng làm primary mean toàn bộ file undefined; `valid_files_*` là thống kê subset riêng. TEST có `historical_test_exposure=true`, không phải holdout độc lập. Không chọn mode tốt hơn riêng cho từng WAV.
+
+Notebook dùng `MODE="enhanced"` mặc định cho bốn TEST figure và một illustration; luôn fit/khóa `MODELS` cả hai mode trước TEST, xuất 16 dòng tám WAV/mode và bảng bốn TEST/mode. TT2 có 200 TRAIN sweep rows mỗi mode. Core plot native T; Energy TT2 được chuẩn hóa chỉ ở bước hiển thị. Source digest và model lock digests độc lập kiểm tra nguồn/outputs và model; Restart Kernel → Run All → Save vẫn chạy độc lập.
+
+PPTX/PDF và ZIP Python cũ giữ nguyên previous version. Các bảng, noise và ví dụ HIGH/LOW bên dưới mô tả enhanced; không phải công thức quyết định FINAL của core. Xem [báo cáo hai mode](KET_QUA_ENDPOINT_MODES_2026_10_07.md).
+
+
 Cập nhật theo code hiện tại ngày 06/10/2026. Tài liệu này mô tả TT3 đang chạy: thống kê trên normalized STE tuyến tính, tìm giao điểm hai mật độ Gaussian bằng phép tính đã center/scale, sau đó lấy biên bằng xử lý chung.
 
 ## Giao thức Stage1 và schema 2
 
 Mọi model, W và `endpoint_noise` được fit từ bốn TRAIN trước khi đọc TEST. Ba thuật toán dùng `schema_version=2`, `parameter_selection_set=train`, `evaluation_protocol=train_selected_reused_test`, `historical_test_exposure=true`. TEST đã được xem trong phát triển trước đây và được dùng lại để chấm; không gọi đây là holdout mới hoặc độc lập. Chạy một file (`--file`) vẫn fit TRAIN trước, không hiệu chỉnh bằng TEST.
 
 Hàm công khai [detect_regions()](../app/pipeline.py#L132) nhận `(algorithm, features, duration, params)`, không nhận LAB, nhãn hay filename; `endpoint_noise` phải được fit sẵn. [predict_and_score()](../app/pipeline.py#L174) gọi detector rồi chấm với LAB. CLI xuất metric vẫn yêu cầu WAV/LAB cùng tên.
 
 Schema 2 dùng `mae_ms`/`rmse_ms` làm metric chính. `final_region_mae_ms` là MAE của mỗi dòng calibration W trên TRAIN. Các sự kiện ghép trong dung sai dùng `tolerance_boundary_*`; `matched_boundary_mae_ms` là diagnostic ghép vùng theo thứ tự. Alias cũ `boundary_MAE_ms` đã bỏ để tránh hai cột chỉ khác hoa/thường.
 
@@ -196,32 +212,32 @@ Với dataset hiện tại, hai nghiệm là:
 \[
 T_a=0.0028777336852,\qquad T_b=-0.0021071776746
 \]
 
 Ta nằm giữa mean silence và mean speech, Tb không nằm trong miền đó, nên:
 
 \[
 \boxed{T3=0.0028777336852}
 \]
 
-[Model TT3](../outputs/models/tt3.json) lưu ngưỡng và hai nghiệm này. Không có sigma nào bị floor trên dữ liệu hiện tại.
+[Model TT3](../outputs/endpoint_modes/enhanced/models/tt3.json) lưu ngưỡng và hai nghiệm này. Không có sigma nào bị floor trên dữ liệu hiện tại.
 
 ## 6. Tạo nhãn ứng viên
 
 [predict()](../algorithms/tt3_gaussian.py#L109) xem hướng của hai mean:
 
 - Mean speech ≥ mean silence → speech nếu `z >= T3`.
 - Mean speech < mean silence → nhánh lõi dùng `z <= T3`.
 
 Dataset hiện tại dùng hướng **high**. Ví dụ z=0.001 → silence ứng viên, z=0.01 → speech ứng viên.
 
-Nhánh lõi hỗ trợ mean đảo hướng, nhưng **FINAL hysteresis chỉ hỗ trợ speech có năng lượng cao**. `fit_training_model()` từ chối TRAIN cho hướng `low`; `detect_regions()` cũng từ chối model nhập vào có hướng `low` hoặc không hợp lệ bằng `ValueError` rõ ràng. Model cũ thiếu trường direction được hiểu là `high` để giữ tương thích. Không còn tình trạng âm thầm trả zero speech do candidate `z<=T` mâu thuẫn với HIGH `z>T`.
+Gaussian native và core FINAL hỗ trợ mean đảo hướng. **Enhanced FINAL hysteresis chỉ hỗ trợ speech có năng lượng cao**. Chỉ khi `endpoint_mode="enhanced"`, `fit_training_model()` từ chối TRAIN hướng `low` và `detect_regions()` từ chối model hướng `low` hoặc không hợp lệ bằng `ValueError`; core giữ hướng high/low native. Model cũ thiếu trường direction được hiểu là `high` để giữ tương thích. Không còn tình trạng âm thầm trả zero speech do candidate `z<=T` mâu thuẫn với HIGH `z>T`.
 
 Đây là giới hạn được công bố của pipeline FINAL, không phải hỗ trợ hoàn chỉnh việc phát hiện speech năng lượng thấp hơn noise. Các hàm lõi `fit()/predict()` vẫn có thể dùng riêng cho thí nghiệm hướng đảo.
 
 Một ngưỡng không tự tạo final region: các khung có thể dao động quanh T3 và tạo nhiều đoạn nhỏ. Bước xử lý chung dưới đây làm nhiệm vụ đó.
 
 ## 7. Noise floor, High/Low và vùng nói cuối
 
 Đây là phần cải tiến dùng chung, tách khỏi việc tính ngưỡng Gaussian.
 
 ### 7.1. Thống kê nền nhiễu
@@ -334,21 +350,21 @@ Tại thư mục gốc của dự án:
 
 ```powershell
 python main_tt3.py
 python main_tt3.py --file phone_F2.wav
 python main_tt3.py --no-show
 python main_tt3.py --evaluate-all
 ```
 
 Mặc định chạy bốn test; `--file` chọn một WAV có LAB cùng tên; `--no-show` chỉ xuất file; `--evaluate-all` chấm cả tám WAV và không mở cửa sổ.
 
-- [Model TT3](../outputs/models/tt3.json): mean/std, nghiệm, sigma floor, T3, noise.
-- [Bảng metric TT3](../outputs/tables/tt3/test_metrics.csv).
-- [Ảnh phân phối train](../outputs/figures/training/gaussian_distributions.png): minh họa mật độ từ tham số đã học, không chứng minh phân phối thực đúng Gaussian.
-- [Diagnostic phone_F2](../outputs/diagnostics/tt3/phone_F2.json).
-- [Ảnh kết quả phone_F2](../outputs/figures/tt3/phone_F2.png).
+- [Model TT3](../outputs/endpoint_modes/enhanced/models/tt3.json): mean/std, nghiệm, sigma floor, T3, noise.
+- [Bảng metric TT3](../outputs/endpoint_modes/enhanced/tables/tt3/test_metrics.csv).
+- [Ảnh phân phối train](../outputs/endpoint_modes/enhanced/figures/training/gaussian_distributions.png): minh họa mật độ từ tham số đã học, không chứng minh phân phối thực đúng Gaussian.
+- [Diagnostic phone_F2](../outputs/endpoint_modes/enhanced/diagnostics/tt3/phone_F2.json).
+- [Ảnh kết quả phone_F2](../outputs/endpoint_modes/enhanced/figures/tt3/phone_F2.png).
 
 ## 11. Cách giải thích ngắn và giới hạn
 
 “Em gom normalized STE của silence và speech trên train, tự tính mean và population standard deviation. Em giả định hai lớp có mật độ Gaussian, giải phương trình hai mật độ bằng nhau và chọn nghiệm giữa hai mean. Ngưỡng tạo ứng viên; High/Low cùng điều kiện thời lượng tạo final speech regions. MAE chỉ chấm START/END của các vùng cuối.”
 
 Giới hạn cần nêu: dữ liệu STE không được kiểm định Gaussian; normalized STE bị giới hạn [0,1] còn Gaussian trải trên toàn trục thực. Code dùng equal density không xét class priors. Một ngưỡng cố định học từ train có thể nhạy khi noise hoặc cách thu thay đổi. Hysteresis là phần bổ sung chung nên kết quả cuối không thể quy hoàn toàn cho một ngưỡng T3.
diff --git a/tests/test_endpoint_mode_integration.py b/tests/test_endpoint_mode_integration.py
new file mode 100644
index 0000000..958f43d
--- /dev/null
+++ b/tests/test_endpoint_mode_integration.py
@@ -0,0 +1,106 @@
+import unittest
+from app.cli import parse_args
+from app.pipeline import summarize
+from tools import build_notebooks as builder
+
+class EndpointModeIntegrationTests(unittest.TestCase):
+    def test_cli_modes(self):
+        self.assertEqual(parse_args([]).endpoint_mode, 'enhanced')
+        self.assertTrue(parse_args(['--compare-endpoint-modes']).compare_endpoint_modes)
+        self.assertEqual(parse_args(['--endpoint-mode','core']).endpoint_mode, 'core')
+
+    def test_summary_groups_modes_and_keeps_primary_undefined(self):
+        common=dict(algorithm='tt1',file='a',frame_f1=1.,ground_truth_region_count=1,predicted_region_count=1,mae_ms=2.,rmse_ms=2.)
+        rows=[dict(common,endpoint_mode='enhanced'),dict(common,endpoint_mode='core'),dict(common,file='b',endpoint_mode='core',predicted_region_count=2,mae_ms=None,rmse_ms=None)]
+        summary=summarize(rows)
+        self.assertEqual(len(summary),2)
+        core=next(row for row in summary if row['endpoint_mode']=='core')
+        self.assertIsNone(core['mean_file_mae_ms'])
+        self.assertEqual(core['valid_files_mean_file_mae_ms'],2.)
+        malformed=summarize([dict(common,endpoint_mode='core',predicted_region_count=2)])[0]
+        self.assertIsNone(malformed['mean_file_mae_ms'])
+
+    def test_notebook_locks_both_modes(self):
+        self.assertIn('MODELS',builder.FIT_MODEL)
+        self.assertIn('MODEL_LOCK_DIGESTS',builder.LOCK_MODEL)
+        self.assertIn('ALL_RESULTS_BY_MODE',builder.EVALUATION)
+
+    def test_schema_three_requires_self_excluded_calibration_digest(self):
+        from tools import run_notebooks as runner
+        model=dict(schema_version=3, metrics_schema_version=2, parameter_selection_set='train',
+                   evaluation_protocol='train_selected_reused_test', historical_test_exposure=True,
+                   training_files=list(runner.TRAIN_NAMES), endpoint_mode='core',minimum_speech_ms=0.,
+                   minimum_silence_ms=200.,endpoint_noise=None,boundary_convention='union of active frame supports',
+                   padding_stage='excluded from core FINAL')
+        with self.assertRaisesRegex(ValueError,'calibration digest'):
+            runner.audit_model_protocol(model,runner.model_digest(model))
+
+    def test_weight_sweep_checks_declared_geometry(self):
+        from app.weight_selection import sweep_final_weights
+        model=dict(endpoint_mode='core',boundary_convention='union of active frame supports')
+        def predictor(*args):
+            return dict(metrics=dict(ground_truth_region_count=1,predicted_region_count=1,mae_ms=0.,status='ok',start_error_ms=0.,end_error_ms=0.), diagnostic=dict(endpoint_mode='core',geometry='frame centers',energy_threshold=1.,low_ste_threshold=None,high_ste_threshold=None,raw_speech_frames=1,candidate_regions=[]),final_regions=[])
+        with self.assertRaisesRegex(ValueError,'geometry|boundary_convention'):
+            sweep_final_weights([dict(name='a',split='train')],model,predictor,candidates=(1.,))
+
+    def test_core_plot_uses_native_threshold_with_nullable_low_high(self):
+        import matplotlib.pyplot as plt
+        from app.plotting import _plot_axis
+        record=dict(name='a',samples=[0.,1.,0.],sample_rate=100,duration=.03,
+                    features=dict(centers=[.01,.02],ste_norm=[.5,1.],energy=[2.,4.]))
+        result=dict(diagnostic=dict(endpoint_mode='core',native_threshold=2.,native_threshold_units='sum of squared samples',
+                                    low_ste_threshold=None,high_ste_threshold=None),ground_truth_boundaries=[],predicted_boundaries=[],
+                    metrics=dict(mae_ms=None),final_regions=[])
+        fig,axis=plt.subplots()
+        try:
+            _plot_axis(axis,record,result)
+            labels=[item.get_text() for item in axis.get_legend().get_texts()]
+            self.assertTrue(any('Native T' in label for label in labels))
+            self.assertFalse(any('High STE' in label or 'Low STE' in label for label in labels))
+            self.assertIn('core',axis.get_title())
+            self.assertIn('FINAL-region endpoint MAE',axis.get_title())
+        finally:plt.close(fig)
+
+    def test_cli_locks_every_algorithm_in_both_modes_before_test_read(self):
+        import tempfile
+        from pathlib import Path
+        from unittest.mock import patch
+        from app import pipeline
+        from tests.test_notebook_protocol import tiny_dataset
+        with tempfile.TemporaryDirectory() as temporary:
+            root=Path(temporary); tiny_dataset(root)
+            events=[]
+            real_fit,real_load=pipeline.fit_training_model,pipeline.load_audio_folder
+            def fit(algorithm,records,**kwargs):
+                result=real_fit(algorithm,records,**kwargs)
+                events.append(('fit',algorithm,kwargs['endpoint_mode']))
+                return result
+            def load(folder):
+                if folder==root/'test':
+                    self.assertEqual(set(events),{('fit',algorithm,mode) for algorithm in ('tt1','tt2','tt3') for mode in ('core','enhanced')})
+                return real_load(folder)
+            with patch.multiple(pipeline,TRAIN_DIR=root/'train',TEST_DIR=root/'test',OUTPUT_DIR=root/'outputs'), \
+                 patch.object(pipeline,'fit_training_model',side_effect=fit),patch.object(pipeline,'load_audio_folder',side_effect=load), \
+                 patch.object(pipeline,'make_file_figure',return_value=None),patch.object(pipeline,'plot_gaussian_training'):
+                pipeline.run_experiment(parse_args(['--evaluate-all','--compare-endpoint-modes']))
+            self.assertTrue((root/'outputs/endpoint_modes/comparison/tables/all_metrics.csv').is_file())
+            self.assertFalse((root/'outputs/models').exists())
+
+    def test_default_main_dispatches_once_and_demo_retains_four_test_figures(self):
+        import contextlib,io,tempfile
+        from pathlib import Path
+        from unittest.mock import patch
+        from app import cli,pipeline
+        from tests.test_notebook_protocol import tiny_dataset
+        with patch('matplotlib.use'),patch.object(pipeline,'run_experiment') as run:
+            cli.main([])
+            run.assert_called_once()
+            self.assertEqual(run.call_args.args[0].endpoint_mode,'enhanced')
+        with tempfile.TemporaryDirectory() as temporary:
+            root=Path(temporary);tiny_dataset(root)
+            with patch.multiple(pipeline,TRAIN_DIR=root/'train',TEST_DIR=root/'test',OUTPUT_DIR=root/'outputs'), \
+                 patch.object(pipeline,'make_file_figure',return_value=None),patch.object(pipeline,'plot_gaussian_training'), \
+                 patch.object(pipeline,'show_figures',return_value=[]) as show,contextlib.redirect_stdout(io.StringIO()):
+                pipeline.run_experiment(parse_args([]))
+            show.assert_called_once()
+            self.assertEqual(len(show.call_args.args[0]),4)
diff --git a/tests/test_framing.py b/tests/test_framing.py
index ec2b392..a435b2f 100644
--- a/tests/test_framing.py
+++ b/tests/test_framing.py
@@ -208,22 +208,22 @@ class PipelineMetadataTests(unittest.TestCase):
                         handle.setnchannels(1)
                         handle.setsampwidth(2)
                         handle.setframerate(1000)
                         handle.writeframes(struct.pack("<100h", *samples))
                     (destination / f"{name}.lab").write_text("0 .03 sil\n.03 .07 v\n.07 .1 sil\n", encoding="utf-8")
             args = SimpleNamespace(algorithm="all", compare_context=True, snr_study=False,
                                    file=None, no_show=True, show_seconds=0)
             with patch.multiple("app.pipeline", TRAIN_DIR=train, TEST_DIR=test, OUTPUT_DIR=output), contextlib.redirect_stdout(io.StringIO()):
                 run_experiment(args)
             for name in ("tt1", "tt2", "tt3", "tt2-context"):
-                model = json.loads((output / "models" / f"{name}.json").read_text(encoding="utf-8"))
+                model = json.loads((output / "endpoint_modes" / "enhanced" / "models" / f"{name}.json").read_text(encoding="utf-8"))
                 self.assertEqual((model["frame_ms"], model["hop_ms"]), (25.0, 10.0))
                 self.assertIn("ties_to_even", model.get("sample_rounding", ""))
                 if name == 'tt2':
                     self.assertEqual(model['W'], 20., 'Equal final scores must retain the previously selected W=20')
-            config = json.loads((output / "tables" / "all_with_context" / "run_config.json").read_text(encoding="utf-8"))
+            config = json.loads((output / "endpoint_modes" / "enhanced" / "tables" / "all_with_context" / "run_config.json").read_text(encoding="utf-8"))
             self.assertEqual((config.get("frame_ms"), config.get("hop_ms")), (25.0, 10.0))
             self.assertIn("ties_to_even", config.get("sample_rounding", ""))
 
 
 if __name__ == "__main__":
     unittest.main()
diff --git a/tests/test_notebook_protocol.py b/tests/test_notebook_protocol.py
index f530142..c3a02ab 100644
--- a/tests/test_notebook_protocol.py
+++ b/tests/test_notebook_protocol.py
@@ -162,34 +162,38 @@ def second(value):
                                 self.assertNotIn(node.func.id, ("exec", "eval", "__import__", "Audio"))
                         if "DATA_ROOT = find_data_root" in source:
                             namespace["DATA_DIR"] = dataset
                             real_loader = namespace["load_dataset_folder"]
                             def guarded_loader(data_root, split):
                                 if split == "test":
                                     self.assertIn("MODEL_LOCK_DIGEST", namespace,
                                                   "TEST reads must follow TRAIN calibration and lock")
                                     self.assertEqual(namespace["MODEL_LOCK_DIGEST"],
                                                      namespace["model_digest"](namespace["MODEL"]))
+                                    self.assertEqual(set(namespace['MODELS']), {'core','enhanced'})
+                                    for mode, model in namespace['MODELS'].items():
+                                        self.assertEqual(namespace['MODEL_LOCK_DIGESTS'][mode], namespace['model_digest'](model))
                                     checked.append(split)
                                 return real_loader(data_root, split)
                             namespace["load_dataset_folder"] = guarded_loader
                         with contextlib.redirect_stdout(io.StringIO()), patch("matplotlib.pyplot.show"), \
                                 patch("IPython.display.display"):
                             exec(compile(source, "<generated-notebook>", "exec"), namespace)
                     self.assertEqual(checked, ["test"])
                     model = namespace["MODEL"]
                     self.assertEqual(model["schema_version"], 3)
                     self.assertEqual(model["parameter_selection_set"], "train")
                     self.assertEqual(model["evaluation_protocol"], "train_selected_reused_test")
                     self.assertIs(model["historical_test_exposure"], True)
                     self.assertEqual(namespace["MODEL_LOCK_DIGEST"], namespace["model_digest"](model))
                     self.assertEqual(len(namespace["DATASET_MANIFEST"]), 8)
+                    self.assertEqual(len(namespace["ALL_METRIC_ROWS"]), 16)
                     for row in namespace["ALL_METRIC_ROWS"]:
                         self.assertEqual(len(row), len({key.casefold() for key in row}))
                         self.assertNotIn("boundary_MAE_ms", row)
                         self.assertIn("tolerance_boundary_mae_ms", row)
                     if algorithm == "tt2":
                         self.assertEqual(len(namespace["TT2W_SWEEP_ROWS"]), 200)
                         self.assertEqual(model["W_selection_train"]["selection_set"], "train")
                         self.assertEqual(model["candidate_cleanup_records"]["full_pipeline_records"], 4)
                         self.assertNotIn("W_selection_test", model)
                     with self.assertRaisesRegex(ValueError, "endpoint_noise"):
@@ -199,34 +203,36 @@ def second(value):
                     original = json.dumps(model, sort_keys=True)
                     with contextlib.redirect_stdout(io.StringIO()), patch("matplotlib.pyplot.show"), \
                             patch("IPython.display.display"):
                         namespace["demo_one_file"](str(dataset / "test/phone_F2.wav"))
                     self.assertEqual(original, json.dumps(model, sort_keys=True))
                     self.audit_with_core_benchmark(namespace, root)
 
     def audit_with_core_benchmark(self, namespace, root):
         """Use tiny real core runs to catch generated metadata/scorer drift."""
         algorithm = namespace['ALGORITHM']
-        with patch.multiple(pipeline, TRAIN_DIR=root / 'data/train', TEST_DIR=root / 'data/test'):
-            train = pipeline.prepare_records(pipeline.load_audio_folder(root / 'data/train'))
-            test = pipeline.prepare_records(pipeline.load_audio_folder(root / 'data/test'))
-            model, rows = pipeline.fit_training_model(algorithm, train)
-        results = [pipeline.predict_and_score(algorithm, record, model) for record in train + test]
-        metric_rows = [dict(file=result['file'], algorithm=algorithm, **result['metrics']) for result in results]
-        pipeline.write_csv(root / 'outputs/tables/all_all_dataset/test_metrics.csv', metric_rows)
-        pipeline.write_csv(root / 'outputs/tables/all/summary.csv', pipeline.summarize(metric_rows[4:]))
-        pipeline.write_json(root / f'outputs/models/{algorithm}.json', model)
-        for result in results:
-            pipeline.write_json(root / f'outputs/diagnostics/{algorithm}/{result["file"]}.json', result['diagnostic'])
-        if algorithm == 'tt2':
-            pipeline.write_csv(root / 'outputs/tables/tt2_w_selection/sweep.csv', rows)
-            pipeline.write_json(root / 'outputs/tables/tt2_w_selection/selection.json', model['W_selection_train'])
+        for mode in ('core', 'enhanced'):
+            with patch.multiple(pipeline, TRAIN_DIR=root / 'data/train', TEST_DIR=root / 'data/test'):
+                train = pipeline.prepare_records(pipeline.load_audio_folder(root / 'data/train'))
+                model, rows = pipeline.fit_training_model(algorithm, train, endpoint_mode=mode)
+                test = pipeline.prepare_records(pipeline.load_audio_folder(root / 'data/test'))
+            results = [pipeline.predict_and_score(algorithm, record, model) for record in train + test]
+            metric_rows = [dict(file=result['file'],algorithm=algorithm,**result['metrics']) for result in results]
+            target = runner.endpoint_mode_root(mode, root / 'outputs')
+            pipeline.write_csv(target / 'tables/all_all_dataset/test_metrics.csv', metric_rows)
+            pipeline.write_csv(target / 'tables/all/summary.csv', pipeline.summarize(metric_rows[4:]))
+            pipeline.write_json(target / f'models/{algorithm}.json', model)
+            for result in results:
+                pipeline.write_json(target / f'diagnostics/{algorithm}/{result["file"]}.json', result['diagnostic'])
+            if algorithm == 'tt2':
+                pipeline.write_csv(target / 'tables/tt2_w_selection/sweep.csv', rows)
+                pipeline.write_json(target / 'tables/tt2_w_selection/selection.json', model['W_selection_train'])
         stream = io.StringIO()
         with contextlib.redirect_stdout(stream):
             exec(runner.AUDIT_CELL, namespace)
         evidence = json.loads(stream.getvalue().split(runner.AUDIT_PREFIX, 1)[1])
         with patch.object(runner, 'ROOT', root):
             self.assertIsInstance(runner.audit_results(evidence), float)
             damaged = copy.deepcopy(evidence)
             damaged['all_results'][0]['metrics']['mae_ms'] += 5
             with self.assertRaisesRegex(ValueError, 'mae_ms'):
                 runner.audit_results(damaged)
@@ -251,20 +257,21 @@ def executed_plot_notebook():
         'endpoint_execution': {'fixture': True, 'code_source_sha256': source_digest}})
 
 
 class NotebookAuditTests(unittest.TestCase):
     def test_schema_three_audit_validates_mode_and_keeps_schema_two_compatible(self):
         model = dict(schema_version=3, metrics_schema_version=2, parameter_selection_set='train',
                      evaluation_protocol='train_selected_reused_test', historical_test_exposure=True,
                      training_files=list(runner.TRAIN_NAMES), endpoint_mode='core',
                      minimum_speech_ms=0., minimum_silence_ms=200., endpoint_noise=None,
                      boundary_convention='union of active frame supports', padding_stage='excluded from core FINAL')
+        model["calibration_digest"] = hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False, allow_nan=False).encode("utf-8")).hexdigest()
         runner.audit_model_protocol(model, runner.model_digest(model))
         selected = dict(model, W=20., finalW=20., W_selection_train=dict(
             endpoint_mode='enhanced', minimum_speech_ms=100., minimum_silence_ms=200.,
             boundary_convention='union of active frame supports', padding_stage='candidate diagnostics only',
             selected_W=20.))
         with self.assertRaisesRegex(ValueError,'policy'):
             runner.audit_model_protocol(selected, runner.model_digest(selected))
         for changes in ({'endpoint_mode':'unknown'}, {'minimum_speech_ms':100.},
                         {'endpoint_noise':{'noise_q95':.1}}, {'padding_stage':'candidate diagnostics only'}):
             damaged = dict(model, **changes)
diff --git a/tests/test_training_protocol.py b/tests/test_training_protocol.py
index f8a9fde..0bb420a 100644
--- a/tests/test_training_protocol.py
+++ b/tests/test_training_protocol.py
@@ -105,21 +105,21 @@ class DetectionContractTests(unittest.TestCase):
     def test_primary_and_tolerance_metrics_have_distinct_casefold_unique_headers(self):
         record = synthetic_record()
         params = dict(threshold=.1, endpoint_noise=dict(noise_q95=.02, noise_upper=.15))
         metrics = pipeline.predict_and_score('tt1', record, params)['metrics']
         self.assertEqual(metrics.get('metrics_schema_version'), 2)
         self.assertIn('mae_ms', metrics)
         self.assertIn('rmse_ms', metrics)
         self.assertIn('matched_boundary_mae_ms', metrics)
         self.assertIn('tolerance_boundary_mae_ms', metrics)
         self.assertNotIn('boundary_MAE_ms', metrics)
-        self.assertFalse(any(key.startswith('boundary_') and not key.startswith('boundary_inside_')
+        self.assertFalse(any(key.startswith('boundary_') and key != 'boundary_convention' and not key.startswith('boundary_inside_')
                              for key in metrics))
         with tempfile.TemporaryDirectory() as folder:
             path = Path(folder) / 'metrics.csv'
             pipeline.write_csv(path, [metrics])
             with path.open(encoding='utf-8-sig', newline='') as handle:
                 fields = next(csv.reader(handle))
             self.assertEqual(len(fields), len(set(key.casefold() for key in fields)))
 
     def test_csv_writer_rejects_case_insensitive_duplicate_headers(self):
         with tempfile.TemporaryDirectory() as folder:
@@ -262,44 +262,44 @@ class TrainingProtocolTests(unittest.TestCase):
                 self.assertEqual(before, json.dumps(model, sort_keys=True))
 
     def test_single_file_fits_before_target_read_and_never_reloads_all_test(self):
         # Keep the real fits/scorers; suppress only artifacts and graphics.
         args = parse_args(['--algorithm', 'all', '--file', 'phone_F2.wav', '--no-show'])
         real_loader = pipeline.load_audio_file
         real_folder = pipeline.load_audio_folder
         lock = []
         self.require_fit()
         real_fit = pipeline.fit_training_model
-        def fit(algorithm, records):
-            value = real_fit(algorithm, records)
+        def fit(algorithm, records, **kwargs):
+            value = real_fit(algorithm, records, **kwargs)
             lock.append(algorithm)
             return value
         def load_file(path):
             if Path(path).parent == TEST_DIR:
                 self.assertEqual(set(lock), {'tt1', 'tt2', 'tt3'}, 'All models fit before TEST WAV/LAB read')
             return real_loader(path)
         def load_folder(folder):
             self.assertNotEqual(Path(folder), TEST_DIR, 'A single-file demo must not reload 4 TEST records')
             return real_folder(folder)
         with tempfile.TemporaryDirectory() as folder, \
                 patch.object(pipeline, 'OUTPUT_DIR', Path(folder)), \
                 patch.object(pipeline, 'load_audio_file', side_effect=load_file), \
                 patch.object(pipeline, 'load_audio_folder', side_effect=load_folder), \
                 patch.object(pipeline, 'fit_training_model', side_effect=fit), \
                 patch.object(pipeline, 'make_file_figure', return_value=None), \
                 patch.object(pipeline, 'plot_gaussian_training'), \
                 patch.object(pipeline, 'plt'), contextlib.redirect_stdout(io.StringIO()):
             pipeline.run_experiment(args)
-            config = json.loads((Path(folder) / 'tables/all/single/phone_F2/run_config.json').read_text())
+            config = json.loads((Path(folder) / 'endpoint_modes/enhanced/tables/all/single/phone_F2/run_config.json').read_text())
             self.assertEqual(config['metrics_schema_version'], 2)
             self.assertEqual(config['parameter_selection_set'], 'train')
             self.assertEqual(config['evaluation_protocol'], 'train_selected_reused_test')
             self.assertTrue(config['historical_test_exposure'])
             self.assertEqual(config['evaluated_files'], ['phone_F2'])
-            with (Path(folder) / 'tables/all/single/phone_F2/test_metrics.csv').open(encoding='utf-8-sig', newline='') as handle:
+            with (Path(folder) / 'endpoint_modes/enhanced/tables/all/single/phone_F2/test_metrics.csv').open(encoding='utf-8-sig', newline='') as handle:
                 fields = next(csv.reader(handle))
             self.assertNotIn('boundary_MAE_ms', fields)
             self.assertEqual(len(fields), len(set(key.casefold() for key in fields)))
 
 
 if __name__ == '__main__':
     unittest.main()
diff --git a/tools/README.md b/tools/README.md
index 35735df..aaab37a 100644
--- a/tools/README.md
+++ b/tools/README.md
@@ -1,12 +1,28 @@
 # Công cụ tạo lại artifacts
 
+## Hai chế độ endpoint (07/10/2026)
+
+Mặc định `enhanced`: ngưỡng native tạo seed; noise TRAIN và HIGH/LOW xác nhận, giữ speech; nối gap support dưới 200 ms và lọc span dưới 100 ms. `core` giữ quyết định native và chỉ nối gap support dưới 200 ms, không lọc duration hoặc padding FINAL; LOW/HIGH là null. Gap ước lượng đúng 200 ms được giữ riêng. TT1 dùng STE ≥ T, TT2 dùng Energy > T, TT3 giữ hướng high/low của Gaussian native. Đây là hai chế độ endpoint của cùng ba thuật toán; enhanced là phần bổ sung của dự án.
+
+```powershell
+python main_tt1.py --endpoint-mode core
+python main.py --evaluate-all --compare-endpoint-modes
+```
+
+Mỗi mode fit và khóa model độc lập trên bốn TRAIN trước đọc TEST. Kết quả mới ở `outputs/endpoint_modes/core/` và `outputs/endpoint_modes/enhanced/`; bảng so sánh ở `outputs/endpoint_modes/comparison/tables/`. Model schema 3 giữ policy/digest, metric schema 2 tiếp tục `mae_ms`/`rmse_ms`. Thiếu/thừa vùng làm primary mean toàn bộ file undefined; `valid_files_*` là thống kê subset riêng. TEST có `historical_test_exposure=true`, không phải holdout độc lập. Không chọn mode tốt hơn riêng cho từng WAV.
+
+Notebook dùng `MODE="enhanced"` mặc định cho bốn TEST figure và một illustration; luôn fit/khóa `MODELS` cả hai mode trước TEST, xuất 16 dòng tám WAV/mode và bảng bốn TEST/mode. TT2 có 200 TRAIN sweep rows mỗi mode. Core plot native T; Energy TT2 được chuẩn hóa chỉ ở bước hiển thị. Source digest và model lock digests độc lập kiểm tra nguồn/outputs và model; Restart Kernel → Run All → Save vẫn chạy độc lập.
+
+PPTX/PDF và ZIP Python cũ giữ nguyên previous version. Các bảng, noise và ví dụ HIGH/LOW bên dưới mô tả enhanced; không phải công thức quyết định FINAL của core. Xem [báo cáo hai mode](../reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md).
+
+
 Các main chạy bài tập không phụ thuộc thư mục này. Công cụ này giúp cập nhật slide và ZIP sau khi có kết quả mới hoặc bổ sung họ tên/MSSV.
 
 ## Mã nguồn Jupyter Notebook
 
 Các lệnh dưới đây dành cho người bảo trì dự án làm mới evidence và gói CODE ZIP đã audit. Notebook độc lập vẫn chạy bằng **Restart Kernel and Run All**, rồi **Save**, không cần module dự án hay builder/runner; yêu cầu runner chỉ thuộc audit/đóng gói của dự án.
 
 ```powershell
 .\.venv\Scripts\python.exe tools/build_notebooks.py
 .\.venv\Scripts\python.exe tools/run_notebooks.py
 ```
diff --git a/tools/build_notebooks.py b/tools/build_notebooks.py
index fdbbe39..e32a7a1 100644
--- a/tools/build_notebooks.py
+++ b/tools/build_notebooks.py
@@ -99,53 +99,53 @@ TT2_STAGE_COMMENTS = {
         ('labels', 'Count pooled speech TP/FP/FN; None labels contribute to none of these totals.'),
         ('denominator', 'Compute pooled F1; strict improvement keeps the smallest candidate W on a tie.'),
         ('@return', 'Return proposal diagnostics; downstream TRAIN FINAL-region calibration selects the reusable W.')],
 }
 
 
 def pipeline_stage_comments(algorithm: str) -> dict:
     decisions = {
         'tt1': 'TT1 compares normalized STE with the TRAIN binary-search threshold.',
         'tt2': 'TT2 estimates raw energy threshold per file; padded masks remain candidate diagnostics.',
-        'tt3': 'TT3 raw classification supports both directions; FINAL rejects explicit low/unknown models.'}
+        'tt3': 'TT3 raw classification supports both directions; enhanced FINAL rejects low/unknown models; core retains native high/low direction.'}
     comments = {
         'detect_regions': [
             ('@input', 'Input: frame features/supports, duration and fitted model; Output: FINAL regions, mask and diagnostics.'),
-            ('noise', decisions[algorithm] + ' Require TRAIN noise before inference.'),
+            ('noise', decisions[algorithm] + ' Enhanced requires TRAIN noise; core uses native decisions.'),
             ('candidate_regions', 'Retain candidate supports for inspection; only FINAL regions produce endpoint scores.'),
             ('base_threshold', 'Use the TRAIN normalized STE threshold and raw classifier seed.'
              if algorithm != 'tt2' else 'Normalize TT2 raw energy threshold and seed from unpadded raw energy decisions.'),
             ('low', 'Derive LOW/HIGH from the threshold and TRAIN silence noise statistics.'),
             ('high', 'Confirm with HIGH and continue above LOW; merge estimated support gaps below 200 ms.'),
             ('mode', 'The enhanced 100 ms support-span filter is a heuristic; core keeps native speech supports.')],
         'predict_and_score': [
             ('detected', 'Detect without LAB first; consult reference regions only after FINAL detection returns.'),
             ('region_scores', 'Score complete FINAL regions in time order; missing/extra regions leave primary MAE undefined.'),
             ('flags', 'Report missing/extra regions and large errors instead of hiding them in matched-only metrics.'),
             ('boundary', 'Inspect endpoint positions against audio bounds and reference silence for diagnostics.'),
             ('frames', 'Compute frame and tolerance-based event diagnostics separately from complete-region MAE.'),
             ('legacy_test_tuned', 'Retain provenance for imported historical models; fresh fits record TRAIN selection.'),
             ('@return', 'Output: FINAL detection, reference regions, scores, status and original detector diagnostics.')],
         'fit_training_model': [
             ('@input', 'Validate supplied TRAIN provenance before fitting; TEST reads occur after model locking.'),
             ('model', {'tt1': 'Fit the normalized STE binary-search threshold from labeled TRAIN frames.',
                        'tt2': 'Fit the candidate-frame histogram W proposal from TRAIN only.',
-                       'tt3': 'Fit robust centered/scaled Gaussian crossings; reject a non-high model before FINAL reuse.'}[algorithm])],
+                       'tt3': 'Fit robust centered/scaled Gaussian crossings; enhanced rejects non-high models; core preserves native direction.'}[algorithm])],
     }
     if algorithm == 'tt2':
         comments['fit_training_model'].extend([
-            ('candidate_frame_selected_W', 'Preserve candidate F1 diagnostics beside schema-v2 TRAIN noise and provenance.'),
+            ('candidate_frame_selected_W', 'Preserve candidate F1 diagnostics beside schema-v3 mode policy, enhanced TRAIN noise and provenance.'),
             ('selection', 'Calibrate shared W on TRAIN FINAL regions; candidate F1 remains a separate diagnostic.'),
             ('@return', 'Return the TRAIN-selected reusable model and all 200 W/file calibration rows.')])
     else:
         comments['fit_training_model'].append(
-            ('sweep_rows', 'Output: schema-v2 model with TRAIN silence noise and provenance; no W sweep for this method.'))
+            ('sweep_rows', 'Output: schema-v3 model with mode policy and TRAIN provenance; no W sweep for this method.'))
     return comments
 
 
 def make_cell(kind: str, source: str, index: int) -> dict:
     result = dict(cell_type=kind, id=f"cell-{index:03d}", metadata={},
                   source=clean_code(source).splitlines(keepends=True))
     if kind == "code":
         result.update(execution_count=None, outputs=[])
     return result
 
@@ -260,20 +260,21 @@ import math
 import wave
 import hashlib
 import json
 import html
 from pathlib import Path
 
 import matplotlib.pyplot as plt
 from IPython.display import HTML, display
 
 ALGORITHM = {algorithm!r}
+MODE = "enhanced"  # selected mode for the four plots and illustration
 FRAME_MS = 25.0
 HOP_MS = 10.0
 SAMPLE_ROUNDING = "nearest_integer_samples_python_round_ties_to_even"
 MIN_SILENCE_SECONDS = 0.200
 MIN_SPEECH_SECONDS = 0.100
 BOUNDARY_TOLERANCE_SECONDS = 0.100
 HISTOGRAM_W_TIE_PREFERENCE = 20.0
 PADDING_MS = 250.0
 PADDING_FRAMES = round(PADDING_MS / HOP_MS)
 FILE_ORDER = ("phone_F2", "phone_M2", "studio_F2", "studio_M2")
@@ -373,21 +374,25 @@ DATASET_MANIFEST = [dict(file=r["name"], split=r["split"],
                          wav_sha256=r["wav_sha256"], lab_sha256=r["lab_sha256"])
                     for r in ALL_RECORDS]
 display_table(DATASET_MANIFEST,
               [("file", "WAV/LAB stem"), ("split", "Split"),
                ("sample_rate_hz", "Fs (Hz)"), ("duration_s", "Duration (s)")],
               "Eight WAV/LAB pairs loaded from the separate dataset")
 '''
 
 
 FIT_MODEL = '''
-MODEL, TT2W_SWEEP_ROWS = fit_training_model(ALGORITHM, TRAIN_RECORDS)
+MODELS, TT2W_SWEEPS = {}, {}
+for endpoint_mode in ("core", "enhanced"):
+    MODELS[endpoint_mode], TT2W_SWEEPS[endpoint_mode] = fit_training_model(
+        ALGORITHM, TRAIN_RECORDS, endpoint_mode=endpoint_mode)
+MODEL, TT2W_SWEEP_ROWS = MODELS[MODE], TT2W_SWEEPS[MODE]
 '''
 
 
 CALIBRATE_W = '''
 # fit_training_model has selected FINAL W from supplied TRAIN records only.
 W_SELECTION = MODEL["W_selection_train"]
 display_table(MODEL["candidate_frame_selection_scores"],
               [("W", "TRAIN candidate W"), ("candidate_frame_f1", "Candidate frame F1"),
                ("tp", "TP"), ("fp", "FP"), ("fn", "FN")],
               f"TRAIN candidate-frame proposal: W={MODEL['candidate_frame_selected_W']:g}")
@@ -403,69 +408,85 @@ display_table(TT2W_SWEEP_ROWS,
                ("predicted_region_count", "FINAL regions"), ("status", "Status")],
               "200 TRAIN FINAL calibration rows; PRIMARY MAE is separate from tolerance diagnostics")
 '''
 
 
 LOCK_MODEL = '''
 def model_digest(model):
     return hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False,
                                      allow_nan=False, separators=(",", ":")).encode("utf-8")).hexdigest()
 
-MODEL_LOCK_DIGEST = model_digest(MODEL)
+MODEL_LOCK_DIGESTS = {mode: model_digest(model) for mode, model in MODELS.items()}
+MODEL_LOCK_DIGEST = MODEL_LOCK_DIGESTS[MODE]
 
 def assert_model_locked():
-    if model_digest(MODEL) != MODEL_LOCK_DIGEST:
-        raise ValueError("Frozen TRAIN model digest changed after calibration")
+    for mode, model in MODELS.items():
+        if model.get("endpoint_mode") != mode or model_digest(model) != MODEL_LOCK_DIGESTS[mode]:
+            raise ValueError("Frozen TRAIN model digest or mode changed after calibration")
+    if MODEL is not MODELS[MODE] or model_digest(MODEL) != MODEL_LOCK_DIGEST:
+        raise ValueError("Selected model alias changed after calibration")
 
 print("MODEL locked before TEST reads:", MODEL_LOCK_DIGEST)
 '''
 
 
 MODEL_DISPLAY = '''
 parameter_names = {parameter_names!r}
 parameter_rows = [dict(parameter=key, value=MODEL.get(key)) for key in parameter_names]
 parameter_rows.extend(dict(parameter=key, value=value)
-                      for key, value in MODEL["endpoint_noise"].items())
+                      for key, value in (MODEL["endpoint_noise"] or {{}}).items())
 display_table(parameter_rows, [("parameter", "Parameter"), ("value", "Freshly computed value")],
               "Training parameters and train-only noise calibration")
 '''
 
 
 EVALUATION = '''
-TEST_RESULTS = [predict_and_score(ALGORITHM, record, MODEL) for record in TEST_RECORDS]
+TEST_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in TEST_RECORDS]
+                        for mode, model in MODELS.items()}
 assert_model_locked()
-ALL_RESULTS = [predict_and_score(ALGORITHM, record, MODEL) for record in ALL_RECORDS]
+ALL_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in ALL_RECORDS]
+                       for mode, model in MODELS.items()}
 assert_model_locked()
+TEST_RESULTS, ALL_RESULTS = TEST_RESULTS_BY_MODE[MODE], ALL_RESULTS_BY_MODE[MODE]
 
 def metric_rows(records, results):
     return [dict(file=record["name"], split=record["split"], algorithm=ALGORITHM,
                  **result["metrics"])
             for record, result in zip(records, results)]
 
-TEST_METRIC_ROWS = metric_rows(TEST_RECORDS, TEST_RESULTS)
-ALL_METRIC_ROWS = metric_rows(ALL_RECORDS, ALL_RESULTS)
-TEST_SUMMARY = summarize(TEST_METRIC_ROWS)
+TEST_METRICS_BY_MODE = {mode: metric_rows(TEST_RECORDS, results) for mode, results in TEST_RESULTS_BY_MODE.items()}
+ALL_METRICS_BY_MODE = {mode: metric_rows(ALL_RECORDS, results) for mode, results in ALL_RESULTS_BY_MODE.items()}
+TEST_SUMMARIES_BY_MODE = {mode: summarize(rows) for mode, rows in TEST_METRICS_BY_MODE.items()}
+TEST_METRIC_ROWS = [row for rows in TEST_METRICS_BY_MODE.values() for row in rows]
+ALL_METRIC_ROWS = [row for rows in ALL_METRICS_BY_MODE.values() for row in rows]
+TEST_SUMMARY = TEST_SUMMARIES_BY_MODE[MODE]
 METRIC_COLUMNS = [
-    ("file", "File"), ("split", "Split"),
+    ("file", "File"), ("split", "Split"), ("endpoint_mode", "Mode"),
     ("ground_truth_region_count", "GT regions"), ("predicted_region_count", "Pred regions"),
     ("mae_ms", "Final MAE (ms)"), ("rmse_ms", "RMSE (ms)"), ("status", "Status"),
     ("start_error_ms", "Signed START error (ms)"), ("end_error_ms", "Signed END error (ms)"),
     ("gt_start_s", "GT START (s)"), ("gt_end_s", "GT END (s)"),
     ("predicted_start_s", "Pred START (s)"), ("predicted_end_s", "Pred END (s)")
 ]
-display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings: final confirmed boundaries")
+display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings in each mode: FINAL-region endpoints")
+THRESHOLD_ROWS = [dict(file=result["file"], endpoint_mode=mode,
+                      **{key:result["diagnostic"].get(key) for key in
+                         ("native_threshold", "native_threshold_units", "low_ste_threshold", "high_ste_threshold",
+                          "geometry", "minimum_speech_ms", "padding_stage")})
+                  for mode, results in ALL_RESULTS_BY_MODE.items() for result in results]
+display_table(THRESHOLD_ROWS, [(key,key) for key in THRESHOLD_ROWS[0]], "Both-mode threshold and geometry diagnostics")
 '''
 
 
 SUMMARY_DISPLAY = '''
-display_table(TEST_SUMMARY,
-              [("algorithm", "Algorithm"), ("files", "Files"),
+display_table([row for rows in TEST_SUMMARIES_BY_MODE.values() for row in rows],
+              [("algorithm", "Algorithm"), ("endpoint_mode", "Mode"), ("files", "Files"),
                ("evaluated_files", "Defined MAE files"), ("mean_file_mae_ms", "Mean MAE (ms)"),
                ("median_file_mae_ms", "Median (ms)"), ("min_file_mae_ms", "Min (ms)"),
                ("max_file_mae_ms", "Max (ms)"), ("mean_file_rmse_ms", "Mean file RMSE (ms)"),
                ("pooled_endpoint_rmse_ms", "Pooled endpoint RMSE (ms)"),
                ("region_count_correct_files", "Correct counts"),
                ("region_count_incorrect_files", "Incorrect counts"),
                ("mean_frame_f1", "Mean frame F1"), ("top_mae_files", "Highest MAE files"),
                ("evaluation_protocol", "Protocol")],
               "Summary of the four TEST recordings only")
 '''
@@ -478,41 +499,46 @@ def plot_record(record, result):
     diagnostic = result["diagnostic"]
     mae = result["metrics"]["mae_ms"]
     mae_text = f"{mae:.2f} ms" if mae is not None else "N/A"
     figure, axes = plt.subplots(2, 1, figsize=(12.5, 5.5), sharex=True,
                                gridspec_kw={"height_ratios": [1, 1.25]})
     time = [index / record["sample_rate"] for index in range(len(record["samples"]))]
     axes[0].plot(time, record["samples"], color="#444444", linewidth=0.6)
     axes[0].set_ylabel("PCM amplitude")
     axes[1].plot(features["centers"], features["ste_norm"], color="#263238",
                  linewidth=1, label="Normalized STE")
-    axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060",
-                   linestyle="--", linewidth=1.2, label="LOW")
-    axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700",
-                   linestyle=":", linewidth=1.4, label="HIGH")
+    if diagnostic["endpoint_mode"] == "core":
+        native = diagnostic["native_threshold"]
+        if diagnostic["native_threshold_units"] == "sum of squared samples":
+            peak = max(features["energy"], default=0.)
+            native = native / peak if peak else 0.
+        axes[1].axhline(native, color="#9b6700", linestyle=":", label="Native T (display normalized)")
+    else:
+        axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060", linestyle="--", label="LOW")
+        axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700", linestyle=":", label="HIGH")
     for axis in axes:
         for index, (start, end) in enumerate(result["ground_truth_regions"]):
             axis.axvspan(start, end, color="red", alpha=0.05)
             axis.axvline(start, color="red", linestyle="--", linewidth=1.25,
                         label="GT boundary" if index == 0 else None)
             axis.axvline(end, color="red", linestyle="--", linewidth=1.25)
         for index, (start, end) in enumerate(result["final_regions"]):
             axis.axvspan(start, end, color="#1769d2", alpha=0.11)
             axis.axvline(start, color="#1769d2", linewidth=1.4,
                         label="FINAL predicted boundary" if index == 0 else None)
             axis.axvline(end, color="#1769d2", linewidth=1.4)
         axis.grid(alpha=0.16)
         axis.set_xlim(0, record["duration"])
     axes[1].set_ylabel("Normalized STE")
     axes[1].set_xlabel("Time (s)")
     axes[1].legend(loc="upper right", fontsize=8, ncol=3)
-    figure.suptitle(f"{record['name']}.wav | Outer boundary MAE: {mae_text} | "
+    figure.suptitle(f"{record['name']}.wav | {MODE} | FINAL-region endpoint MAE: {mae_text} | "
                    f"{len(result['final_regions'])} speech regions")
     figure.tight_layout()
     plt.show()
     plt.close(figure)
 
 
 TEST_RECORDS_BY_FILE = {record["name"]: record for record in TEST_RECORDS}
 TEST_RESULTS_BY_FILE = {result["file"]: result for result in TEST_RESULTS}
 '''
 
@@ -690,92 +716,92 @@ def demo_one_file(filename="phone_F2"):
 '''
 
 
 def build_notebook(algorithm: str) -> dict:
     titles = {"tt1": "TT1 — Equal-confusion-area binary search",
               "tt2": "TT2 — Energy histogram threshold",
               "tt3": "TT3 — Gaussian energy distributions"}
     explanations = {
         "tt1": "Learn the normalized STE threshold from labeled TRAIN silence/speech by the source binary-search rule.",
         "tt2": "Estimate each recording's energy threshold from the first two histogram peaks. Show the TRAIN candidate-frame F1 proposal separately from global FINAL W calibration on the four TRAIN recordings.",
-        "tt3": "Fit population mean and standard deviation to labeled TRAIN normalized STE. Solve equal Gaussian densities in centered/scaled coordinates with an explicit 1e-9 sigma floor, stable quadratic roots and a log-density check; use the declared midpoint fallback if no valid crossing lies between the means. Raw fit/predict supports speech_direction='low', while the current FINAL HIGH/LOW energy hysteresis requires speech_direction='high' and explicitly rejects low or unknown directions during fitting and inference.",
+        "tt3": "Fit population mean and standard deviation to labeled TRAIN normalized STE. Solve equal Gaussian densities in centered/scaled coordinates with an explicit 1e-9 sigma floor, stable quadratic roots and a log-density check; use the declared midpoint fallback if no valid crossing lies between the means. Raw fit/predict supports speech_direction='low', core FINAL preserves that native direction; enhanced FINAL HIGH/LOW energy hysteresis requires speech_direction='high' and explicitly rejects low or unknown directions during fitting and inference.",
     }
     sections: list[tuple[str, str]] = []
     def md(source: str) -> None:
         sections.append(("markdown", source))
     def code(source: str) -> None:
         sections.append(("code", source))
 
     md(f"""# {titles[algorithm]}
 
 {explanations[algorithm]}
 
 This notebook contains all computation for one student's algorithm. Run the cells in order with Python 3, matplotlib and IPython. WAV/LAB input is supplied separately in `data/train/` and `data/test/`; edit `DATA_DIR` if needed. The notebook discovers these folders from its working directory and ancestors.
 
-The signal is framed with full 25 ms windows and 10 ms hops, using Python's nearest-sample rounding with ties to even. Energy is STE divided by frame size. Final regions require HIGH confirmation and continue above LOW. The 200 ms rule measures estimated gaps between active frame supports, and the 100 ms minimum is a support-span heuristic. Overlapping frames can bridge physical silence or retain brief impulses; these settings do not guarantee 200 ms of physical silence or 100 ms of voiced audio. Training and test results are labeled separately. Every number and plot below is recomputed from input WAV/LAB; no saved model or result is loaded.
+The signal is framed with full 25 ms windows and 10 ms hops, using Python's nearest-sample rounding with ties to even. Energy is STE divided by frame size. Default MODE=enhanced requires HIGH confirmation and continuation above LOW. Core uses native decisions without HIGH/LOW, final padding or duration filtering. The 200 ms rule measures estimated gaps between active frame supports; exact 200 ms is preserved. Enhanced alone uses the 100 ms support-span heuristic. Overlapping frames can bridge physical silence or retain brief impulses; these settings do not guarantee 200 ms of physical silence or 100 ms of voiced audio. Training and test results are labeled separately. Every number and plot below is recomputed from input WAV/LAB; no saved model or result is loaded.
 
 For standalone use, choose **Restart Kernel and Run All** and save the executed notebook so tables and plots stay visible; this notebook needs no project modules or generator/runner scripts to execute. Submit this `.ipynb` without bundling WAV or other signal files.
 
 Project maintainers refresh this repository's audited CODE ZIP by rebuilding with `tools/build_notebooks.py`, executing with `tools/run_notebooks.py` in fresh kernels, then checking saved evidence with `--validate-only`. That runner hashes ordered code-cell sources after removing its temporary audit cell. A code edit, including a comment, requires fresh runner execution before the repository's source-bound audit/packaging accepts it; this audit requirement is separate from standalone notebook execution.
 """)
     md("## Imports and fixed configuration\n\nOnly the standard library, matplotlib and IPython are used. Timing and endpoint rules are fixed.")
     code(CONFIG.format(algorithm=algorithm))
     md("## WAV and LAB input\n\nPCM decoding and interval validation are manual. `sil=0`; `v` and `uv` are speech. Optional Praat metadata lines are ignored after format validation.")
     code(functions("core/io_utils.py", "read_wav", "read_lab"))
     code(DATA_HELPERS)
     md("## Manual frame features\n\nEach full frame computes STE and mean absolute amplitude by sample loops. Normalization divides by the recording's maximum; an all-zero recording stays zero. The short tail is discarded.")
     code(manual_features())
     md("## LAB alignment and scoring\n\nLAB labels use the frame center and half-open intervals. Region MAE/RMSE score START and END of complete matched final regions. A missing or extra region leaves the primary MAE undefined; frame and tolerance-based boundary scores are additional diagnostics.\n\nFor multiple speech regions, \"outer\" refers to each final region's START/END; the metric does not collapse regions into a single global envelope.")
     code(functions("core/metrics.py", "frame_labels", "frame_metrics", "ground_truth_regions", "region_endpoint_metrics", "boundary_metrics"))
-    md("## Final endpoint confirmation\n\nThe noise floor is estimated from TRAIN silence only. HIGH confirms speech; LOW retains weak speech. The 200 ms estimated support-gap rule and 100 ms support-span filter are heuristics, without a guarantee about physical silence or voiced duration. Silence waiting time and TT2 candidate padding do not extend final boundaries.")
+    md("## Final endpoint confirmation\n\nIn enhanced mode the noise floor is estimated from TRAIN silence only. Core uses native decisions and merges internal support gaps below 200 ms. Enhanced HIGH confirms speech; LOW retains weak speech. The 200 ms estimated support-gap rule and 100 ms support-span filter are heuristics, without a guarantee about physical silence or voiced duration. Silence waiting time and TT2 candidate padding do not extend final boundaries.")
     code(functions("core/endpoints.py", "fit_noise_floor", "endpoint_thresholds", "hysteresis_regions", "regions_to_mask"))
     post_names = ("_validate", "mask_segments", "fill_short_internal_silences") if algorithm == "tt2" else ("_validate", "mask_segments")
     code(functions("core/postprocess.py", *post_names))
     md(f"## {titles[algorithm]} implementation\n\n{explanations[algorithm]}")
     helpers, fit_predict = algorithm_code(algorithm)
     code(helpers)
     code(fit_predict)
     md("## End-to-end detection and summary\n\nDetection uses features and the fitted model. Target LAB is consulted only after final regions have been computed, for scores and plot references.")
     prepared = source_function("app/pipeline.py", "prepare_records")
     prepared = prepared.replace("def prepare_records(audio_records, source_histogram=False):", "def prepare_records(audio_records):")
     prepared = prepared.replace("    Input: audio_records chứa waveform/Fs/LAB. source_histogram giữ tương\n    thích các điểm gọi cũ; mọi thuật toán hiện chỉ cần đặc trưng năng lượng.\n",
                                 "    Input: audio_records chứa waveform/Fs/LAB; dùng đặc trưng năng lượng.\n")
     code(prepared + "\n\n\n" + standalone_pipeline(algorithm))
     code(source_function("app/pipeline.py", "summarize"))
     if algorithm == "tt2":
         md("## Global W calibration rule\n\nEvaluate integer W=1…50 on the four TRAIN LABs using the actual FINAL endpoint pipeline. Prefer valid region counts, minimize worst per-file regret, then mean MAE; tied values prefer W=20. Historical TEST sweeps are prior development evidence only; they are not rerun for calibration.")
         code('W_CANDIDATES = tuple(float(w) for w in range(1, 51))\nERROR_EPS_MS = 1e-8\nPOLICY_FIELDS = ("endpoint_mode", "boundary_convention", "minimum_speech_ms", "minimum_silence_ms", "padding_stage")\n\n' + functions("app/weight_selection.py", "select_final_weight", "sweep_final_weights"))
     md("## Load four TRAIN input pairs\n\nTRAIN is read first. TEST WAV/LAB reads follow calibration and model locking.")
     code(LOAD_DATA)
-    md("## Fit fresh TRAIN parameters\n\nAll core model parameters and noise statistics are computed using the four TRAIN recordings.")
+    md("## Fit fresh TRAIN parameters\n\nBoth mode models are fit independently on the four TRAIN recordings; noise is calibrated only for enhanced.")
     code(FIT_MODEL)
     if algorithm == "tt2":
         md("### TRAIN FINAL W calibration\n\nShow all 50 candidates and 200 TRAIN rows. The original candidate-frame F1 proposal remains a separate diagnostic. The selected FINAL W is shared by all files.")
-        code(CALIBRATE_W)
+        code("for mode in ('core', 'enhanced'):\n    MODEL, TT2W_SWEEP_ROWS = MODELS[mode], TT2W_SWEEPS[mode]\n" + textwrap.indent(clean_code(CALIBRATE_W), "    ") + "\nMODEL, TT2W_SWEEP_ROWS = MODELS[MODE], TT2W_SWEEPS[MODE]")
     parameters = {
         "tt1": ["threshold", "silence_count", "speech_count", "overlap_low", "overlap_high", "iterations", "stop_reason", "area_residual", "overlap_silence_count", "overlap_speech_count"],
         "tt2": ["candidate_frame_selected_W", "candidate_frame_f1", "candidate_cleanup_records", "W", "finalW", "tie_preference_W", "bins", "smooth_radius", "padding_ms", "padding_frames"],
         "tt3": ["muSil", "stdSil", "muSp", "stdSp", "silence_count", "speech_count", "threshold", "threshold_rule", "speech_direction", "sigma_floor", "sigma_was_floored"],
     }
     code(MODEL_DISPLAY.format(parameter_names=parameters[algorithm]))
-    md("## Lock TRAIN model, then load TEST\n\nThe model digest is captured before TEST input reads and checked after scoring. Schema 2 uses `parameter_selection_set=train`, `evaluation_protocol=train_selected_reused_test`, and `historical_test_exposure=true`: these TEST recordings were seen during earlier development. The eight-file manifest retains WAV/LAB hashes and split provenance.")
+    md("## Lock TRAIN model, then load TEST\n\nBoth mode model digests are captured before TEST input reads and checked after scoring. Schema 3 model policy with schema 2 metrics uses `parameter_selection_set=train`, `evaluation_protocol=train_selected_reused_test`, and `historical_test_exposure=true`: these TEST recordings were seen during earlier development. The eight-file manifest retains WAV/LAB hashes and split provenance.")
     code(LOCK_MODEL)
     code(LOAD_TEST)
     md("## Computed algorithm illustration\n\nThe illustration uses the features and statistics calculated in this run.")
     code({"tt1": TT1_ILLUSTRATION, "tt2": TT2_ILLUSTRATION, "tt3": TT3_ILLUSTRATION}[algorithm])
     md("## Four TEST results\n\nThe main table scores the final confirmed regions. START/END columns are in seconds; MAE/RMSE are in milliseconds.")
     code(EVALUATION)
     md("### TEST summary\n\nMean, median, minimum, maximum, count correctness and highest-error files describe only the four TEST recordings.")
     code(SUMMARY_DISPLAY)
     md("## All eight input files\n\nThis separate table includes TRAIN and TEST with explicit split labels. TRAIN results reuse the model fitted from TRAIN and therefore describe its training fit.")
     code('display_table(ALL_METRIC_ROWS, METRIC_COLUMNS, "All eight files: TRAIN and TEST shown explicitly")')
-    md("## Four inline TEST figures\n\nRed indicates LAB ground truth, blue indicates final predicted regions. Waveform and normalized STE share the same time axis. LOW/HIGH are the actual final confirmation thresholds. Each recording has its own figure cell.")
+    md("## Four inline TEST figures\n\nRed indicates LAB ground truth, blue indicates final predicted regions. Waveform and normalized STE share the same time axis. Enhanced LOW/HIGH are actual confirmation thresholds; core plots native T and exports LOW/HIGH as null. Each recording has its own figure cell.")
     code(PLOTTING)
     for filename in ("phone_F2", "phone_M2", "studio_F2", "studio_M2"):
         md(f"### {filename}.wav")
         code(f'plot_record(TEST_RECORDS_BY_FILE["{filename}"], TEST_RESULTS_BY_FILE["{filename}"])')
     md("## Optional single-file demonstration\n\nAfter running all previous cells, call `demo_one_file` with a dataset stem or WAV path. It uses the current model and performs no parameter tuning.")
     code(OPTIONAL_DEMO)
     return dict(nbformat=4, nbformat_minor=5,
                 metadata=dict(kernelspec=dict(display_name="Python 3", language="python", name="python3"),
                               language_info=dict(name="python", file_extension=".py", mimetype="text/x-python",
                                                  codemirror_mode=dict(name="ipython", version=3), pygments_lexer="ipython3")),
diff --git a/tools/run_notebooks.py b/tools/run_notebooks.py
index 9efa878..79fdc15 100644
--- a/tools/run_notebooks.py
+++ b/tools/run_notebooks.py
@@ -1,53 +1,63 @@
 """Execute the three standalone notebooks and package only verified notebook source.
 
 This runs notebooks in fresh kernels and retains genuine output in each .ipynb.
 The audit is performed outside their submitted code; no saved results are fed
 into inference. Existing Python benchmark artifacts are read only for comparison.
 """
 from __future__ import annotations
 
 import argparse
+import copy
+import os
 import ast
 import base64
 import csv
 import hashlib
 import json
 import math
 import re
 import sys
 import zipfile
 from pathlib import Path
 
 import nbformat
 from jupyter_client import KernelManager
 from nbclient import NotebookClient
 
 ROOT = Path(__file__).resolve().parents[1]
 # External auditing uses the current Python selection helper. Direct script
 # launch otherwise places only tools/ on sys.path, unlike module launch.
 if str(ROOT) not in sys.path:
     sys.path.insert(0, str(ROOT))
+from app.config import endpoint_mode_root
 NOTEBOOK_DIR = ROOT / 'notebooks'
 TEST_NAMES = ('phone_F2', 'phone_M2', 'studio_F2', 'studio_M2')
 TRAIN_NAMES = ('phone_F1', 'phone_M1', 'studio_F1', 'studio_M1')
 AUDIT_PREFIX = '__ENDPOINT_NOTEBOOK_AUDIT__'
 
 AUDIT_CELL = r'''
 import json
 assert_model_locked()
 def _compact_result(result):
     return {key: result[key] for key in (
         'file', 'algorithm', 'metrics', 'final_regions', 'ground_truth_regions',
         'predicted_boundaries', 'ground_truth_boundaries', 'diagnostic')}
 _audit = {
     'algorithm': ALGORITHM,
+    'selected_mode': MODE,
+    'models': MODELS,
+    'model_lock_digests': MODEL_LOCK_DIGESTS,
+    'tt2_w_sweeps': TT2W_SWEEPS,
+    'test_results_by_mode': {mode: [_compact_result(result) for result in results] for mode, results in TEST_RESULTS_BY_MODE.items()},
+    'all_results_by_mode': {mode: [_compact_result(result) for result in results] for mode, results in ALL_RESULTS_BY_MODE.items()},
+    'test_summaries_by_mode': TEST_SUMMARIES_BY_MODE,
     'model': MODEL,
     'model_lock_digest': MODEL_LOCK_DIGEST,
     'tt2_w_sweep_rows': TT2W_SWEEP_ROWS,
     'test_results': [_compact_result(result) for result in TEST_RESULTS],
     'all_results': [_compact_result(result) for result in ALL_RESULTS],
     'test_summary': TEST_SUMMARY,
     'dataset_manifest': DATASET_MANIFEST,
 }
 print('__ENDPOINT_NOTEBOOK_AUDIT__' + json.dumps(_audit, ensure_ascii=False, allow_nan=False))
 '''
@@ -76,21 +86,21 @@ def code_source_digest(notebook):
                if cell.cell_type == 'code' and cell.source != AUDIT_CELL]
     payload = json.dumps(sources, ensure_ascii=False, separators=(',', ':'))
     return hashlib.sha256(payload.encode('utf-8')).hexdigest()
 
 
 def audit_metric_keys(scores, label, require_primary=True):
     if len(scores) != len({key.casefold() for key in scores}):
         raise ValueError(f'{label}: duplicate casefold metric keys')
     if (require_primary and 'mae_ms' not in scores) or 'boundary_MAE_ms' in scores:
         raise ValueError(f'{label}: PRIMARY MAE must use mae_ms without a boundary alias')
-    if any(key.startswith('boundary_') and not key.startswith('boundary_inside_') for key in scores):
+    if any(key.startswith('boundary_') and key != 'boundary_convention' and not key.startswith('boundary_inside_') for key in scores):
         raise ValueError(f'{label}: tolerance metrics must use tolerance_boundary_ prefix')
 
 
 def audit_model_protocol(model, locked_digest):
     if 'W_selection_test' in model:
         raise ValueError('New models cannot contain legacy TEST W selection')
     if model.get('schema_version') not in (2, 3):
         raise ValueError('Model schema_version: expected schema2/3 TRAIN protocol')
     if model['schema_version'] == 3:
         mode = model.get('endpoint_mode')
@@ -109,20 +119,31 @@ def audit_model_protocol(model, locked_digest):
         if 'W_selection_train' in model:
             selection = model['W_selection_train']
             policy_keys = ('endpoint_mode', 'boundary_convention', 'minimum_speech_ms',
                            'minimum_silence_ms', 'padding_stage')
             if any(selection.get(key) != model.get(key) for key in policy_keys):
                 raise ValueError('TRAIN W selection policy differs from model policy')
             if any(model.get(key) != selection.get('selected_W') for key in ('W', 'finalW')):
                 raise ValueError('TRAIN selected W differs from locked model')
             if selection.get('calibration_digest') != model.get('calibration_digest'):
                 raise ValueError('TRAIN selection calibration digest differs from model')
+        declared = model.get('calibration_digest')
+        if not isinstance(declared, str) or not re.fullmatch('[0-9a-f]{64}', declared):
+            raise ValueError('Model calibration digest must be a nonempty SHA256')
+        payload = copy.deepcopy(model)
+        payload.pop('calibration_digest', None)
+        if 'W_selection_train' in payload:
+            payload['W_selection_train'].pop('calibration_digest', None)
+        computed = hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False,
+                                             allow_nan=False).encode('utf-8')).hexdigest()
+        if computed != declared:
+            raise ValueError('Model calibration digest differs from self-excluded calibration')
     expected = dict(metrics_schema_version=2,
                     parameter_selection_set='train', evaluation_protocol='train_selected_reused_test',
                     historical_test_exposure=True)
     for key, value in expected.items():
         if model.get(key) != value:
             raise ValueError(f'Model {key}: expected schema2 TRAIN protocol ({value})')
     if set(model.get('training_files', [])) != set(TRAIN_NAMES) or len(model.get('training_files', [])) != 4:
         raise ValueError('Model training_files must contain exactly four TRAIN names')
     if model_digest(model) != locked_digest:
         raise ValueError('Frozen TRAIN model lock digest differs after TEST/ALL scoring')
@@ -157,21 +178,22 @@ def audit_train_sweep(audit):
     if (selection.get('selection_set') != 'train'
             or selection.get('evaluation_protocol') != 'train_final_calibration'
             or set(selection.get('evaluated_files', [])) != set(TRAIN_NAMES)
             or len(selection.get('evaluated_files', [])) != 4):
         raise ValueError('TT2 selection must use exactly four TRAIN files and TRAIN FINAL calibration')
     if selection.get('candidate_W') != list(range(1, 51)) or selection.get('tie_preference_W') != 20:
         raise ValueError('TT2 selection requires integer W1…50 and declared tie preference W20')
     keys = {(row['filename'], row['W']) for row in rows}
     if keys != {(name, float(w)) for name in TRAIN_NAMES for w in range(1, 51)} or len(keys) != 200:
         raise ValueError('TT2 TRAIN sweep rows must be unique and cover all 200 file/W pairs')
-    target = ROOT / 'outputs/tables/tt2_w_selection'
+    target = ((endpoint_mode_root(model['endpoint_mode'], ROOT / 'outputs') / 'tables/tt2_w_selection')
+              if model.get('schema_version') == 3 else ROOT / 'outputs/tables/tt2_w_selection')
     reference = read_csv(target / 'sweep.csv')
     if len(reference) != 200:
         raise ValueError('Python TRAIN sweep benchmark needs 200 rows; regenerate schema2 artifacts')
     reference = {(row['filename'], float(row['W'])): row for row in reference}
     if set(reference) != keys:
         raise ValueError('Python TRAIN sweep file/W manifest differs')
     for row in rows:
         baseline = reference[row['filename'], row['W']]
         if set(row) != set(baseline):
             raise ValueError('TRAIN sweep columns differ; regenerate schema2 artifacts')
@@ -208,20 +230,26 @@ def audit_test_summary(algorithm, results, summary_rows):
     if not isinstance(summary_rows, list) or len(summary_rows) != 1:
         raise ValueError(f'{algorithm}: need one captured TEST summary row')
     summary = summary_rows[0]
     audit_metric_keys(summary, f'{algorithm}/TEST summary', require_primary=False)
     if (summary.get('metrics_schema_version') != 2
             or summary.get('evaluation_protocol') != 'train_selected_reused_test'
             or summary.get('historical_test_exposure') is not True):
         raise ValueError(f'{algorithm}: TEST summary must disclose schema2 reused TEST protocol')
     if summary.get('algorithm') != algorithm:
         raise ValueError(f'{algorithm}: wrong algorithm in TEST summary')
+    if 'endpoint_mode' in summary:
+        from app.pipeline import summarize
+        mode = summary['endpoint_mode']
+        expected = summarize([dict(file=result['file'],algorithm=algorithm,**result['metrics']) for result in results])
+        compare_structure(summary, expected[0], 'TEST summary')
+        return
     scores = [result['metrics'] for result in results]
     valid = [score for score in scores if score['mae_ms'] is not None]
     ordered = sorted(score['mae_ms'] for score in valid)
     count = len(valid)
     correct = sum(score['ground_truth_region_count'] == score['predicted_region_count']
                   for score in scores)
     expected_counts = {
         'files': len(scores), 'evaluated_files': count,
         'missing_speech_files': len(scores) - count,
         'region_count_correct_files': correct,
@@ -250,82 +278,111 @@ def audit_test_summary(algorithm, results, summary_rows):
             raise ValueError(f'{algorithm}/TEST summary: missing {key}')
         close_number(summary[key], expected, f'{algorithm}/TEST summary/{key}')
     highest = sorted((result for result in results if result['metrics']['mae_ms'] is not None),
                      key=lambda result: result['metrics']['mae_ms'], reverse=True)[:3]
     expected_top = '; '.join(f"{result['file']}:{result['metrics']['mae_ms']:.2f}ms" for result in highest)
     if summary.get('top_mae_files') != expected_top:
         raise ValueError(f'{algorithm}: highest-error TEST list differs from actual results')
 
 
 def audit_results(audit):
+    if 'models' in audit:
+        required = {'core', 'enhanced'}
+        for key in ('models', 'model_lock_digests', 'tt2_w_sweeps', 'test_results_by_mode', 'all_results_by_mode', 'test_summaries_by_mode'):
+            if set(audit.get(key, {})) != required:
+                raise ValueError('Both endpoint modes must have independent model/result evidence')
+        selected = audit.get('selected_mode')
+        if selected not in required:
+            raise ValueError('Invalid selected endpoint mode')
+        means = {}
+        for mode in ('core', 'enhanced'):
+            if audit['models'][mode].get('endpoint_mode') != mode:
+                raise ValueError('Model mode index disagrees with model')
+            item = dict(audit)
+            item.pop('models')
+            item.update(model=audit['models'][mode],model_lock_digest=audit['model_lock_digests'][mode],
+                        tt2_w_sweep_rows=audit['tt2_w_sweeps'][mode],test_results=audit['test_results_by_mode'][mode],
+                        all_results=audit['all_results_by_mode'][mode],test_summary=audit['test_summaries_by_mode'][mode])
+            means[mode] = audit_results(item)
+        for key, expected in (('model',audit['models'][selected]),('model_lock_digest',audit['model_lock_digests'][selected]),
+                              ('test_results',audit['test_results_by_mode'][selected]),('all_results',audit['all_results_by_mode'][selected]),
+                              ('test_summary',audit['test_summaries_by_mode'][selected]),('tt2_w_sweep_rows',audit['tt2_w_sweeps'][selected])):
+            compare_structure(audit.get(key),expected,'Selected mode alias/'+key)
+        return means[selected]
     algorithm = audit['algorithm']
     if algorithm not in ('tt1', 'tt2', 'tt3'):
         raise ValueError('Only three primary algorithms are submitted')
     model = audit['model']
     audit_model_protocol(model, audit.get('model_lock_digest'))
+    mode = model.get('endpoint_mode', 'enhanced')
+    output_root = endpoint_mode_root(mode, ROOT / 'outputs') if model.get('schema_version') == 3 else ROOT / 'outputs'
     test = audit['test_results']
     all_results = audit['all_results']
     if tuple(result['file'] for result in test) != TEST_NAMES:
         raise ValueError('Notebook must evaluate all four test WAVs in the declared order')
     expected_names = {path.stem for split in ('train', 'test')
                       for path in (ROOT / 'data' / split).glob('*.wav')}
     if len(all_results) != 8 or {result['file'] for result in all_results} != expected_names:
         raise ValueError('All-dataset evaluation must include eight unique WAVs')
     reference = {row['file']: row for row in read_csv(
-        ROOT / 'outputs/tables/all_all_dataset/test_metrics.csv') if row['algorithm'] == algorithm}
+        output_root / 'tables/all_all_dataset/test_metrics.csv') if row['algorithm'] == algorithm}
     for result in all_results + test:
         name = result['file']
         row = reference[name]
         if result['algorithm'] != algorithm:
             raise ValueError('Wrong algorithm in notebook result')
         scores = result['metrics']
         audit_metric_keys(scores, f'{algorithm}/{name}')
         if set(scores) != set(row) - {'file', 'split', 'algorithm'}:
             raise ValueError(f'{algorithm}/{name}: captured metric keys differ from schema2 benchmark')
         for key, value in scores.items():
             if key not in row:
                 raise ValueError(f'{algorithm}/{name}: missing schema2 benchmark metric {key}')
             if isinstance(value, bool):
                 if str(value).casefold() != row[key].casefold():
                     raise ValueError(f'{algorithm}/{name}/{key} differs')
             elif value is None or isinstance(value, (int, float)):
                 close_number(value, row[key], f'{algorithm}/{name}/{key}')
             elif str(value) != row[key]:
                 raise ValueError(f'{algorithm}/{name}/{key} differs')
-        diagnostic = json.loads((ROOT / f'outputs/diagnostics/{algorithm}/{name}.json').read_text(encoding='utf-8'))
+        if model.get('schema_version') == 3 and result['diagnostic'].get('endpoint_mode') != mode:
+            raise ValueError('Result endpoint mode disagrees with model')
+        diagnostic = json.loads((output_root / f'diagnostics/{algorithm}/{name}.json').read_text(encoding='utf-8'))
         compare_structure(result['final_regions'], diagnostic['final_regions'],
                           f'{algorithm}/{name}/final regions')
         compare_structure(result['predicted_boundaries'],
                           [edge for region in diagnostic['final_regions'] for edge in region],
                           f'{algorithm}/{name}/predicted boundaries')
+        if model.get('schema_version') == 3:
+            compare_structure(result['diagnostic'], diagnostic, f'{algorithm}/{name}/mode diagnostic')
         for key in ('low_ste_threshold', 'high_ste_threshold'):
             close_number(result['diagnostic'][key], diagnostic[key], f'{algorithm}/{name}/{key}', 1e-12)
-    original = json.loads((ROOT / f'outputs/models/{algorithm}.json').read_text(encoding='utf-8'))
+    original = json.loads((output_root / f'models/{algorithm}.json').read_text(encoding='utf-8'))
     audit_model_protocol(original, model_digest(original))
     compare_structure(model, original, f'{algorithm}/model/source/framing/noise')
     if algorithm == 'tt2':
         audit_train_sweep(audit)
     elif audit.get('tt2_w_sweep_rows') != []:
         raise ValueError('Non-histogram notebooks cannot contain a W sweep')
     manifest = audit['dataset_manifest']
     if len(manifest) != 8:
         raise ValueError('Need eight input provenance records')
     if {(entry['split'], entry['file']) for entry in manifest} != (
             {('train', name) for name in TRAIN_NAMES} | {('test', name) for name in TEST_NAMES}):
         raise ValueError('Input provenance must contain eight unique correctly split files')
     for entry in manifest:
         for extension, key in (('wav', 'wav_sha256'), ('lab', 'lab_sha256')):
             path = ROOT / 'data' / entry['split'] / f"{entry['file']}.{extension}"
             if hashlib.sha256(path.read_bytes()).hexdigest() != entry[key]:
                 raise ValueError(f'Input fingerprint differs: {path.name}')
     audit_test_summary(algorithm, test, audit.get('test_summary'))
-    saved_summary = [row for row in read_csv(ROOT / 'outputs/tables/all/summary.csv')
+    saved_summary = [row for row in read_csv(output_root / 'tables/all/summary.csv')
                      if row['algorithm'] == algorithm]
     if len(saved_summary) != 1:
         raise ValueError('Python TEST benchmark needs one summary per algorithm')
     if set(audit['test_summary'][0]) != set(saved_summary[0]):
         raise ValueError('TEST saved summary metric keys differ')
     for key, value in audit['test_summary'][0].items():
         expected = saved_summary[0][key]
         if isinstance(value, bool):
             if str(value).casefold() != expected.casefold():
                 raise ValueError(f'TEST saved summary/{key} differs')
@@ -401,20 +458,21 @@ def audit_notebook(notebook, filename):
 
 
 def execute_notebook(path):
     notebook = nbformat.read(path, as_version=4)
     # Re-execution always starts empty; a failed run does not overwrite the file.
     for cell in notebook.cells:
         if cell.cell_type == 'code':
             cell.outputs = []
             cell.execution_count = None
     notebook.cells.append(nbformat.v4.new_code_cell(AUDIT_CELL))
+    os.environ.pop('MPLBACKEND', None)  # fresh notebook kernels must render inline PNGs
     manager = KernelManager(kernel_name='python3')
     manager.kernel_spec.argv = [sys.executable, '-m', 'ipykernel_launcher', '-f', '{connection_file}']
     client = NotebookClient(notebook, km=manager, timeout=600,
                             resources={'metadata': {'path': str(path.parent)}},
                             allow_errors=False, record_timing=False)
     print(f'Executing {path.name} in a fresh kernel...', flush=True)
     try:
         notebook = client.execute()
     finally:
         if manager.has_kernel:
@@ -426,21 +484,21 @@ def execute_notebook(path):
                           if output.output_type == 'stream')
     marker = output_text.find(AUDIT_PREFIX)
     if marker < 0:
         raise ValueError('Execution completed without auditable numerical results')
     evidence = json.loads(output_text[marker + len(AUDIT_PREFIX):].strip())
     notebook.cells.pop()  # Do not submit the external verification cell.
     evidence['code_source_sha256'] = code_source_digest(notebook)
     notebook.metadata['endpoint_execution'] = evidence
     images, mean = audit_notebook(notebook, path.name)
     nbformat.write(notebook, path)
-    print(f'{path.name}: 8/8 benchmark matches; {images} embedded plots; test mean MAE {mean:.2f} ms.', flush=True)
+    print(f'{path.name}: 16/16 mode/file benchmark matches; {images} embedded plots; test mean MAE {mean if mean is not None else 'N/A'} ms.', flush=True)
 
 
 def package_notebooks(group_number=None):
     """Use documented STTNhom placeholder until the actual group index is supplied."""
     notebooks = [NOTEBOOK_DIR / f'THUAT_TOAN_{number}.ipynb' for number in range(1, 4)]
     for path in notebooks:
         audit_notebook(nbformat.read(path, as_version=4), path.name)
     group = f'{int(group_number):02d}' if group_number is not None else 'STTNhom'
     prefix = f'{group}-PhanDoanTiengNoiKhoangLang/'
     destination = ROOT / 'submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip'
@@ -463,18 +521,18 @@ def main():
     parser = argparse.ArgumentParser(description=__doc__)
     parser.add_argument('--validate-only', action='store_true', help='Check saved notebook outputs without running them')
     parser.add_argument('--group-number', type=int, help='Optional actual group index for STTnhom-TenDeTai folder naming')
     arguments = parser.parse_args()
     if arguments.group_number is not None and not 1 <= arguments.group_number <= 999:
         parser.error('--group-number must be between 1 and 999')
     for number in range(1, 4):
         path = NOTEBOOK_DIR / f'THUAT_TOAN_{number}.ipynb'
         if arguments.validate_only:
             images, mean = audit_notebook(nbformat.read(path, as_version=4), path.name)
-            print(f'{path.name}: saved outputs valid, {images} figures, test mean MAE {mean:.2f} ms.')
+            print(f'{path.name}: saved outputs valid, {images} figures, test mean MAE {mean if mean is not None else 'N/A'} ms.')
         else:
             execute_notebook(path)
     package_notebooks(arguments.group_number)
 
 
 if __name__ == '__main__':
     main()
Generated numeric/image artifacts remain in outputs/endpoint_modes and CODE ZIP; artifact_audit.json and task-5-report.md provide audit evidence. Notebook ordered code cell diffs follow; image base64/output serialization is inspected via saved notebook audit rather than dumped here.
diff --git "a/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\THUAT_TOAN_1.ipynb.oldcode.txt" "b/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\THUAT_TOAN_1.ipynb.newcode.txt"
index 23ea100..e32fe35 100644
--- "a/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\THUAT_TOAN_1.ipynb.oldcode.txt"
+++ "b/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\THUAT_TOAN_1.ipynb.newcode.txt"
@@ -2,20 +2,21 @@ import math
 import wave
 import hashlib
 import json
 import html
 from pathlib import Path
 
 import matplotlib.pyplot as plt
 from IPython.display import HTML, display
 
 ALGORITHM = 'tt1'
+MODE = "enhanced"  # selected mode for the four plots and illustration
 FRAME_MS = 25.0
 HOP_MS = 10.0
 SAMPLE_ROUNDING = "nearest_integer_samples_python_round_ties_to_even"
 MIN_SILENCE_SECONDS = 0.200
 MIN_SPEECH_SECONDS = 0.100
 BOUNDARY_TOLERANCE_SECONDS = 0.100
 HISTOGRAM_W_TIE_PREFERENCE = 20.0
 PADDING_MS = 250.0
 PADDING_FRAMES = round(PADDING_MS / HOP_MS)
 FILE_ORDER = ("phone_F2", "phone_M2", "studio_F2", "studio_M2")
@@ -746,45 +747,72 @@ def prepare_records(audio_records):
     records = []
     for base in audio_records:
         features = compute_features(base["samples"], base["sample_rate"],
                                     FRAME_MS, HOP_MS)
         record = dict(base, features=features,
                       labels=frame_labels(features["centers"], base["intervals"]))
         records.append(record)
     return records
 
 
+def algorithm_decision(algorithm: str, features: dict, params: dict) -> tuple[list[int], dict]:
+    """Return native unpadded decisions and thresholds without LAB or endpoint policy.
+
+    TT1/high TT3 include equality; low TT3 includes equality in the opposite
+    direction. TT2 uses strict raw Energy > threshold (context uses STE).
+    Existing TT2 padding diagnostics describe its candidate stage only.
+    """
+    if algorithm != ALGORITHM:
+        raise ValueError('This notebook contains only ' + ALGORITHM)
+    mask, diagnostic = (predict(features, params), dict(threshold=params['threshold']))
+    source_histogram = False and diagnostic.get('variant') == 'source'
+    diagnostic.update(native_threshold=params['threshold'], native_threshold_units='sum of squared samples' if source_histogram else 'normalized STE')
+    return (mask, diagnostic)
+
 def detect_regions(algorithm, features, duration, params):
     """Detect FINAL regions from features, duration and a fitted model."""
     # Input: frame features/supports, duration and fitted model; Output: FINAL regions, mask and diagnostics.
     if algorithm != ALGORITHM:
         raise ValueError('This notebook contains only ' + ALGORITHM)
-    # TT1 compares normalized STE with the TRAIN binary-search threshold. Require TRAIN noise before inference.
-    noise = params.get('endpoint_noise')
-    if noise is None:
+    # The enhanced 100 ms support-span filter is a heuristic; core keeps native speech supports.
+    mode = params.get('endpoint_mode', 'enhanced')
+    if mode not in ('core', 'enhanced'):
+        raise ValueError(f'Unknown endpoint_mode: {mode}')
+    # TT1 compares normalized STE with the TRAIN binary-search threshold. Enhanced requires TRAIN noise; core uses native decisions.
+    noise = params.get('endpoint_noise') if mode == 'enhanced' else None
+    if mode == 'enhanced' and noise is None:
         raise ValueError('Fitted model requires endpoint_noise; call fit_training_model on TRAIN before inference')
-    if False and params.get('speech_direction', 'high') != 'high':
+    if mode == 'enhanced' and False and (params.get('speech_direction', 'high') != 'high'):
         raise ValueError("FINAL endpoint detection requires TT3 speech_direction='high'; inverted/unknown directions are not supported by energy hysteresis")
-    mask, diagnostic = (predict(features, params), {'threshold': params['threshold']})
+    seed, diagnostic = algorithm_decision(algorithm, features, params)
+    source_histogram = False and params.get('variant', 'source') == 'source'
+    mask = pad_speech(seed, diagnostic['padding_frames']) if mode == 'enhanced' and source_histogram else seed
     # Retain candidate supports for inspection; only FINAL regions produce endpoint scores.
     candidate_regions = [(s, e) for s, e, state in mask_segments(mask, features['starts'], duration, features['ends']) if state]
-    source_histogram = False and params.get('variant', 'source') == 'source'
+    if mode == 'core':
+        final_regions = []
+        for start, end in candidate_regions:
+            if final_regions and start - final_regions[-1][1] < MIN_SILENCE_SECONDS - 1e-12:
+                final_regions[-1] = (final_regions[-1][0], end)
+            else:
+                final_regions.append((start, end))
+        mask = regions_to_mask(final_regions, features['starts'], features['ends'])
+        diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, low_ste_threshold=None, high_ste_threshold=None, endpoint_noise=None, minimum_speech_ms=0.0, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_mode=mode, geometry='union of active frame supports', final_padding_ms=0.0, padding_stage='excluded from core FINAL', endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding')
+        return dict(mask=mask, final_regions=final_regions, diagnostic=diagnostic, predicted_boundaries=[b for region in final_regions for b in region])
     # Use the TRAIN normalized STE threshold and raw classifier seed.
     base_threshold = params['threshold']
-    seed = mask
+    # Confirm with HIGH and continue above LOW; merge estimated support gaps below 200 ms.
     # Derive LOW/HIGH from the threshold and TRAIN silence noise statistics.
     low, high = endpoint_thresholds(base_threshold, noise, histogram=False)
-    # Confirm with HIGH and continue above LOW; merge estimated support gaps below 200 ms.
     final_regions = hysteresis_regions(features['ste_norm'], features['starts'], features['ends'], duration, low, high, MIN_SILENCE_SECONDS, MIN_SPEECH_SECONDS, seed_mask=seed)
     mask = regions_to_mask(final_regions, features['starts'], features['ends'])
-    diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, low_ste_threshold=low, high_ste_threshold=high, endpoint_noise=noise, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_policy='raw STE hysteresis; candidates/debug excluded; no fixed final padding')
-    # The 100 ms support-span filter is a heuristic; support bounds do not guarantee physical silence.
+    diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, endpoint_mode=mode, geometry='union of active frame supports', final_padding_ms=0.0, padding_stage='candidate diagnostics only' if source_histogram else 'none', low_ste_threshold=low, high_ste_threshold=high, endpoint_noise=noise, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_policy='raw STE hysteresis; candidates/debug excluded; no fixed final padding')
     return dict(mask=mask, final_regions=final_regions, diagnostic=diagnostic, predicted_boundaries=[b for region in final_regions for b in region])
 
 def predict_and_score(algorithm, record, params):
     """Invoke LAB-free detection, then score complete regions and frames.
 
     Input: algorithm, prepared annotated record, fitted TRAIN parameters.
     Output: detection plus reference regions, metrics and scoring status.
     LAB and filename enter only after detect_regions has returned.
     """
     if algorithm != ALGORITHM:
@@ -823,101 +851,119 @@ def predict_and_score(algorithm, record, params):
     scores.update(status='; '.join(dict.fromkeys(flags)) if flags else 'OK' if expected_regions or final_regions else 'both_no_speech', boundary_inside_silence_count=inside, boundary_inside_silence_far_count=far_inside)
     # Compute frame and tolerance-based event diagnostics separately from complete-region MAE.
     frames = frame_metrics(record['labels'], mask)
     events = boundary_metrics(expected_boundaries, predicted_boundaries, BOUNDARY_TOLERANCE_SECONDS)
     scores.update({f'frame_{key}': value for key, value in frames.items()})
     scores.update({f'tolerance_boundary_{key}': value for key, value in events.items() if key != 'pairs'})
     scores.update(gt_start_s=reference[0] if reference else None, gt_end_s=reference[1] if reference else None, predicted_start_s=predicted[0] if predicted else None, predicted_end_s=predicted[1] if predicted else None)
     # Retain provenance for imported historical models; fresh fits record TRAIN selection.
     legacy_test_tuned = False and 'W_selection_test' in params
     scores.update(metrics_schema_version=2, model_schema_version=params.get('schema_version', 1), parameter_selection_set='test' if legacy_test_tuned else params.get('parameter_selection_set', 'train'), evaluation_protocol='test_tuned_not_independent' if legacy_test_tuned else params.get('evaluation_protocol', 'train_selected_reused_test'), historical_test_exposure=True if legacy_test_tuned else params.get('historical_test_exposure', True))
+    scores.update(endpoint_mode=params.get('endpoint_mode', 'enhanced'), boundary_convention=params.get('boundary_convention', diagnostic.get('geometry')), minimum_speech_ms=diagnostic.get('minimum_speech_ms'), minimum_silence_ms=diagnostic.get('minimum_silence_ms'), padding_stage=diagnostic.get('padding_stage'), final_padding_ms=diagnostic.get('final_padding_ms'), frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, actual_frame_ms=record['features'].get('frame_ms'), actual_hop_ms=record['features'].get('hop_ms'), frame_samples=record['features'].get('frame_size'), hop_samples=record['features'].get('hop_size'))
     # Output: FINAL detection, reference regions, scores, status and original detector diagnostics.
     return dict(file=record['name'], algorithm=algorithm, mask=mask, metrics=scores, final_regions=final_regions, ground_truth_regions=expected_regions, region_pairs=region_scores['region_pairs'], predicted_boundaries=predicted_boundaries, ground_truth_boundaries=expected_boundaries, diagnostic=diagnostic)
 
-def fit_training_model(algorithm, train_records):
+def fit_training_model(algorithm, train_records, *, endpoint_mode='enhanced'):
     """Fit and lock parameters and FINAL W from supplied prepared TRAIN only.
 
     Input: prepared records with explicit split=train; array records need no
     path and support future folds. Known TEST/external paths are rejected.
-    Output: (schema-v2 model, FINAL W sweep rows), empty rows for other methods.
+    Output: (schema-v3 model, FINAL W sweep rows), empty rows for other methods.
     No files are loaded here, including during the histogram calibration.
-    TT3 must fit speech-high for the current FINAL energy hysteresis.
+    Enhanced TT3 must fit speech-high for FINAL energy hysteresis; core
+    retains either native Gaussian decision direction.
     """
     # Validate supplied TRAIN provenance before fitting; TEST reads occur after model locking.
     if algorithm != ALGORITHM:
         raise ValueError('This notebook contains only ' + ALGORITHM)
+    if endpoint_mode not in ('core', 'enhanced'):
+        raise ValueError(f'Unknown endpoint_mode: {endpoint_mode}')
     if not train_records:
         raise ValueError('fit_training_model requires TRAIN records')
     for record in train_records:
         if record.get('split') != 'train':
             raise ValueError('Training records require explicit TRAIN provenance (split=train)')
         if 'wav_path' in record and Path(record['wav_path']).resolve().parent != (DATA_ROOT / 'train').resolve():
             raise ValueError('Training record path must belong to TRAIN, never TEST/external')
     # Fit the normalized STE binary-search threshold from labeled TRAIN frames.
     model = fit(train_records)
-    model.update(schema_version=2, metrics_schema_version=2, parameter_selection_set='train', evaluation_protocol='train_selected_reused_test', historical_test_exposure=True, training_files=[record['name'] for record in train_records], frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, endpoint_noise=fit_noise_floor(train_records), endpoint_policy='hysteresis final regions; no fixed final padding', boundary_convention='union of active frame supports')
-    # Output: schema-v2 model with TRAIN silence noise and provenance; no W sweep for this method.
+    model.update(schema_version=3, metrics_schema_version=2, endpoint_mode=endpoint_mode, parameter_selection_set='train', evaluation_protocol='train_selected_reused_test', historical_test_exposure=True, training_files=[record['name'] for record in train_records], frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000, minimum_speech_ms=0.0 if endpoint_mode == 'core' else MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_noise=fit_noise_floor(train_records) if endpoint_mode == 'enhanced' else None, endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding' if endpoint_mode == 'core' else 'hysteresis final regions; no fixed final padding', feature_rule='normalized STE', decision_rule='STE <= threshold' if model.get('speech_direction') == 'low' else 'STE >= threshold', padding_stage='excluded from core FINAL' if endpoint_mode == 'core' else 'none', boundary_convention='union of active frame supports')
+    # Output: schema-v3 model with mode policy and TRAIN provenance; no W sweep for this method.
     sweep_rows = []
+    digest = hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False, allow_nan=False).encode('utf-8')).hexdigest()
+    model['calibration_digest'] = digest
     return (model, sweep_rows)
 
 def summarize(metrics):
     """Tổng hợp metric từng thuật toán, phân biệt mean file và pooled RMSE.
 
     Input: metrics là rows endpoint/frame của từng file. Output: rows mean
     MAE/RMSE, pooled endpoint RMSE, F1 và số file có metric không xác định;
-    metric không xác định được loại khỏi mean và được đếm rõ.
+    primary mean chỉ xác định khi mọi file hợp lệ; mean subset được ghi riêng.
     """
     rows = []
-    for algorithm in dict.fromkeys(row["algorithm"] for row in metrics):
-        selected = [row for row in metrics if row["algorithm"] == algorithm]
-        valid = [row for row in selected if row["mae_ms"] is not None]
+    for algorithm, mode in dict.fromkeys((row["algorithm"], row.get("endpoint_mode", "enhanced")) for row in metrics):
+        selected = [row for row in metrics if row["algorithm"] == algorithm and row.get("endpoint_mode", "enhanced") == mode]
+        valid = [row for row in selected if row["mae_ms"] is not None
+                 and row.get("ground_truth_region_count") == row.get("predicted_region_count")]
         squared=sum(row.get('endpoint_squared_error_ms2',(row['rmse_ms']**2)*2) for row in valid)
         error_count=sum(row.get('endpoint_error_count',2) for row in valid)
         ordered=sorted(row['mae_ms'] for row in valid)
         median=(ordered[len(ordered)//2] if len(ordered)%2 else (ordered[len(ordered)//2-1]+ordered[len(ordered)//2])/2) if ordered else None
         count_correct=sum(row.get('ground_truth_region_count')==row.get('predicted_region_count') for row in selected)
-        rows.append(dict(algorithm=algorithm, metrics_schema_version=2,
+        rows.append(dict(algorithm=algorithm, endpoint_mode=mode, metrics_schema_version=2,
                          files=len(selected), evaluated_files=len(valid),
                          missing_speech_files=len(selected) - len(valid),
-                         mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,
-                         mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,
-                         pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,
+                         mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,
+                         valid_files_mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,
+                         mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,
+                         valid_files_mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,
+                         pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count and len(valid)==len(selected) else None,
+                         valid_files_pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,
                          median_file_mae_ms=median,min_file_mae_ms=min(ordered) if ordered else None,max_file_mae_ms=max(ordered) if ordered else None,
                          region_count_correct_files=count_correct,region_count_incorrect_files=len(selected)-count_correct,
                          top_mae_files='; '.join(f"{r['file']}:{r['mae_ms']:.2f}ms" for r in sorted(valid,key=lambda r:r['mae_ms'],reverse=True)[:3]),
                          parameter_selection_set=selected[0].get('parameter_selection_set','train'),
                          evaluation_protocol=selected[0].get('evaluation_protocol','train_selected_reused_test'),
                          historical_test_exposure=selected[0].get('historical_test_exposure', True),
                          mean_frame_f1=sum(row["frame_f1"] for row in selected) / len(selected)))
     return rows
 
 DATA_ROOT = find_data_root(DATA_DIR)
 TRAIN_RECORDS = prepare_records(load_dataset_folder(DATA_ROOT, "train"))
 
-MODEL, TT2W_SWEEP_ROWS = fit_training_model(ALGORITHM, TRAIN_RECORDS)
+MODELS, TT2W_SWEEPS = {}, {}
+for endpoint_mode in ("core", "enhanced"):
+    MODELS[endpoint_mode], TT2W_SWEEPS[endpoint_mode] = fit_training_model(
+        ALGORITHM, TRAIN_RECORDS, endpoint_mode=endpoint_mode)
+MODEL, TT2W_SWEEP_ROWS = MODELS[MODE], TT2W_SWEEPS[MODE]
 
 parameter_names = ['threshold', 'silence_count', 'speech_count', 'overlap_low', 'overlap_high', 'iterations', 'stop_reason', 'area_residual', 'overlap_silence_count', 'overlap_speech_count']
 parameter_rows = [dict(parameter=key, value=MODEL.get(key)) for key in parameter_names]
 parameter_rows.extend(dict(parameter=key, value=value)
-                      for key, value in MODEL["endpoint_noise"].items())
+                      for key, value in (MODEL["endpoint_noise"] or {}).items())
 display_table(parameter_rows, [("parameter", "Parameter"), ("value", "Freshly computed value")],
               "Training parameters and train-only noise calibration")
 
 def model_digest(model):
     return hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False,
                                      allow_nan=False, separators=(",", ":")).encode("utf-8")).hexdigest()
 
-MODEL_LOCK_DIGEST = model_digest(MODEL)
+MODEL_LOCK_DIGESTS = {mode: model_digest(model) for mode, model in MODELS.items()}
+MODEL_LOCK_DIGEST = MODEL_LOCK_DIGESTS[MODE]
 
 def assert_model_locked():
-    if model_digest(MODEL) != MODEL_LOCK_DIGEST:
-        raise ValueError("Frozen TRAIN model digest changed after calibration")
+    for mode, model in MODELS.items():
+        if model.get("endpoint_mode") != mode or model_digest(model) != MODEL_LOCK_DIGESTS[mode]:
+            raise ValueError("Frozen TRAIN model digest or mode changed after calibration")
+    if MODEL is not MODELS[MODE] or model_digest(MODEL) != MODEL_LOCK_DIGEST:
+        raise ValueError("Selected model alias changed after calibration")
 
 print("MODEL locked before TEST reads:", MODEL_LOCK_DIGEST)
 
 assert_model_locked()
 TEST_RECORDS = prepare_records(load_dataset_folder(DATA_ROOT, "test"))
 TEST_RECORDS.sort(key=lambda r: FILE_ORDER.index(r["name"]) if r["name"] in FILE_ORDER else len(FILE_ORDER))
 ALL_RECORDS = TRAIN_RECORDS + TEST_RECORDS
 DATASET_MANIFEST = [dict(file=r["name"], split=r["split"],
                          sample_rate_hz=r["sample_rate"], duration_s=r["duration"],
                          wav_sha256=r["wav_sha256"], lab_sha256=r["lab_sha256"])
@@ -972,45 +1018,57 @@ if BINARY_TRACE:
     axes[0].axhline(MODEL["threshold"], color="blue", linestyle="--", label="Final T")
     axes[0].set(xlabel="Iteration", ylabel="Normalized STE threshold", title="Threshold updates")
     axes[0].legend()
     axes[1].plot(iterations, [row["area_before"] for row in BINARY_TRACE], "o-")
     axes[1].axhline(0, color="black", linewidth=0.7)
     axes[1].set(xlabel="Iteration", ylabel="Silence area - speech area", title="Confusion-area residual")
     figure.tight_layout()
     plt.show()
     plt.close(figure)
 
-TEST_RESULTS = [predict_and_score(ALGORITHM, record, MODEL) for record in TEST_RECORDS]
+TEST_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in TEST_RECORDS]
+                        for mode, model in MODELS.items()}
 assert_model_locked()
-ALL_RESULTS = [predict_and_score(ALGORITHM, record, MODEL) for record in ALL_RECORDS]
+ALL_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in ALL_RECORDS]
+                       for mode, model in MODELS.items()}
 assert_model_locked()
+TEST_RESULTS, ALL_RESULTS = TEST_RESULTS_BY_MODE[MODE], ALL_RESULTS_BY_MODE[MODE]
 
 def metric_rows(records, results):
     return [dict(file=record["name"], split=record["split"], algorithm=ALGORITHM,
                  **result["metrics"])
             for record, result in zip(records, results)]
 
-TEST_METRIC_ROWS = metric_rows(TEST_RECORDS, TEST_RESULTS)
-ALL_METRIC_ROWS = metric_rows(ALL_RECORDS, ALL_RESULTS)
-TEST_SUMMARY = summarize(TEST_METRIC_ROWS)
+TEST_METRICS_BY_MODE = {mode: metric_rows(TEST_RECORDS, results) for mode, results in TEST_RESULTS_BY_MODE.items()}
+ALL_METRICS_BY_MODE = {mode: metric_rows(ALL_RECORDS, results) for mode, results in ALL_RESULTS_BY_MODE.items()}
+TEST_SUMMARIES_BY_MODE = {mode: summarize(rows) for mode, rows in TEST_METRICS_BY_MODE.items()}
+TEST_METRIC_ROWS = [row for rows in TEST_METRICS_BY_MODE.values() for row in rows]
+ALL_METRIC_ROWS = [row for rows in ALL_METRICS_BY_MODE.values() for row in rows]
+TEST_SUMMARY = TEST_SUMMARIES_BY_MODE[MODE]
 METRIC_COLUMNS = [
-    ("file", "File"), ("split", "Split"),
+    ("file", "File"), ("split", "Split"), ("endpoint_mode", "Mode"),
     ("ground_truth_region_count", "GT regions"), ("predicted_region_count", "Pred regions"),
     ("mae_ms", "Final MAE (ms)"), ("rmse_ms", "RMSE (ms)"), ("status", "Status"),
     ("start_error_ms", "Signed START error (ms)"), ("end_error_ms", "Signed END error (ms)"),
     ("gt_start_s", "GT START (s)"), ("gt_end_s", "GT END (s)"),
     ("predicted_start_s", "Pred START (s)"), ("predicted_end_s", "Pred END (s)")
 ]
-display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings: final confirmed boundaries")
+display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings in each mode: FINAL-region endpoints")
+THRESHOLD_ROWS = [dict(file=result["file"], endpoint_mode=mode,
+                      **{key:result["diagnostic"].get(key) for key in
+                         ("native_threshold", "native_threshold_units", "low_ste_threshold", "high_ste_threshold",
+                          "geometry", "minimum_speech_ms", "padding_stage")})
+                  for mode, results in ALL_RESULTS_BY_MODE.items() for result in results]
+display_table(THRESHOLD_ROWS, [(key,key) for key in THRESHOLD_ROWS[0]], "Both-mode threshold and geometry diagnostics")
 
-display_table(TEST_SUMMARY,
-              [("algorithm", "Algorithm"), ("files", "Files"),
+display_table([row for rows in TEST_SUMMARIES_BY_MODE.values() for row in rows],
+              [("algorithm", "Algorithm"), ("endpoint_mode", "Mode"), ("files", "Files"),
                ("evaluated_files", "Defined MAE files"), ("mean_file_mae_ms", "Mean MAE (ms)"),
                ("median_file_mae_ms", "Median (ms)"), ("min_file_mae_ms", "Min (ms)"),
                ("max_file_mae_ms", "Max (ms)"), ("mean_file_rmse_ms", "Mean file RMSE (ms)"),
                ("pooled_endpoint_rmse_ms", "Pooled endpoint RMSE (ms)"),
                ("region_count_correct_files", "Correct counts"),
                ("region_count_incorrect_files", "Incorrect counts"),
                ("mean_frame_f1", "Mean frame F1"), ("top_mae_files", "Highest MAE files"),
                ("evaluation_protocol", "Protocol")],
               "Summary of the four TEST recordings only")
 
@@ -1022,41 +1080,46 @@ def plot_record(record, result):
     diagnostic = result["diagnostic"]
     mae = result["metrics"]["mae_ms"]
     mae_text = f"{mae:.2f} ms" if mae is not None else "N/A"
     figure, axes = plt.subplots(2, 1, figsize=(12.5, 5.5), sharex=True,
                                gridspec_kw={"height_ratios": [1, 1.25]})
     time = [index / record["sample_rate"] for index in range(len(record["samples"]))]
     axes[0].plot(time, record["samples"], color="#444444", linewidth=0.6)
     axes[0].set_ylabel("PCM amplitude")
     axes[1].plot(features["centers"], features["ste_norm"], color="#263238",
                  linewidth=1, label="Normalized STE")
-    axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060",
-                   linestyle="--", linewidth=1.2, label="LOW")
-    axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700",
-                   linestyle=":", linewidth=1.4, label="HIGH")
+    if diagnostic["endpoint_mode"] == "core":
+        native = diagnostic["native_threshold"]
+        if diagnostic["native_threshold_units"] == "sum of squared samples":
+            peak = max(features["energy"], default=0.)
+            native = native / peak if peak else 0.
+        axes[1].axhline(native, color="#9b6700", linestyle=":", label="Native T (display normalized)")
+    else:
+        axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060", linestyle="--", label="LOW")
+        axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700", linestyle=":", label="HIGH")
     for axis in axes:
         for index, (start, end) in enumerate(result["ground_truth_regions"]):
             axis.axvspan(start, end, color="red", alpha=0.05)
             axis.axvline(start, color="red", linestyle="--", linewidth=1.25,
                         label="GT boundary" if index == 0 else None)
             axis.axvline(end, color="red", linestyle="--", linewidth=1.25)
         for index, (start, end) in enumerate(result["final_regions"]):
             axis.axvspan(start, end, color="#1769d2", alpha=0.11)
             axis.axvline(start, color="#1769d2", linewidth=1.4,
                         label="FINAL predicted boundary" if index == 0 else None)
             axis.axvline(end, color="#1769d2", linewidth=1.4)
         axis.grid(alpha=0.16)
         axis.set_xlim(0, record["duration"])
     axes[1].set_ylabel("Normalized STE")
     axes[1].set_xlabel("Time (s)")
     axes[1].legend(loc="upper right", fontsize=8, ncol=3)
-    figure.suptitle(f"{record['name']}.wav | Outer boundary MAE: {mae_text} | "
+    figure.suptitle(f"{record['name']}.wav | {MODE} | FINAL-region endpoint MAE: {mae_text} | "
                    f"{len(result['final_regions'])} speech regions")
     figure.tight_layout()
     plt.show()
     plt.close(figure)
 
 
 TEST_RECORDS_BY_FILE = {record["name"]: record for record in TEST_RECORDS}
 TEST_RESULTS_BY_FILE = {result["file"]: result for result in TEST_RESULTS}
 
 plot_record(TEST_RECORDS_BY_FILE["phone_F2"], TEST_RESULTS_BY_FILE["phone_F2"])
diff --git "a/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\THUAT_TOAN_2.ipynb.oldcode.txt" "b/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\THUAT_TOAN_2.ipynb.newcode.txt"
index 65a9525..aab0a16 100644
--- "a/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\THUAT_TOAN_2.ipynb.oldcode.txt"
+++ "b/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\THUAT_TOAN_2.ipynb.newcode.txt"
@@ -2,20 +2,21 @@ import math
 import wave
 import hashlib
 import json
 import html
 from pathlib import Path
 
 import matplotlib.pyplot as plt
 from IPython.display import HTML, display
 
 ALGORITHM = 'tt2'
+MODE = "enhanced"  # selected mode for the four plots and illustration
 FRAME_MS = 25.0
 HOP_MS = 10.0
 SAMPLE_ROUNDING = "nearest_integer_samples_python_round_ties_to_even"
 MIN_SILENCE_SECONDS = 0.200
 MIN_SPEECH_SECONDS = 0.100
 BOUNDARY_TOLERANCE_SECONDS = 0.100
 HISTOGRAM_W_TIE_PREFERENCE = 20.0
 PADDING_MS = 250.0
 PADDING_FRAMES = round(PADDING_MS / HOP_MS)
 FILE_ORDER = ("phone_F2", "phone_M2", "studio_F2", "studio_M2")
@@ -897,46 +898,75 @@ def prepare_records(audio_records):
     records = []
     for base in audio_records:
         features = compute_features(base["samples"], base["sample_rate"],
                                     FRAME_MS, HOP_MS)
         record = dict(base, features=features,
                       labels=frame_labels(features["centers"], base["intervals"]))
         records.append(record)
     return records
 
 
+def algorithm_decision(algorithm: str, features: dict, params: dict) -> tuple[list[int], dict]:
+    """Return native unpadded decisions and thresholds without LAB or endpoint policy.
+
+    TT1/high TT3 include equality; low TT3 includes equality in the opposite
+    direction. TT2 uses strict raw Energy > threshold (context uses STE).
+    Existing TT2 padding diagnostics describe its candidate stage only.
+    """
+    if algorithm != ALGORITHM:
+        raise ValueError('This notebook contains only ' + ALGORITHM)
+    mask, diagnostic = predict(features, params)
+    if diagnostic['variant'] == 'source':
+        mask = [int(e > diagnostic['energy_threshold']) for e in features['energy']]
+    source_histogram = True and diagnostic.get('variant') == 'source'
+    diagnostic.update(native_threshold=diagnostic['energy_threshold'], native_threshold_units='sum of squared samples' if source_histogram else 'normalized STE')
+    return (mask, diagnostic)
+
 def detect_regions(algorithm, features, duration, params):
     """Detect FINAL regions from features, duration and a fitted model."""
     # Input: frame features/supports, duration and fitted model; Output: FINAL regions, mask and diagnostics.
     if algorithm != ALGORITHM:
         raise ValueError('This notebook contains only ' + ALGORITHM)
-    # TT2 estimates raw energy threshold per file; padded masks remain candidate diagnostics. Require TRAIN noise before inference.
-    noise = params.get('endpoint_noise')
-    if noise is None:
+    # The enhanced 100 ms support-span filter is a heuristic; core keeps native speech supports.
+    mode = params.get('endpoint_mode', 'enhanced')
+    if mode not in ('core', 'enhanced'):
+        raise ValueError(f'Unknown endpoint_mode: {mode}')
+    # TT2 estimates raw energy threshold per file; padded masks remain candidate diagnostics. Enhanced requires TRAIN noise; core uses native decisions.
+    noise = params.get('endpoint_noise') if mode == 'enhanced' else None
+    if mode == 'enhanced' and noise is None:
         raise ValueError('Fitted model requires endpoint_noise; call fit_training_model on TRAIN before inference')
-    if False and params.get('speech_direction', 'high') != 'high':
+    if mode == 'enhanced' and False and (params.get('speech_direction', 'high') != 'high'):
         raise ValueError("FINAL endpoint detection requires TT3 speech_direction='high'; inverted/unknown directions are not supported by energy hysteresis")
-    mask, diagnostic = predict(features, params)
+    seed, diagnostic = algorithm_decision(algorithm, features, params)
+    source_histogram = True and params.get('variant', 'source') == 'source'
+    mask = pad_speech(seed, diagnostic['padding_frames']) if mode == 'enhanced' and source_histogram else seed
     # Retain candidate supports for inspection; only FINAL regions produce endpoint scores.
     candidate_regions = [(s, e) for s, e, state in mask_segments(mask, features['starts'], duration, features['ends']) if state]
-    source_histogram = True and params.get('variant', 'source') == 'source'
+    if mode == 'core':
+        final_regions = []
+        for start, end in candidate_regions:
+            if final_regions and start - final_regions[-1][1] < MIN_SILENCE_SECONDS - 1e-12:
+                final_regions[-1] = (final_regions[-1][0], end)
+            else:
+                final_regions.append((start, end))
+        mask = regions_to_mask(final_regions, features['starts'], features['ends'])
+        diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, low_ste_threshold=None, high_ste_threshold=None, endpoint_noise=None, minimum_speech_ms=0.0, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_mode=mode, geometry='union of active frame supports', final_padding_ms=0.0, padding_stage='excluded from core FINAL', endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding')
+        return dict(mask=mask, final_regions=final_regions, diagnostic=diagnostic, predicted_boundaries=[b for region in final_regions for b in region])
     peak = max(features['energy'], default=0.0)
     # Normalize TT2 raw energy threshold and seed from unpadded raw energy decisions.
     base_threshold = diagnostic['energy_threshold'] / peak if source_histogram and peak > 0 else diagnostic['energy_threshold'] if not source_histogram else 0.0
-    seed = [int(e > diagnostic['energy_threshold']) for e in features['energy']] if source_histogram else mask
+    # Confirm with HIGH and continue above LOW; merge estimated support gaps below 200 ms.
     # Derive LOW/HIGH from the threshold and TRAIN silence noise statistics.
     low, high = endpoint_thresholds(base_threshold, noise, histogram=True)
-    # Confirm with HIGH and continue above LOW; merge estimated support gaps below 200 ms.
     final_regions = hysteresis_regions(features['ste_norm'], features['starts'], features['ends'], duration, low, high, MIN_SILENCE_SECONDS, MIN_SPEECH_SECONDS, seed_mask=seed)
     mask = regions_to_mask(final_regions, features['starts'], features['ends'])
-    diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, low_ste_threshold=low, high_ste_threshold=high, endpoint_noise=noise, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_policy='raw STE hysteresis; candidates/debug excluded; no fixed final padding')
-    # The 100 ms support-span filter is a heuristic; support bounds do not guarantee physical silence.
+    diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, endpoint_mode=mode, geometry='union of active frame supports', final_padding_ms=0.0, padding_stage='candidate diagnostics only' if source_histogram else 'none', low_ste_threshold=low, high_ste_threshold=high, endpoint_noise=noise, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_policy='raw STE hysteresis; candidates/debug excluded; no fixed final padding')
     return dict(mask=mask, final_regions=final_regions, diagnostic=diagnostic, predicted_boundaries=[b for region in final_regions for b in region])
 
 def predict_and_score(algorithm, record, params):
     """Invoke LAB-free detection, then score complete regions and frames.
 
     Input: algorithm, prepared annotated record, fitted TRAIN parameters.
     Output: detection plus reference regions, metrics and scoring status.
     LAB and filename enter only after detect_regions has returned.
     """
     if algorithm != ALGORITHM:
@@ -975,100 +1005,115 @@ def predict_and_score(algorithm, record, params):
     scores.update(status='; '.join(dict.fromkeys(flags)) if flags else 'OK' if expected_regions or final_regions else 'both_no_speech', boundary_inside_silence_count=inside, boundary_inside_silence_far_count=far_inside)
     # Compute frame and tolerance-based event diagnostics separately from complete-region MAE.
     frames = frame_metrics(record['labels'], mask)
     events = boundary_metrics(expected_boundaries, predicted_boundaries, BOUNDARY_TOLERANCE_SECONDS)
     scores.update({f'frame_{key}': value for key, value in frames.items()})
     scores.update({f'tolerance_boundary_{key}': value for key, value in events.items() if key != 'pairs'})
     scores.update(gt_start_s=reference[0] if reference else None, gt_end_s=reference[1] if reference else None, predicted_start_s=predicted[0] if predicted else None, predicted_end_s=predicted[1] if predicted else None)
     # Retain provenance for imported historical models; fresh fits record TRAIN selection.
     legacy_test_tuned = True and 'W_selection_test' in params
     scores.update(metrics_schema_version=2, model_schema_version=params.get('schema_version', 1), parameter_selection_set='test' if legacy_test_tuned else params.get('parameter_selection_set', 'train'), evaluation_protocol='test_tuned_not_independent' if legacy_test_tuned else params.get('evaluation_protocol', 'train_selected_reused_test'), historical_test_exposure=True if legacy_test_tuned else params.get('historical_test_exposure', True))
+    scores.update(endpoint_mode=params.get('endpoint_mode', 'enhanced'), boundary_convention=params.get('boundary_convention', diagnostic.get('geometry')), minimum_speech_ms=diagnostic.get('minimum_speech_ms'), minimum_silence_ms=diagnostic.get('minimum_silence_ms'), padding_stage=diagnostic.get('padding_stage'), final_padding_ms=diagnostic.get('final_padding_ms'), frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, actual_frame_ms=record['features'].get('frame_ms'), actual_hop_ms=record['features'].get('hop_ms'), frame_samples=record['features'].get('frame_size'), hop_samples=record['features'].get('hop_size'))
     # Output: FINAL detection, reference regions, scores, status and original detector diagnostics.
     return dict(file=record['name'], algorithm=algorithm, mask=mask, metrics=scores, final_regions=final_regions, ground_truth_regions=expected_regions, region_pairs=region_scores['region_pairs'], predicted_boundaries=predicted_boundaries, ground_truth_boundaries=expected_boundaries, diagnostic=diagnostic)
 
-def fit_training_model(algorithm, train_records):
+def fit_training_model(algorithm, train_records, *, endpoint_mode='enhanced'):
     """Fit and lock parameters and FINAL W from supplied prepared TRAIN only.
 
     Input: prepared records with explicit split=train; array records need no
     path and support future folds. Known TEST/external paths are rejected.
-    Output: (schema-v2 model, FINAL W sweep rows), empty rows for other methods.
+    Output: (schema-v3 model, FINAL W sweep rows), empty rows for other methods.
     No files are loaded here, including during the histogram calibration.
-    TT3 must fit speech-high for the current FINAL energy hysteresis.
+    Enhanced TT3 must fit speech-high for FINAL energy hysteresis; core
+    retains either native Gaussian decision direction.
     """
     # Validate supplied TRAIN provenance before fitting; TEST reads occur after model locking.
     if algorithm != ALGORITHM:
         raise ValueError('This notebook contains only ' + ALGORITHM)
+    if endpoint_mode not in ('core', 'enhanced'):
+        raise ValueError(f'Unknown endpoint_mode: {endpoint_mode}')
     if not train_records:
         raise ValueError('fit_training_model requires TRAIN records')
     for record in train_records:
         if record.get('split') != 'train':
             raise ValueError('Training records require explicit TRAIN provenance (split=train)')
         if 'wav_path' in record and Path(record['wav_path']).resolve().parent != (DATA_ROOT / 'train').resolve():
             raise ValueError('Training record path must belong to TRAIN, never TEST/external')
     # Fit the candidate-frame histogram W proposal from TRAIN only.
     model = fit(train_records, variant='source')
-    model.update(schema_version=2, metrics_schema_version=2, parameter_selection_set='train', evaluation_protocol='train_selected_reused_test', historical_test_exposure=True, training_files=[record['name'] for record in train_records], frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, endpoint_noise=fit_noise_floor(train_records), endpoint_policy='hysteresis final regions; no fixed final padding', boundary_convention='union of active frame supports')
+    model.update(schema_version=3, metrics_schema_version=2, endpoint_mode=endpoint_mode, parameter_selection_set='train', evaluation_protocol='train_selected_reused_test', historical_test_exposure=True, training_files=[record['name'] for record in train_records], frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000, minimum_speech_ms=0.0 if endpoint_mode == 'core' else MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_noise=fit_noise_floor(train_records) if endpoint_mode == 'enhanced' else None, endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding' if endpoint_mode == 'core' else 'hysteresis final regions; no fixed final padding', feature_rule='Energy (sum of squared samples)', decision_rule='Energy > threshold', padding_stage='excluded from core FINAL' if endpoint_mode == 'core' else 'candidate diagnostics only', boundary_convention='union of active frame supports')
     sweep_rows = []
-    # Preserve candidate F1 diagnostics beside schema-v2 TRAIN noise and provenance.
+    # Preserve candidate F1 diagnostics beside schema-v3 mode policy, enhanced TRAIN noise and provenance.
     model['candidate_frame_selected_W'] = model['W']
     model['candidate_frame_f1'] = model.pop('train_frame_f1')
     model['candidate_frame_selection_scores'] = [dict(W=row['W'], candidate_frame_f1=row['train_frame_f1'], **{key: value for key, value in row.items() if key not in ('W', 'train_frame_f1')}) for row in model.pop('selection_scores')]
     model['candidate_cleanup_records'] = {key: model.pop(key) for key in ('full_pipeline_records', 'predict_only_fallback_records')}
     model['candidate_frame_selection_applicable'] = True
     # Calibrate shared W on TRAIN FINAL regions; candidate F1 remains a separate diagnostic.
     selection, sweep_rows = sweep_final_weights(train_records, model, predict_and_score, tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE)
     model.update(W=selection['selected_W'], finalW=selection['selected_W'], tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE, W_selection_train=selection, parameter_rule=selection['selection_rule'])
+    digest = hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False, allow_nan=False).encode('utf-8')).hexdigest()
+    model['calibration_digest'] = digest
+    model['W_selection_train']['calibration_digest'] = digest
     # Return the TRAIN-selected reusable model and all 200 W/file calibration rows.
     return (model, sweep_rows)
 
 def summarize(metrics):
     """Tổng hợp metric từng thuật toán, phân biệt mean file và pooled RMSE.
 
     Input: metrics là rows endpoint/frame của từng file. Output: rows mean
     MAE/RMSE, pooled endpoint RMSE, F1 và số file có metric không xác định;
-    metric không xác định được loại khỏi mean và được đếm rõ.
+    primary mean chỉ xác định khi mọi file hợp lệ; mean subset được ghi riêng.
     """
     rows = []
-    for algorithm in dict.fromkeys(row["algorithm"] for row in metrics):
-        selected = [row for row in metrics if row["algorithm"] == algorithm]
-        valid = [row for row in selected if row["mae_ms"] is not None]
+    for algorithm, mode in dict.fromkeys((row["algorithm"], row.get("endpoint_mode", "enhanced")) for row in metrics):
+        selected = [row for row in metrics if row["algorithm"] == algorithm and row.get("endpoint_mode", "enhanced") == mode]
+        valid = [row for row in selected if row["mae_ms"] is not None
+                 and row.get("ground_truth_region_count") == row.get("predicted_region_count")]
         squared=sum(row.get('endpoint_squared_error_ms2',(row['rmse_ms']**2)*2) for row in valid)
         error_count=sum(row.get('endpoint_error_count',2) for row in valid)
         ordered=sorted(row['mae_ms'] for row in valid)
         median=(ordered[len(ordered)//2] if len(ordered)%2 else (ordered[len(ordered)//2-1]+ordered[len(ordered)//2])/2) if ordered else None
         count_correct=sum(row.get('ground_truth_region_count')==row.get('predicted_region_count') for row in selected)
-        rows.append(dict(algorithm=algorithm, metrics_schema_version=2,
+        rows.append(dict(algorithm=algorithm, endpoint_mode=mode, metrics_schema_version=2,
                          files=len(selected), evaluated_files=len(valid),
                          missing_speech_files=len(selected) - len(valid),
-                         mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,
-                         mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,
-                         pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,
+                         mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,
+                         valid_files_mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,
+                         mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,
+                         valid_files_mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,
+                         pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count and len(valid)==len(selected) else None,
+                         valid_files_pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,
                          median_file_mae_ms=median,min_file_mae_ms=min(ordered) if ordered else None,max_file_mae_ms=max(ordered) if ordered else None,
                          region_count_correct_files=count_correct,region_count_incorrect_files=len(selected)-count_correct,
                          top_mae_files='; '.join(f"{r['file']}:{r['mae_ms']:.2f}ms" for r in sorted(valid,key=lambda r:r['mae_ms'],reverse=True)[:3]),
                          parameter_selection_set=selected[0].get('parameter_selection_set','train'),
                          evaluation_protocol=selected[0].get('evaluation_protocol','train_selected_reused_test'),
                          historical_test_exposure=selected[0].get('historical_test_exposure', True),
                          mean_frame_f1=sum(row["frame_f1"] for row in selected) / len(selected)))
     return rows
 
 W_CANDIDATES = tuple(float(w) for w in range(1, 51))
 ERROR_EPS_MS = 1e-8
+POLICY_FIELDS = ("endpoint_mode", "boundary_convention", "minimum_speech_ms", "minimum_silence_ms", "padding_stage")
 
 def select_final_weight(rows,tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE):
     """Input: one MAE/count row per (W,file). Output: shared W and audit tables.
 
     Prefer valid region counts, then minimize the worst per-file loss relative
     to that file's own optimum, then mean MAE. Ties use the declared preference;
     if unavailable, choose the smallest W. No candidate/debug boundary is scored.
     """
     if not rows:raise ValueError('W selection needs evaluation rows')
+    policy={key:rows[0][key] for key in POLICY_FIELDS if key in rows[0]}
+    if any({key:row[key] for key in POLICY_FIELDS if key in row} != policy for row in rows):
+        raise ValueError('Each candidate W must use the same endpoint policy')
     grouped={}
     for row in rows:
         w=row['W'];name=row['filename'];mae=row['final_region_mae_ms']
         if not math.isfinite(w) or w<0 or (mae is not None and (not math.isfinite(mae) or mae<0)):
             raise ValueError('Invalid W or endpoint MAE')
         files=grouped.setdefault(w,{})
         if name in files:raise ValueError('Duplicate (W,filename) in selection')
         files[name]=row
     names=sorted(next(iter(grouped.values())))
     if any(set(files)!=set(names) for files in grouped.values()):
@@ -1098,94 +1143,120 @@ def select_final_weight(rows,tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE):
                     candidate['valid_files_mean_MAE_ms'] if candidate['valid_files_mean_MAE_ms'] is not None else math.inf)
         if chosen is None:chosen=candidate;best_objectives=objectives;continue
         better=False;tied=True
         for left,right in zip(objectives,best_objectives):
             if left==right or (math.isfinite(left) and math.isfinite(right) and abs(left-right)<=ERROR_EPS_MS):continue
             better=left<right;tied=False;break
         if tied:
             better=(candidate['W']!=tie_preference_W,candidate['W'])<(chosen['W']!=tie_preference_W,chosen['W'])
         if better:chosen=candidate;best_objectives=objectives
     shared=set.intersection(*(set(v['optimal_W']) for v in best_by_file.values()))
-    return dict(selected_W=chosen['W'],tie_preference_W=tie_preference_W,selected_summary=chosen,
+    return dict(**policy,selected_W=chosen['W'],tie_preference_W=tie_preference_W,selected_summary=chosen,
         summaries=summaries,best_by_file=best_by_file,shared_optimal_W=sorted(shared),
         candidate_W=sorted(grouped),selection_set='train',evaluation_protocol='train_final_calibration',
         selection_rule='valid regions; minimum worst per-file regret; mean MAE; declared W preference on ties; smallest W otherwise')
 
 
 def sweep_final_weights(records,model,predictor,candidates=W_CANDIDATES,
                         tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE):
     """Evaluate every W on all calibration files with the real endpoint pipeline.
 
     Input: annotated TRAIN records, fitted TRAIN/noise model, real predictor.
     Output: selection manifest and rows. Does not mutate records or model.
     """
     if not records:raise ValueError('W sweep needs annotated TRAIN recordings')
     if any(record.get('split')!='train' for record in records):
         raise ValueError('W sweep requires explicit TRAIN provenance (split=train)')
+    mode=model.get('endpoint_mode','enhanced')
+    if mode not in ('core','enhanced'):raise ValueError('Unknown endpoint_mode')
+    policy=dict(endpoint_mode=mode,
+        boundary_convention=model.get('boundary_convention','union of active frame supports'),
+        minimum_speech_ms=model.get('minimum_speech_ms',0. if mode=='core' else 100.),
+        minimum_silence_ms=model.get('minimum_silence_ms',model.get('minimum_internal_silence_ms',200.)),
+        padding_stage=model.get('padding_stage','excluded from core FINAL' if mode=='core' else 'candidate diagnostics only'))
     rows=[]
     for w in candidates:
         params=dict(model,W=float(w))
         for record in records:
             result=predictor('tt2',record,params);metrics=result['metrics'];diag=result['diagnostic']
-            rows.append(dict(filename=record['name'],W=float(w),
+            if diag.get('endpoint_mode','enhanced') != mode:
+                raise ValueError('Predictor endpoint_mode disagrees with calibration model')
+            if diag.get('geometry', policy['boundary_convention']) != policy['boundary_convention']:
+                raise ValueError('Predictor geometry disagrees with calibration boundary_convention')
+            for key in ('minimum_speech_ms','minimum_silence_ms','padding_stage'):
+                if key in diag and diag[key] != policy[key]:
+                    raise ValueError(f'Predictor {key} disagrees with calibration model')
+            rows.append(dict(**policy,filename=record['name'],W=float(w),
                 ground_truth_region_count=metrics['ground_truth_region_count'],predicted_region_count=metrics['predicted_region_count'],
                 final_region_mae_ms=metrics['mae_ms'],status=metrics['status'],
                 start_error_ms=metrics['start_error_ms'],end_error_ms=metrics['end_error_ms'],
                 energy_threshold=diag['energy_threshold'],
                 low_ste_threshold=diag['low_ste_threshold'],high_ste_threshold=diag['high_ste_threshold'],
                 raw_speech_frames=diag['raw_speech_frames'],candidate_region_count=len(diag['candidate_regions']),
                 final_regions=str(result['final_regions'])))
     result=select_final_weight(rows,tie_preference_W)
     result.update(evaluated_files=[record['name'] for record in records],
-                  endpoint_policy='fixed raw STE hysteresis; final START/END only; no padding endpoints',
+                  endpoint_policy=model.get('endpoint_policy','fixed raw STE hysteresis; final START/END only; no padding endpoints'),
                   note='W was calibrated using these TRAIN LABs; TEST has historical exposure and is reused for scoring, so no holdout independence is claimed.')
     return result,rows
 
 DATA_ROOT = find_data_root(DATA_DIR)
 TRAIN_RECORDS = prepare_records(load_dataset_folder(DATA_ROOT, "train"))
 
-MODEL, TT2W_SWEEP_ROWS = fit_training_model(ALGORITHM, TRAIN_RECORDS)
+MODELS, TT2W_SWEEPS = {}, {}
+for endpoint_mode in ("core", "enhanced"):
+    MODELS[endpoint_mode], TT2W_SWEEPS[endpoint_mode] = fit_training_model(
+        ALGORITHM, TRAIN_RECORDS, endpoint_mode=endpoint_mode)
+MODEL, TT2W_SWEEP_ROWS = MODELS[MODE], TT2W_SWEEPS[MODE]
 
-# fit_training_model has selected FINAL W from supplied TRAIN records only.
-W_SELECTION = MODEL["W_selection_train"]
-display_table(MODEL["candidate_frame_selection_scores"],
-              [("W", "TRAIN candidate W"), ("candidate_frame_f1", "Candidate frame F1"),
-               ("tp", "TP"), ("fp", "FP"), ("fn", "FN")],
-              f"TRAIN candidate-frame proposal: W={MODEL['candidate_frame_selected_W']:g}")
-display_table(W_SELECTION["summaries"],
-              [("W", "W"), ("invalid_files", "Invalid files"),
-               ("mean_MAE_ms", "Mean final MAE (ms)"), ("max_MAE_ms", "Max MAE (ms)"),
-               ("max_regret_ms", "Worst per-file regret (ms)")],
-              f"TRAIN FINAL calibration: all W=1…50; selected W={MODEL['W']:g}; tie preference W20")
-display_table(TT2W_SWEEP_ROWS,
-              [("filename", "TRAIN file"), ("W", "W"),
-               ("final_region_mae_ms", "FINAL region MAE (ms)"),
-               ("ground_truth_region_count", "GT regions"),
-               ("predicted_region_count", "FINAL regions"), ("status", "Status")],
-              "200 TRAIN FINAL calibration rows; PRIMARY MAE is separate from tolerance diagnostics")
+for mode in ('core', 'enhanced'):
+    MODEL, TT2W_SWEEP_ROWS = MODELS[mode], TT2W_SWEEPS[mode]
+    # fit_training_model has selected FINAL W from supplied TRAIN records only.
+    W_SELECTION = MODEL["W_selection_train"]
+    display_table(MODEL["candidate_frame_selection_scores"],
+                  [("W", "TRAIN candidate W"), ("candidate_frame_f1", "Candidate frame F1"),
+                   ("tp", "TP"), ("fp", "FP"), ("fn", "FN")],
+                  f"TRAIN candidate-frame proposal: W={MODEL['candidate_frame_selected_W']:g}")
+    display_table(W_SELECTION["summaries"],
+                  [("W", "W"), ("invalid_files", "Invalid files"),
+                   ("mean_MAE_ms", "Mean final MAE (ms)"), ("max_MAE_ms", "Max MAE (ms)"),
+                   ("max_regret_ms", "Worst per-file regret (ms)")],
+                  f"TRAIN FINAL calibration: all W=1…50; selected W={MODEL['W']:g}; tie preference W20")
+    display_table(TT2W_SWEEP_ROWS,
+                  [("filename", "TRAIN file"), ("W", "W"),
+                   ("final_region_mae_ms", "FINAL region MAE (ms)"),
+                   ("ground_truth_region_count", "GT regions"),
+                   ("predicted_region_count", "FINAL regions"), ("status", "Status")],
+                  "200 TRAIN FINAL calibration rows; PRIMARY MAE is separate from tolerance diagnostics")
+
+MODEL, TT2W_SWEEP_ROWS = MODELS[MODE], TT2W_SWEEPS[MODE]
 
 parameter_names = ['candidate_frame_selected_W', 'candidate_frame_f1', 'candidate_cleanup_records', 'W', 'finalW', 'tie_preference_W', 'bins', 'smooth_radius', 'padding_ms', 'padding_frames']
 parameter_rows = [dict(parameter=key, value=MODEL.get(key)) for key in parameter_names]
 parameter_rows.extend(dict(parameter=key, value=value)
-                      for key, value in MODEL["endpoint_noise"].items())
+                      for key, value in (MODEL["endpoint_noise"] or {}).items())
 display_table(parameter_rows, [("parameter", "Parameter"), ("value", "Freshly computed value")],
               "Training parameters and train-only noise calibration")
 
 def model_digest(model):
     return hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False,
                                      allow_nan=False, separators=(",", ":")).encode("utf-8")).hexdigest()
 
-MODEL_LOCK_DIGEST = model_digest(MODEL)
+MODEL_LOCK_DIGESTS = {mode: model_digest(model) for mode, model in MODELS.items()}
+MODEL_LOCK_DIGEST = MODEL_LOCK_DIGESTS[MODE]
 
 def assert_model_locked():
-    if model_digest(MODEL) != MODEL_LOCK_DIGEST:
-        raise ValueError("Frozen TRAIN model digest changed after calibration")
+    for mode, model in MODELS.items():
+        if model.get("endpoint_mode") != mode or model_digest(model) != MODEL_LOCK_DIGESTS[mode]:
+            raise ValueError("Frozen TRAIN model digest or mode changed after calibration")
+    if MODEL is not MODELS[MODE] or model_digest(MODEL) != MODEL_LOCK_DIGEST:
+        raise ValueError("Selected model alias changed after calibration")
 
 print("MODEL locked before TEST reads:", MODEL_LOCK_DIGEST)
 
 assert_model_locked()
 TEST_RECORDS = prepare_records(load_dataset_folder(DATA_ROOT, "test"))
 TEST_RECORDS.sort(key=lambda r: FILE_ORDER.index(r["name"]) if r["name"] in FILE_ORDER else len(FILE_ORDER))
 ALL_RECORDS = TRAIN_RECORDS + TEST_RECORDS
 DATASET_MANIFEST = [dict(file=r["name"], split=r["split"],
                          sample_rate_hz=r["sample_rate"], duration_s=r["duration"],
                          wav_sha256=r["wav_sha256"], lab_sha256=r["lab_sha256"])
@@ -1227,45 +1298,57 @@ for label, value in (("M1", histogram_details["first_peak"]), ("M2", histogram_d
     if value is not None:
         axis.axvline(value, color="#7854a1", linestyle="--", label=f"{label}={value:.6g}")
 axis.axvline(energy_threshold, color="blue", linewidth=1.5, label=f"Energy T={energy_threshold:.6g}")
 axis.set(xlabel="Mean square energy = STE / frame_size", ylabel="Smoothed frame count",
          title=f"phone_F2.wav | First two peaks by energy | W={MODEL['W']:g}")
 axis.legend(fontsize=8)
 figure.tight_layout()
 plt.show()
 plt.close(figure)
 
-TEST_RESULTS = [predict_and_score(ALGORITHM, record, MODEL) for record in TEST_RECORDS]
+TEST_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in TEST_RECORDS]
+                        for mode, model in MODELS.items()}
 assert_model_locked()
-ALL_RESULTS = [predict_and_score(ALGORITHM, record, MODEL) for record in ALL_RECORDS]
+ALL_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in ALL_RECORDS]
+                       for mode, model in MODELS.items()}
 assert_model_locked()
+TEST_RESULTS, ALL_RESULTS = TEST_RESULTS_BY_MODE[MODE], ALL_RESULTS_BY_MODE[MODE]
 
 def metric_rows(records, results):
     return [dict(file=record["name"], split=record["split"], algorithm=ALGORITHM,
                  **result["metrics"])
             for record, result in zip(records, results)]
 
-TEST_METRIC_ROWS = metric_rows(TEST_RECORDS, TEST_RESULTS)
-ALL_METRIC_ROWS = metric_rows(ALL_RECORDS, ALL_RESULTS)
-TEST_SUMMARY = summarize(TEST_METRIC_ROWS)
+TEST_METRICS_BY_MODE = {mode: metric_rows(TEST_RECORDS, results) for mode, results in TEST_RESULTS_BY_MODE.items()}
+ALL_METRICS_BY_MODE = {mode: metric_rows(ALL_RECORDS, results) for mode, results in ALL_RESULTS_BY_MODE.items()}
+TEST_SUMMARIES_BY_MODE = {mode: summarize(rows) for mode, rows in TEST_METRICS_BY_MODE.items()}
+TEST_METRIC_ROWS = [row for rows in TEST_METRICS_BY_MODE.values() for row in rows]
+ALL_METRIC_ROWS = [row for rows in ALL_METRICS_BY_MODE.values() for row in rows]
+TEST_SUMMARY = TEST_SUMMARIES_BY_MODE[MODE]
 METRIC_COLUMNS = [
-    ("file", "File"), ("split", "Split"),
+    ("file", "File"), ("split", "Split"), ("endpoint_mode", "Mode"),
     ("ground_truth_region_count", "GT regions"), ("predicted_region_count", "Pred regions"),
     ("mae_ms", "Final MAE (ms)"), ("rmse_ms", "RMSE (ms)"), ("status", "Status"),
     ("start_error_ms", "Signed START error (ms)"), ("end_error_ms", "Signed END error (ms)"),
     ("gt_start_s", "GT START (s)"), ("gt_end_s", "GT END (s)"),
     ("predicted_start_s", "Pred START (s)"), ("predicted_end_s", "Pred END (s)")
 ]
-display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings: final confirmed boundaries")
+display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings in each mode: FINAL-region endpoints")
+THRESHOLD_ROWS = [dict(file=result["file"], endpoint_mode=mode,
+                      **{key:result["diagnostic"].get(key) for key in
+                         ("native_threshold", "native_threshold_units", "low_ste_threshold", "high_ste_threshold",
+                          "geometry", "minimum_speech_ms", "padding_stage")})
+                  for mode, results in ALL_RESULTS_BY_MODE.items() for result in results]
+display_table(THRESHOLD_ROWS, [(key,key) for key in THRESHOLD_ROWS[0]], "Both-mode threshold and geometry diagnostics")
 
-display_table(TEST_SUMMARY,
-              [("algorithm", "Algorithm"), ("files", "Files"),
+display_table([row for rows in TEST_SUMMARIES_BY_MODE.values() for row in rows],
+              [("algorithm", "Algorithm"), ("endpoint_mode", "Mode"), ("files", "Files"),
                ("evaluated_files", "Defined MAE files"), ("mean_file_mae_ms", "Mean MAE (ms)"),
                ("median_file_mae_ms", "Median (ms)"), ("min_file_mae_ms", "Min (ms)"),
                ("max_file_mae_ms", "Max (ms)"), ("mean_file_rmse_ms", "Mean file RMSE (ms)"),
                ("pooled_endpoint_rmse_ms", "Pooled endpoint RMSE (ms)"),
                ("region_count_correct_files", "Correct counts"),
                ("region_count_incorrect_files", "Incorrect counts"),
                ("mean_frame_f1", "Mean frame F1"), ("top_mae_files", "Highest MAE files"),
                ("evaluation_protocol", "Protocol")],
               "Summary of the four TEST recordings only")
 
@@ -1277,41 +1360,46 @@ def plot_record(record, result):
     diagnostic = result["diagnostic"]
     mae = result["metrics"]["mae_ms"]
     mae_text = f"{mae:.2f} ms" if mae is not None else "N/A"
     figure, axes = plt.subplots(2, 1, figsize=(12.5, 5.5), sharex=True,
                                gridspec_kw={"height_ratios": [1, 1.25]})
     time = [index / record["sample_rate"] for index in range(len(record["samples"]))]
     axes[0].plot(time, record["samples"], color="#444444", linewidth=0.6)
     axes[0].set_ylabel("PCM amplitude")
     axes[1].plot(features["centers"], features["ste_norm"], color="#263238",
                  linewidth=1, label="Normalized STE")
-    axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060",
-                   linestyle="--", linewidth=1.2, label="LOW")
-    axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700",
-                   linestyle=":", linewidth=1.4, label="HIGH")
+    if diagnostic["endpoint_mode"] == "core":
+        native = diagnostic["native_threshold"]
+        if diagnostic["native_threshold_units"] == "sum of squared samples":
+            peak = max(features["energy"], default=0.)
+            native = native / peak if peak else 0.
+        axes[1].axhline(native, color="#9b6700", linestyle=":", label="Native T (display normalized)")
+    else:
+        axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060", linestyle="--", label="LOW")
+        axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700", linestyle=":", label="HIGH")
     for axis in axes:
         for index, (start, end) in enumerate(result["ground_truth_regions"]):
             axis.axvspan(start, end, color="red", alpha=0.05)
             axis.axvline(start, color="red", linestyle="--", linewidth=1.25,
                         label="GT boundary" if index == 0 else None)
             axis.axvline(end, color="red", linestyle="--", linewidth=1.25)
         for index, (start, end) in enumerate(result["final_regions"]):
             axis.axvspan(start, end, color="#1769d2", alpha=0.11)
             axis.axvline(start, color="#1769d2", linewidth=1.4,
                         label="FINAL predicted boundary" if index == 0 else None)
             axis.axvline(end, color="#1769d2", linewidth=1.4)
         axis.grid(alpha=0.16)
         axis.set_xlim(0, record["duration"])
     axes[1].set_ylabel("Normalized STE")
     axes[1].set_xlabel("Time (s)")
     axes[1].legend(loc="upper right", fontsize=8, ncol=3)
-    figure.suptitle(f"{record['name']}.wav | Outer boundary MAE: {mae_text} | "
+    figure.suptitle(f"{record['name']}.wav | {MODE} | FINAL-region endpoint MAE: {mae_text} | "
                    f"{len(result['final_regions'])} speech regions")
     figure.tight_layout()
     plt.show()
     plt.close(figure)
 
 
 TEST_RECORDS_BY_FILE = {record["name"]: record for record in TEST_RECORDS}
 TEST_RESULTS_BY_FILE = {result["file"]: result for result in TEST_RESULTS}
 
 plot_record(TEST_RECORDS_BY_FILE["phone_F2"], TEST_RESULTS_BY_FILE["phone_F2"])
diff --git "a/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\THUAT_TOAN_3.ipynb.oldcode.txt" "b/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\THUAT_TOAN_3.ipynb.newcode.txt"
index 190da2c..9e4bc63 100644
--- "a/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\THUAT_TOAN_3.ipynb.oldcode.txt"
+++ "b/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\THUAT_TOAN_3.ipynb.newcode.txt"
@@ -2,20 +2,21 @@ import math
 import wave
 import hashlib
 import json
 import html
 from pathlib import Path
 
 import matplotlib.pyplot as plt
 from IPython.display import HTML, display
 
 ALGORITHM = 'tt3'
+MODE = "enhanced"  # selected mode for the four plots and illustration
 FRAME_MS = 25.0
 HOP_MS = 10.0
 SAMPLE_ROUNDING = "nearest_integer_samples_python_round_ties_to_even"
 MIN_SILENCE_SECONDS = 0.200
 MIN_SPEECH_SECONDS = 0.100
 BOUNDARY_TOLERANCE_SECONDS = 0.100
 HISTOGRAM_W_TIE_PREFERENCE = 20.0
 PADDING_MS = 250.0
 PADDING_FRAMES = round(PADDING_MS / HOP_MS)
 FILE_ORDER = ("phone_F2", "phone_M2", "studio_F2", "studio_M2")
@@ -755,45 +756,74 @@ def prepare_records(audio_records):
     records = []
     for base in audio_records:
         features = compute_features(base["samples"], base["sample_rate"],
                                     FRAME_MS, HOP_MS)
         record = dict(base, features=features,
                       labels=frame_labels(features["centers"], base["intervals"]))
         records.append(record)
     return records
 
 
+def algorithm_decision(algorithm: str, features: dict, params: dict) -> tuple[list[int], dict]:
+    """Return native unpadded decisions and thresholds without LAB or endpoint policy.
+
+    TT1/high TT3 include equality; low TT3 includes equality in the opposite
+    direction. TT2 uses strict raw Energy > threshold (context uses STE).
+    Existing TT2 padding diagnostics describe its candidate stage only.
+    """
+    if algorithm != ALGORITHM:
+        raise ValueError('This notebook contains only ' + ALGORITHM)
+    if params.get('speech_direction', 'high') not in ('high', 'low'):
+        raise ValueError('Unknown TT3 speech_direction')
+    mask, diagnostic = (predict(features, params), dict(threshold=params['threshold']))
+    source_histogram = False and diagnostic.get('variant') == 'source'
+    diagnostic.update(native_threshold=params['threshold'], native_threshold_units='sum of squared samples' if source_histogram else 'normalized STE')
+    return (mask, diagnostic)
+
 def detect_regions(algorithm, features, duration, params):
     """Detect FINAL regions from features, duration and a fitted model."""
     # Input: frame features/supports, duration and fitted model; Output: FINAL regions, mask and diagnostics.
     if algorithm != ALGORITHM:
         raise ValueError('This notebook contains only ' + ALGORITHM)
-    # TT3 raw classification supports both directions; FINAL rejects explicit low/unknown models. Require TRAIN noise before inference.
-    noise = params.get('endpoint_noise')
-    if noise is None:
+    # The enhanced 100 ms support-span filter is a heuristic; core keeps native speech supports.
+    mode = params.get('endpoint_mode', 'enhanced')
+    if mode not in ('core', 'enhanced'):
+        raise ValueError(f'Unknown endpoint_mode: {mode}')
+    # TT3 raw classification supports both directions; enhanced FINAL rejects low/unknown models; core retains native high/low direction. Enhanced requires TRAIN noise; core uses native decisions.
+    noise = params.get('endpoint_noise') if mode == 'enhanced' else None
+    if mode == 'enhanced' and noise is None:
         raise ValueError('Fitted model requires endpoint_noise; call fit_training_model on TRAIN before inference')
-    if True and params.get('speech_direction', 'high') != 'high':
+    if mode == 'enhanced' and True and (params.get('speech_direction', 'high') != 'high'):
         raise ValueError("FINAL endpoint detection requires TT3 speech_direction='high'; inverted/unknown directions are not supported by energy hysteresis")
-    mask, diagnostic = (predict(features, params), {'threshold': params['threshold']})
+    seed, diagnostic = algorithm_decision(algorithm, features, params)
+    source_histogram = False and params.get('variant', 'source') == 'source'
+    mask = pad_speech(seed, diagnostic['padding_frames']) if mode == 'enhanced' and source_histogram else seed
     # Retain candidate supports for inspection; only FINAL regions produce endpoint scores.
     candidate_regions = [(s, e) for s, e, state in mask_segments(mask, features['starts'], duration, features['ends']) if state]
-    source_histogram = False and params.get('variant', 'source') == 'source'
+    if mode == 'core':
+        final_regions = []
+        for start, end in candidate_regions:
+            if final_regions and start - final_regions[-1][1] < MIN_SILENCE_SECONDS - 1e-12:
+                final_regions[-1] = (final_regions[-1][0], end)
+            else:
+                final_regions.append((start, end))
+        mask = regions_to_mask(final_regions, features['starts'], features['ends'])
+        diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, low_ste_threshold=None, high_ste_threshold=None, endpoint_noise=None, minimum_speech_ms=0.0, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_mode=mode, geometry='union of active frame supports', final_padding_ms=0.0, padding_stage='excluded from core FINAL', endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding')
+        return dict(mask=mask, final_regions=final_regions, diagnostic=diagnostic, predicted_boundaries=[b for region in final_regions for b in region])
     # Use the TRAIN normalized STE threshold and raw classifier seed.
     base_threshold = params['threshold']
-    seed = mask
+    # Confirm with HIGH and continue above LOW; merge estimated support gaps below 200 ms.
     # Derive LOW/HIGH from the threshold and TRAIN silence noise statistics.
     low, high = endpoint_thresholds(base_threshold, noise, histogram=False)
-    # Confirm with HIGH and continue above LOW; merge estimated support gaps below 200 ms.
     final_regions = hysteresis_regions(features['ste_norm'], features['starts'], features['ends'], duration, low, high, MIN_SILENCE_SECONDS, MIN_SPEECH_SECONDS, seed_mask=seed)
     mask = regions_to_mask(final_regions, features['starts'], features['ends'])
-    diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, low_ste_threshold=low, high_ste_threshold=high, endpoint_noise=noise, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_policy='raw STE hysteresis; candidates/debug excluded; no fixed final padding')
-    # The 100 ms support-span filter is a heuristic; support bounds do not guarantee physical silence.
+    diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, endpoint_mode=mode, geometry='union of active frame supports', final_padding_ms=0.0, padding_stage='candidate diagnostics only' if source_histogram else 'none', low_ste_threshold=low, high_ste_threshold=high, endpoint_noise=noise, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_policy='raw STE hysteresis; candidates/debug excluded; no fixed final padding')
     return dict(mask=mask, final_regions=final_regions, diagnostic=diagnostic, predicted_boundaries=[b for region in final_regions for b in region])
 
 def predict_and_score(algorithm, record, params):
     """Invoke LAB-free detection, then score complete regions and frames.
 
     Input: algorithm, prepared annotated record, fitted TRAIN parameters.
     Output: detection plus reference regions, metrics and scoring status.
     LAB and filename enter only after detect_regions has returned.
     """
     if algorithm != ALGORITHM:
@@ -832,103 +862,121 @@ def predict_and_score(algorithm, record, params):
     scores.update(status='; '.join(dict.fromkeys(flags)) if flags else 'OK' if expected_regions or final_regions else 'both_no_speech', boundary_inside_silence_count=inside, boundary_inside_silence_far_count=far_inside)
     # Compute frame and tolerance-based event diagnostics separately from complete-region MAE.
     frames = frame_metrics(record['labels'], mask)
     events = boundary_metrics(expected_boundaries, predicted_boundaries, BOUNDARY_TOLERANCE_SECONDS)
     scores.update({f'frame_{key}': value for key, value in frames.items()})
     scores.update({f'tolerance_boundary_{key}': value for key, value in events.items() if key != 'pairs'})
     scores.update(gt_start_s=reference[0] if reference else None, gt_end_s=reference[1] if reference else None, predicted_start_s=predicted[0] if predicted else None, predicted_end_s=predicted[1] if predicted else None)
     # Retain provenance for imported historical models; fresh fits record TRAIN selection.
     legacy_test_tuned = False and 'W_selection_test' in params
     scores.update(metrics_schema_version=2, model_schema_version=params.get('schema_version', 1), parameter_selection_set='test' if legacy_test_tuned else params.get('parameter_selection_set', 'train'), evaluation_protocol='test_tuned_not_independent' if legacy_test_tuned else params.get('evaluation_protocol', 'train_selected_reused_test'), historical_test_exposure=True if legacy_test_tuned else params.get('historical_test_exposure', True))
+    scores.update(endpoint_mode=params.get('endpoint_mode', 'enhanced'), boundary_convention=params.get('boundary_convention', diagnostic.get('geometry')), minimum_speech_ms=diagnostic.get('minimum_speech_ms'), minimum_silence_ms=diagnostic.get('minimum_silence_ms'), padding_stage=diagnostic.get('padding_stage'), final_padding_ms=diagnostic.get('final_padding_ms'), frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, actual_frame_ms=record['features'].get('frame_ms'), actual_hop_ms=record['features'].get('hop_ms'), frame_samples=record['features'].get('frame_size'), hop_samples=record['features'].get('hop_size'))
     # Output: FINAL detection, reference regions, scores, status and original detector diagnostics.
     return dict(file=record['name'], algorithm=algorithm, mask=mask, metrics=scores, final_regions=final_regions, ground_truth_regions=expected_regions, region_pairs=region_scores['region_pairs'], predicted_boundaries=predicted_boundaries, ground_truth_boundaries=expected_boundaries, diagnostic=diagnostic)
 
-def fit_training_model(algorithm, train_records):
+def fit_training_model(algorithm, train_records, *, endpoint_mode='enhanced'):
     """Fit and lock parameters and FINAL W from supplied prepared TRAIN only.
 
     Input: prepared records with explicit split=train; array records need no
     path and support future folds. Known TEST/external paths are rejected.
-    Output: (schema-v2 model, FINAL W sweep rows), empty rows for other methods.
+    Output: (schema-v3 model, FINAL W sweep rows), empty rows for other methods.
     No files are loaded here, including during the histogram calibration.
-    TT3 must fit speech-high for the current FINAL energy hysteresis.
+    Enhanced TT3 must fit speech-high for FINAL energy hysteresis; core
+    retains either native Gaussian decision direction.
     """
     # Validate supplied TRAIN provenance before fitting; TEST reads occur after model locking.
     if algorithm != ALGORITHM:
         raise ValueError('This notebook contains only ' + ALGORITHM)
+    if endpoint_mode not in ('core', 'enhanced'):
+        raise ValueError(f'Unknown endpoint_mode: {endpoint_mode}')
     if not train_records:
         raise ValueError('fit_training_model requires TRAIN records')
     for record in train_records:
         if record.get('split') != 'train':
             raise ValueError('Training records require explicit TRAIN provenance (split=train)')
         if 'wav_path' in record and Path(record['wav_path']).resolve().parent != (DATA_ROOT / 'train').resolve():
             raise ValueError('Training record path must belong to TRAIN, never TEST/external')
-    # Fit robust centered/scaled Gaussian crossings; reject a non-high model before FINAL reuse.
+    # Fit robust centered/scaled Gaussian crossings; enhanced rejects non-high models; core preserves native direction.
     model = fit(train_records)
-    if model.get('speech_direction', 'high') != 'high':
+    if endpoint_mode == 'enhanced' and model.get('speech_direction', 'high') != 'high':
         raise ValueError("FINAL endpoint detection requires TT3 speech_direction='high'; TRAIN speech mean is below silence mean")
-    model.update(schema_version=2, metrics_schema_version=2, parameter_selection_set='train', evaluation_protocol='train_selected_reused_test', historical_test_exposure=True, training_files=[record['name'] for record in train_records], frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, endpoint_noise=fit_noise_floor(train_records), endpoint_policy='hysteresis final regions; no fixed final padding', boundary_convention='union of active frame supports')
-    # Output: schema-v2 model with TRAIN silence noise and provenance; no W sweep for this method.
+    model.update(schema_version=3, metrics_schema_version=2, endpoint_mode=endpoint_mode, parameter_selection_set='train', evaluation_protocol='train_selected_reused_test', historical_test_exposure=True, training_files=[record['name'] for record in train_records], frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000, minimum_speech_ms=0.0 if endpoint_mode == 'core' else MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_noise=fit_noise_floor(train_records) if endpoint_mode == 'enhanced' else None, endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding' if endpoint_mode == 'core' else 'hysteresis final regions; no fixed final padding', feature_rule='normalized STE', decision_rule='STE <= threshold' if model.get('speech_direction') == 'low' else 'STE >= threshold', padding_stage='excluded from core FINAL' if endpoint_mode == 'core' else 'none', boundary_convention='union of active frame supports')
+    # Output: schema-v3 model with mode policy and TRAIN provenance; no W sweep for this method.
     sweep_rows = []
+    digest = hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False, allow_nan=False).encode('utf-8')).hexdigest()
+    model['calibration_digest'] = digest
     return (model, sweep_rows)
 
 def summarize(metrics):
     """Tổng hợp metric từng thuật toán, phân biệt mean file và pooled RMSE.
 
     Input: metrics là rows endpoint/frame của từng file. Output: rows mean
     MAE/RMSE, pooled endpoint RMSE, F1 và số file có metric không xác định;
-    metric không xác định được loại khỏi mean và được đếm rõ.
+    primary mean chỉ xác định khi mọi file hợp lệ; mean subset được ghi riêng.
     """
     rows = []
-    for algorithm in dict.fromkeys(row["algorithm"] for row in metrics):
-        selected = [row for row in metrics if row["algorithm"] == algorithm]
-        valid = [row for row in selected if row["mae_ms"] is not None]
+    for algorithm, mode in dict.fromkeys((row["algorithm"], row.get("endpoint_mode", "enhanced")) for row in metrics):
+        selected = [row for row in metrics if row["algorithm"] == algorithm and row.get("endpoint_mode", "enhanced") == mode]
+        valid = [row for row in selected if row["mae_ms"] is not None
+                 and row.get("ground_truth_region_count") == row.get("predicted_region_count")]
         squared=sum(row.get('endpoint_squared_error_ms2',(row['rmse_ms']**2)*2) for row in valid)
         error_count=sum(row.get('endpoint_error_count',2) for row in valid)
         ordered=sorted(row['mae_ms'] for row in valid)
         median=(ordered[len(ordered)//2] if len(ordered)%2 else (ordered[len(ordered)//2-1]+ordered[len(ordered)//2])/2) if ordered else None
         count_correct=sum(row.get('ground_truth_region_count')==row.get('predicted_region_count') for row in selected)
-        rows.append(dict(algorithm=algorithm, metrics_schema_version=2,
+        rows.append(dict(algorithm=algorithm, endpoint_mode=mode, metrics_schema_version=2,
                          files=len(selected), evaluated_files=len(valid),
                          missing_speech_files=len(selected) - len(valid),
-                         mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,
-                         mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,
-                         pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,
+                         mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,
+                         valid_files_mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,
+                         mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,
+                         valid_files_mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,
+                         pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count and len(valid)==len(selected) else None,
+                         valid_files_pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,
                          median_file_mae_ms=median,min_file_mae_ms=min(ordered) if ordered else None,max_file_mae_ms=max(ordered) if ordered else None,
                          region_count_correct_files=count_correct,region_count_incorrect_files=len(selected)-count_correct,
                          top_mae_files='; '.join(f"{r['file']}:{r['mae_ms']:.2f}ms" for r in sorted(valid,key=lambda r:r['mae_ms'],reverse=True)[:3]),
                          parameter_selection_set=selected[0].get('parameter_selection_set','train'),
                          evaluation_protocol=selected[0].get('evaluation_protocol','train_selected_reused_test'),
                          historical_test_exposure=selected[0].get('historical_test_exposure', True),
                          mean_frame_f1=sum(row["frame_f1"] for row in selected) / len(selected)))
     return rows
 
 DATA_ROOT = find_data_root(DATA_DIR)
 TRAIN_RECORDS = prepare_records(load_dataset_folder(DATA_ROOT, "train"))
 
-MODEL, TT2W_SWEEP_ROWS = fit_training_model(ALGORITHM, TRAIN_RECORDS)
+MODELS, TT2W_SWEEPS = {}, {}
+for endpoint_mode in ("core", "enhanced"):
+    MODELS[endpoint_mode], TT2W_SWEEPS[endpoint_mode] = fit_training_model(
+        ALGORITHM, TRAIN_RECORDS, endpoint_mode=endpoint_mode)
+MODEL, TT2W_SWEEP_ROWS = MODELS[MODE], TT2W_SWEEPS[MODE]
 
 parameter_names = ['muSil', 'stdSil', 'muSp', 'stdSp', 'silence_count', 'speech_count', 'threshold', 'threshold_rule', 'speech_direction', 'sigma_floor', 'sigma_was_floored']
 parameter_rows = [dict(parameter=key, value=MODEL.get(key)) for key in parameter_names]
 parameter_rows.extend(dict(parameter=key, value=value)
-                      for key, value in MODEL["endpoint_noise"].items())
+                      for key, value in (MODEL["endpoint_noise"] or {}).items())
 display_table(parameter_rows, [("parameter", "Parameter"), ("value", "Freshly computed value")],
               "Training parameters and train-only noise calibration")
 
 def model_digest(model):
     return hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False,
                                      allow_nan=False, separators=(",", ":")).encode("utf-8")).hexdigest()
 
-MODEL_LOCK_DIGEST = model_digest(MODEL)
+MODEL_LOCK_DIGESTS = {mode: model_digest(model) for mode, model in MODELS.items()}
+MODEL_LOCK_DIGEST = MODEL_LOCK_DIGESTS[MODE]
 
 def assert_model_locked():
-    if model_digest(MODEL) != MODEL_LOCK_DIGEST:
-        raise ValueError("Frozen TRAIN model digest changed after calibration")
+    for mode, model in MODELS.items():
+        if model.get("endpoint_mode") != mode or model_digest(model) != MODEL_LOCK_DIGESTS[mode]:
+            raise ValueError("Frozen TRAIN model digest or mode changed after calibration")
+    if MODEL is not MODELS[MODE] or model_digest(MODEL) != MODEL_LOCK_DIGEST:
+        raise ValueError("Selected model alias changed after calibration")
 
 print("MODEL locked before TEST reads:", MODEL_LOCK_DIGEST)
 
 assert_model_locked()
 TEST_RECORDS = prepare_records(load_dataset_folder(DATA_ROOT, "test"))
 TEST_RECORDS.sort(key=lambda r: FILE_ORDER.index(r["name"]) if r["name"] in FILE_ORDER else len(FILE_ORDER))
 ALL_RECORDS = TRAIN_RECORDS + TEST_RECORDS
 DATASET_MANIFEST = [dict(file=r["name"], split=r["split"],
                          sample_rate_hz=r["sample_rate"], duration_s=r["duration"],
                          wav_sha256=r["wav_sha256"], lab_sha256=r["lab_sha256"])
@@ -967,45 +1015,57 @@ for axis, (lower, upper) in zip(axes, ranges):
                             gaussian_density(MODEL["muSp"], MODEL["muSp"], MODEL["stdSp"])) * 2)
     axis.set(xlabel="Normalized STE", ylabel="Gaussian density (log scale)")
     axis.grid(alpha=0.2)
     axis.legend(fontsize=8)
 axes[0].set_title("Fitted TRAIN Gaussian densities")
 axes[1].set_title("Threshold detail")
 figure.tight_layout()
 plt.show()
 plt.close(figure)
 
-TEST_RESULTS = [predict_and_score(ALGORITHM, record, MODEL) for record in TEST_RECORDS]
+TEST_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in TEST_RECORDS]
+                        for mode, model in MODELS.items()}
 assert_model_locked()
-ALL_RESULTS = [predict_and_score(ALGORITHM, record, MODEL) for record in ALL_RECORDS]
+ALL_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in ALL_RECORDS]
+                       for mode, model in MODELS.items()}
 assert_model_locked()
+TEST_RESULTS, ALL_RESULTS = TEST_RESULTS_BY_MODE[MODE], ALL_RESULTS_BY_MODE[MODE]
 
 def metric_rows(records, results):
     return [dict(file=record["name"], split=record["split"], algorithm=ALGORITHM,
                  **result["metrics"])
             for record, result in zip(records, results)]
 
-TEST_METRIC_ROWS = metric_rows(TEST_RECORDS, TEST_RESULTS)
-ALL_METRIC_ROWS = metric_rows(ALL_RECORDS, ALL_RESULTS)
-TEST_SUMMARY = summarize(TEST_METRIC_ROWS)
+TEST_METRICS_BY_MODE = {mode: metric_rows(TEST_RECORDS, results) for mode, results in TEST_RESULTS_BY_MODE.items()}
+ALL_METRICS_BY_MODE = {mode: metric_rows(ALL_RECORDS, results) for mode, results in ALL_RESULTS_BY_MODE.items()}
+TEST_SUMMARIES_BY_MODE = {mode: summarize(rows) for mode, rows in TEST_METRICS_BY_MODE.items()}
+TEST_METRIC_ROWS = [row for rows in TEST_METRICS_BY_MODE.values() for row in rows]
+ALL_METRIC_ROWS = [row for rows in ALL_METRICS_BY_MODE.values() for row in rows]
+TEST_SUMMARY = TEST_SUMMARIES_BY_MODE[MODE]
 METRIC_COLUMNS = [
-    ("file", "File"), ("split", "Split"),
+    ("file", "File"), ("split", "Split"), ("endpoint_mode", "Mode"),
     ("ground_truth_region_count", "GT regions"), ("predicted_region_count", "Pred regions"),
     ("mae_ms", "Final MAE (ms)"), ("rmse_ms", "RMSE (ms)"), ("status", "Status"),
     ("start_error_ms", "Signed START error (ms)"), ("end_error_ms", "Signed END error (ms)"),
     ("gt_start_s", "GT START (s)"), ("gt_end_s", "GT END (s)"),
     ("predicted_start_s", "Pred START (s)"), ("predicted_end_s", "Pred END (s)")
 ]
-display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings: final confirmed boundaries")
+display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings in each mode: FINAL-region endpoints")
+THRESHOLD_ROWS = [dict(file=result["file"], endpoint_mode=mode,
+                      **{key:result["diagnostic"].get(key) for key in
+                         ("native_threshold", "native_threshold_units", "low_ste_threshold", "high_ste_threshold",
+                          "geometry", "minimum_speech_ms", "padding_stage")})
+                  for mode, results in ALL_RESULTS_BY_MODE.items() for result in results]
+display_table(THRESHOLD_ROWS, [(key,key) for key in THRESHOLD_ROWS[0]], "Both-mode threshold and geometry diagnostics")
 
-display_table(TEST_SUMMARY,
-              [("algorithm", "Algorithm"), ("files", "Files"),
+display_table([row for rows in TEST_SUMMARIES_BY_MODE.values() for row in rows],
+              [("algorithm", "Algorithm"), ("endpoint_mode", "Mode"), ("files", "Files"),
                ("evaluated_files", "Defined MAE files"), ("mean_file_mae_ms", "Mean MAE (ms)"),
                ("median_file_mae_ms", "Median (ms)"), ("min_file_mae_ms", "Min (ms)"),
                ("max_file_mae_ms", "Max (ms)"), ("mean_file_rmse_ms", "Mean file RMSE (ms)"),
                ("pooled_endpoint_rmse_ms", "Pooled endpoint RMSE (ms)"),
                ("region_count_correct_files", "Correct counts"),
                ("region_count_incorrect_files", "Incorrect counts"),
                ("mean_frame_f1", "Mean frame F1"), ("top_mae_files", "Highest MAE files"),
                ("evaluation_protocol", "Protocol")],
               "Summary of the four TEST recordings only")
 
@@ -1017,41 +1077,46 @@ def plot_record(record, result):
     diagnostic = result["diagnostic"]
     mae = result["metrics"]["mae_ms"]
     mae_text = f"{mae:.2f} ms" if mae is not None else "N/A"
     figure, axes = plt.subplots(2, 1, figsize=(12.5, 5.5), sharex=True,
                                gridspec_kw={"height_ratios": [1, 1.25]})
     time = [index / record["sample_rate"] for index in range(len(record["samples"]))]
     axes[0].plot(time, record["samples"], color="#444444", linewidth=0.6)
     axes[0].set_ylabel("PCM amplitude")
     axes[1].plot(features["centers"], features["ste_norm"], color="#263238",
                  linewidth=1, label="Normalized STE")
-    axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060",
-                   linestyle="--", linewidth=1.2, label="LOW")
-    axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700",
-                   linestyle=":", linewidth=1.4, label="HIGH")
+    if diagnostic["endpoint_mode"] == "core":
+        native = diagnostic["native_threshold"]
+        if diagnostic["native_threshold_units"] == "sum of squared samples":
+            peak = max(features["energy"], default=0.)
+            native = native / peak if peak else 0.
+        axes[1].axhline(native, color="#9b6700", linestyle=":", label="Native T (display normalized)")
+    else:
+        axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060", linestyle="--", label="LOW")
+        axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700", linestyle=":", label="HIGH")
     for axis in axes:
         for index, (start, end) in enumerate(result["ground_truth_regions"]):
             axis.axvspan(start, end, color="red", alpha=0.05)
             axis.axvline(start, color="red", linestyle="--", linewidth=1.25,
                         label="GT boundary" if index == 0 else None)
             axis.axvline(end, color="red", linestyle="--", linewidth=1.25)
         for index, (start, end) in enumerate(result["final_regions"]):
             axis.axvspan(start, end, color="#1769d2", alpha=0.11)
             axis.axvline(start, color="#1769d2", linewidth=1.4,
                         label="FINAL predicted boundary" if index == 0 else None)
             axis.axvline(end, color="#1769d2", linewidth=1.4)
         axis.grid(alpha=0.16)
         axis.set_xlim(0, record["duration"])
     axes[1].set_ylabel("Normalized STE")
     axes[1].set_xlabel("Time (s)")
     axes[1].legend(loc="upper right", fontsize=8, ncol=3)
-    figure.suptitle(f"{record['name']}.wav | Outer boundary MAE: {mae_text} | "
+    figure.suptitle(f"{record['name']}.wav | {MODE} | FINAL-region endpoint MAE: {mae_text} | "
                    f"{len(result['final_regions'])} speech regions")
     figure.tight_layout()
     plt.show()
     plt.close(figure)
 
 
 TEST_RECORDS_BY_FILE = {record["name"]: record for record in TEST_RECORDS}
 TEST_RESULTS_BY_FILE = {result["file"]: result for result in TEST_RESULTS}
 
 plot_record(TEST_RECORDS_BY_FILE["phone_F2"], TEST_RESULTS_BY_FILE["phone_F2"])
