# Review task-3
Base: 116384e31a8027926cdc1131dc79d85bedd682bd
Head: HEAD

47cc00b Calibrate and lock TRAIN models and histogram weights by endpoint mode
 app/pipeline.py                 | 31 ++++++++++++++++------
 app/weight_selection.py         | 23 +++++++++++++---
 tests/test_notebook_protocol.py | 21 ++++++++++++++-
 tests/test_training_protocol.py | 58 +++++++++++++++++++++++++++++++++++------
 tests/test_weight_selection.py  | 12 +++++++++
 tools/build_notebooks.py        |  2 +-
 tools/run_notebooks.py          | 28 +++++++++++++++++++-
 7 files changed, 153 insertions(+), 22 deletions(-)
diff --git a/app/pipeline.py b/app/pipeline.py
index b098858..b32024d 100644
--- a/app/pipeline.py
+++ b/app/pipeline.py
@@ -1,12 +1,13 @@
 """Học tham số bằng train, dự đoán test, lưu kết quả và điều phối demo."""
 import csv
+import hashlib
 import json
 import math
 import random
 import zlib
 from pathlib import Path
 
 import matplotlib.pyplot as plt
 
 from algorithms import tt1_hodgkinson as tt1
 from algorithms import tt2_histogram as tt2
@@ -263,56 +264,63 @@ def predict_and_score(algorithm, record, params):
     scores.update(metrics_schema_version=2, model_schema_version=params.get('schema_version', 1),
                   parameter_selection_set='test' if legacy_test_tuned else params.get('parameter_selection_set', 'train'),
                   evaluation_protocol='test_tuned_not_independent' if legacy_test_tuned else params.get('evaluation_protocol', 'train_selected_reused_test'),
                   historical_test_exposure=True if legacy_test_tuned else params.get('historical_test_exposure', True))
     return dict(file=record["name"], algorithm=algorithm, mask=mask, metrics=scores,
                 final_regions=final_regions, ground_truth_regions=expected_regions,region_pairs=region_scores['region_pairs'],
                 predicted_boundaries=predicted_boundaries,
                 ground_truth_boundaries=expected_boundaries, diagnostic=diagnostic)
 
 
-def fit_training_model(algorithm, train_records):
+def fit_training_model(algorithm, train_records, *, endpoint_mode='enhanced'):
     """Fit and lock parameters and FINAL W from supplied prepared TRAIN only.
 
     Input: prepared records with explicit split=train; array records need no
     path and support future folds. Known TEST/external paths are rejected.
-    Output: (schema-v2 model, FINAL W sweep rows), empty rows for other methods.
+    Output: (schema-v3 model, FINAL W sweep rows), empty rows for other methods.
     No files are loaded here, including during the histogram calibration.
-    TT3 must fit speech-high for the current FINAL energy hysteresis.
+    Enhanced TT3 must fit speech-high for FINAL energy hysteresis; core
+    retains either native Gaussian decision direction.
     """
+    if endpoint_mode not in ('core', 'enhanced'):
+        raise ValueError(f'Unknown endpoint_mode: {endpoint_mode}')
     if not train_records:
         raise ValueError('fit_training_model requires TRAIN records')
     for record in train_records:
         if record.get('split') != 'train':
             raise ValueError('Training records require explicit TRAIN provenance (split=train)')
         if 'wav_path' in record and Path(record['wav_path']).resolve().parent != TRAIN_DIR.resolve():
             raise ValueError('Training record path must belong to TRAIN, never TEST/external')
     if algorithm == 'tt1':
         model = tt1.fit(train_records)
     elif algorithm == 'tt3':
         model = tt3.fit(train_records)
         # Do not lock a raw Gaussian model whose inequality contradicts HIGH.
-        if model.get('speech_direction', 'high') != 'high':
+        if endpoint_mode == 'enhanced' and model.get('speech_direction', 'high') != 'high':
             raise ValueError("FINAL endpoint detection requires TT3 speech_direction='high'; "
                              "TRAIN speech mean is below silence mean")
     elif algorithm in ('tt2', 'tt2-context'):
         model = tt2.fit(train_records, variant='context' if algorithm == 'tt2-context' else 'source')
     else:
         raise ValueError(f'Unknown algorithm: {algorithm}')
-    model.update(schema_version=2, metrics_schema_version=2,
+    model.update(schema_version=3, metrics_schema_version=2, endpoint_mode=endpoint_mode,
                  parameter_selection_set='train', evaluation_protocol='train_selected_reused_test',
                  historical_test_exposure=True, training_files=[record['name'] for record in train_records],
                  frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING,
                  minimum_internal_silence_ms=MIN_SILENCE_SECONDS*1000,
-                 minimum_speech_ms=MIN_SPEECH_SECONDS*1000,
-                 endpoint_noise=fit_noise_floor(train_records),
-                 endpoint_policy='hysteresis final regions; no fixed final padding',
+                 minimum_speech_ms=0. if endpoint_mode == 'core' else MIN_SPEECH_SECONDS*1000,
+                 minimum_silence_ms=MIN_SILENCE_SECONDS*1000,
+                 endpoint_noise=fit_noise_floor(train_records) if endpoint_mode == 'enhanced' else None,
+                 endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding' if endpoint_mode == 'core' else 'hysteresis final regions; no fixed final padding',
+                 feature_rule='Energy (sum of squared samples)' if algorithm == 'tt2' else 'normalized STE',
+                 decision_rule='Energy > threshold' if algorithm == 'tt2' else 'STE <= threshold' if model.get('speech_direction') == 'low' else 'STE >= threshold',
+                 padding_stage='excluded from core FINAL' if endpoint_mode == 'core' else 'candidate diagnostics only' if algorithm == 'tt2' else 'none',
                  boundary_convention='union of active frame supports')
     sweep_rows = []
     if algorithm == 'tt2':
         # Preserve the core's candidate-stage proposal under explicit names.
         # Its F1 is not a score for the W selected below by FINAL-region MAE.
         model['candidate_frame_selected_W'] = model['W']
         model['candidate_frame_f1'] = model.pop('train_frame_f1')
         model['candidate_frame_selection_scores'] = [
             dict(W=row['W'], candidate_frame_f1=row['train_frame_f1'],
                  **{key: value for key, value in row.items() if key not in ('W', 'train_frame_f1')})
@@ -323,20 +331,27 @@ def fit_training_model(algorithm, train_records):
         selection, sweep_rows = sweep_final_weights(train_records, model, predict_and_score,
                                                     tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE)
         model.update(W=selection['selected_W'], finalW=selection['selected_W'],
                      tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE, W_selection_train=selection,
                      parameter_rule=selection['selection_rule'])
     elif algorithm == 'tt2-context':
         # Context W is declared by the report and has no candidate F1 fit.
         model.update(candidate_frame_selected_W=None, candidate_frame_f1=None,
                      candidate_frame_selection_scores=[], candidate_cleanup_records=None,
                      candidate_frame_selection_applicable=False, finalW=model['W'], tie_preference_W=None)
+    # Hash the complete locked model before attaching the digest to itself or
+    # its manifest. This includes numeric calibration and TRAIN provenance.
+    digest = hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False,
+                                       allow_nan=False).encode('utf-8')).hexdigest()
+    model['calibration_digest'] = digest
+    if algorithm == 'tt2':
+        model['W_selection_train']['calibration_digest'] = digest
     return model, sweep_rows
 
 
 def data_statistics(records, split):
     """Ước lượng SNR môi trường theo công suất speech/silence của LAB.
 
     Input: records chứa waveform/Fs/LAB, split là tên tập dữ liệu.
     Output: rows thời lượng/biên chuẩn/công suất và snr_proxy_db; SNR là
     proxy speech-plus-noise/silence, không phải SNR sạch đã biết.
     """
diff --git a/app/weight_selection.py b/app/weight_selection.py
index e838076..edb983d 100644
--- a/app/weight_selection.py
+++ b/app/weight_selection.py
@@ -1,29 +1,34 @@
 """Choose one histogram W using FINAL-region errors on supplied TRAIN records.
 
 TRAIN calibration is reused for scoring historically exposed TEST recordings.
 All timing, feature extraction, histogram and hysteresis settings stay fixed.
 """
 import math
 from app.config import HISTOGRAM_W_TIE_PREFERENCE
 
 W_CANDIDATES=tuple(float(w) for w in range(1,51))
 ERROR_EPS_MS=1e-8
+POLICY_FIELDS=('endpoint_mode','boundary_convention','minimum_speech_ms',
+               'minimum_silence_ms','padding_stage')
 
 def select_final_weight(rows,tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE):
     """Input: one MAE/count row per (W,file). Output: shared W and audit tables.
 
     Prefer valid region counts, then minimize the worst per-file loss relative
     to that file's own optimum, then mean MAE. Ties use the declared preference;
     if unavailable, choose the smallest W. No candidate/debug boundary is scored.
     """
     if not rows:raise ValueError('W selection needs evaluation rows')
+    policy={key:rows[0][key] for key in POLICY_FIELDS if key in rows[0]}
+    if any({key:row[key] for key in POLICY_FIELDS if key in row} != policy for row in rows):
+        raise ValueError('Each candidate W must use the same endpoint policy')
     grouped={}
     for row in rows:
         w=row['W'];name=row['filename'];mae=row['final_region_mae_ms']
         if not math.isfinite(w) or w<0 or (mae is not None and (not math.isfinite(mae) or mae<0)):
             raise ValueError('Invalid W or endpoint MAE')
         files=grouped.setdefault(w,{})
         if name in files:raise ValueError('Duplicate (W,filename) in selection')
         files[name]=row
     names=sorted(next(iter(grouped.values())))
     if any(set(files)!=set(names) for files in grouped.values()):
@@ -53,43 +58,55 @@ def select_final_weight(rows,tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE):
                     candidate['valid_files_mean_MAE_ms'] if candidate['valid_files_mean_MAE_ms'] is not None else math.inf)
         if chosen is None:chosen=candidate;best_objectives=objectives;continue
         better=False;tied=True
         for left,right in zip(objectives,best_objectives):
             if left==right or (math.isfinite(left) and math.isfinite(right) and abs(left-right)<=ERROR_EPS_MS):continue
             better=left<right;tied=False;break
         if tied:
             better=(candidate['W']!=tie_preference_W,candidate['W'])<(chosen['W']!=tie_preference_W,chosen['W'])
         if better:chosen=candidate;best_objectives=objectives
     shared=set.intersection(*(set(v['optimal_W']) for v in best_by_file.values()))
-    return dict(selected_W=chosen['W'],tie_preference_W=tie_preference_W,selected_summary=chosen,
+    return dict(**policy,selected_W=chosen['W'],tie_preference_W=tie_preference_W,selected_summary=chosen,
         summaries=summaries,best_by_file=best_by_file,shared_optimal_W=sorted(shared),
         candidate_W=sorted(grouped),selection_set='train',evaluation_protocol='train_final_calibration',
         selection_rule='valid regions; minimum worst per-file regret; mean MAE; declared W preference on ties; smallest W otherwise')
 
 def sweep_final_weights(records,model,predictor,candidates=W_CANDIDATES,
                         tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE):
     """Evaluate every W on all calibration files with the real endpoint pipeline.
 
     Input: annotated TRAIN records, fitted TRAIN/noise model, real predictor.
     Output: selection manifest and rows. Does not mutate records or model.
     """
     if not records:raise ValueError('W sweep needs annotated TRAIN recordings')
     if any(record.get('split')!='train' for record in records):
         raise ValueError('W sweep requires explicit TRAIN provenance (split=train)')
+    mode=model.get('endpoint_mode','enhanced')
+    if mode not in ('core','enhanced'):raise ValueError('Unknown endpoint_mode')
+    policy=dict(endpoint_mode=mode,
+        boundary_convention=model.get('boundary_convention','union of active frame supports'),
+        minimum_speech_ms=model.get('minimum_speech_ms',0. if mode=='core' else 100.),
+        minimum_silence_ms=model.get('minimum_silence_ms',model.get('minimum_internal_silence_ms',200.)),
+        padding_stage=model.get('padding_stage','excluded from core FINAL' if mode=='core' else 'candidate diagnostics only'))
     rows=[]
     for w in candidates:
         params=dict(model,W=float(w))
         for record in records:
             result=predictor('tt2',record,params);metrics=result['metrics'];diag=result['diagnostic']
-            rows.append(dict(filename=record['name'],W=float(w),
+            if diag.get('endpoint_mode','enhanced') != mode:
+                raise ValueError('Predictor endpoint_mode disagrees with calibration model')
+            for key in ('minimum_speech_ms','minimum_silence_ms','padding_stage'):
+                if key in diag and diag[key] != policy[key]:
+                    raise ValueError(f'Predictor {key} disagrees with calibration model')
+            rows.append(dict(**policy,filename=record['name'],W=float(w),
                 ground_truth_region_count=metrics['ground_truth_region_count'],predicted_region_count=metrics['predicted_region_count'],
                 final_region_mae_ms=metrics['mae_ms'],status=metrics['status'],
                 start_error_ms=metrics['start_error_ms'],end_error_ms=metrics['end_error_ms'],
                 energy_threshold=diag['energy_threshold'],
                 low_ste_threshold=diag['low_ste_threshold'],high_ste_threshold=diag['high_ste_threshold'],
                 raw_speech_frames=diag['raw_speech_frames'],candidate_region_count=len(diag['candidate_regions']),
                 final_regions=str(result['final_regions'])))
     result=select_final_weight(rows,tie_preference_W)
     result.update(evaluated_files=[record['name'] for record in records],
-                  endpoint_policy='fixed raw STE hysteresis; final START/END only; no padding endpoints',
+                  endpoint_policy=model.get('endpoint_policy','fixed raw STE hysteresis; final START/END only; no padding endpoints'),
                   note='W was calibrated using these TRAIN LABs; TEST has historical exposure and is reused for scoring, so no holdout independence is claimed.')
     return result,rows
diff --git a/tests/test_notebook_protocol.py b/tests/test_notebook_protocol.py
index abbb7b7..f530142 100644
--- a/tests/test_notebook_protocol.py
+++ b/tests/test_notebook_protocol.py
@@ -170,21 +170,21 @@ def second(value):
                                     self.assertEqual(namespace["MODEL_LOCK_DIGEST"],
                                                      namespace["model_digest"](namespace["MODEL"]))
                                     checked.append(split)
                                 return real_loader(data_root, split)
                             namespace["load_dataset_folder"] = guarded_loader
                         with contextlib.redirect_stdout(io.StringIO()), patch("matplotlib.pyplot.show"), \
                                 patch("IPython.display.display"):
                             exec(compile(source, "<generated-notebook>", "exec"), namespace)
                     self.assertEqual(checked, ["test"])
                     model = namespace["MODEL"]
-                    self.assertEqual(model["schema_version"], 2)
+                    self.assertEqual(model["schema_version"], 3)
                     self.assertEqual(model["parameter_selection_set"], "train")
                     self.assertEqual(model["evaluation_protocol"], "train_selected_reused_test")
                     self.assertIs(model["historical_test_exposure"], True)
                     self.assertEqual(namespace["MODEL_LOCK_DIGEST"], namespace["model_digest"](model))
                     self.assertEqual(len(namespace["DATASET_MANIFEST"]), 8)
                     for row in namespace["ALL_METRIC_ROWS"]:
                         self.assertEqual(len(row), len({key.casefold() for key in row}))
                         self.assertNotIn("boundary_MAE_ms", row)
                         self.assertIn("tolerance_boundary_mae_ms", row)
                     if algorithm == "tt2":
@@ -245,20 +245,39 @@ def executed_plot_notebook():
             '# Display this TEST record from the freshly computed results.\n'
             f'plot_record(TEST_RECORDS_BY_FILE["{name}"], TEST_RESULTS_BY_FILE["{name}"])',
             execution_count=index, outputs=[copy.deepcopy(output)]))
     source_digest = hashlib.sha256(json.dumps([cell.source for cell in cells],
                                              ensure_ascii=False, separators=(',', ':')).encode('utf-8')).hexdigest()
     return nbformat.v4.new_notebook(cells=cells, metadata={
         'endpoint_execution': {'fixture': True, 'code_source_sha256': source_digest}})
 
 
 class NotebookAuditTests(unittest.TestCase):
+    def test_schema_three_audit_validates_mode_and_keeps_schema_two_compatible(self):
+        model = dict(schema_version=3, metrics_schema_version=2, parameter_selection_set='train',
+                     evaluation_protocol='train_selected_reused_test', historical_test_exposure=True,
+                     training_files=list(runner.TRAIN_NAMES), endpoint_mode='core',
+                     minimum_speech_ms=0., minimum_silence_ms=200., endpoint_noise=None,
+                     boundary_convention='union of active frame supports', padding_stage='excluded from core FINAL')
+        runner.audit_model_protocol(model, runner.model_digest(model))
+        selected = dict(model, W=20., finalW=20., W_selection_train=dict(
+            endpoint_mode='enhanced', minimum_speech_ms=100., minimum_silence_ms=200.,
+            boundary_convention='union of active frame supports', padding_stage='candidate diagnostics only',
+            selected_W=20.))
+        with self.assertRaisesRegex(ValueError,'policy'):
+            runner.audit_model_protocol(selected, runner.model_digest(selected))
+        for changes in ({'endpoint_mode':'unknown'}, {'minimum_speech_ms':100.},
+                        {'endpoint_noise':{'noise_q95':.1}}, {'padding_stage':'candidate diagnostics only'}):
+            damaged = dict(model, **changes)
+            with self.subTest(changes=changes), self.assertRaisesRegex(ValueError,'policy|mode'):
+                runner.audit_model_protocol(damaged, runner.model_digest(damaged))
+
     def test_source_bound_audit_rejects_changed_code_even_when_only_a_comment_changes(self):
         notebook = executed_plot_notebook()
         notebook.cells[0].source += '\n# Added after execution.'
         with patch.object(runner, 'audit_results', return_value=10.):
             with self.assertRaisesRegex(ValueError, 'source.*rerun|rerun.*source'):
                 runner.audit_notebook(notebook, 'changed.ipynb')
 
     def test_source_bound_audit_requires_digest_and_accepts_unchanged_source(self):
         notebook = executed_plot_notebook()
         with patch.object(runner, 'audit_results', return_value=10.):
diff --git a/tests/test_training_protocol.py b/tests/test_training_protocol.py
index cf83915..f8a9fde 100644
--- a/tests/test_training_protocol.py
+++ b/tests/test_training_protocol.py
@@ -143,20 +143,57 @@ class DetectionContractTests(unittest.TestCase):
         params = dict(threshold=.1, schema_version=2,
                       endpoint_noise=dict(noise_q95=.02, noise_upper=.15))
         scores = pipeline.predict_and_score('tt1', record, params)['metrics']
         summary = pipeline.summarize([dict(file='fixture', algorithm='tt1', **scores)])[0]
         self.assertEqual(summary.get('metrics_schema_version'), 2)
         self.assertEqual(summary.get('evaluation_protocol'), 'train_selected_reused_test')
         self.assertTrue(summary.get('historical_test_exposure'))
 
 
 class TrainingProtocolTests(unittest.TestCase):
+    def test_core_fit_skips_noise_calibration(self):
+        for algorithm in ('tt1', 'tt3'):
+            with self.subTest(algorithm=algorithm), patch.object(
+                    pipeline, 'fit_noise_floor', side_effect=AssertionError('core noise fit')):
+                model, rows = pipeline.fit_training_model(algorithm, [synthetic_record()], endpoint_mode='core')
+            self.assertIsNone(model['endpoint_noise'])
+            self.assertEqual(model['minimum_speech_ms'], 0)
+            self.assertEqual(model['endpoint_mode'], 'core')
+            self.assertEqual(rows, [])
+
+    def test_core_accepts_speech_low_gaussian_but_enhanced_rejects_it(self):
+        record = synthetic_record()
+        record['features']['ste_norm'] = [1. - value for value in record['features']['ste_norm']]
+        model, _ = pipeline.fit_training_model('tt3', [record], endpoint_mode='core')
+        self.assertEqual(model['speech_direction'], 'low')
+        result = pipeline.predict_and_score('tt3', record, model)
+        self.assertEqual(result['final_regions'], [(.1, .515)])
+        with self.assertRaisesRegex(ValueError, 'speech_direction'):
+            pipeline.fit_training_model('tt3', [record], endpoint_mode='enhanced')
+
+    def test_both_policies_sweep_final_train_regions_and_export_null_thresholds(self):
+        for mode in ('core', 'enhanced'):
+            with self.subTest(mode=mode):
+                model, rows = pipeline.fit_training_model('tt2', self.training, endpoint_mode=mode)
+                selection = model['W_selection_train']
+                self.assertEqual(len(rows), 200)
+                self.assertEqual(selection['endpoint_mode'], mode)
+                self.assertEqual(model['W'], selection['selected_W'])
+                self.assertEqual(len(model['calibration_digest']), 64)
+                self.assertTrue(all(row['endpoint_mode'] == mode for row in rows))
+                if mode == 'core':
+                    self.assertTrue(all(row['low_ste_threshold'] is None and
+                                        row['high_ste_threshold'] is None for row in rows))
+                    with tempfile.TemporaryDirectory() as folder:
+                        pipeline.write_csv(Path(folder) / 'sweep.csv', rows)
+                        pipeline.write_json(Path(folder) / 'selection.json', selection)
+
     @classmethod
     def setUpClass(cls):
         cls.training = pipeline.prepare_records(pipeline.load_audio_folder(TRAIN_DIR))
 
     def require_fit(self):
         self.assertTrue(callable(getattr(pipeline, 'fit_training_model', None)),
                         'Models must be calibrated and locked from TRAIN before TEST reads')
 
     def test_loader_preserves_explicit_split_provenance(self):
         self.assertEqual({record.get('split') for record in self.training}, {'train'})
@@ -180,21 +217,21 @@ class TrainingProtocolTests(unittest.TestCase):
         self.assertNotIn('previous_W', selection)
         self.assertEqual(set(selection['evaluated_files']), {'phone_F1', 'phone_M1', 'studio_F1', 'studio_M1'})
         self.assertEqual(model['W'], selection['selected_W'])
         self.assertEqual(model['finalW'], model['W'])
         self.assertEqual(model['candidate_frame_selected_W'], proposal['W'])
         self.assertEqual(model['candidate_frame_f1'], proposal['train_frame_f1'])
         self.assertEqual(model['candidate_cleanup_records']['full_pipeline_records'], 4)
         self.assertNotIn('train_frame_f1', model)
         self.assertNotIn('selection_scores', model)
         self.assertNotIn('W_selection_test', model)
-        self.assertEqual(model['schema_version'], 2)
+        self.assertEqual(model['schema_version'], 3)
         self.assertEqual(model['metrics_schema_version'], 2)
         self.assertEqual(model['parameter_selection_set'], 'train')
         self.assertEqual(model['evaluation_protocol'], 'train_selected_reused_test')
         self.assertTrue(model['historical_test_exposure'])
         self.assertTrue(all('final_region_mae_ms' in row and 'boundary_MAE_ms' not in row for row in rows))
         self.assertEqual(before, json.dumps(self.training, sort_keys=True))
 
     def test_fit_rejects_test_external_and_spoofed_test_path_but_accepts_array_fold(self):
         self.require_fit()
         for split in ('test', 'external', None):
@@ -202,29 +239,34 @@ class TrainingProtocolTests(unittest.TestCase):
             with self.subTest(split=split), self.assertRaisesRegex(ValueError, 'TRAIN|train'):
                 pipeline.fit_training_model('tt1', [record])
         with self.assertRaisesRegex(ValueError, 'TRAIN|train'):
             pipeline.fit_training_model('tt1', [dict(synthetic_record(), wav_path=str(TEST_DIR / 'phone_F2.wav'))])
         model, rows = pipeline.fit_training_model('tt1', [synthetic_record()])
         self.assertEqual(rows, [])
         self.assertEqual(model['training_files'], ['array_fold'])
 
     def test_changed_test_lab_does_not_affect_model_noise_or_weight(self):
         self.require_fit()
-        model, _ = pipeline.fit_training_model('tt2', self.training)
         record = pipeline.prepare_records(pipeline.load_audio_folder(TEST_DIR))[0]
-        before = json.dumps(model, sort_keys=True)
-        first = pipeline.predict_and_score('tt2', record, model)
         modified = dict(record, intervals=[(0., record['duration'], 'sil')], labels=[0] * len(record['labels']))
-        second = pipeline.predict_and_score('tt2', modified, model)
-        self.assertEqual(first['final_regions'], second['final_regions'])
-        self.assertNotEqual(first['metrics']['mae_ms'], second['metrics']['mae_ms'])
-        self.assertEqual(before, json.dumps(model, sort_keys=True))
+        for mode in ('core', 'enhanced'):
+            with self.subTest(mode=mode):
+                model, _ = pipeline.fit_training_model('tt2', self.training, endpoint_mode=mode)
+                before = json.dumps(model, sort_keys=True)
+                first = pipeline.predict_and_score('tt2', record, model)
+                second = pipeline.predict_and_score('tt2', modified, model)
+                self.assertEqual(first['final_regions'], second['final_regions'])
+                self.assertEqual(first['mask'], second['mask'])
+                self.assertEqual(first['diagnostic'], second['diagnostic'])
+                self.assertNotEqual(first['metrics']['ground_truth_region_count'],
+                                    second['metrics']['ground_truth_region_count'])
+                self.assertEqual(before, json.dumps(model, sort_keys=True))
 
     def test_single_file_fits_before_target_read_and_never_reloads_all_test(self):
         # Keep the real fits/scorers; suppress only artifacts and graphics.
         args = parse_args(['--algorithm', 'all', '--file', 'phone_F2.wav', '--no-show'])
         real_loader = pipeline.load_audio_file
         real_folder = pipeline.load_audio_folder
         lock = []
         self.require_fit()
         real_fit = pipeline.fit_training_model
         def fit(algorithm, records):
diff --git a/tests/test_weight_selection.py b/tests/test_weight_selection.py
index bb8439d..b23e3fd 100644
--- a/tests/test_weight_selection.py
+++ b/tests/test_weight_selection.py
@@ -1,20 +1,32 @@
 """Final-region W selection: balanced errors, valid counts, deterministic ties."""
 import unittest
 from app import pipeline
 from app.config import TRAIN_DIR
 
 def row(weight,name,error,gt=1,pred=1):
     return dict(W=weight,filename=name,final_region_mae_ms=error,
                 ground_truth_region_count=gt,predicted_region_count=pred)
 
 class FinalWeightSelectionTests(unittest.TestCase):
+    def test_mixed_endpoint_policies_cannot_select_one_shared_weight(self):
+        rows=[dict(row(1,'a',1),endpoint_mode='core'),
+              dict(row(20,'a',0),endpoint_mode='enhanced')]
+        with self.assertRaisesRegex(ValueError,'policy'):
+            self.select(rows)
+
+    def test_primary_mean_is_undefined_with_one_invalid_count(self):
+        result=self.select([row(1,'a',None,pred=2),row(1,'b',10)])
+        self.assertIsNone(result['selected_summary']['mean_MAE_ms'])
+        self.assertEqual(result['selected_summary']['invalid_files'],1)
+        self.assertEqual(result['selected_summary']['valid_files_mean_MAE_ms'],10)
+
     def select(self,rows,tie_preference=20):
         return pipeline.select_final_weight(rows,tie_preference)
 
     def test_all_four_optimal_uses_declared_tie_preference(self):
         rows=[row(w,n,e) for w in (1,5,20) for n,e in [('a',32.5),('b',7.5),('c',7.5),('d',7.5)]]
         result=self.select(rows)
         self.assertEqual(result['selected_W'],20)
         self.assertEqual(result['shared_optimal_W'],[1,5,20])
         self.assertAlmostEqual(result['selected_summary']['mean_MAE_ms'],13.75)
 
diff --git a/tools/build_notebooks.py b/tools/build_notebooks.py
index c9461db..fdbbe39 100644
--- a/tools/build_notebooks.py
+++ b/tools/build_notebooks.py
@@ -736,21 +736,21 @@ Project maintainers refresh this repository's audited CODE ZIP by rebuilding wit
     code(fit_predict)
     md("## End-to-end detection and summary\n\nDetection uses features and the fitted model. Target LAB is consulted only after final regions have been computed, for scores and plot references.")
     prepared = source_function("app/pipeline.py", "prepare_records")
     prepared = prepared.replace("def prepare_records(audio_records, source_histogram=False):", "def prepare_records(audio_records):")
     prepared = prepared.replace("    Input: audio_records chứa waveform/Fs/LAB. source_histogram giữ tương\n    thích các điểm gọi cũ; mọi thuật toán hiện chỉ cần đặc trưng năng lượng.\n",
                                 "    Input: audio_records chứa waveform/Fs/LAB; dùng đặc trưng năng lượng.\n")
     code(prepared + "\n\n\n" + standalone_pipeline(algorithm))
     code(source_function("app/pipeline.py", "summarize"))
     if algorithm == "tt2":
         md("## Global W calibration rule\n\nEvaluate integer W=1…50 on the four TRAIN LABs using the actual FINAL endpoint pipeline. Prefer valid region counts, minimize worst per-file regret, then mean MAE; tied values prefer W=20. Historical TEST sweeps are prior development evidence only; they are not rerun for calibration.")
-        code('W_CANDIDATES = tuple(float(w) for w in range(1, 51))\nERROR_EPS_MS = 1e-8\n\n' + functions("app/weight_selection.py", "select_final_weight", "sweep_final_weights"))
+        code('W_CANDIDATES = tuple(float(w) for w in range(1, 51))\nERROR_EPS_MS = 1e-8\nPOLICY_FIELDS = ("endpoint_mode", "boundary_convention", "minimum_speech_ms", "minimum_silence_ms", "padding_stage")\n\n' + functions("app/weight_selection.py", "select_final_weight", "sweep_final_weights"))
     md("## Load four TRAIN input pairs\n\nTRAIN is read first. TEST WAV/LAB reads follow calibration and model locking.")
     code(LOAD_DATA)
     md("## Fit fresh TRAIN parameters\n\nAll core model parameters and noise statistics are computed using the four TRAIN recordings.")
     code(FIT_MODEL)
     if algorithm == "tt2":
         md("### TRAIN FINAL W calibration\n\nShow all 50 candidates and 200 TRAIN rows. The original candidate-frame F1 proposal remains a separate diagnostic. The selected FINAL W is shared by all files.")
         code(CALIBRATE_W)
     parameters = {
         "tt1": ["threshold", "silence_count", "speech_count", "overlap_low", "overlap_high", "iterations", "stop_reason", "area_residual", "overlap_silence_count", "overlap_speech_count"],
         "tt2": ["candidate_frame_selected_W", "candidate_frame_f1", "candidate_cleanup_records", "W", "finalW", "tie_preference_W", "bins", "smooth_radius", "padding_ms", "padding_frames"],
diff --git a/tools/run_notebooks.py b/tools/run_notebooks.py
index 4731174..9efa878 100644
--- a/tools/run_notebooks.py
+++ b/tools/run_notebooks.py
@@ -83,21 +83,47 @@ def audit_metric_keys(scores, label, require_primary=True):
         raise ValueError(f'{label}: duplicate casefold metric keys')
     if (require_primary and 'mae_ms' not in scores) or 'boundary_MAE_ms' in scores:
         raise ValueError(f'{label}: PRIMARY MAE must use mae_ms without a boundary alias')
     if any(key.startswith('boundary_') and not key.startswith('boundary_inside_') for key in scores):
         raise ValueError(f'{label}: tolerance metrics must use tolerance_boundary_ prefix')
 
 
 def audit_model_protocol(model, locked_digest):
     if 'W_selection_test' in model:
         raise ValueError('New models cannot contain legacy TEST W selection')
-    expected = dict(schema_version=2, metrics_schema_version=2,
+    if model.get('schema_version') not in (2, 3):
+        raise ValueError('Model schema_version: expected schema2/3 TRAIN protocol')
+    if model['schema_version'] == 3:
+        mode = model.get('endpoint_mode')
+        if mode not in ('core', 'enhanced'):
+            raise ValueError('Model endpoint_mode: unknown endpoint mode')
+        expected_policy = dict(minimum_speech_ms=0. if mode == 'core' else 100.,
+                               minimum_silence_ms=200., boundary_convention='union of active frame supports')
+        if any(model.get(key) != value for key, value in expected_policy.items()):
+            raise ValueError('Model endpoint policy fields disagree with mode')
+        if mode == 'core' and (model.get('endpoint_noise') is not None or
+                                model.get('padding_stage') != 'excluded from core FINAL'):
+            raise ValueError('Core endpoint policy cannot apply noise or padding')
+        if mode == 'enhanced' and (model.get('endpoint_noise') is None or
+                                    model.get('padding_stage') not in ('none', 'candidate diagnostics only')):
+            raise ValueError('Enhanced endpoint policy requires TRAIN noise and candidate-only padding')
+        if 'W_selection_train' in model:
+            selection = model['W_selection_train']
+            policy_keys = ('endpoint_mode', 'boundary_convention', 'minimum_speech_ms',
+                           'minimum_silence_ms', 'padding_stage')
+            if any(selection.get(key) != model.get(key) for key in policy_keys):
+                raise ValueError('TRAIN W selection policy differs from model policy')
+            if any(model.get(key) != selection.get('selected_W') for key in ('W', 'finalW')):
+                raise ValueError('TRAIN selected W differs from locked model')
+            if selection.get('calibration_digest') != model.get('calibration_digest'):
+                raise ValueError('TRAIN selection calibration digest differs from model')
+    expected = dict(metrics_schema_version=2,
                     parameter_selection_set='train', evaluation_protocol='train_selected_reused_test',
                     historical_test_exposure=True)
     for key, value in expected.items():
         if model.get(key) != value:
             raise ValueError(f'Model {key}: expected schema2 TRAIN protocol ({value})')
     if set(model.get('training_files', [])) != set(TRAIN_NAMES) or len(model.get('training_files', [])) != 4:
         raise ValueError('Model training_files must contain exactly four TRAIN names')
     if model_digest(model) != locked_digest:
         raise ValueError('Frozen TRAIN model lock digest differs after TEST/ALL scoring')
 
