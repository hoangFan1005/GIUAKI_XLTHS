### Task4 — Thời gian biên và 200/100 ms: khảo sát TRAIN, không đổi default bằng TEST

**Files:** mở rộng `tools/check_endpoint_robustness.py`, `tests/test_endpoint_robustness.py`; nếu cần helper dùng riêng thí nghiệm thì thêm `core/decision_timing.py`, `tests/test_decision_timing.py`. Không nối helper thử nghiệm vào detector default trong task này.

**Interfaces:** `decision_cells(features: dict, duration: float) -> tuple[list[float],list[float]]` dùng tâm và hop thực. Các cạnh nội bộ là midpoint giữa hai centers liên tiếp; cạnh ngoài 0/duration theo nearest-frame convention được công bố. Trả một cell không chồng lấn cho mỗi frame; không thay analysis window 25 ms. Chuỗi không frame trả([],[]).

- [ ] Viết RED cho cell coverage/order/clipping và nhiều regions ở hai Fs; gap decision cells đúng190/200/210 ms; mép0/duration; chỉ một frame và đuôi ngắn. Không dùng `regions_to_mask` full 25ms support để chấm cell-basedregions.
- [ ] Thực hiện helper và diagnostic branch dùng cells **nhất quán** cho START/END/gap/span/mask membership; không chỉ trừ15 ms END. Không coi jH là END của chính khungj.
- [ ] Khảo sát tối đa các yếu tố đã khai báo: support hiện tại vs centered cells; min speech 0 vs100; riêng enhancedTT1 LOW gốc vsLOW=T1/HIGH=max(1.5T1,noise_upper). Thử từng yếu tố, không quét toàn bộ tổ hợp. Học trên 3 TRAIN, kiểm tra file TRAIN thứ 4 trong4 folds. Với TT2, **hiệu chỉnh lại W1…50 riêng cho từng nhánh thử nghiệm bằng chính geometry/cleanup/scorer của nhánh đó trên 3 fit files**, rồi khóa W để chấm file TRAIN giữ lại. Manifest ghi trial_id và geometry/filter/mode dùng cho chọn W; không dùng W đã chọn theo support-enhanced để gọi nhánh cells hoặc core là đã tối ưu.
- [ ] Xuất START/END errors, regioncounts, full/valid-only MAE/RMSE và config provenance. Gate numeric: enhanced current unchanged; báo mọi fold regression. Chưa chọn convention từ TEST counterfactual ở phầnA.
- [ ] Reuse48 waveforms physical190/200/210/250, hai Fs/sáu phase; thêm burst 75/95/100/105ms và audioedges/weak tails. Phân biệt tests duration-rule trên nhãn với characterization duration thực.

**Giới hạn bắt buộc:** centered cells **không đủ** bảo đảm silence vật lý200 ms được giữ; window có speech một phần vẫn có thể bị phân loại speech. Không biến24 ca physical200/210 hiện fail thành pass bằng đổi GT/giảm ngưỡng 200. Đề yêu cầu lọc khoảng lặng ước lượng dưới200, không nêu convention END hay bảo đảm detector biết mọi silence thật. Nếu cần sửa estimator để giữ đúng silence vật lý quanh200, cần thiết kế refinement riêng dựa trên TRAIN/waveform, không chỉ đổi timestamp. Task này bàn giao khảo sát và khuyến nghị; áp dụng production convention/LOW mới cần trình người dùng kết quả cụ thể để quyết định, giữ default hiện tại trong lúc đó.

### Global Constraints

- Giữ3 thuật toán, Python tự tính; TT2 chỉ Energy, không F0/Centroid, không thêm ZCR/thuật toán thứ 4.
- Analysis frame 25 ms, hop 10 ms, nearest samples/ties-to-even; Fs44.1k dùng1102/441samples, thời gian thực được báo cáo.
- Minimum internal silence 200 ms; exact estimated200 ms phải giữ, <200 ms mới nối. Silence đầu/cuối không ép kéo dài200 ms.
- Mỗi FINAL speech region có START/END; không candidate/debug trong primary figure/MAE.
- TRAIN chọn tham số và khóa model trước mở TEST; target LAB chỉ dùng scoring/plot. Không rule filename, GT snapping, TEST tuning hoặc bỏ lỗi lớn.
- Giữ `historical_test_exposure=true`; legacy TEST-calibrated model phải giữ provenance cũ. Đổi protocol không tạo holdout độc lập.
- Metric schema 2 tiếp tục `mae_ms`/`rmse_ms`; thiếu/thừa vùng làm primary undefined, không dùng mean subset thay mean đầy đủ.
- Không sửa slides/PPTX/PDF, dữ liệu Source/audio hoặc ZIP Python cũ. CODE notebook ZIP được cập nhật khi source notebook thay đổi.
- Không hứa MAE core thấp hơn enhanced hoặc timestamp mới làm mọi file tốt lên.



Execution interfaces from integration: native decision helper lives in app.pipeline.algorithm_decision; fit_training_model accepts endpoint_mode keyword after Task3. Do not alter default detect_regions or persist models to canonical outputs. Use a dedicated outputs/tables/endpoint_modes_oct07/timing_research/ evidence subfolder. Locked legacy support geometry remains default. For experiments, common branch predictor must be used in BOTH W sweep and held-out scoring; fit TT1/T3/noise only on 3 train files. If calling fit_training_model for preliminary TT2 produces a support W sweep, it is only preliminary: branch-specific experiment sweep must select final experiment W separately and manifest must capture that. Share 3-fit TRAIN native model per fold where feasible, avoid copying full candidate arrays in each CSV row. Report all fold regressions against matching same-mode support branch, do not pick by TEST or automatically apply default timing. Characterize each declared production mode on 48 physical-gap waveforms with valid locked TRAIN models in addition to the existing fixed LOW=.1/HIGH=.5 oracle study; distinguish calibration-model thresholds from fixed diagnostic thresholds. Test expected *estimated* 200ms gap retention separately from true physical-gap characterization.
