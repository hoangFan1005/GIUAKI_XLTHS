# Task 5 independent spec and quality review

Reviewed committed scope: 27dc471..b38d640, requirements in task-5-brief.md, implementation report and review package. Task 4 timing/research and Task 6 global gates are excluded. No implementation edits, staging, subagents, suite reruns, or production artifact changes were made.

## Verdicts

**Spec compliance: PASS for the required committed comparison/default notebook deliverables.** CLI defaults to enhanced, exposes core and headless both-mode comparison, and fits all requested algorithm/mode models before TEST reads. Production paths use the common mode-root helper and comparison root. Metrics retain schema2 primary keys; summaries group by algorithm and mode and make full primary means undefined for invalid counts. Core plots use native thresholds with nullable LOW/HIGH; enhanced plots show actual HIGH/LOW. Three standalone notebooks contain both models and lock digests before TEST, both-mode results/diagnostics, selected enhanced aliases and five image cells. TT2 has 200 TRAIN sweep rows per mode. The CODE ZIP contains exactly the three executed notebooks, byte equal. Documentation distinguishes policy modes, discloses reused TEST and Gaussian approximation, and retains large/count errors. The Task 3 digest and geometry follow-ups are implemented; generated Task 2 comments qualify enhanced noise and TT3 direction. No committed slide, Source/audio, old Python ZIP, native detector/fit arithmetic, or API changes were found.

**Code quality: REQUEST CHANGES — one P2 regression.** The committed comparison artifacts are valid, but an ordinary supported CLI invocation can invalidate the shared benchmark needed by the notebook auditor.

## Finding

### [P2] Preserve the all-algorithm TEST table during a single-algorithm all-dataset run

Location: `app/pipeline.py:623-625` (especially 624-625).

The new `if evaluate_all:` branch writes `tables/all/test_metrics.csv` and `tables/all/summary.csv` for every algorithm selection. After the full all-algorithm benchmark exists, `python main1.py --evaluate-all` (or `main.py --algorithm tt1 --evaluate-all`) replaces these shared files with TT1-only rows. The dedicated run folder is correctly `tt1_all_dataset`, but the unconditional extra writes delete TT2/TT3 shared benchmark rows. `tools/run_notebooks.py` reads `tables/all/summary.csv` and requires one saved row for each notebook algorithm, so TT2/TT3 notebook validation and packaging fail after that valid command. This also conflicts with the run-isolation intention explicitly documented immediately above this branch.

Bounded reproduction: disposable synthetic data from the existing tiny dataset helper, real production pipeline, plotting mocked, no existing test suite run. First `--evaluate-all` produced shared summary algorithms `['tt1', 'tt2', 'tt3']`; then fixed TT1 `--evaluate-all` changed them to `['tt1']`. No production outputs were touched.

Suggested correction: update the shared `tables/all` TEST projection only when the selected algorithms cover all three primary algorithms; keep single-algorithm projections within their dedicated run folder. Add a focused regression covering full run followed by each fixed main all-dataset invocation.

## Evidence and review limits

- Read-only notebook JSON checks: every notebook has exactly five PNG outputs; ordered code source SHA256 equals execution metadata; `models` indexes contain core/enhanced; each mode has eight all-file results; each notebook model equals its actual mode production JSON. TT2 sweeps contain 200 rows each, other algorithms contain none.
- Read-only CODE ZIP checks: exactly three members; each member byte equal to corresponding saved notebook.
- Production CSV counts: 24 rows per mode in all-dataset metric table, 200 rows per mode in TT2 sweep.
- AST comparison of algorithm_decision, detect_regions, fit_training_model against 47cc00b: identical at b38d640, including docstrings and all numeric/API nodes.
- Source review confirms schema3 requires a nonempty 64-hex calibration digest and recomputes the self-excluded digest; old schema2 acceptance is preserved. Weight selection compares diagnostic geometry to declared boundary convention, and notebook generator embeds that helper.
- Source review confirms default main dispatches once and default demo retains four selected-mode TEST figures; compare flag forces no-show.
- Existing implementation's focused test evidence was read; those suites and fresh notebook kernels were not rerun. Full global gate remains Task 6/root scope.
- No additional P0/P1/P2 issues identified within this review. A remaining production-source comment at app/pipeline.py:182 describes HIGH/LOW without saying enhanced; generated comments are mode-specific, so this is a prose cleanup observation, not a blocking finding.
