"""Scratch evidence only: fresh fits compared to immutable Task1 baseline."""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from app import pipeline
from app.config import TRAIN_DIR, TEST_DIR

out = ROOT / 'outputs/tables/endpoint_modes_oct07'
baseline = json.loads((out / 'baseline.json').read_text(encoding='utf-8'))
train = pipeline.prepare_records(pipeline.load_audio_folder(TRAIN_DIR))
models = {}
sweeps = {}
for mode in ('core', 'enhanced'):
    for algorithm in ('tt1', 'tt2', 'tt3'):
        models[mode, algorithm], sweeps[mode, algorithm] = pipeline.fit_training_model(
            algorithm, train, endpoint_mode=mode)
# Every model is locked before the first TEST WAV/LAB load.
test = pipeline.prepare_records(pipeline.load_audio_folder(TEST_DIR))
records = {f"{r['split']}/{r['name']}": r for r in train + test}
cases = []
for old in baseline['detections']:
    algorithm = old['algorithm']
    model = models['enhanced', algorithm]
    actual = json.loads(json.dumps(pipeline.predict_and_score(algorithm, records[old['record_id']], model)))
    for key in ('mask', 'final_regions', 'predicted_boundaries', 'ground_truth_regions', 'ground_truth_boundaries', 'region_pairs'):
        assert actual[key] == old[key], (old['record_id'], algorithm, key)
    for key, value in old['metrics'].items():
        if key != 'model_schema_version':
            assert actual['metrics'][key] == value, (old['record_id'], algorithm, key)
    for key, value in old['diagnostic'].items():
        assert actual['diagnostic'][key] == value, (old['record_id'], algorithm, key)
    cases.append(dict(record_id=old['record_id'], algorithm=algorithm,
                      mask_final_boundaries_numeric_metrics_status_exact=True,
                      original_diagnostics_exact=True))
for algorithm in ('tt1', 'tt2', 'tt3'):
    old = baseline['models'][algorithm]
    new = models['enhanced', algorithm]
    for key in ('threshold', 'W', 'endpoint_noise', 'candidate_frame_selected_W', 'candidate_frame_f1'):
        if key in old:
            assert new[key] == old[key], (algorithm, key)
summary = {}
for mode in ('core', 'enhanced'):
    summary[mode] = {}
    for algorithm in ('tt1', 'tt2', 'tt3'):
        model = models[mode, algorithm]
        summary[mode][algorithm] = dict(T=model.get('threshold'), W=model.get('W'),
            endpoint_noise=model['endpoint_noise'], calibration_digest=model['calibration_digest'])
        if algorithm == 'tt2':
            selection = model['W_selection_train']
            summary[mode][algorithm].update(selected_summary=selection['selected_summary'],
                shared_optimal_W=selection['shared_optimal_W'], candidate_frame_W=model['candidate_frame_selected_W'])
            pipeline.write_csv(out / f'task3-{mode}-sweep.csv', sweeps[mode, algorithm])
            pipeline.write_json(out / f'task3-{mode}-selection.json', selection)
protected = {}
for relative, expected in baseline['sha256'].items():
    if (relative.startswith(('Source/', 'data/', 'slides/',
                            'outputs/models/', 'outputs/tables/', 'outputs/diagnostics/',
                            'outputs/predictions/', 'notebooks/')) or
            relative.startswith('submission/') and relative.endswith('.zip')):
        actual = hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()
        assert actual == expected, relative
        protected[relative] = actual
pipeline.write_json(out / 'task3-enhanced-regression.json', dict(
    cases=cases, count=len(cases), locked_models=summary, protected_unchanged=protected))
print(json.dumps(dict(cases=len(cases), policies=summary), ensure_ascii=False))
