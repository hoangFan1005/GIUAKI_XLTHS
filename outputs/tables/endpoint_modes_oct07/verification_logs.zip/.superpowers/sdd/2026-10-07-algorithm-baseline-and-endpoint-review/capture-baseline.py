"""One-shot Task1 evidence capture; never writes canonical artifacts."""
import csv
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import platform
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from app import pipeline
from app.config import TRAIN_DIR, TEST_DIR

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def normalized(value):
    return json.loads(json.dumps(value))

models = {algorithm: json.loads((ROOT / f'outputs/models/{algorithm}.json').read_text(encoding='utf-8'))
          for algorithm in ('tt1', 'tt2', 'tt3')}
records = pipeline.prepare_records(pipeline.load_audio_folder(TRAIN_DIR))
records += pipeline.prepare_records(pipeline.load_audio_folder(TEST_DIR))
with (ROOT / 'outputs/tables/all_all_dataset/test_metrics.csv').open(encoding='utf-8-sig', newline='') as handle:
    saved_metrics = {(row['file'], row['algorithm']): row for row in csv.DictReader(handle)}
with (ROOT / 'outputs/tables/hotfix_oct06/regression.csv').open(encoding='utf-8-sig', newline='') as handle:
    accepted = {(row['filename'], row['algorithm']): row for row in csv.DictReader(handle)}
results = []
for algorithm, model in models.items():
    before = json.dumps(model, sort_keys=True)
    for record in records:
        result = normalized(pipeline.predict_and_score(algorithm, record, model))
        name = record['name']
        saved_diagnostic = json.loads((ROOT / f'outputs/diagnostics/{algorithm}/{name}.json').read_text(encoding='utf-8'))
        assert result['diagnostic'] == saved_diagnostic, (algorithm, name, 'diagnostics')
        row = saved_metrics[(name, algorithm)]
        for key, value in result['metrics'].items():
            saved = row[key]
            if value is None:
                assert saved == '', (algorithm, name, key)
            elif isinstance(value, bool):
                assert saved == str(value), (algorithm, name, key)
            elif isinstance(value, (float, int)):
                assert float(saved) == value, (algorithm, name, key)
            else:
                assert saved == value, (algorithm, name, key)
        old = accepted[(name, algorithm)]
        assert result['final_regions'] == json.loads(old['after_regions']), (algorithm, name, 'accepted FINAL')
        assert result['metrics']['mae_ms'] == float(old['after_mae_ms']), (algorithm, name, 'accepted MAE')
        assert result['metrics']['status'] == old['status'], (algorithm, name, 'accepted status')
        result.update(split=record['split'], record_id=f"{record['split']}/{name}",
                      model_id=f'outputs/models/{algorithm}.json',
                      T=result['diagnostic'].get('threshold', result['diagnostic'].get('energy_threshold')),
                      W=model.get('W'), LOW=result['diagnostic']['low_ste_threshold'],
                      HIGH=result['diagnostic']['high_ste_threshold'])
        results.append(result)
    assert before == json.dumps(model, sort_keys=True), (algorithm, 'model mutated')

paths = set()
for directory in ('Source', 'data', 'slides', 'algorithms', 'app', 'core', 'notebooks'):
    paths.update(path for path in (ROOT / directory).rglob('*')
                 if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc')
paths.update((ROOT / 'submission').glob('*.zip'))
for directory in ('outputs/models', 'outputs/tables', 'outputs/diagnostics', 'outputs/predictions'):
    paths.update(path for path in (ROOT / directory).rglob('*')
                 if path.is_file() and 'endpoint_modes_oct07' not in path.parts)
paths.update(ROOT / path for path in ('outputs/README.md', 'submission/README.md', 'reports/KET_QUA_HIEN_TAI.md'))
hashes = {path.relative_to(ROOT).as_posix(): digest(path) for path in sorted(paths)}
verification = json.loads((ROOT / 'outputs/tables/hotfix_oct06/verification.json').read_text(encoding='utf-8'))
protected = ('Source/', 'data/', 'slides/', 'submission/THUAT_TOAN_')
previous = verification.get('preserved_sha256', verification.get('preserved_file_sha256', {}))
# Oct07 evidence uses preserved_sha256 on some revisions; inspect all hash maps.
compared = set()
for mapping in verification.values():
    if not isinstance(mapping, dict):
        continue
    for path, old_hash in mapping.items():
        if path.startswith(protected) and path in hashes and isinstance(old_hash, str) and len(old_hash) == 64:
            assert hashes[path] == old_hash, (path, 'Oct07 protected hash mismatch')
            compared.add(path)

evidence = dict(captured_utc=datetime.now(timezone.utc).isoformat(),
                git_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                baseline_mode='enhanced current saved models; read-only inference, no fit or regeneration',
                expected_existing_test_count=133,
                environment=dict(python=sys.version, executable=sys.executable, platform=platform.platform(),
                                 packages={name: importlib.metadata.version(name)
                                           for name in ('numpy', 'matplotlib', 'nbformat', 'nbclient', 'ipython')}),
                models=models,
                records=[dict(record_id=f"{record['split']}/{record['name']}", name=record['name'],
                              split=record['split'], sample_rate=record['sample_rate'], duration=record['duration'],
                              wav_path=str(record['wav_path']), features=record['features'],
                              intervals=record['intervals'], labels=record['labels']) for record in records],
                detections=results, sha256=hashes,
                verification=dict(saved_diagnostic_matches=24, saved_metric_matches=24,
                                  oct07_accepted_region_mae_status_matches=24,
                                  oct07_protected_hash_matches=sorted(compared),
                                  test_mean_mae_ms={algorithm: sum(result['metrics']['mae_ms'] for result in results
                                      if result['algorithm'] == algorithm and result['split'] == 'test') / 4
                                      for algorithm in models}))
target = ROOT / 'outputs/tables/endpoint_modes_oct07/baseline.json'
target.parent.mkdir(parents=True, exist_ok=True)
with target.open('x', encoding='utf-8', newline='\n') as handle:
    json.dump(evidence, handle, ensure_ascii=False, indent=2, allow_nan=False)
    handle.write('\n')
print(json.dumps(evidence['verification'], ensure_ascii=False))
print(f'Captured {len(models)} saved models, {len(records)} records, {len(results)} detections, {len(hashes)} hashes')
