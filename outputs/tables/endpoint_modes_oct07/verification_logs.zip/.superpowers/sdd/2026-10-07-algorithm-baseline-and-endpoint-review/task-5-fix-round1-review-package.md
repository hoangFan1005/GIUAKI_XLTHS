# Review task-5-fix-round1
Base: 9227b1d
Head: HEAD

c5e82dd Preserve shared benchmarks and correct Energy units
 app/pipeline.py                                    |   8 +-
 app/plotting.py                                    |   2 +-
 notebooks/THUAT_TOAN_1.ipynb                       |   6 +-
 notebooks/THUAT_TOAN_2.ipynb                       | 108 ++++-----
 notebooks/THUAT_TOAN_3.ipynb                       |   6 +-
 .../endpoint_modes/comparison/artifact_audit.json  |  54 ++++-
 .../core/diagnostics/tt2/phone_F1.json             |   2 +-
 .../core/diagnostics/tt2/phone_F2.json             |   2 +-
 .../core/diagnostics/tt2/phone_M1.json             |   2 +-
 .../core/diagnostics/tt2/phone_M2.json             |   2 +-
 .../core/diagnostics/tt2/studio_F1.json            |   2 +-
 .../core/diagnostics/tt2/studio_F2.json            |   2 +-
 .../core/diagnostics/tt2/studio_M1.json            |   2 +-
 .../core/diagnostics/tt2/studio_M2.json            |   2 +-
 .../core/figures/comparison/phone_F1.png           | Bin 572576 -> 572786 bytes
 .../core/figures/comparison/phone_F2.png           | Bin 490260 -> 490404 bytes
 .../core/figures/comparison/phone_M1.png           | Bin 588846 -> 588886 bytes
 .../core/figures/comparison/phone_M2.png           | Bin 594801 -> 594824 bytes
 .../core/figures/comparison/studio_F1.png          | Bin 553766 -> 553808 bytes
 .../core/figures/comparison/studio_F2.png          | Bin 494145 -> 494272 bytes
 .../core/figures/comparison/studio_M1.png          | Bin 434966 -> 434986 bytes
 .../core/figures/comparison/studio_M2.png          | Bin 583707 -> 583835 bytes
 .../endpoint_modes/core/figures/tt2/phone_F1.png   | Bin 210514 -> 210911 bytes
 .../endpoint_modes/core/figures/tt2/phone_F2.png   | Bin 177022 -> 177002 bytes
 .../endpoint_modes/core/figures/tt2/phone_M1.png   | Bin 216280 -> 216344 bytes
 .../endpoint_modes/core/figures/tt2/phone_M2.png   | Bin 218509 -> 218477 bytes
 .../endpoint_modes/core/figures/tt2/studio_F1.png  | Bin 204318 -> 204395 bytes
 .../endpoint_modes/core/figures/tt2/studio_F2.png  | Bin 183530 -> 183770 bytes
 .../endpoint_modes/core/figures/tt2/studio_M1.png  | Bin 160473 -> 160419 bytes
 .../endpoint_modes/core/figures/tt2/studio_M2.png  | Bin 212779 -> 212897 bytes
 outputs/endpoint_modes/core/models/tt2.json        |   6 +-
 .../tables/all_all_dataset/test_thresholds.csv     |  16 +-
 .../core/tables/tt2_w_selection/selection.json     |   2 +-
 .../enhanced/diagnostics/tt2/phone_F1.json         |   2 +-
 .../enhanced/diagnostics/tt2/phone_F2.json         |   2 +-
 .../enhanced/diagnostics/tt2/phone_M1.json         |   2 +-
 .../enhanced/diagnostics/tt2/phone_M2.json         |   2 +-
 .../enhanced/diagnostics/tt2/studio_F1.json        |   2 +-
 .../enhanced/diagnostics/tt2/studio_F2.json        |   2 +-
 .../enhanced/diagnostics/tt2/studio_M1.json        |   2 +-
 .../enhanced/diagnostics/tt2/studio_M2.json        |   2 +-
 outputs/endpoint_modes/enhanced/models/tt2.json    |   6 +-
 .../tables/all_all_dataset/test_thresholds.csv     |  16 +-
 .../enhanced/tables/tt2_w_selection/selection.json |   2 +-
 submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip         | Bin 1729909 -> 1729936 bytes
 tests/test_endpoint_mode_integration.py            | 246 ++++++++++++---------
 tests/test_endpoint_modes.py                       |   2 +-
 tools/build_notebooks.py                           |   2 +-
 48 files changed, 296 insertions(+), 218 deletions(-)
diff --git a/app/pipeline.py b/app/pipeline.py
index 12b013a..16958ab 100644
--- a/app/pipeline.py
+++ b/app/pipeline.py
@@ -145,21 +145,21 @@ def algorithm_decision(algorithm: str, features: dict, params: dict) -> tuple[li
             raise ValueError('Unknown TT3 speech_direction')
         mask, diagnostic = tt3.predict(features, params), dict(threshold=params['threshold'])
     elif algorithm in ('tt2', 'tt2-context'):
         mask, diagnostic = tt2.predict(features, params)
         if diagnostic['variant'] == 'source':
             mask = [int(e > diagnostic['energy_threshold']) for e in features['energy']]
     else:
         raise ValueError(f'Unknown algorithm: {algorithm}')
     source_histogram = algorithm in ('tt2', 'tt2-context') and diagnostic.get('variant') == 'source'
     diagnostic.update(native_threshold=diagnostic['energy_threshold'] if algorithm in ('tt2', 'tt2-context') else params['threshold'],
-                      native_threshold_units='sum of squared samples' if source_histogram else 'normalized STE')
+                      native_threshold_units='mean squared sample amplitude' if source_histogram else 'normalized STE')
     return mask, diagnostic
 
 
 def detect_regions(algorithm, features, duration, params):
     """Detect FINAL speech from features and a fitted model, without LAB or I/O.
 
     Input: algorithm, frame features/supports, duration and frozen TRAIN model.
     Output: mask/final_regions/diagnostic and derived predicted_boundaries.
     Core merges native support gaps below 200 ms without a duration filter.
     Enhanced requires TRAIN noise and speech-high Gaussian direction.
@@ -172,21 +172,21 @@ def detect_regions(algorithm, features, duration, params):
         raise ValueError('Fitted model requires endpoint_noise; call fit_training_model on TRAIN before inference')
     # The raw Gaussian classifier supports both directions. FINAL HIGH/LOW
     # requires speech-high, so reject an incompatible imported model early.
     if mode == 'enhanced' and algorithm == 'tt3' and params.get('speech_direction', 'high') != 'high':
         raise ValueError("FINAL endpoint detection requires TT3 speech_direction='high'; "
                          "inverted/unknown directions are not supported by energy hysteresis")
     seed, diagnostic = algorithm_decision(algorithm, features, params)
     source_histogram=algorithm=='tt2' and params.get('variant','source')=='source'
     mask = tt2.pad_speech(seed, diagnostic['padding_frames']) if mode == 'enhanced' and source_histogram else seed
 
-    # Algorithm masks are candidates. Final endpoints require HIGH confirmation,
+    # Algorithm masks are candidates. Enhanced endpoints require HIGH confirmation,
     # LOW continuation, short-gap merging and duration filtering.
     candidate_regions=[(s,e) for s,e,state in mask_segments(mask,features['starts'],duration,features['ends']) if state]
     if mode == 'core':
         final_regions = []
         for start, end in candidate_regions:
             if final_regions and start - final_regions[-1][1] < MIN_SILENCE_SECONDS - 1e-12:
                 final_regions[-1] = (final_regions[-1][0], end)
             else:
                 final_regions.append((start, end))
         mask = regions_to_mask(final_regions, features['starts'], features['ends'])
@@ -314,21 +314,21 @@ def fit_training_model(algorithm, train_records, *, endpoint_mode='enhanced'):
         raise ValueError(f'Unknown algorithm: {algorithm}')
     model.update(schema_version=3, metrics_schema_version=2, endpoint_mode=endpoint_mode,
                  parameter_selection_set='train', evaluation_protocol='train_selected_reused_test',
                  historical_test_exposure=True, training_files=[record['name'] for record in train_records],
                  frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING,
                  minimum_internal_silence_ms=MIN_SILENCE_SECONDS*1000,
                  minimum_speech_ms=0. if endpoint_mode == 'core' else MIN_SPEECH_SECONDS*1000,
                  minimum_silence_ms=MIN_SILENCE_SECONDS*1000,
                  endpoint_noise=fit_noise_floor(train_records) if endpoint_mode == 'enhanced' else None,
                  endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding' if endpoint_mode == 'core' else 'hysteresis final regions; no fixed final padding',
-                 feature_rule='Energy (sum of squared samples)' if algorithm == 'tt2' else 'normalized STE',
+                 feature_rule='Energy (mean squared sample amplitude)' if algorithm == 'tt2' else 'normalized STE',
                  decision_rule='Energy > threshold' if algorithm == 'tt2' else 'STE <= threshold' if model.get('speech_direction') == 'low' else 'STE >= threshold',
                  padding_stage='excluded from core FINAL' if endpoint_mode == 'core' else 'candidate diagnostics only' if algorithm == 'tt2' else 'none',
                  boundary_convention='union of active frame supports')
     sweep_rows = []
     if algorithm == 'tt2':
         # Preserve the core's candidate-stage proposal under explicit names.
         # Its F1 is not a score for the W selected below by FINAL-region MAE.
         model['candidate_frame_selected_W'] = model['W']
         model['candidate_frame_f1'] = model.pop('train_frame_f1')
         model['candidate_frame_selection_scores'] = [
@@ -613,21 +613,21 @@ def run_experiment(args):
                 if args.no_show:
                     plt.close(figure)
                 else:
                     demo_figures.append(figure)
         else:
             demo_figures.sort(key=lambda figure: display_order.index(figure._suptitle.get_text()))
 
         # Lưu từng run độc lập; demo một thuật toán không ghi đè bảng tổng hợp all.
         all_mode_rows.extend(metric_rows)
         write_csv(run_folder / "test_metrics.csv", metric_rows)
-        if evaluate_all:
+        if evaluate_all and {"tt1", "tt2", "tt3"}.issubset(selected):
             write_csv(tables / "all" / "test_metrics.csv", [row for row in metric_rows if row["split"]=="test"])
             write_csv(tables / "all" / "summary.csv", summarize([row for row in metric_rows if row["split"]=="test"]))
         write_csv(run_folder / "summary.csv", summarize(metric_rows))
         write_csv(run_folder / "test_thresholds.csv", threshold_rows)
         if args.snr_study:
             write_csv(run_folder / "snr_study.csv", noise_rows)
         if args.compare_context:
             write_csv(tables / "context_benchmark_check.csv", context_benchmark(test_common))
         write_json(run_folder / "run_config.json", dict(algorithm=args.algorithm, endpoint_mode=mode, selected=selected,
                    input_file=str(input_path) if input_path else None, evaluated_files=evaluated_names,
diff --git a/app/plotting.py b/app/plotting.py
index c337327..aa82607 100644
--- a/app/plotting.py
+++ b/app/plotting.py
@@ -22,21 +22,21 @@ def _plot_axis(axis, record, result):
     axis.plot([i / fs for i in range(0, len(samples), stride)], samples[::stride],
               color="#555555", linewidth=.55, alpha=.4)
     energy_axis = axis.twinx()
     energy_axis.plot(record["features"]["centers"], record["features"]["ste_norm"],
                      color="#dd8b12", linewidth=1.6, alpha=.95)
     diagnostic = result['diagnostic']
     mode = diagnostic.get('endpoint_mode', 'enhanced')
     threshold_handles = []
     if mode == 'core':
         native = diagnostic['native_threshold']
-        if diagnostic['native_threshold_units'] == 'sum of squared samples':
+        if diagnostic['native_threshold_units'] == 'mean squared sample amplitude':
             peak = max(record['features']['energy'], default=0.)
             native = native / peak if peak else 0.
         energy_axis.axhline(native, color='#8E44AD', linestyle='-.', linewidth=1.2)
         threshold_handles.append(Line2D([], [], color='#8E44AD', linestyle='-.', label=f'Native T ({diagnostic.get("native_threshold_units")}): {diagnostic["native_threshold"]:.5g}'))
     else:
         low, high = diagnostic['low_ste_threshold'], diagnostic['high_ste_threshold']
         energy_axis.axhline(high,color='#8E44AD',linestyle='-.',linewidth=1.2)
         energy_axis.axhline(low,color='#148F77',linestyle=':',linewidth=1.2)
         threshold_handles.extend([Line2D([], [], color='#8E44AD',linestyle='-.',label=f'High STE: {high:.5g}'),
                                   Line2D([], [], color='#148F77',linestyle=':',label=f'Low STE: {low:.5g}')])
diff --git a/notebooks/THUAT_TOAN_1.ipynb b/notebooks/THUAT_TOAN_1.ipynb
index b600ed3..dc87e00 100644
--- a/notebooks/THUAT_TOAN_1.ipynb
+++ b/notebooks/THUAT_TOAN_1.ipynb
@@ -929,21 +929,21 @@
     "    \"\"\"Return native unpadded decisions and thresholds without LAB or endpoint policy.\n",
     "\n",
     "    TT1/high TT3 include equality; low TT3 includes equality in the opposite\n",
     "    direction. TT2 uses strict raw Energy > threshold (context uses STE).\n",
     "    Existing TT2 padding diagnostics describe its candidate stage only.\n",
     "    \"\"\"\n",
     "    if algorithm != ALGORITHM:\n",
     "        raise ValueError('This notebook contains only ' + ALGORITHM)\n",
     "    mask, diagnostic = (predict(features, params), dict(threshold=params['threshold']))\n",
     "    source_histogram = False and diagnostic.get('variant') == 'source'\n",
-    "    diagnostic.update(native_threshold=params['threshold'], native_threshold_units='sum of squared samples' if source_histogram else 'normalized STE')\n",
+    "    diagnostic.update(native_threshold=params['threshold'], native_threshold_units='mean squared sample amplitude' if source_histogram else 'normalized STE')\n",
     "    return (mask, diagnostic)\n",
     "\n",
     "def detect_regions(algorithm, features, duration, params):\n",
     "    \"\"\"Detect FINAL regions from features, duration and a fitted model.\"\"\"\n",
     "    # Input: frame features/supports, duration and fitted model; Output: FINAL regions, mask and diagnostics.\n",
     "    if algorithm != ALGORITHM:\n",
     "        raise ValueError('This notebook contains only ' + ALGORITHM)\n",
     "    # The enhanced 100 ms support-span filter is a heuristic; core keeps native speech supports.\n",
     "    mode = params.get('endpoint_mode', 'enhanced')\n",
     "    if mode not in ('core', 'enhanced'):\n",
@@ -1536,21 +1536,21 @@
     "    mae_text = f\"{mae:.2f} ms\" if mae is not None else \"N/A\"\n",
     "    figure, axes = plt.subplots(2, 1, figsize=(12.5, 5.5), sharex=True,\n",
     "                               gridspec_kw={\"height_ratios\": [1, 1.25]})\n",
     "    time = [index / record[\"sample_rate\"] for index in range(len(record[\"samples\"]))]\n",
     "    axes[0].plot(time, record[\"samples\"], color=\"#444444\", linewidth=0.6)\n",
     "    axes[0].set_ylabel(\"PCM amplitude\")\n",
     "    axes[1].plot(features[\"centers\"], features[\"ste_norm\"], color=\"#263238\",\n",
     "                 linewidth=1, label=\"Normalized STE\")\n",
     "    if diagnostic[\"endpoint_mode\"] == \"core\":\n",
     "        native = diagnostic[\"native_threshold\"]\n",
-    "        if diagnostic[\"native_threshold_units\"] == \"sum of squared samples\":\n",
+    "        if diagnostic[\"native_threshold_units\"] == \"mean squared sample amplitude\":\n",
     "            peak = max(features[\"energy\"], default=0.)\n",
     "            native = native / peak if peak else 0.\n",
     "        axes[1].axhline(native, color=\"#9b6700\", linestyle=\":\", label=\"Native T (display normalized)\")\n",
     "    else:\n",
     "        axes[1].axhline(diagnostic[\"low_ste_threshold\"], color=\"#008060\", linestyle=\"--\", label=\"LOW\")\n",
     "        axes[1].axhline(diagnostic[\"high_ste_threshold\"], color=\"#9b6700\", linestyle=\":\", label=\"HIGH\")\n",
     "    for axis in axes:\n",
     "        for index, (start, end) in enumerate(result[\"ground_truth_regions\"]):\n",
     "            axis.axvspan(start, end, color=\"red\", alpha=0.05)\n",
     "            axis.axvline(start, color=\"red\", linestyle=\"--\", linewidth=1.25,\n",
@@ -4958,21 +4958,21 @@
        "tolerance_boundary_rmse_ms": 3.5275168222458926,
        "tolerance_boundary_tolerance_ms": 100.0
       },
       "predicted_boundaries": [
        0.45,
        1.9349886621315193
       ]
      }
     ]
    },
-   "code_source_sha256": "0752fcc76d08500624dc8eabef683b48df1ed00fc9a63c9dceff38ba331f396c",
+   "code_source_sha256": "4275ea2687f52a07b5df13efd22729407e2923257f22face217de054fa415b78",
    "dataset_manifest": [
     {
      "duration_s": 3.24,
      "file": "phone_F1",
      "lab_sha256": "e30d41cc8e84112819bd7c6ab4a2c8d3adeadd4cb85054dd37f3dc824c1ca522",
      "sample_rate_hz": 16000,
      "split": "train",
      "wav_sha256": "4209a6ffe642f93b89554000fa7766135faf7c6cd97ce99b912b44af5e39db12"
     },
     {
diff --git a/notebooks/THUAT_TOAN_2.ipynb b/notebooks/THUAT_TOAN_2.ipynb
index 1a3c25f..f1b9cef 100644
--- a/notebooks/THUAT_TOAN_2.ipynb
+++ b/notebooks/THUAT_TOAN_2.ipynb
@@ -1082,21 +1082,21 @@
     "    TT1/high TT3 include equality; low TT3 includes equality in the opposite\n",
     "    direction. TT2 uses strict raw Energy > threshold (context uses STE).\n",
     "    Existing TT2 padding diagnostics describe its candidate stage only.\n",
     "    \"\"\"\n",
     "    if algorithm != ALGORITHM:\n",
     "        raise ValueError('This notebook contains only ' + ALGORITHM)\n",
     "    mask, diagnostic = predict(features, params)\n",
     "    if diagnostic['variant'] == 'source':\n",
     "        mask = [int(e > diagnostic['energy_threshold']) for e in features['energy']]\n",
     "    source_histogram = True and diagnostic.get('variant') == 'source'\n",
-    "    diagnostic.update(native_threshold=diagnostic['energy_threshold'], native_threshold_units='sum of squared samples' if source_histogram else 'normalized STE')\n",
+    "    diagnostic.update(native_threshold=diagnostic['energy_threshold'], native_threshold_units='mean squared sample amplitude' if source_histogram else 'normalized STE')\n",
     "    return (mask, diagnostic)\n",
     "\n",
     "def detect_regions(algorithm, features, duration, params):\n",
     "    \"\"\"Detect FINAL regions from features, duration and a fitted model.\"\"\"\n",
     "    # Input: frame features/supports, duration and fitted model; Output: FINAL regions, mask and diagnostics.\n",
     "    if algorithm != ALGORITHM:\n",
     "        raise ValueError('This notebook contains only ' + ALGORITHM)\n",
     "    # The enhanced 100 ms support-span filter is a heuristic; core keeps native speech supports.\n",
     "    mode = params.get('endpoint_mode', 'enhanced')\n",
     "    if mode not in ('core', 'enhanced'):\n",
@@ -1204,21 +1204,21 @@
     "        raise ValueError(f'Unknown endpoint_mode: {endpoint_mode}')\n",
     "    if not train_records:\n",
     "        raise ValueError('fit_training_model requires TRAIN records')\n",
     "    for record in train_records:\n",
     "        if record.get('split') != 'train':\n",
     "            raise ValueError('Training records require explicit TRAIN provenance (split=train)')\n",
     "        if 'wav_path' in record and Path(record['wav_path']).resolve().parent != (DATA_ROOT / 'train').resolve():\n",
     "            raise ValueError('Training record path must belong to TRAIN, never TEST/external')\n",
     "    # Fit the candidate-frame histogram W proposal from TRAIN only.\n",
     "    model = fit(train_records, variant='source')\n",
-    "    model.update(schema_version=3, metrics_schema_version=2, endpoint_mode=endpoint_mode, parameter_selection_set='train', evaluation_protocol='train_selected_reused_test', historical_test_exposure=True, training_files=[record['name'] for record in train_records], frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000, minimum_speech_ms=0.0 if endpoint_mode == 'core' else MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_noise=fit_noise_floor(train_records) if endpoint_mode == 'enhanced' else None, endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding' if endpoint_mode == 'core' else 'hysteresis final regions; no fixed final padding', feature_rule='Energy (sum of squared samples)', decision_rule='Energy > threshold', padding_stage='excluded from core FINAL' if endpoint_mode == 'core' else 'candidate diagnostics only', boundary_convention='union of active frame supports')\n",
+    "    model.update(schema_version=3, metrics_schema_version=2, endpoint_mode=endpoint_mode, parameter_selection_set='train', evaluation_protocol='train_selected_reused_test', historical_test_exposure=True, training_files=[record['name'] for record in train_records], frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000, minimum_speech_ms=0.0 if endpoint_mode == 'core' else MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_noise=fit_noise_floor(train_records) if endpoint_mode == 'enhanced' else None, endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding' if endpoint_mode == 'core' else 'hysteresis final regions; no fixed final padding', feature_rule='Energy (mean squared sample amplitude)', decision_rule='Energy > threshold', padding_stage='excluded from core FINAL' if endpoint_mode == 'core' else 'candidate diagnostics only', boundary_convention='union of active frame supports')\n",
     "    sweep_rows = []\n",
     "    # Preserve candidate F1 diagnostics beside schema-v3 mode policy, enhanced TRAIN noise and provenance.\n",
     "    model['candidate_frame_selected_W'] = model['W']\n",
     "    model['candidate_frame_f1'] = model.pop('train_frame_f1')\n",
     "    model['candidate_frame_selection_scores'] = [dict(W=row['W'], candidate_frame_f1=row['train_frame_f1'], **{key: value for key, value in row.items() if key not in ('W', 'train_frame_f1')}) for row in model.pop('selection_scores')]\n",
     "    model['candidate_cleanup_records'] = {key: model.pop(key) for key in ('full_pipeline_records', 'predict_only_fallback_records')}\n",
     "    model['candidate_frame_selection_applicable'] = True\n",
     "    # Calibrate shared W on TRAIN FINAL regions; candidate F1 remains a separate diagnostic.\n",
     "    selection, sweep_rows = sweep_final_weights(train_records, model, predict_and_score, tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE)\n",
     "    model.update(W=selection['selected_W'], finalW=selection['selected_W'], tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE, W_selection_train=selection, parameter_rule=selection['selection_rule'])\n",
@@ -1596,21 +1596,21 @@
   {
    "cell_type": "code",
    "execution_count": 17,
    "id": "cell-030",
    "metadata": {},
    "outputs": [
     {
      "name": "stdout",
      "output_type": "stream",
      "text": [
-      "MODEL locked before TEST reads: 169f44d678a4518c37bacf2f6493693f8f1c2950cb0b2c7fee1585fedd98ca7c\n"
+      "MODEL locked before TEST reads: 4ca7fe4de10a36394f330016e7bce494e6fe77067bde1b9e6549d23c4b091705\n"
      ]
     }
    ],
    "source": [
     "def model_digest(model):\n",
     "    return hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False,\n",
     "                                     allow_nan=False, separators=(\",\", \":\")).encode(\"utf-8\")).hexdigest()\n",
     "\n",
     "MODEL_LOCK_DIGESTS = {mode: model_digest(model) for mode, model in MODELS.items()}\n",
     "MODEL_LOCK_DIGEST = MODEL_LOCK_DIGESTS[MODE]\n",
@@ -1775,21 +1775,21 @@
       "text/plain": [
        "<IPython.core.display.HTML object>"
       ]
      },
      "metadata": {},
      "output_type": "display_data"
     },
     {
      "data": {
       "text/html": [
-       "<table style='border-collapse:collapse;font-size:13px'><caption style='text-align:left;font-weight:bold;margin:10px 0'>Both-mode threshold and geometry diagnostics</caption><thead><tr><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>file</th><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>endpoint_mode</th><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>native_threshold</th><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>native_threshold_units</th><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>low_ste_threshold</th><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>high_ste_threshold</th><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>geometry</th><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>minimum_speech_ms</th><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>padding_stage</th></tr></thead><tbody><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>phone_F1</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>core</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0017156231</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>sum of squared samples</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>excluded from core FINAL</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>phone_M1</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>core</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000178287733</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>sum of squared samples</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>excluded from core FINAL</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>studio_F1</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>core</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000268489967</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>sum of squared samples</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>excluded from core FINAL</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>studio_M1</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>core</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000271396706</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>sum of squared samples</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>excluded from core FINAL</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>phone_F2</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>core</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000105823433</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>sum of squared samples</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>excluded from core FINAL</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>phone_M2</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>core</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000206775886</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>sum of squared samples</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>excluded from core FINAL</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>studio_F2</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>core</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00136423549</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>sum of squared samples</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>excluded from core FINAL</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>studio_M2</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>core</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00025823544</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>sum of squared samples</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>excluded from core FINAL</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>phone_F1</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>enhanced</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0017156231</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>sum of squared samples</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00251496724</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0133073323</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>100</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>candidate diagnostics only</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>phone_M1</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>enhanced</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000178287733</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>sum of squared samples</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00251496724</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0126370153</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>100</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>candidate diagnostics only</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>studio_F1</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>enhanced</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000268489967</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>sum of squared samples</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00251496724</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0152538756</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>100</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>candidate diagnostics only</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>studio_M1</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>enhanced</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000271396706</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>sum of squared samples</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00251496724</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.012276806</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>100</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>candidate diagnostics only</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>phone_F2</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>enhanced</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000105823433</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>sum of squared samples</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00251496724</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0115995058</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>100</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>candidate diagnostics only</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>phone_M2</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>enhanced</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000206775886</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>sum of squared samples</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00251496724</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0167411749</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>100</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>candidate diagnostics only</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>studio_F2</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>enhanced</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00136423549</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>sum of squared samples</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00251496724</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0122767857</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>100</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>candidate diagnostics only</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>studio_M2</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>enhanced</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00025823544</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>sum of squared samples</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00251496724</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0130209294</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>100</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>candidate diagnostics only</td></tr></tbody></table>"
+       "<table style='border-collapse:collapse;font-size:13px'><caption style='text-align:left;font-weight:bold;margin:10px 0'>Both-mode threshold and geometry diagnostics</caption><thead><tr><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>file</th><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>endpoint_mode</th><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>native_threshold</th><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>native_threshold_units</th><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>low_ste_threshold</th><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>high_ste_threshold</th><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>geometry</th><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>minimum_speech_ms</th><th style='padding:5px 9px;border-bottom:2px solid #888;text-align:left'>padding_stage</th></tr></thead><tbody><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>phone_F1</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>core</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0017156231</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>mean squared sample amplitude</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>excluded from core FINAL</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>phone_M1</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>core</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000178287733</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>mean squared sample amplitude</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>excluded from core FINAL</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>studio_F1</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>core</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000268489967</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>mean squared sample amplitude</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>excluded from core FINAL</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>studio_M1</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>core</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000271396706</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>mean squared sample amplitude</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>excluded from core FINAL</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>phone_F2</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>core</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000105823433</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>mean squared sample amplitude</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>excluded from core FINAL</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>phone_M2</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>core</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000206775886</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>mean squared sample amplitude</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>excluded from core FINAL</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>studio_F2</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>core</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00136423549</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>mean squared sample amplitude</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>excluded from core FINAL</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>studio_M2</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>core</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00025823544</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>mean squared sample amplitude</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>N/A</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>excluded from core FINAL</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>phone_F1</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>enhanced</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0017156231</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>mean squared sample amplitude</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00251496724</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0133073323</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>100</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>candidate diagnostics only</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>phone_M1</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>enhanced</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000178287733</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>mean squared sample amplitude</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00251496724</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0126370153</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>100</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>candidate diagnostics only</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>studio_F1</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>enhanced</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000268489967</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>mean squared sample amplitude</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00251496724</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0152538756</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>100</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>candidate diagnostics only</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>studio_M1</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>enhanced</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000271396706</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>mean squared sample amplitude</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00251496724</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.012276806</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>100</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>candidate diagnostics only</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>phone_F2</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>enhanced</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000105823433</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>mean squared sample amplitude</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00251496724</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0115995058</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>100</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>candidate diagnostics only</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>phone_M2</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>enhanced</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.000206775886</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>mean squared sample amplitude</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00251496724</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0167411749</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>100</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>candidate diagnostics only</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>studio_F2</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>enhanced</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00136423549</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>mean squared sample amplitude</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00251496724</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0122767857</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>100</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>candidate diagnostics only</td></tr><tr><td style='padding:5px 9px;border-bottom:1px solid #ddd'>studio_M2</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>enhanced</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00025823544</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>mean squared sample amplitude</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.00251496724</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>0.0130209294</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>union of active frame supports</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>100</td><td style='padding:5px 9px;border-bottom:1px solid #ddd'>candidate diagnostics only</td></tr></tbody></table>"
       ],
       "text/plain": [
        "<IPython.core.display.HTML object>"
       ]
      },
      "metadata": {},
      "output_type": "display_data"
     }
    ],
    "source": [
@@ -1930,21 +1930,21 @@
     "    mae_text = f\"{mae:.2f} ms\" if mae is not None else \"N/A\"\n",
     "    figure, axes = plt.subplots(2, 1, figsize=(12.5, 5.5), sharex=True,\n",
     "                               gridspec_kw={\"height_ratios\": [1, 1.25]})\n",
     "    time = [index / record[\"sample_rate\"] for index in range(len(record[\"samples\"]))]\n",
     "    axes[0].plot(time, record[\"samples\"], color=\"#444444\", linewidth=0.6)\n",
     "    axes[0].set_ylabel(\"PCM amplitude\")\n",
     "    axes[1].plot(features[\"centers\"], features[\"ste_norm\"], color=\"#263238\",\n",
     "                 linewidth=1, label=\"Normalized STE\")\n",
     "    if diagnostic[\"endpoint_mode\"] == \"core\":\n",
     "        native = diagnostic[\"native_threshold\"]\n",
-    "        if diagnostic[\"native_threshold_units\"] == \"sum of squared samples\":\n",
+    "        if diagnostic[\"native_threshold_units\"] == \"mean squared sample amplitude\":\n",
     "            peak = max(features[\"energy\"], default=0.)\n",
     "            native = native / peak if peak else 0.\n",
     "        axes[1].axhline(native, color=\"#9b6700\", linestyle=\":\", label=\"Native T (display normalized)\")\n",
     "    else:\n",
     "        axes[1].axhline(diagnostic[\"low_ste_threshold\"], color=\"#008060\", linestyle=\"--\", label=\"LOW\")\n",
     "        axes[1].axhline(diagnostic[\"high_ste_threshold\"], color=\"#9b6700\", linestyle=\":\", label=\"HIGH\")\n",
     "    for axis in axes:\n",
     "        for index, (start, end) in enumerate(result[\"ground_truth_regions\"]):\n",
     "            axis.axvspan(start, end, color=\"red\", alpha=0.05)\n",
     "            axis.axvline(start, color=\"red\", linestyle=\"--\", linewidth=1.25,\n",
@@ -2216,21 +2216,21 @@
         0.53,
         2.745
        ]
       ],
       "geometry": "union of active frame supports",
       "high_ste_threshold": 0.013307332273144389,
       "low_ste_threshold": 0.0025149672448754727,
       "minimum_silence_ms": 200.0,
       "minimum_speech_ms": 100.0,
       "native_threshold": 0.0017156231046586373,
-      "native_threshold_units": "sum of squared samples",
+      "native_threshold_units": "mean squared sample amplitude",
       "padded_speech_frames": 269,
       "padding_frames": 25,
       "padding_ms": 250.0,
       "padding_stage": "candidate diagnostics only",
       "raw_speech_frames": 142,
       "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
       "variant": "source"
      },
      "file": "phone_F1",
      "final_regions": [
@@ -2389,21 +2389,21 @@
         0.46,
         3.545
        ]
       ],
       "geometry": "union of active frame supports",
       "high_ste_threshold": 0.012637015253843122,
       "low_ste_threshold": 0.0025149672448754727,
       "minimum_silence_ms": 200.0,
       "minimum_speech_ms": 100.0,
       "native_threshold": 0.00017828773279688904,
-      "native_threshold_units": "sum of squared samples",
+      "native_threshold_units": "mean squared sample amplitude",
       "padded_speech_frames": 355,
       "padding_frames": 25,
       "padding_ms": 250.0,
       "padding_stage": "candidate diagnostics only",
       "raw_speech_frames": 244,
       "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
       "variant": "source"
      },
      "file": "phone_M1",
      "final_regions": [
@@ -2562,21 +2562,21 @@
         0.66,
         2.164988662131519
        ]
       ],
       "geometry": "union of active frame supports",
       "high_ste_threshold": 0.015253875587669167,
       "low_ste_threshold": 0.0025149672448754727,
       "minimum_silence_ms": 200.0,
       "minimum_speech_ms": 100.0,
       "native_threshold": 0.00026848996726078445,
-      "native_threshold_units": "sum of squared samples",
+      "native_threshold_units": "mean squared sample amplitude",
       "padded_speech_frames": 196,
       "padding_frames": 25,
       "padding_ms": 250.0,
       "padding_stage": "candidate diagnostics only",
       "raw_speech_frames": 127,
       "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
       "variant": "source"
      },
      "file": "studio_F1",
      "final_regions": [
@@ -2729,21 +2729,21 @@
         0.91,
         2.0649886621315194
        ]
       ],
       "geometry": "union of active frame supports",
       "high_ste_threshold": 0.012276806029288843,
       "low_ste_threshold": 0.0025149672448754727,
       "minimum_silence_ms": 200.0,
       "minimum_speech_ms": 100.0,
       "native_threshold": 0.00027139670637816725,
-      "native_threshold_units": "sum of squared samples",
+      "native_threshold_units": "mean squared sample amplitude",
       "padded_speech_frames": 162,
       "padding_frames": 25,
       "padding_ms": 250.0,
       "padding_stage": "candidate diagnostics only",
       "raw_speech_frames": 93,
       "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
       "variant": "source"
      },
      "file": "studio_M1",
      "final_regions": [
@@ -2892,21 +2892,21 @@
         1.01,
         4.095
        ]
       ],
       "geometry": "union of active frame supports",
       "high_ste_threshold": 0.011599505796759687,
       "low_ste_threshold": 0.0025149672448754727,
       "minimum_silence_ms": 200.0,
       "minimum_speech_ms": 100.0,
       "native_threshold": 0.00010582343327162865,
-      "native_threshold_units": "sum of squared samples",
+      "native_threshold_units": "mean squared sample amplitude",
       "padded_speech_frames": 345,
       "padding_frames": 25,
       "padding_ms": 250.0,
       "padding_stage": "candidate diagnostics only",
       "raw_speech_frames": 224,
       "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
       "variant": "source"
      },
      "file": "phone_F2",
      "final_regions": [
@@ -3057,21 +3057,21 @@
         0.52,
         2.525
        ]
       ],
       "geometry": "union of active frame supports",
       "high_ste_threshold": 0.016741174854225986,
       "low_ste_threshold": 0.0025149672448754727,
       "minimum_silence_ms": 200.0,
       "minimum_speech_ms": 100.0,
       "native_threshold": 0.00020677588617607918,
-      "native_threshold_units": "sum of squared samples",
+      "native_threshold_units": "mean squared sample amplitude",
       "padded_speech_frames": 247,
       "padding_frames": 25,
       "padding_ms": 250.0,
       "padding_stage": "candidate diagnostics only",
       "raw_speech_frames": 153,
       "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
       "variant": "source"
      },
      "file": "phone_M2",
      "final_regions": [
@@ -3216,21 +3216,21 @@
         0.76,
         2.3649886621315193
        ]
       ],
       "geometry": "union of active frame supports",
       "high_ste_threshold": 0.012276785714285716,
       "low_ste_threshold": 0.0025149672448754727,
       "minimum_silence_ms": 200.0,
       "minimum_speech_ms": 100.0,
       "native_threshold": 0.00136423548694805,
-      "native_threshold_units": "sum of squared samples",
+      "native_threshold_units": "mean squared sample amplitude",
       "padded_speech_frames": 207,
       "padding_frames": 25,
       "padding_ms": 250.0,
       "padding_stage": "candidate diagnostics only",
       "raw_speech_frames": 137,
       "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
       "variant": "source"
      },
      "file": "studio_F2",
      "final_regions": [
@@ -3381,21 +3381,21 @@
         0.46,
         1.9349886621315193
        ]
       ],
       "geometry": "union of active frame supports",
       "high_ste_threshold": 0.013020929394699838,
       "low_ste_threshold": 0.0025149672448754727,
       "minimum_silence_ms": 200.0,
       "minimum_speech_ms": 100.0,
       "native_threshold": 0.00025823544010657173,
-      "native_threshold_units": "sum of squared samples",
+      "native_threshold_units": "mean squared sample amplitude",
       "padded_speech_frames": 195,
       "padding_frames": 25,
       "padding_ms": 250.0,
       "padding_stage": "candidate diagnostics only",
       "raw_speech_frames": 125,
       "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
       "variant": "source"
      },
      "file": "studio_M2",
      "final_regions": [
@@ -3581,21 +3581,21 @@
          1.9,
          2.745
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": null,
        "low_ste_threshold": null,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 0.0,
        "native_threshold": 0.0017156231046586373,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 269,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "excluded from core FINAL",
        "raw_speech_frames": 142,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "phone_F1",
       "final_regions": [
@@ -3780,21 +3780,21 @@
          0.46,
          3.525
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": null,
        "low_ste_threshold": null,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 0.0,
        "native_threshold": 0.00017828773279688904,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 355,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "excluded from core FINAL",
        "raw_speech_frames": 244,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "phone_M1",
       "final_regions": [
@@ -3965,21 +3965,21 @@
          0.67,
          2.144988662131519
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": null,
        "low_ste_threshold": null,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 0.0,
        "native_threshold": 0.00026848996726078445,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 196,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "excluded from core FINAL",
        "raw_speech_frames": 127,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "studio_F1",
       "final_regions": [
@@ -4140,21 +4140,21 @@
          0.91,
          2.0449886621315194
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": null,
        "low_ste_threshold": null,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 0.0,
        "native_threshold": 0.00027139670637816725,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 162,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "excluded from core FINAL",
        "raw_speech_frames": 93,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "studio_M1",
       "final_regions": [
@@ -4327,21 +4327,21 @@
          2.78,
          4.015
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": null,
        "low_ste_threshold": null,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 0.0,
        "native_threshold": 0.00010582343327162865,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 345,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "excluded from core FINAL",
        "raw_speech_frames": 224,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "phone_F2",
       "final_regions": [
@@ -4518,21 +4518,21 @@
          0.53,
          2.515
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": null,
        "low_ste_threshold": null,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 0.0,
        "native_threshold": 0.00020677588617607918,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 247,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "excluded from core FINAL",
        "raw_speech_frames": 153,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "phone_M2",
       "final_regions": [
@@ -4685,21 +4685,21 @@
          0.76,
          2.3449886621315192
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": null,
        "low_ste_threshold": null,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 0.0,
        "native_threshold": 0.00136423548694805,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 207,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "excluded from core FINAL",
        "raw_speech_frames": 137,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "studio_F2",
       "final_regions": [
@@ -4850,21 +4850,21 @@
          0.46,
          1.9249886621315193
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": null,
        "low_ste_threshold": null,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 0.0,
        "native_threshold": 0.00025823544010657173,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 195,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "excluded from core FINAL",
        "raw_speech_frames": 125,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "studio_M2",
       "final_regions": [
@@ -5025,21 +5025,21 @@
          0.53,
          2.745
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": 0.013307332273144389,
        "low_ste_threshold": 0.0025149672448754727,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 100.0,
        "native_threshold": 0.0017156231046586373,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 269,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "candidate diagnostics only",
        "raw_speech_frames": 142,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "phone_F1",
       "final_regions": [
@@ -5198,21 +5198,21 @@
          0.46,
          3.545
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": 0.012637015253843122,
        "low_ste_threshold": 0.0025149672448754727,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 100.0,
        "native_threshold": 0.00017828773279688904,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 355,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "candidate diagnostics only",
        "raw_speech_frames": 244,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "phone_M1",
       "final_regions": [
@@ -5371,21 +5371,21 @@
          0.66,
          2.164988662131519
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": 0.015253875587669167,
        "low_ste_threshold": 0.0025149672448754727,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 100.0,
        "native_threshold": 0.00026848996726078445,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 196,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "candidate diagnostics only",
        "raw_speech_frames": 127,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "studio_F1",
       "final_regions": [
@@ -5538,21 +5538,21 @@
          0.91,
          2.0649886621315194
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": 0.012276806029288843,
        "low_ste_threshold": 0.0025149672448754727,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 100.0,
        "native_threshold": 0.00027139670637816725,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 162,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "candidate diagnostics only",
        "raw_speech_frames": 93,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "studio_M1",
       "final_regions": [
@@ -5701,21 +5701,21 @@
          1.01,
          4.095
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": 0.011599505796759687,
        "low_ste_threshold": 0.0025149672448754727,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 100.0,
        "native_threshold": 0.00010582343327162865,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 345,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "candidate diagnostics only",
        "raw_speech_frames": 224,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "phone_F2",
       "final_regions": [
@@ -5866,21 +5866,21 @@
          0.52,
          2.525
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": 0.016741174854225986,
        "low_ste_threshold": 0.0025149672448754727,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 100.0,
        "native_threshold": 0.00020677588617607918,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 247,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "candidate diagnostics only",
        "raw_speech_frames": 153,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "phone_M2",
       "final_regions": [
@@ -6025,21 +6025,21 @@
          0.76,
          2.3649886621315193
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": 0.012276785714285716,
        "low_ste_threshold": 0.0025149672448754727,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 100.0,
        "native_threshold": 0.00136423548694805,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 207,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "candidate diagnostics only",
        "raw_speech_frames": 137,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "studio_F2",
       "final_regions": [
@@ -6190,21 +6190,21 @@
          0.46,
          1.9349886621315193
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": 0.013020929394699838,
        "low_ste_threshold": 0.0025149672448754727,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 100.0,
        "native_threshold": 0.00025823544010657173,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 195,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "candidate diagnostics only",
        "raw_speech_frames": 125,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "studio_M2",
       "final_regions": [
@@ -6286,21 +6286,21 @@
        "tolerance_boundary_rmse_ms": 7.902112055091845,
        "tolerance_boundary_tolerance_ms": 100.0
       },
       "predicted_boundaries": [
        0.46,
        1.9349886621315193
       ]
      }
     ]
    },
-   "code_source_sha256": "c35b274765431ae9413fecdc96672467489246a7eea1488738bac9782bb4ac46",
+   "code_source_sha256": "6be6d5ad4bd277b55f3c0547035fe008a65b53daf3fbc53eaa80719dd4a8cf00",
    "dataset_manifest": [
     {
      "duration_s": 3.24,
      "file": "phone_F1",
      "lab_sha256": "e30d41cc8e84112819bd7c6ab4a2c8d3adeadd4cb85054dd37f3dc824c1ca522",
      "sample_rate_hz": 16000,
      "split": "train",
      "wav_sha256": "4209a6ffe642f93b89554000fa7766135faf7c6cd97ce99b912b44af5e39db12"
     },
     {
@@ -6579,21 +6579,21 @@
         45.0,
         46.0,
         47.0,
         48.0,
         49.0,
         50.0
        ]
       }
      },
      "boundary_convention": "union of active frame supports",
-     "calibration_digest": "72c661f212a202e564e4546c76425ce4ab20883144fd12d7e0a971ac20c469dd",
+     "calibration_digest": "33a016d798ea363b0079dc61e2b390848a391ad7384847142cb5dedb03684361",
      "candidate_W": [
       1.0,
       2.0,
       3.0,
       4.0,
       5.0,
       6.0,
       7.0,
       8.0,
       9.0,
@@ -7165,21 +7165,21 @@
        "max_MAE_ms": 22.49433106575971,
        "max_regret_ms": 0.0,
        "mean_MAE_ms": 13.747165532879801,
        "valid_files_mean_MAE_ms": 13.747165532879801
       }
      ],
      "tie_preference_W": 20.0
     },
     "bins": 64,
     "boundary_convention": "union of active frame supports",
-    "calibration_digest": "72c661f212a202e564e4546c76425ce4ab20883144fd12d7e0a971ac20c469dd",
+    "calibration_digest": "33a016d798ea363b0079dc61e2b390848a391ad7384847142cb5dedb03684361",
     "candidate_cleanup_records": {
      "full_pipeline_records": 4,
      "predict_only_fallback_records": 0
     },
     "candidate_frame_f1": 0.8986983588002264,
     "candidate_frame_selected_W": 1.0,
     "candidate_frame_selection_applicable": true,
     "candidate_frame_selection_scores": [
      {
       "W": 1.0,
@@ -7224,21 +7224,21 @@
      "high_multiplier": 1.5,
      "noise_count": 497,
      "noise_mean": 0.00038711079659476316,
      "noise_q95": 0.0012140144555334857,
      "noise_std": 0.0007092854827602364,
      "noise_upper": 0.0025149672448754727
     },
     "endpoint_policy": "hysteresis final regions; no fixed final padding",
     "evaluation_protocol": "train_selected_reused_test",
     "feature": "energy",
-    "feature_rule": "Energy (sum of squared samples)",
+    "feature_rule": "Energy (mean squared sample amplitude)",
     "finalW": 20.0,
     "frame_ms": 25.0,
     "framing_adaptation": "paper 50/50 ms to assignment 25/10 ms; preserve 250 ms padding as 25 hops",
     "historical_test_exposure": true,
     "hop_ms": 10.0,
     "metrics_schema_version": 2,
     "minimum_internal_silence_ms": 200.0,
     "minimum_silence_ms": 200.0,
     "minimum_speech_ms": 100.0,
     "padding_frames": 25,
@@ -7252,24 +7252,24 @@
     "source": "Energy-only adaptation requested by teacher; histogram threshold from Giannakopoulos pp.1-2; 25/10 ms and candidate padding are declared choices",
     "tie_preference_W": 20.0,
     "training_files": [
      "phone_F1",
      "phone_M1",
      "studio_F1",
      "studio_M1"
     ],
     "variant": "source"
    },
-   "model_lock_digest": "169f44d678a4518c37bacf2f6493693f8f1c2950cb0b2c7fee1585fedd98ca7c",
+   "model_lock_digest": "4ca7fe4de10a36394f330016e7bce494e6fe77067bde1b9e6549d23c4b091705",
    "model_lock_digests": {
-    "core": "83d3e69001dbf50452f385f7997196403129fcc4aa198e50bf6bf629e69e5c45",
-    "enhanced": "169f44d678a4518c37bacf2f6493693f8f1c2950cb0b2c7fee1585fedd98ca7c"
+    "core": "eb3abf8e67947a86d6f37465a3194484e354a9f69bcf66aea43f08f64b1a57bc",
+    "enhanced": "4ca7fe4de10a36394f330016e7bce494e6fe77067bde1b9e6549d23c4b091705"
    },
    "models": {
     "core": {
      "W": 20.0,
      "W_selection_train": {
       "best_by_file": {
        "phone_F1": {
         "minimum_MAE_ms": null,
         "optimal_W": []
        },
@@ -7361,21 +7361,21 @@
          45.0,
          46.0,
          47.0,
          48.0,
          49.0,
          50.0
         ]
        }
       },
       "boundary_convention": "union of active frame supports",
-      "calibration_digest": "44b1591191d1956579d75f195c1f40f7fffc8a1b953104a9227f42dda5b40509",
+      "calibration_digest": "2432f69d291a4d9dc5de612b34976b687041294d8943f502f3ec53ef8e2de80f",
       "candidate_W": [
        1.0,
        2.0,
        3.0,
        4.0,
        5.0,
        6.0,
        7.0,
        8.0,
        9.0,
@@ -7896,21 +7896,21 @@
         "max_MAE_ms": 27.505668934240333,
         "max_regret_ms": 5.0000000000001155,
         "mean_MAE_ms": null,
         "valid_files_mean_MAE_ms": 14.166666666666698
        }
       ],
       "tie_preference_W": 20.0
      },
      "bins": 64,
      "boundary_convention": "union of active frame supports",
-     "calibration_digest": "44b1591191d1956579d75f195c1f40f7fffc8a1b953104a9227f42dda5b40509",
+     "calibration_digest": "2432f69d291a4d9dc5de612b34976b687041294d8943f502f3ec53ef8e2de80f",
      "candidate_cleanup_records": {
       "full_pipeline_records": 4,
       "predict_only_fallback_records": 0
      },
      "candidate_frame_f1": 0.8986983588002264,
      "candidate_frame_selected_W": 1.0,
      "candidate_frame_selection_applicable": true,
      "candidate_frame_selection_scores": [
       {
        "W": 1.0,
@@ -7947,21 +7947,21 @@
        "fp": 188,
        "tp": 794
       }
      ],
      "decision_rule": "Energy > threshold",
      "endpoint_mode": "core",
      "endpoint_noise": null,
      "endpoint_policy": "native decisions; merge internal support gaps below 200 ms; no duration filter or final padding",
      "evaluation_protocol": "train_selected_reused_test",
      "feature": "energy",
-     "feature_rule": "Energy (sum of squared samples)",
+     "feature_rule": "Energy (mean squared sample amplitude)",
      "finalW": 20.0,
      "frame_ms": 25.0,
      "framing_adaptation": "paper 50/50 ms to assignment 25/10 ms; preserve 250 ms padding as 25 hops",
      "historical_test_exposure": true,
      "hop_ms": 10.0,
      "metrics_schema_version": 2,
      "minimum_internal_silence_ms": 200.0,
      "minimum_silence_ms": 200.0,
      "minimum_speech_ms": 0.0,
      "padding_frames": 25,
@@ -8201,21 +8201,21 @@
          45.0,
          46.0,
          47.0,
          48.0,
          49.0,
          50.0
         ]
        }
       },
       "boundary_convention": "union of active frame supports",
-      "calibration_digest": "72c661f212a202e564e4546c76425ce4ab20883144fd12d7e0a971ac20c469dd",
+      "calibration_digest": "33a016d798ea363b0079dc61e2b390848a391ad7384847142cb5dedb03684361",
       "candidate_W": [
        1.0,
        2.0,
        3.0,
        4.0,
        5.0,
        6.0,
        7.0,
        8.0,
        9.0,
@@ -8787,21 +8787,21 @@
         "max_MAE_ms": 22.49433106575971,
         "max_regret_ms": 0.0,
         "mean_MAE_ms": 13.747165532879801,
         "valid_files_mean_MAE_ms": 13.747165532879801
        }
       ],
       "tie_preference_W": 20.0
      },
      "bins": 64,
      "boundary_convention": "union of active frame supports",
-     "calibration_digest": "72c661f212a202e564e4546c76425ce4ab20883144fd12d7e0a971ac20c469dd",
+     "calibration_digest": "33a016d798ea363b0079dc61e2b390848a391ad7384847142cb5dedb03684361",
      "candidate_cleanup_records": {
       "full_pipeline_records": 4,
       "predict_only_fallback_records": 0
      },
      "candidate_frame_f1": 0.8986983588002264,
      "candidate_frame_selected_W": 1.0,
      "candidate_frame_selection_applicable": true,
      "candidate_frame_selection_scores": [
       {
        "W": 1.0,
@@ -8846,21 +8846,21 @@
       "high_multiplier": 1.5,
       "noise_count": 497,
       "noise_mean": 0.00038711079659476316,
       "noise_q95": 0.0012140144555334857,
       "noise_std": 0.0007092854827602364,
       "noise_upper": 0.0025149672448754727
      },
      "endpoint_policy": "hysteresis final regions; no fixed final padding",
      "evaluation_protocol": "train_selected_reused_test",
      "feature": "energy",
-     "feature_rule": "Energy (sum of squared samples)",
+     "feature_rule": "Energy (mean squared sample amplitude)",
      "finalW": 20.0,
      "frame_ms": 25.0,
      "framing_adaptation": "paper 50/50 ms to assignment 25/10 ms; preserve 250 ms padding as 25 hops",
      "historical_test_exposure": true,
      "hop_ms": 10.0,
      "metrics_schema_version": 2,
      "minimum_internal_silence_ms": 200.0,
      "minimum_silence_ms": 200.0,
      "minimum_speech_ms": 100.0,
      "padding_frames": 25,
@@ -8946,21 +8946,21 @@
         1.01,
         4.095
        ]
       ],
       "geometry": "union of active frame supports",
       "high_ste_threshold": 0.011599505796759687,
       "low_ste_threshold": 0.0025149672448754727,
       "minimum_silence_ms": 200.0,
       "minimum_speech_ms": 100.0,
       "native_threshold": 0.00010582343327162865,
-      "native_threshold_units": "sum of squared samples",
+      "native_threshold_units": "mean squared sample amplitude",
       "padded_speech_frames": 345,
       "padding_frames": 25,
       "padding_ms": 250.0,
       "padding_stage": "candidate diagnostics only",
       "raw_speech_frames": 224,
       "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
       "variant": "source"
      },
      "file": "phone_F2",
      "final_regions": [
@@ -9111,21 +9111,21 @@
         0.52,
         2.525
        ]
       ],
       "geometry": "union of active frame supports",
       "high_ste_threshold": 0.016741174854225986,
       "low_ste_threshold": 0.0025149672448754727,
       "minimum_silence_ms": 200.0,
       "minimum_speech_ms": 100.0,
       "native_threshold": 0.00020677588617607918,
-      "native_threshold_units": "sum of squared samples",
+      "native_threshold_units": "mean squared sample amplitude",
       "padded_speech_frames": 247,
       "padding_frames": 25,
       "padding_ms": 250.0,
       "padding_stage": "candidate diagnostics only",
       "raw_speech_frames": 153,
       "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
       "variant": "source"
      },
      "file": "phone_M2",
      "final_regions": [
@@ -9270,21 +9270,21 @@
         0.76,
         2.3649886621315193
        ]
       ],
       "geometry": "union of active frame supports",
       "high_ste_threshold": 0.012276785714285716,
       "low_ste_threshold": 0.0025149672448754727,
       "minimum_silence_ms": 200.0,
       "minimum_speech_ms": 100.0,
       "native_threshold": 0.00136423548694805,
-      "native_threshold_units": "sum of squared samples",
+      "native_threshold_units": "mean squared sample amplitude",
       "padded_speech_frames": 207,
       "padding_frames": 25,
       "padding_ms": 250.0,
       "padding_stage": "candidate diagnostics only",
       "raw_speech_frames": 137,
       "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
       "variant": "source"
      },
      "file": "studio_F2",
      "final_regions": [
@@ -9435,21 +9435,21 @@
         0.46,
         1.9349886621315193
        ]
       ],
       "geometry": "union of active frame supports",
       "high_ste_threshold": 0.013020929394699838,
       "low_ste_threshold": 0.0025149672448754727,
       "minimum_silence_ms": 200.0,
       "minimum_speech_ms": 100.0,
       "native_threshold": 0.00025823544010657173,
-      "native_threshold_units": "sum of squared samples",
+      "native_threshold_units": "mean squared sample amplitude",
       "padded_speech_frames": 195,
       "padding_frames": 25,
       "padding_ms": 250.0,
       "padding_stage": "candidate diagnostics only",
       "raw_speech_frames": 125,
       "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
       "variant": "source"
      },
      "file": "studio_M2",
      "final_regions": [
@@ -9625,21 +9625,21 @@
          2.78,
          4.015
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": null,
        "low_ste_threshold": null,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 0.0,
        "native_threshold": 0.00010582343327162865,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 345,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "excluded from core FINAL",
        "raw_speech_frames": 224,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "phone_F2",
       "final_regions": [
@@ -9816,21 +9816,21 @@
          0.53,
          2.515
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": null,
        "low_ste_threshold": null,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 0.0,
        "native_threshold": 0.00020677588617607918,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 247,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "excluded from core FINAL",
        "raw_speech_frames": 153,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "phone_M2",
       "final_regions": [
@@ -9983,21 +9983,21 @@
          0.76,
          2.3449886621315192
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": null,
        "low_ste_threshold": null,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 0.0,
        "native_threshold": 0.00136423548694805,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 207,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "excluded from core FINAL",
        "raw_speech_frames": 137,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "studio_F2",
       "final_regions": [
@@ -10148,21 +10148,21 @@
          0.46,
          1.9249886621315193
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": null,
        "low_ste_threshold": null,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 0.0,
        "native_threshold": 0.00025823544010657173,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 195,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "excluded from core FINAL",
        "raw_speech_frames": 125,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "studio_M2",
       "final_regions": [
@@ -10313,21 +10313,21 @@
          1.01,
          4.095
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": 0.011599505796759687,
        "low_ste_threshold": 0.0025149672448754727,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 100.0,
        "native_threshold": 0.00010582343327162865,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 345,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "candidate diagnostics only",
        "raw_speech_frames": 224,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "phone_F2",
       "final_regions": [
@@ -10478,21 +10478,21 @@
          0.52,
          2.525
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": 0.016741174854225986,
        "low_ste_threshold": 0.0025149672448754727,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 100.0,
        "native_threshold": 0.00020677588617607918,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 247,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "candidate diagnostics only",
        "raw_speech_frames": 153,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "phone_M2",
       "final_regions": [
@@ -10637,21 +10637,21 @@
          0.76,
          2.3649886621315193
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": 0.012276785714285716,
        "low_ste_threshold": 0.0025149672448754727,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 100.0,
        "native_threshold": 0.00136423548694805,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 207,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "candidate diagnostics only",
        "raw_speech_frames": 137,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "studio_F2",
       "final_regions": [
@@ -10802,21 +10802,21 @@
          0.46,
          1.9349886621315193
         ]
        ],
        "geometry": "union of active frame supports",
        "high_ste_threshold": 0.013020929394699838,
        "low_ste_threshold": 0.0025149672448754727,
        "minimum_silence_ms": 200.0,
        "minimum_speech_ms": 100.0,
        "native_threshold": 0.00025823544010657173,
-       "native_threshold_units": "sum of squared samples",
+       "native_threshold_units": "mean squared sample amplitude",
        "padded_speech_frames": 195,
        "padding_frames": 25,
        "padding_ms": 250.0,
        "padding_stage": "candidate diagnostics only",
        "raw_speech_frames": 125,
        "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
        "variant": "source"
       },
       "file": "studio_M2",
       "final_regions": [
diff --git a/notebooks/THUAT_TOAN_3.ipynb b/notebooks/THUAT_TOAN_3.ipynb
index ecc1fe8..dc8e3a5 100644
--- a/notebooks/THUAT_TOAN_3.ipynb
+++ b/notebooks/THUAT_TOAN_3.ipynb
@@ -940,21 +940,21 @@
     "    TT1/high TT3 include equality; low TT3 includes equality in the opposite\n",
     "    direction. TT2 uses strict raw Energy > threshold (context uses STE).\n",
     "    Existing TT2 padding diagnostics describe its candidate stage only.\n",
     "    \"\"\"\n",
     "    if algorithm != ALGORITHM:\n",
     "        raise ValueError('This notebook contains only ' + ALGORITHM)\n",
     "    if params.get('speech_direction', 'high') not in ('high', 'low'):\n",
     "        raise ValueError('Unknown TT3 speech_direction')\n",
     "    mask, diagnostic = (predict(features, params), dict(threshold=params['threshold']))\n",
     "    source_histogram = False and diagnostic.get('variant') == 'source'\n",
-    "    diagnostic.update(native_threshold=params['threshold'], native_threshold_units='sum of squared samples' if source_histogram else 'normalized STE')\n",
+    "    diagnostic.update(native_threshold=params['threshold'], native_threshold_units='mean squared sample amplitude' if source_histogram else 'normalized STE')\n",
     "    return (mask, diagnostic)\n",
     "\n",
     "def detect_regions(algorithm, features, duration, params):\n",
     "    \"\"\"Detect FINAL regions from features, duration and a fitted model.\"\"\"\n",
     "    # Input: frame features/supports, duration and fitted model; Output: FINAL regions, mask and diagnostics.\n",
     "    if algorithm != ALGORITHM:\n",
     "        raise ValueError('This notebook contains only ' + ALGORITHM)\n",
     "    # The enhanced 100 ms support-span filter is a heuristic; core keeps native speech supports.\n",
     "    mode = params.get('endpoint_mode', 'enhanced')\n",
     "    if mode not in ('core', 'enhanced'):\n",
@@ -1533,21 +1533,21 @@
     "    mae_text = f\"{mae:.2f} ms\" if mae is not None else \"N/A\"\n",
     "    figure, axes = plt.subplots(2, 1, figsize=(12.5, 5.5), sharex=True,\n",
     "                               gridspec_kw={\"height_ratios\": [1, 1.25]})\n",
     "    time = [index / record[\"sample_rate\"] for index in range(len(record[\"samples\"]))]\n",
     "    axes[0].plot(time, record[\"samples\"], color=\"#444444\", linewidth=0.6)\n",
     "    axes[0].set_ylabel(\"PCM amplitude\")\n",
     "    axes[1].plot(features[\"centers\"], features[\"ste_norm\"], color=\"#263238\",\n",
     "                 linewidth=1, label=\"Normalized STE\")\n",
     "    if diagnostic[\"endpoint_mode\"] == \"core\":\n",
     "        native = diagnostic[\"native_threshold\"]\n",
-    "        if diagnostic[\"native_threshold_units\"] == \"sum of squared samples\":\n",
+    "        if diagnostic[\"native_threshold_units\"] == \"mean squared sample amplitude\":\n",
     "            peak = max(features[\"energy\"], default=0.)\n",
     "            native = native / peak if peak else 0.\n",
     "        axes[1].axhline(native, color=\"#9b6700\", linestyle=\":\", label=\"Native T (display normalized)\")\n",
     "    else:\n",
     "        axes[1].axhline(diagnostic[\"low_ste_threshold\"], color=\"#008060\", linestyle=\"--\", label=\"LOW\")\n",
     "        axes[1].axhline(diagnostic[\"high_ste_threshold\"], color=\"#9b6700\", linestyle=\":\", label=\"HIGH\")\n",
     "    for axis in axes:\n",
     "        for index, (start, end) in enumerate(result[\"ground_truth_regions\"]):\n",
     "            axis.axvspan(start, end, color=\"red\", alpha=0.05)\n",
     "            axis.axvline(start, color=\"red\", linestyle=\"--\", linewidth=1.25,\n",
@@ -4935,21 +4935,21 @@
        "tolerance_boundary_rmse_ms": 7.902112055091845,
        "tolerance_boundary_tolerance_ms": 100.0
       },
       "predicted_boundaries": [
        0.46,
        1.9349886621315193
       ]
      }
     ]
    },
-   "code_source_sha256": "cd630d306fbe2150dca8a8f06d0234be027bdde81d98c6bf4fb255d96eca0568",
+   "code_source_sha256": "4bbd40bf0b3fbbed68898e8e35ec313e20a1eb0ed7155fcecabc38210c11f4e2",
    "dataset_manifest": [
     {
      "duration_s": 3.24,
      "file": "phone_F1",
      "lab_sha256": "e30d41cc8e84112819bd7c6ab4a2c8d3adeadd4cb85054dd37f3dc824c1ca522",
      "sample_rate_hz": 16000,
      "split": "train",
      "wav_sha256": "4209a6ffe642f93b89554000fa7766135faf7c6cd97ce99b912b44af5e39db12"
     },
     {
diff --git a/outputs/endpoint_modes/comparison/artifact_audit.json b/outputs/endpoint_modes/comparison/artifact_audit.json
index 0337791..c0adfdb 100644
--- a/outputs/endpoint_modes/comparison/artifact_audit.json
+++ b/outputs/endpoint_modes/comparison/artifact_audit.json
@@ -1,59 +1,103 @@
 {
   "stable_detector_fit_AST": {
+    "algorithm_decision": false,
+    "detect_regions": true,
+    "fit_training_model": false
+  },
+  "arithmetic_and_API_AST_preserved_after_two_metadata_literals": {
     "algorithm_decision": true,
     "detect_regions": true,
     "fit_training_model": true
   },
+  "intentional_metadata_delta": {
+    "algorithm_decision.native_threshold_units": [
+      "sum of squared samples",
+      "mean squared sample amplitude"
+    ],
+    "fit_training_model.feature_rule": [
+      "Energy (sum of squared samples)",
+      "Energy (mean squared sample amplitude)"
+    ]
+  },
   "mode_rows": {
     "core": 24,
     "enhanced": 24
   },
   "tt2_sweep_rows": {
     "core": 200,
     "enhanced": 200
   },
   "notebooks": {
     "THUAT_TOAN_1.ipynb": {
       "pngs": 5,
       "mode_rows": {
         "core": 8,
         "enhanced": 8
       },
-      "code_source_sha256": "0752fcc76d08500624dc8eabef683b48df1ed00fc9a63c9dceff38ba331f396c",
+      "code_source_sha256": "4275ea2687f52a07b5df13efd22729407e2923257f22face217de054fa415b78",
       "model_lock_digests": {
         "core": "5100b645bfdadfa9f1635a3cf7934cd9894256909a72fca8360d3341297c6d68",
         "enhanced": "38ce0f36959e363d38b7921f892c0b2d274a9233a9d05c064be89d32c8743f8d"
       }
     },
     "THUAT_TOAN_2.ipynb": {
       "pngs": 5,
       "mode_rows": {
         "core": 8,
         "enhanced": 8
       },
-      "code_source_sha256": "c35b274765431ae9413fecdc96672467489246a7eea1488738bac9782bb4ac46",
+      "code_source_sha256": "6be6d5ad4bd277b55f3c0547035fe008a65b53daf3fbc53eaa80719dd4a8cf00",
       "model_lock_digests": {
-        "core": "83d3e69001dbf50452f385f7997196403129fcc4aa198e50bf6bf629e69e5c45",
-        "enhanced": "169f44d678a4518c37bacf2f6493693f8f1c2950cb0b2c7fee1585fedd98ca7c"
+        "core": "eb3abf8e67947a86d6f37465a3194484e354a9f69bcf66aea43f08f64b1a57bc",
+        "enhanced": "4ca7fe4de10a36394f330016e7bce494e6fe77067bde1b9e6549d23c4b091705"
       }
     },
     "THUAT_TOAN_3.ipynb": {
       "pngs": 5,
       "mode_rows": {
         "core": 8,
         "enhanced": 8
       },
-      "code_source_sha256": "cd630d306fbe2150dca8a8f06d0234be027bdde81d98c6bf4fb255d96eca0568",
+      "code_source_sha256": "4bbd40bf0b3fbbed68898e8e35ec313e20a1eb0ed7155fcecabc38210c11f4e2",
       "model_lock_digests": {
         "core": "aa765832be8c85e0b8b4320cd4e64a47718792f34a39193cfe88b1c7f30d0bfe",
         "enhanced": "607e418b02303a8cb6b339656b0cbde3b26d3f257b3001606985ab03e213a3e7"
       }
     }
   },
   "notebook_zip_exact_three_byteequal": true,
   "enhanced_legacy_endpoint_regression": {
     "tt1": true,
     "tt2": true,
     "tt3": true
+  },
+  "round1_numeric_regression": {
+    "core": {
+      "all24_diagnostics_equal_except_unit_label": true,
+      "all24_prediction_CSVs_byteequal": true,
+      "all24_metrics_status_rows_CSV_byteequal": true
+    },
+    "enhanced": {
+      "all24_diagnostics_equal_except_unit_label": true,
+      "all24_prediction_CSVs_byteequal": true,
+      "all24_metrics_status_rows_CSV_byteequal": true
+    }
+  },
+  "touched_sha256": {
+    "app/pipeline.py": "7bd39fd5a85dd5710624dfc8cd861a3bba5dce4f9b52b8afe401a50b70a5378b",
+    "app/plotting.py": "56f9a58050273898361e8384845d25f86b06a06ce3782d6b411d2d094a85aaa2",
+    "tools/build_notebooks.py": "74dcce2c42c785bb59dcffcea8e111702ace8d248dce4722ee7c530ce878cd27",
+    "tests/test_endpoint_modes.py": "7fc2ab5d2e0d3af41639ac5cc858b3e226b385d39c2a4fb2a77ab491751b941e",
+    "tests/test_endpoint_mode_integration.py": "5923fe02040cce0aa33e9facd76a1c304b5887e7a7e797d8ccf63984e9c7f575",
+    "notebooks/THUAT_TOAN_1.ipynb": "cc3bfd3f3abf5f7b7e74b8edf5973f1972f42e084652362e41d68de16a5c8c4c",
+    "notebooks/THUAT_TOAN_2.ipynb": "f2904adc854002217c4873b0b39eba40379e4ea2a9d7e64857551824fd5160fc",
+    "notebooks/THUAT_TOAN_3.ipynb": "c7fbea5ab82dfa2db62493d50692e8310cd46f421709c86a2d91da45217bb605",
+    "submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip": "c4c668bafa97db7f8ab0364ad1aa23e6e7f08c15c8f59ec1f2b0e87fda4e437e",
+    "outputs/endpoint_modes/core/models/tt1.json": "fb91bcb188a5a970b1c5bc5fb15c1c3a21cfbb6a5a05fa66dc1fbd5d53466203",
+    "outputs/endpoint_modes/core/models/tt2.json": "bb4d0151431d5efd089ef8a0d1fd9c2201007c94a0614d3a4c9def84698d5536",
+    "outputs/endpoint_modes/core/models/tt3.json": "6929871511ba9cb5ce4ec3f677ae2f921b46cc0f8f6cdd237955ede85e13ff96",
+    "outputs/endpoint_modes/enhanced/models/tt1.json": "b4f80954272209feb43e4ad7b6cf50aaa2c69ff0fb6b96d7dd567c0401a5c668",
+    "outputs/endpoint_modes/enhanced/models/tt2.json": "0dc7884d18b55ba415396fbb3259e2022caec89e7eaf88f27bf6b0ac500a3aa6",
+    "outputs/endpoint_modes/enhanced/models/tt3.json": "f490662a37c4001b6033a02949ab76ae2fdf9148194c1ce309e23dbacb2160cf"
   }
 }
\ No newline at end of file
diff --git a/outputs/endpoint_modes/core/diagnostics/tt2/phone_F1.json b/outputs/endpoint_modes/core/diagnostics/tt2/phone_F1.json
index c4a0f19..0461cb5 100644
--- a/outputs/endpoint_modes/core/diagnostics/tt2/phone_F1.json
+++ b/outputs/endpoint_modes/core/diagnostics/tt2/phone_F1.json
@@ -45,21 +45,21 @@
     "W": 20.0
   },
   "padding_frames": 25,
   "padding_ms": 250.0,
   "effective_padding_ms": 250.0,
   "raw_speech_frames": 142,
   "padded_speech_frames": 269,
   "feature": "energy",
   "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
   "native_threshold": 0.0017156231046586373,
-  "native_threshold_units": "sum of squared samples",
+  "native_threshold_units": "mean squared sample amplitude",
   "candidate_regions": [
     [
       0.54,
       1.145
     ],
     [
       1.2,
       1.345
     ],
     [
diff --git a/outputs/endpoint_modes/core/diagnostics/tt2/phone_F2.json b/outputs/endpoint_modes/core/diagnostics/tt2/phone_F2.json
index 75125ad..1a3baa4 100644
--- a/outputs/endpoint_modes/core/diagnostics/tt2/phone_F2.json
+++ b/outputs/endpoint_modes/core/diagnostics/tt2/phone_F2.json
@@ -35,21 +35,21 @@
     "W": 20.0
   },
   "padding_frames": 25,
   "padding_ms": 250.0,
   "effective_padding_ms": 250.0,
   "raw_speech_frames": 224,
   "padded_speech_frames": 345,
   "feature": "energy",
   "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
   "native_threshold": 0.00010582343327162865,
-  "native_threshold_units": "sum of squared samples",
+  "native_threshold_units": "mean squared sample amplitude",
   "candidate_regions": [
     [
       1.05,
       1.885
     ],
     [
       1.95,
       2.165
     ],
     [
diff --git a/outputs/endpoint_modes/core/diagnostics/tt2/phone_M1.json b/outputs/endpoint_modes/core/diagnostics/tt2/phone_M1.json
index b5c37fa..59e777b 100644
--- a/outputs/endpoint_modes/core/diagnostics/tt2/phone_M1.json
+++ b/outputs/endpoint_modes/core/diagnostics/tt2/phone_M1.json
@@ -45,21 +45,21 @@
     "W": 20.0
   },
   "padding_frames": 25,
   "padding_ms": 250.0,
   "effective_padding_ms": 250.0,
   "raw_speech_frames": 244,
   "padded_speech_frames": 355,
   "feature": "energy",
   "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
   "native_threshold": 0.00017828773279688904,
-  "native_threshold_units": "sum of squared samples",
+  "native_threshold_units": "mean squared sample amplitude",
   "candidate_regions": [
     [
       0.46,
       1.365
     ],
     [
       1.48,
       1.695
     ],
     [
diff --git a/outputs/endpoint_modes/core/diagnostics/tt2/phone_M2.json b/outputs/endpoint_modes/core/diagnostics/tt2/phone_M2.json
index eb869ba..d0edbf8 100644
--- a/outputs/endpoint_modes/core/diagnostics/tt2/phone_M2.json
+++ b/outputs/endpoint_modes/core/diagnostics/tt2/phone_M2.json
@@ -37,21 +37,21 @@
     "W": 20.0
   },
   "padding_frames": 25,
   "padding_ms": 250.0,
   "effective_padding_ms": 250.0,
   "raw_speech_frames": 153,
   "padded_speech_frames": 247,
   "feature": "energy",
   "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
   "native_threshold": 0.00020677588617607918,
-  "native_threshold_units": "sum of squared samples",
+  "native_threshold_units": "mean squared sample amplitude",
   "candidate_regions": [
     [
       0.53,
       1.055
     ],
     [
       1.1,
       1.255
     ],
     [
diff --git a/outputs/endpoint_modes/core/diagnostics/tt2/studio_F1.json b/outputs/endpoint_modes/core/diagnostics/tt2/studio_F1.json
index f76528c..fe4d0c0 100644
--- a/outputs/endpoint_modes/core/diagnostics/tt2/studio_F1.json
+++ b/outputs/endpoint_modes/core/diagnostics/tt2/studio_F1.json
@@ -45,21 +45,21 @@
     "W": 20.0
   },
   "padding_frames": 25,
   "padding_ms": 250.0,
   "effective_padding_ms": 250.0,
   "raw_speech_frames": 127,
   "padded_speech_frames": 196,
   "feature": "energy",
   "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
   "native_threshold": 0.00026848996726078445,
-  "native_threshold_units": "sum of squared samples",
+  "native_threshold_units": "mean squared sample amplitude",
   "candidate_regions": [
     [
       0.67,
       1.0949886621315192
     ],
     [
       1.1,
       1.2049886621315193
     ],
     [
diff --git a/outputs/endpoint_modes/core/diagnostics/tt2/studio_F2.json b/outputs/endpoint_modes/core/diagnostics/tt2/studio_F2.json
index a3f8e95..2562d93 100644
--- a/outputs/endpoint_modes/core/diagnostics/tt2/studio_F2.json
+++ b/outputs/endpoint_modes/core/diagnostics/tt2/studio_F2.json
@@ -31,21 +31,21 @@
     "W": 20.0
   },
   "padding_frames": 25,
   "padding_ms": 250.0,
   "effective_padding_ms": 250.0,
   "raw_speech_frames": 137,
   "padded_speech_frames": 207,
   "feature": "energy",
   "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
   "native_threshold": 0.00136423548694805,
-  "native_threshold_units": "sum of squared samples",
+  "native_threshold_units": "mean squared sample amplitude",
   "candidate_regions": [
     [
       0.76,
       1.2449886621315194
     ],
     [
       1.25,
       1.3449886621315192
     ],
     [
diff --git a/outputs/endpoint_modes/core/diagnostics/tt2/studio_M1.json b/outputs/endpoint_modes/core/diagnostics/tt2/studio_M1.json
index b60f909..377ef8b 100644
--- a/outputs/endpoint_modes/core/diagnostics/tt2/studio_M1.json
+++ b/outputs/endpoint_modes/core/diagnostics/tt2/studio_M1.json
@@ -39,21 +39,21 @@
     "W": 20.0
   },
   "padding_frames": 25,
   "padding_ms": 250.0,
   "effective_padding_ms": 250.0,
   "raw_speech_frames": 93,
   "padded_speech_frames": 162,
   "feature": "energy",
   "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
   "native_threshold": 0.00027139670637816725,
-  "native_threshold_units": "sum of squared samples",
+  "native_threshold_units": "mean squared sample amplitude",
   "candidate_regions": [
     [
       0.91,
       1.1849886621315193
     ],
     [
       1.19,
       1.2749886621315192
     ],
     [
diff --git a/outputs/endpoint_modes/core/diagnostics/tt2/studio_M2.json b/outputs/endpoint_modes/core/diagnostics/tt2/studio_M2.json
index 676509c..840a75d 100644
--- a/outputs/endpoint_modes/core/diagnostics/tt2/studio_M2.json
+++ b/outputs/endpoint_modes/core/diagnostics/tt2/studio_M2.json
@@ -37,21 +37,21 @@
     "W": 20.0
   },
   "padding_frames": 25,
   "padding_ms": 250.0,
   "effective_padding_ms": 250.0,
   "raw_speech_frames": 125,
   "padded_speech_frames": 195,
   "feature": "energy",
   "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
   "native_threshold": 0.00025823544010657173,
-  "native_threshold_units": "sum of squared samples",
+  "native_threshold_units": "mean squared sample amplitude",
   "candidate_regions": [
     [
       0.46,
       0.8849886621315193
     ],
     [
       0.9,
       1.4349886621315193
     ],
     [
diff --git a/outputs/endpoint_modes/core/figures/comparison/phone_F1.png b/outputs/endpoint_modes/core/figures/comparison/phone_F1.png
index 5a2d6e9..2c29190 100644
Binary files a/outputs/endpoint_modes/core/figures/comparison/phone_F1.png and b/outputs/endpoint_modes/core/figures/comparison/phone_F1.png differ
diff --git a/outputs/endpoint_modes/core/figures/comparison/phone_F2.png b/outputs/endpoint_modes/core/figures/comparison/phone_F2.png
index 82cc0c1..2938359 100644
Binary files a/outputs/endpoint_modes/core/figures/comparison/phone_F2.png and b/outputs/endpoint_modes/core/figures/comparison/phone_F2.png differ
diff --git a/outputs/endpoint_modes/core/figures/comparison/phone_M1.png b/outputs/endpoint_modes/core/figures/comparison/phone_M1.png
index 38abfb6..e8e7c4e 100644
Binary files a/outputs/endpoint_modes/core/figures/comparison/phone_M1.png and b/outputs/endpoint_modes/core/figures/comparison/phone_M1.png differ
diff --git a/outputs/endpoint_modes/core/figures/comparison/phone_M2.png b/outputs/endpoint_modes/core/figures/comparison/phone_M2.png
index cd4c71f..c1be05c 100644
Binary files a/outputs/endpoint_modes/core/figures/comparison/phone_M2.png and b/outputs/endpoint_modes/core/figures/comparison/phone_M2.png differ
diff --git a/outputs/endpoint_modes/core/figures/comparison/studio_F1.png b/outputs/endpoint_modes/core/figures/comparison/studio_F1.png
index 040e88c..b67d42f 100644
Binary files a/outputs/endpoint_modes/core/figures/comparison/studio_F1.png and b/outputs/endpoint_modes/core/figures/comparison/studio_F1.png differ
diff --git a/outputs/endpoint_modes/core/figures/comparison/studio_F2.png b/outputs/endpoint_modes/core/figures/comparison/studio_F2.png
index 90145de..ac62f31 100644
Binary files a/outputs/endpoint_modes/core/figures/comparison/studio_F2.png and b/outputs/endpoint_modes/core/figures/comparison/studio_F2.png differ
diff --git a/outputs/endpoint_modes/core/figures/comparison/studio_M1.png b/outputs/endpoint_modes/core/figures/comparison/studio_M1.png
index 4ba585a..aaab40e 100644
Binary files a/outputs/endpoint_modes/core/figures/comparison/studio_M1.png and b/outputs/endpoint_modes/core/figures/comparison/studio_M1.png differ
diff --git a/outputs/endpoint_modes/core/figures/comparison/studio_M2.png b/outputs/endpoint_modes/core/figures/comparison/studio_M2.png
index 10d2b81..509306d 100644
Binary files a/outputs/endpoint_modes/core/figures/comparison/studio_M2.png and b/outputs/endpoint_modes/core/figures/comparison/studio_M2.png differ
diff --git a/outputs/endpoint_modes/core/figures/tt2/phone_F1.png b/outputs/endpoint_modes/core/figures/tt2/phone_F1.png
index c1cc13f..7003507 100644
Binary files a/outputs/endpoint_modes/core/figures/tt2/phone_F1.png and b/outputs/endpoint_modes/core/figures/tt2/phone_F1.png differ
diff --git a/outputs/endpoint_modes/core/figures/tt2/phone_F2.png b/outputs/endpoint_modes/core/figures/tt2/phone_F2.png
index a32e907..5f4fea2 100644
Binary files a/outputs/endpoint_modes/core/figures/tt2/phone_F2.png and b/outputs/endpoint_modes/core/figures/tt2/phone_F2.png differ
diff --git a/outputs/endpoint_modes/core/figures/tt2/phone_M1.png b/outputs/endpoint_modes/core/figures/tt2/phone_M1.png
index 44e6887..6ad62e8 100644
Binary files a/outputs/endpoint_modes/core/figures/tt2/phone_M1.png and b/outputs/endpoint_modes/core/figures/tt2/phone_M1.png differ
diff --git a/outputs/endpoint_modes/core/figures/tt2/phone_M2.png b/outputs/endpoint_modes/core/figures/tt2/phone_M2.png
index 35e245d..083097a 100644
Binary files a/outputs/endpoint_modes/core/figures/tt2/phone_M2.png and b/outputs/endpoint_modes/core/figures/tt2/phone_M2.png differ
diff --git a/outputs/endpoint_modes/core/figures/tt2/studio_F1.png b/outputs/endpoint_modes/core/figures/tt2/studio_F1.png
index edd4f33..b695bb9 100644
Binary files a/outputs/endpoint_modes/core/figures/tt2/studio_F1.png and b/outputs/endpoint_modes/core/figures/tt2/studio_F1.png differ
diff --git a/outputs/endpoint_modes/core/figures/tt2/studio_F2.png b/outputs/endpoint_modes/core/figures/tt2/studio_F2.png
index 40fad96..a952b74 100644
Binary files a/outputs/endpoint_modes/core/figures/tt2/studio_F2.png and b/outputs/endpoint_modes/core/figures/tt2/studio_F2.png differ
diff --git a/outputs/endpoint_modes/core/figures/tt2/studio_M1.png b/outputs/endpoint_modes/core/figures/tt2/studio_M1.png
index eea40ba..0554de0 100644
Binary files a/outputs/endpoint_modes/core/figures/tt2/studio_M1.png and b/outputs/endpoint_modes/core/figures/tt2/studio_M1.png differ
diff --git a/outputs/endpoint_modes/core/figures/tt2/studio_M2.png b/outputs/endpoint_modes/core/figures/tt2/studio_M2.png
index 9a42439..3780dc9 100644
Binary files a/outputs/endpoint_modes/core/figures/tt2/studio_M2.png and b/outputs/endpoint_modes/core/figures/tt2/studio_M2.png differ
diff --git a/outputs/endpoint_modes/core/models/tt2.json b/outputs/endpoint_modes/core/models/tt2.json
index 6b62f93..7581f49 100644
--- a/outputs/endpoint_modes/core/models/tt2.json
+++ b/outputs/endpoint_modes/core/models/tt2.json
@@ -23,21 +23,21 @@
     "phone_F1",
     "phone_M1",
     "studio_F1",
     "studio_M1"
   ],
   "minimum_internal_silence_ms": 200.0,
   "minimum_speech_ms": 0.0,
   "minimum_silence_ms": 200.0,
   "endpoint_noise": null,
   "endpoint_policy": "native decisions; merge internal support gaps below 200 ms; no duration filter or final padding",
-  "feature_rule": "Energy (sum of squared samples)",
+  "feature_rule": "Energy (mean squared sample amplitude)",
   "padding_stage": "excluded from core FINAL",
   "boundary_convention": "union of active frame supports",
   "candidate_frame_selected_W": 1.0,
   "candidate_frame_f1": 0.8986983588002264,
   "candidate_frame_selection_scores": [
     {
       "W": 1.0,
       "candidate_frame_f1": 0.8986983588002264,
       "tp": 794,
       "fp": 179,
@@ -704,14 +704,14 @@
     "evaluation_protocol": "train_final_calibration",
     "selection_rule": "valid regions; minimum worst per-file regret; mean MAE; declared W preference on ties; smallest W otherwise",
     "evaluated_files": [
       "phone_F1",
       "phone_M1",
       "studio_F1",
       "studio_M1"
     ],
     "endpoint_policy": "native decisions; merge internal support gaps below 200 ms; no duration filter or final padding",
     "note": "W was calibrated using these TRAIN LABs; TEST has historical exposure and is reused for scoring, so no holdout independence is claimed.",
-    "calibration_digest": "44b1591191d1956579d75f195c1f40f7fffc8a1b953104a9227f42dda5b40509"
+    "calibration_digest": "2432f69d291a4d9dc5de612b34976b687041294d8943f502f3ec53ef8e2de80f"
   },
-  "calibration_digest": "44b1591191d1956579d75f195c1f40f7fffc8a1b953104a9227f42dda5b40509"
+  "calibration_digest": "2432f69d291a4d9dc5de612b34976b687041294d8943f502f3ec53ef8e2de80f"
 }
\ No newline at end of file
diff --git a/outputs/endpoint_modes/core/tables/all_all_dataset/test_thresholds.csv b/outputs/endpoint_modes/core/tables/all_all_dataset/test_thresholds.csv
index 5f34d58..d2ce617 100644
--- a/outputs/endpoint_modes/core/tables/all_all_dataset/test_thresholds.csv
+++ b/outputs/endpoint_modes/core/tables/all_all_dataset/test_thresholds.csv
@@ -1,25 +1,25 @@
 ﻿file,algorithm,threshold,native_threshold,native_threshold_units,low_ste_threshold,high_ste_threshold,endpoint_noise,minimum_speech_ms,minimum_silence_ms,endpoint_mode,geometry,final_padding_ms,padding_stage,endpoint_policy,variant,energy_threshold,padding_frames,padding_ms,effective_padding_ms,raw_speech_frames,padded_speech_frames,feature,source_status
 phone_F1,tt1,0.0010293375196035162,0.0010293375196035162,normalized STE,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,,,,,,,,,
 phone_M1,tt1,0.0010293375196035162,0.0010293375196035162,normalized STE,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,,,,,,,,,
 studio_F1,tt1,0.0010293375196035162,0.0010293375196035162,normalized STE,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,,,,,,,,,
 studio_M1,tt1,0.0010293375196035162,0.0010293375196035162,normalized STE,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,,,,,,,,,
 phone_F2,tt1,0.0010293375196035162,0.0010293375196035162,normalized STE,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,,,,,,,,,
 phone_M2,tt1,0.0010293375196035162,0.0010293375196035162,normalized STE,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,,,,,,,,,
 studio_F2,tt1,0.0010293375196035162,0.0010293375196035162,normalized STE,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,,,,,,,,,
 studio_M2,tt1,0.0010293375196035162,0.0010293375196035162,normalized STE,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,,,,,,,,,
-phone_F1,tt2,,0.0017156231046586373,sum of squared samples,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,source,0.0017156231046586373,25,250.0,250.0,142,269,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
-phone_M1,tt2,,0.00017828773279688904,sum of squared samples,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,source,0.00017828773279688904,25,250.0,250.0,244,355,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
-studio_F1,tt2,,0.00026848996726078445,sum of squared samples,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,source,0.00026848996726078445,25,250.0,250.0,127,196,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
-studio_M1,tt2,,0.00027139670637816725,sum of squared samples,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,source,0.00027139670637816725,25,250.0,250.0,93,162,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
-phone_F2,tt2,,0.00010582343327162865,sum of squared samples,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,source,0.00010582343327162865,25,250.0,250.0,224,345,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
-phone_M2,tt2,,0.00020677588617607918,sum of squared samples,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,source,0.00020677588617607918,25,250.0,250.0,153,247,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
-studio_F2,tt2,,0.00136423548694805,sum of squared samples,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,source,0.00136423548694805,25,250.0,250.0,137,207,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
-studio_M2,tt2,,0.00025823544010657173,sum of squared samples,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,source,0.00025823544010657173,25,250.0,250.0,125,195,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
+phone_F1,tt2,,0.0017156231046586373,mean squared sample amplitude,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,source,0.0017156231046586373,25,250.0,250.0,142,269,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
+phone_M1,tt2,,0.00017828773279688904,mean squared sample amplitude,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,source,0.00017828773279688904,25,250.0,250.0,244,355,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
+studio_F1,tt2,,0.00026848996726078445,mean squared sample amplitude,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,source,0.00026848996726078445,25,250.0,250.0,127,196,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
+studio_M1,tt2,,0.00027139670637816725,mean squared sample amplitude,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,source,0.00027139670637816725,25,250.0,250.0,93,162,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
+phone_F2,tt2,,0.00010582343327162865,mean squared sample amplitude,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,source,0.00010582343327162865,25,250.0,250.0,224,345,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
+phone_M2,tt2,,0.00020677588617607918,mean squared sample amplitude,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,source,0.00020677588617607918,25,250.0,250.0,153,247,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
+studio_F2,tt2,,0.00136423548694805,mean squared sample amplitude,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,source,0.00136423548694805,25,250.0,250.0,137,207,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
+studio_M2,tt2,,0.00025823544010657173,mean squared sample amplitude,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,source,0.00025823544010657173,25,250.0,250.0,125,195,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
 phone_F1,tt3,0.0028777336852328582,0.0028777336852328582,normalized STE,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,,,,,,,,,
 phone_M1,tt3,0.0028777336852328582,0.0028777336852328582,normalized STE,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,,,,,,,,,
 studio_F1,tt3,0.0028777336852328582,0.0028777336852328582,normalized STE,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,,,,,,,,,
 studio_M1,tt3,0.0028777336852328582,0.0028777336852328582,normalized STE,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,,,,,,,,,
 phone_F2,tt3,0.0028777336852328582,0.0028777336852328582,normalized STE,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,,,,,,,,,
 phone_M2,tt3,0.0028777336852328582,0.0028777336852328582,normalized STE,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,,,,,,,,,
 studio_F2,tt3,0.0028777336852328582,0.0028777336852328582,normalized STE,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,,,,,,,,,
 studio_M2,tt3,0.0028777336852328582,0.0028777336852328582,normalized STE,,,,0.0,200.0,core,union of active frame supports,0.0,excluded from core FINAL,native decisions; merge internal support gaps below 200 ms; no duration filter or final padding,,,,,,,,,
diff --git a/outputs/endpoint_modes/core/tables/tt2_w_selection/selection.json b/outputs/endpoint_modes/core/tables/tt2_w_selection/selection.json
index fb6313e..447fe81 100644
--- a/outputs/endpoint_modes/core/tables/tt2_w_selection/selection.json
+++ b/outputs/endpoint_modes/core/tables/tt2_w_selection/selection.json
@@ -623,12 +623,12 @@
   "evaluation_protocol": "train_final_calibration",
   "selection_rule": "valid regions; minimum worst per-file regret; mean MAE; declared W preference on ties; smallest W otherwise",
   "evaluated_files": [
     "phone_F1",
     "phone_M1",
     "studio_F1",
     "studio_M1"
   ],
   "endpoint_policy": "native decisions; merge internal support gaps below 200 ms; no duration filter or final padding",
   "note": "W was calibrated using these TRAIN LABs; TEST has historical exposure and is reused for scoring, so no holdout independence is claimed.",
-  "calibration_digest": "44b1591191d1956579d75f195c1f40f7fffc8a1b953104a9227f42dda5b40509"
+  "calibration_digest": "2432f69d291a4d9dc5de612b34976b687041294d8943f502f3ec53ef8e2de80f"
 }
\ No newline at end of file
diff --git a/outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_F1.json b/outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_F1.json
index d904f81..d3d71c0 100644
--- a/outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_F1.json
+++ b/outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_F1.json
@@ -45,21 +45,21 @@
     "W": 20.0
   },
   "padding_frames": 25,
   "padding_ms": 250.0,
   "effective_padding_ms": 250.0,
   "raw_speech_frames": 142,
   "padded_speech_frames": 269,
   "feature": "energy",
   "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
   "native_threshold": 0.0017156231046586373,
-  "native_threshold_units": "sum of squared samples",
+  "native_threshold_units": "mean squared sample amplitude",
   "candidate_regions": [
     [
       0.29,
       2.995
     ]
   ],
   "final_regions": [
     [
       0.53,
       2.745
diff --git a/outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_F2.json b/outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_F2.json
index af62756..b18ac10 100644
--- a/outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_F2.json
+++ b/outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_F2.json
@@ -35,21 +35,21 @@
     "W": 20.0
   },
   "padding_frames": 25,
   "padding_ms": 250.0,
   "effective_padding_ms": 250.0,
   "raw_speech_frames": 224,
   "padded_speech_frames": 345,
   "feature": "energy",
   "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
   "native_threshold": 0.00010582343327162865,
-  "native_threshold_units": "sum of squared samples",
+  "native_threshold_units": "mean squared sample amplitude",
   "candidate_regions": [
     [
       0.8,
       4.265
     ]
   ],
   "final_regions": [
     [
       1.01,
       4.095
diff --git a/outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_M1.json b/outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_M1.json
index dd58f7d..45907d9 100644
--- a/outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_M1.json
+++ b/outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_M1.json
@@ -45,21 +45,21 @@
     "W": 20.0
   },
   "padding_frames": 25,
   "padding_ms": 250.0,
   "effective_padding_ms": 250.0,
   "raw_speech_frames": 244,
   "padded_speech_frames": 355,
   "feature": "energy",
   "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
   "native_threshold": 0.00017828773279688904,
-  "native_threshold_units": "sum of squared samples",
+  "native_threshold_units": "mean squared sample amplitude",
   "candidate_regions": [
     [
       0.21,
       3.775
     ]
   ],
   "final_regions": [
     [
       0.46,
       3.545
diff --git a/outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_M2.json b/outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_M2.json
index a32c9dd..e562404 100644
--- a/outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_M2.json
+++ b/outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_M2.json
@@ -37,21 +37,21 @@
     "W": 20.0
   },
   "padding_frames": 25,
   "padding_ms": 250.0,
   "effective_padding_ms": 250.0,
   "raw_speech_frames": 153,
   "padded_speech_frames": 247,
   "feature": "energy",
   "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
   "native_threshold": 0.00020677588617607918,
-  "native_threshold_units": "sum of squared samples",
+  "native_threshold_units": "mean squared sample amplitude",
   "candidate_regions": [
     [
       0.28,
       2.765
     ]
   ],
   "final_regions": [
     [
       0.52,
       2.525
diff --git a/outputs/endpoint_modes/enhanced/diagnostics/tt2/studio_F1.json b/outputs/endpoint_modes/enhanced/diagnostics/tt2/studio_F1.json
index f276be5..cb41405 100644
--- a/outputs/endpoint_modes/enhanced/diagnostics/tt2/studio_F1.json
+++ b/outputs/endpoint_modes/enhanced/diagnostics/tt2/studio_F1.json
@@ -45,21 +45,21 @@
     "W": 20.0
   },
   "padding_frames": 25,
   "padding_ms": 250.0,
   "effective_padding_ms": 250.0,
   "raw_speech_frames": 127,
   "padded_speech_frames": 196,
   "feature": "energy",
   "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
   "native_threshold": 0.00026848996726078445,
-  "native_threshold_units": "sum of squared samples",
+  "native_threshold_units": "mean squared sample amplitude",
   "candidate_regions": [
     [
       0.42,
       2.394988662131519
     ]
   ],
   "final_regions": [
     [
       0.66,
       2.164988662131519
diff --git a/outputs/endpoint_modes/enhanced/diagnostics/tt2/studio_F2.json b/outputs/endpoint_modes/enhanced/diagnostics/tt2/studio_F2.json
index 7bd1fd1..09dcad4 100644
--- a/outputs/endpoint_modes/enhanced/diagnostics/tt2/studio_F2.json
+++ b/outputs/endpoint_modes/enhanced/diagnostics/tt2/studio_F2.json
@@ -31,21 +31,21 @@
     "W": 20.0
   },
   "padding_frames": 25,
   "padding_ms": 250.0,
   "effective_padding_ms": 250.0,
   "raw_speech_frames": 137,
   "padded_speech_frames": 207,
   "feature": "energy",
   "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
   "native_threshold": 0.00136423548694805,
-  "native_threshold_units": "sum of squared samples",
+  "native_threshold_units": "mean squared sample amplitude",
   "candidate_regions": [
     [
       0.51,
       2.5949886621315192
     ]
   ],
   "final_regions": [
     [
       0.76,
       2.3649886621315193
diff --git a/outputs/endpoint_modes/enhanced/diagnostics/tt2/studio_M1.json b/outputs/endpoint_modes/enhanced/diagnostics/tt2/studio_M1.json
index a1372fe..dee7247 100644
--- a/outputs/endpoint_modes/enhanced/diagnostics/tt2/studio_M1.json
+++ b/outputs/endpoint_modes/enhanced/diagnostics/tt2/studio_M1.json
@@ -39,21 +39,21 @@
     "W": 20.0
   },
   "padding_frames": 25,
   "padding_ms": 250.0,
   "effective_padding_ms": 250.0,
   "raw_speech_frames": 93,
   "padded_speech_frames": 162,
   "feature": "energy",
   "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
   "native_threshold": 0.00027139670637816725,
-  "native_threshold_units": "sum of squared samples",
+  "native_threshold_units": "mean squared sample amplitude",
   "candidate_regions": [
     [
       0.66,
       2.2949886621315194
     ]
   ],
   "final_regions": [
     [
       0.91,
       2.0649886621315194
diff --git a/outputs/endpoint_modes/enhanced/diagnostics/tt2/studio_M2.json b/outputs/endpoint_modes/enhanced/diagnostics/tt2/studio_M2.json
index d858868..e0fd0cf 100644
--- a/outputs/endpoint_modes/enhanced/diagnostics/tt2/studio_M2.json
+++ b/outputs/endpoint_modes/enhanced/diagnostics/tt2/studio_M2.json
@@ -37,21 +37,21 @@
     "W": 20.0
   },
   "padding_frames": 25,
   "padding_ms": 250.0,
   "effective_padding_ms": 250.0,
   "raw_speech_frames": 125,
   "padded_speech_frames": 195,
   "feature": "energy",
   "source_status": "Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops",
   "native_threshold": 0.00025823544010657173,
-  "native_threshold_units": "sum of squared samples",
+  "native_threshold_units": "mean squared sample amplitude",
   "candidate_regions": [
     [
       0.21,
       2.1749886621315193
     ]
   ],
   "final_regions": [
     [
       0.46,
       1.9349886621315193
diff --git a/outputs/endpoint_modes/enhanced/models/tt2.json b/outputs/endpoint_modes/enhanced/models/tt2.json
index a8053dd..b5277b3 100644
--- a/outputs/endpoint_modes/enhanced/models/tt2.json
+++ b/outputs/endpoint_modes/enhanced/models/tt2.json
@@ -31,21 +31,21 @@
   "endpoint_noise": {
     "noise_mean": 0.00038711079659476316,
     "noise_std": 0.0007092854827602364,
     "noise_q95": 0.0012140144555334857,
     "noise_upper": 0.0025149672448754727,
     "noise_count": 497,
     "calibration": "training silence only; population std; Q95 nearest rank",
     "high_multiplier": 1.5
   },
   "endpoint_policy": "hysteresis final regions; no fixed final padding",
-  "feature_rule": "Energy (sum of squared samples)",
+  "feature_rule": "Energy (mean squared sample amplitude)",
   "padding_stage": "candidate diagnostics only",
   "boundary_convention": "union of active frame supports",
   "candidate_frame_selected_W": 1.0,
   "candidate_frame_f1": 0.8986983588002264,
   "candidate_frame_selection_scores": [
     {
       "W": 1.0,
       "candidate_frame_f1": 0.8986983588002264,
       "tp": 794,
       "fp": 179,
@@ -886,14 +886,14 @@
     "evaluation_protocol": "train_final_calibration",
     "selection_rule": "valid regions; minimum worst per-file regret; mean MAE; declared W preference on ties; smallest W otherwise",
     "evaluated_files": [
       "phone_F1",
       "phone_M1",
       "studio_F1",
       "studio_M1"
     ],
     "endpoint_policy": "hysteresis final regions; no fixed final padding",
     "note": "W was calibrated using these TRAIN LABs; TEST has historical exposure and is reused for scoring, so no holdout independence is claimed.",
-    "calibration_digest": "72c661f212a202e564e4546c76425ce4ab20883144fd12d7e0a971ac20c469dd"
+    "calibration_digest": "33a016d798ea363b0079dc61e2b390848a391ad7384847142cb5dedb03684361"
   },
-  "calibration_digest": "72c661f212a202e564e4546c76425ce4ab20883144fd12d7e0a971ac20c469dd"
+  "calibration_digest": "33a016d798ea363b0079dc61e2b390848a391ad7384847142cb5dedb03684361"
 }
\ No newline at end of file
diff --git a/outputs/endpoint_modes/enhanced/tables/all_all_dataset/test_thresholds.csv b/outputs/endpoint_modes/enhanced/tables/all_all_dataset/test_thresholds.csv
index 9ea99d0..1a96110 100644
--- a/outputs/endpoint_modes/enhanced/tables/all_all_dataset/test_thresholds.csv
+++ b/outputs/endpoint_modes/enhanced/tables/all_all_dataset/test_thresholds.csv
@@ -1,25 +1,25 @@
 ﻿file,algorithm,threshold,native_threshold,native_threshold_units,endpoint_mode,geometry,final_padding_ms,padding_stage,low_ste_threshold,high_ste_threshold,minimum_speech_ms,minimum_silence_ms,endpoint_policy,variant,energy_threshold,padding_frames,padding_ms,effective_padding_ms,raw_speech_frames,padded_speech_frames,feature,source_status
 phone_F1,tt1,0.0010293375196035162,0.0010293375196035162,normalized STE,enhanced,union of active frame supports,0.0,none,0.0012140144555334857,0.0025149672448754727,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,,,,,,,,,
 phone_M1,tt1,0.0010293375196035162,0.0010293375196035162,normalized STE,enhanced,union of active frame supports,0.0,none,0.0012140144555334857,0.0025149672448754727,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,,,,,,,,,
 studio_F1,tt1,0.0010293375196035162,0.0010293375196035162,normalized STE,enhanced,union of active frame supports,0.0,none,0.0012140144555334857,0.0025149672448754727,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,,,,,,,,,
 studio_M1,tt1,0.0010293375196035162,0.0010293375196035162,normalized STE,enhanced,union of active frame supports,0.0,none,0.0012140144555334857,0.0025149672448754727,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,,,,,,,,,
 phone_F2,tt1,0.0010293375196035162,0.0010293375196035162,normalized STE,enhanced,union of active frame supports,0.0,none,0.0012140144555334857,0.0025149672448754727,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,,,,,,,,,
 phone_M2,tt1,0.0010293375196035162,0.0010293375196035162,normalized STE,enhanced,union of active frame supports,0.0,none,0.0012140144555334857,0.0025149672448754727,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,,,,,,,,,
 studio_F2,tt1,0.0010293375196035162,0.0010293375196035162,normalized STE,enhanced,union of active frame supports,0.0,none,0.0012140144555334857,0.0025149672448754727,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,,,,,,,,,
 studio_M2,tt1,0.0010293375196035162,0.0010293375196035162,normalized STE,enhanced,union of active frame supports,0.0,none,0.0012140144555334857,0.0025149672448754727,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,,,,,,,,,
-phone_F1,tt2,,0.0017156231046586373,sum of squared samples,enhanced,union of active frame supports,0.0,candidate diagnostics only,0.0025149672448754727,0.013307332273144389,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,source,0.0017156231046586373,25,250.0,250.0,142,269,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
-phone_M1,tt2,,0.00017828773279688904,sum of squared samples,enhanced,union of active frame supports,0.0,candidate diagnostics only,0.0025149672448754727,0.012637015253843122,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,source,0.00017828773279688904,25,250.0,250.0,244,355,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
-studio_F1,tt2,,0.00026848996726078445,sum of squared samples,enhanced,union of active frame supports,0.0,candidate diagnostics only,0.0025149672448754727,0.015253875587669167,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,source,0.00026848996726078445,25,250.0,250.0,127,196,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
-studio_M1,tt2,,0.00027139670637816725,sum of squared samples,enhanced,union of active frame supports,0.0,candidate diagnostics only,0.0025149672448754727,0.012276806029288843,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,source,0.00027139670637816725,25,250.0,250.0,93,162,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
-phone_F2,tt2,,0.00010582343327162865,sum of squared samples,enhanced,union of active frame supports,0.0,candidate diagnostics only,0.0025149672448754727,0.011599505796759687,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,source,0.00010582343327162865,25,250.0,250.0,224,345,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
-phone_M2,tt2,,0.00020677588617607918,sum of squared samples,enhanced,union of active frame supports,0.0,candidate diagnostics only,0.0025149672448754727,0.016741174854225986,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,source,0.00020677588617607918,25,250.0,250.0,153,247,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
-studio_F2,tt2,,0.00136423548694805,sum of squared samples,enhanced,union of active frame supports,0.0,candidate diagnostics only,0.0025149672448754727,0.012276785714285716,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,source,0.00136423548694805,25,250.0,250.0,137,207,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
-studio_M2,tt2,,0.00025823544010657173,sum of squared samples,enhanced,union of active frame supports,0.0,candidate diagnostics only,0.0025149672448754727,0.013020929394699838,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,source,0.00025823544010657173,25,250.0,250.0,125,195,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
+phone_F1,tt2,,0.0017156231046586373,mean squared sample amplitude,enhanced,union of active frame supports,0.0,candidate diagnostics only,0.0025149672448754727,0.013307332273144389,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,source,0.0017156231046586373,25,250.0,250.0,142,269,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
+phone_M1,tt2,,0.00017828773279688904,mean squared sample amplitude,enhanced,union of active frame supports,0.0,candidate diagnostics only,0.0025149672448754727,0.012637015253843122,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,source,0.00017828773279688904,25,250.0,250.0,244,355,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
+studio_F1,tt2,,0.00026848996726078445,mean squared sample amplitude,enhanced,union of active frame supports,0.0,candidate diagnostics only,0.0025149672448754727,0.015253875587669167,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,source,0.00026848996726078445,25,250.0,250.0,127,196,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
+studio_M1,tt2,,0.00027139670637816725,mean squared sample amplitude,enhanced,union of active frame supports,0.0,candidate diagnostics only,0.0025149672448754727,0.012276806029288843,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,source,0.00027139670637816725,25,250.0,250.0,93,162,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
+phone_F2,tt2,,0.00010582343327162865,mean squared sample amplitude,enhanced,union of active frame supports,0.0,candidate diagnostics only,0.0025149672448754727,0.011599505796759687,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,source,0.00010582343327162865,25,250.0,250.0,224,345,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
+phone_M2,tt2,,0.00020677588617607918,mean squared sample amplitude,enhanced,union of active frame supports,0.0,candidate diagnostics only,0.0025149672448754727,0.016741174854225986,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,source,0.00020677588617607918,25,250.0,250.0,153,247,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
+studio_F2,tt2,,0.00136423548694805,mean squared sample amplitude,enhanced,union of active frame supports,0.0,candidate diagnostics only,0.0025149672448754727,0.012276785714285716,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,source,0.00136423548694805,25,250.0,250.0,137,207,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
+studio_M2,tt2,,0.00025823544010657173,mean squared sample amplitude,enhanced,union of active frame supports,0.0,candidate diagnostics only,0.0025149672448754727,0.013020929394699838,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,source,0.00025823544010657173,25,250.0,250.0,125,195,energy,Teacher-requested energy-only histogram; 25/10 ms; 250 ms candidate padding retained as 25 hops
 phone_F1,tt3,0.0028777336852328582,0.0028777336852328582,normalized STE,enhanced,union of active frame supports,0.0,none,0.0028777336852328582,0.004316600527849287,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,,,,,,,,,
 phone_M1,tt3,0.0028777336852328582,0.0028777336852328582,normalized STE,enhanced,union of active frame supports,0.0,none,0.0028777336852328582,0.004316600527849287,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,,,,,,,,,
 studio_F1,tt3,0.0028777336852328582,0.0028777336852328582,normalized STE,enhanced,union of active frame supports,0.0,none,0.0028777336852328582,0.004316600527849287,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,,,,,,,,,
 studio_M1,tt3,0.0028777336852328582,0.0028777336852328582,normalized STE,enhanced,union of active frame supports,0.0,none,0.0028777336852328582,0.004316600527849287,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,,,,,,,,,
 phone_F2,tt3,0.0028777336852328582,0.0028777336852328582,normalized STE,enhanced,union of active frame supports,0.0,none,0.0028777336852328582,0.004316600527849287,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,,,,,,,,,
 phone_M2,tt3,0.0028777336852328582,0.0028777336852328582,normalized STE,enhanced,union of active frame supports,0.0,none,0.0028777336852328582,0.004316600527849287,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,,,,,,,,,
 studio_F2,tt3,0.0028777336852328582,0.0028777336852328582,normalized STE,enhanced,union of active frame supports,0.0,none,0.0028777336852328582,0.004316600527849287,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,,,,,,,,,
 studio_M2,tt3,0.0028777336852328582,0.0028777336852328582,normalized STE,enhanced,union of active frame supports,0.0,none,0.0028777336852328582,0.004316600527849287,100.0,200.0,raw STE hysteresis; candidates/debug excluded; no fixed final padding,,,,,,,,,
diff --git a/outputs/endpoint_modes/enhanced/tables/tt2_w_selection/selection.json b/outputs/endpoint_modes/enhanced/tables/tt2_w_selection/selection.json
index 70478f1..4abcd0a 100644
--- a/outputs/endpoint_modes/enhanced/tables/tt2_w_selection/selection.json
+++ b/outputs/endpoint_modes/enhanced/tables/tt2_w_selection/selection.json
@@ -797,12 +797,12 @@
   "evaluation_protocol": "train_final_calibration",
   "selection_rule": "valid regions; minimum worst per-file regret; mean MAE; declared W preference on ties; smallest W otherwise",
   "evaluated_files": [
     "phone_F1",
     "phone_M1",
     "studio_F1",
     "studio_M1"
   ],
   "endpoint_policy": "hysteresis final regions; no fixed final padding",
   "note": "W was calibrated using these TRAIN LABs; TEST has historical exposure and is reused for scoring, so no holdout independence is claimed.",
-  "calibration_digest": "72c661f212a202e564e4546c76425ce4ab20883144fd12d7e0a971ac20c469dd"
+  "calibration_digest": "33a016d798ea363b0079dc61e2b390848a391ad7384847142cb5dedb03684361"
 }
\ No newline at end of file
diff --git a/submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip b/submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip
index 010d37a..7987ec7 100644
Binary files a/submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip and b/submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip differ
diff --git a/tests/test_endpoint_mode_integration.py b/tests/test_endpoint_mode_integration.py
index 958f43d..7b52707 100644
--- a/tests/test_endpoint_mode_integration.py
+++ b/tests/test_endpoint_mode_integration.py
@@ -1,106 +1,140 @@
-import unittest
-from app.cli import parse_args
-from app.pipeline import summarize
-from tools import build_notebooks as builder
-
-class EndpointModeIntegrationTests(unittest.TestCase):
-    def test_cli_modes(self):
-        self.assertEqual(parse_args([]).endpoint_mode, 'enhanced')
-        self.assertTrue(parse_args(['--compare-endpoint-modes']).compare_endpoint_modes)
-        self.assertEqual(parse_args(['--endpoint-mode','core']).endpoint_mode, 'core')
-
-    def test_summary_groups_modes_and_keeps_primary_undefined(self):
-        common=dict(algorithm='tt1',file='a',frame_f1=1.,ground_truth_region_count=1,predicted_region_count=1,mae_ms=2.,rmse_ms=2.)
-        rows=[dict(common,endpoint_mode='enhanced'),dict(common,endpoint_mode='core'),dict(common,file='b',endpoint_mode='core',predicted_region_count=2,mae_ms=None,rmse_ms=None)]
-        summary=summarize(rows)
-        self.assertEqual(len(summary),2)
-        core=next(row for row in summary if row['endpoint_mode']=='core')
-        self.assertIsNone(core['mean_file_mae_ms'])
-        self.assertEqual(core['valid_files_mean_file_mae_ms'],2.)
-        malformed=summarize([dict(common,endpoint_mode='core',predicted_region_count=2)])[0]
-        self.assertIsNone(malformed['mean_file_mae_ms'])
-
-    def test_notebook_locks_both_modes(self):
-        self.assertIn('MODELS',builder.FIT_MODEL)
-        self.assertIn('MODEL_LOCK_DIGESTS',builder.LOCK_MODEL)
-        self.assertIn('ALL_RESULTS_BY_MODE',builder.EVALUATION)
-
-    def test_schema_three_requires_self_excluded_calibration_digest(self):
-        from tools import run_notebooks as runner
-        model=dict(schema_version=3, metrics_schema_version=2, parameter_selection_set='train',
-                   evaluation_protocol='train_selected_reused_test', historical_test_exposure=True,
-                   training_files=list(runner.TRAIN_NAMES), endpoint_mode='core',minimum_speech_ms=0.,
-                   minimum_silence_ms=200.,endpoint_noise=None,boundary_convention='union of active frame supports',
-                   padding_stage='excluded from core FINAL')
-        with self.assertRaisesRegex(ValueError,'calibration digest'):
-            runner.audit_model_protocol(model,runner.model_digest(model))
-
-    def test_weight_sweep_checks_declared_geometry(self):
-        from app.weight_selection import sweep_final_weights
-        model=dict(endpoint_mode='core',boundary_convention='union of active frame supports')
-        def predictor(*args):
-            return dict(metrics=dict(ground_truth_region_count=1,predicted_region_count=1,mae_ms=0.,status='ok',start_error_ms=0.,end_error_ms=0.), diagnostic=dict(endpoint_mode='core',geometry='frame centers',energy_threshold=1.,low_ste_threshold=None,high_ste_threshold=None,raw_speech_frames=1,candidate_regions=[]),final_regions=[])
-        with self.assertRaisesRegex(ValueError,'geometry|boundary_convention'):
-            sweep_final_weights([dict(name='a',split='train')],model,predictor,candidates=(1.,))
-
-    def test_core_plot_uses_native_threshold_with_nullable_low_high(self):
-        import matplotlib.pyplot as plt
-        from app.plotting import _plot_axis
-        record=dict(name='a',samples=[0.,1.,0.],sample_rate=100,duration=.03,
-                    features=dict(centers=[.01,.02],ste_norm=[.5,1.],energy=[2.,4.]))
-        result=dict(diagnostic=dict(endpoint_mode='core',native_threshold=2.,native_threshold_units='sum of squared samples',
-                                    low_ste_threshold=None,high_ste_threshold=None),ground_truth_boundaries=[],predicted_boundaries=[],
-                    metrics=dict(mae_ms=None),final_regions=[])
-        fig,axis=plt.subplots()
-        try:
-            _plot_axis(axis,record,result)
-            labels=[item.get_text() for item in axis.get_legend().get_texts()]
-            self.assertTrue(any('Native T' in label for label in labels))
-            self.assertFalse(any('High STE' in label or 'Low STE' in label for label in labels))
-            self.assertIn('core',axis.get_title())
-            self.assertIn('FINAL-region endpoint MAE',axis.get_title())
-        finally:plt.close(fig)
-
-    def test_cli_locks_every_algorithm_in_both_modes_before_test_read(self):
-        import tempfile
-        from pathlib import Path
-        from unittest.mock import patch
-        from app import pipeline
-        from tests.test_notebook_protocol import tiny_dataset
-        with tempfile.TemporaryDirectory() as temporary:
-            root=Path(temporary); tiny_dataset(root)
-            events=[]
-            real_fit,real_load=pipeline.fit_training_model,pipeline.load_audio_folder
-            def fit(algorithm,records,**kwargs):
-                result=real_fit(algorithm,records,**kwargs)
-                events.append(('fit',algorithm,kwargs['endpoint_mode']))
-                return result
-            def load(folder):
-                if folder==root/'test':
-                    self.assertEqual(set(events),{('fit',algorithm,mode) for algorithm in ('tt1','tt2','tt3') for mode in ('core','enhanced')})
-                return real_load(folder)
-            with patch.multiple(pipeline,TRAIN_DIR=root/'train',TEST_DIR=root/'test',OUTPUT_DIR=root/'outputs'), \
-                 patch.object(pipeline,'fit_training_model',side_effect=fit),patch.object(pipeline,'load_audio_folder',side_effect=load), \
-                 patch.object(pipeline,'make_file_figure',return_value=None),patch.object(pipeline,'plot_gaussian_training'):
-                pipeline.run_experiment(parse_args(['--evaluate-all','--compare-endpoint-modes']))
-            self.assertTrue((root/'outputs/endpoint_modes/comparison/tables/all_metrics.csv').is_file())
-            self.assertFalse((root/'outputs/models').exists())
-
-    def test_default_main_dispatches_once_and_demo_retains_four_test_figures(self):
-        import contextlib,io,tempfile
-        from pathlib import Path
-        from unittest.mock import patch
-        from app import cli,pipeline
-        from tests.test_notebook_protocol import tiny_dataset
-        with patch('matplotlib.use'),patch.object(pipeline,'run_experiment') as run:
-            cli.main([])
-            run.assert_called_once()
-            self.assertEqual(run.call_args.args[0].endpoint_mode,'enhanced')
-        with tempfile.TemporaryDirectory() as temporary:
-            root=Path(temporary);tiny_dataset(root)
-            with patch.multiple(pipeline,TRAIN_DIR=root/'train',TEST_DIR=root/'test',OUTPUT_DIR=root/'outputs'), \
-                 patch.object(pipeline,'make_file_figure',return_value=None),patch.object(pipeline,'plot_gaussian_training'), \
-                 patch.object(pipeline,'show_figures',return_value=[]) as show,contextlib.redirect_stdout(io.StringIO()):
-                pipeline.run_experiment(parse_args([]))
-            show.assert_called_once()
-            self.assertEqual(len(show.call_args.args[0]),4)
+import unittest
+from app.cli import parse_args
+from app.pipeline import summarize
+from tools import build_notebooks as builder
+
+class EndpointModeIntegrationTests(unittest.TestCase):
+    def test_cli_modes(self):
+        self.assertEqual(parse_args([]).endpoint_mode, 'enhanced')
+        self.assertTrue(parse_args(['--compare-endpoint-modes']).compare_endpoint_modes)
+        self.assertEqual(parse_args(['--endpoint-mode','core']).endpoint_mode, 'core')
+
+    def test_summary_groups_modes_and_keeps_primary_undefined(self):
+        common=dict(algorithm='tt1',file='a',frame_f1=1.,ground_truth_region_count=1,predicted_region_count=1,mae_ms=2.,rmse_ms=2.)
+        rows=[dict(common,endpoint_mode='enhanced'),dict(common,endpoint_mode='core'),dict(common,file='b',endpoint_mode='core',predicted_region_count=2,mae_ms=None,rmse_ms=None)]
+        summary=summarize(rows)
+        self.assertEqual(len(summary),2)
+        core=next(row for row in summary if row['endpoint_mode']=='core')
+        self.assertIsNone(core['mean_file_mae_ms'])
+        self.assertEqual(core['valid_files_mean_file_mae_ms'],2.)
+        malformed=summarize([dict(common,endpoint_mode='core',predicted_region_count=2)])[0]
+        self.assertIsNone(malformed['mean_file_mae_ms'])
+
+    def test_notebook_locks_both_modes(self):
+        self.assertIn('MODELS',builder.FIT_MODEL)
+        self.assertIn('MODEL_LOCK_DIGESTS',builder.LOCK_MODEL)
+        self.assertIn('ALL_RESULTS_BY_MODE',builder.EVALUATION)
+
+    def test_schema_three_requires_self_excluded_calibration_digest(self):
+        from tools import run_notebooks as runner
+        model=dict(schema_version=3, metrics_schema_version=2, parameter_selection_set='train',
+                   evaluation_protocol='train_selected_reused_test', historical_test_exposure=True,
+                   training_files=list(runner.TRAIN_NAMES), endpoint_mode='core',minimum_speech_ms=0.,
+                   minimum_silence_ms=200.,endpoint_noise=None,boundary_convention='union of active frame supports',
+                   padding_stage='excluded from core FINAL')
+        with self.assertRaisesRegex(ValueError,'calibration digest'):
+            runner.audit_model_protocol(model,runner.model_digest(model))
+
+    def test_weight_sweep_checks_declared_geometry(self):
+        from app.weight_selection import sweep_final_weights
+        model=dict(endpoint_mode='core',boundary_convention='union of active frame supports')
+        def predictor(*args):
+            return dict(metrics=dict(ground_truth_region_count=1,predicted_region_count=1,mae_ms=0.,status='ok',start_error_ms=0.,end_error_ms=0.), diagnostic=dict(endpoint_mode='core',geometry='frame centers',energy_threshold=1.,low_ste_threshold=None,high_ste_threshold=None,raw_speech_frames=1,candidate_regions=[]),final_regions=[])
+        with self.assertRaisesRegex(ValueError,'geometry|boundary_convention'):
+            sweep_final_weights([dict(name='a',split='train')],model,predictor,candidates=(1.,))
+
+    def test_core_plot_uses_native_threshold_with_nullable_low_high(self):
+        import matplotlib.pyplot as plt
+        from app.plotting import _plot_axis
+        record=dict(name='a',samples=[0.,1.,0.],sample_rate=100,duration=.03,
+                    features=dict(centers=[.01,.02],ste_norm=[.5,1.],energy=[2.,4.]))
+        result=dict(diagnostic=dict(endpoint_mode='core',native_threshold=2.,native_threshold_units='mean squared sample amplitude',
+                                    low_ste_threshold=None,high_ste_threshold=None),ground_truth_boundaries=[],predicted_boundaries=[],
+                    metrics=dict(mae_ms=None),final_regions=[])
+        fig,axis=plt.subplots()
+        try:
+            _plot_axis(axis,record,result)
+            labels=[item.get_text() for item in axis.get_legend().get_texts()]
+            self.assertTrue(any('Native T' in label for label in labels))
+            self.assertFalse(any('High STE' in label or 'Low STE' in label for label in labels))
+            self.assertIn('core',axis.get_title())
+            self.assertEqual(list(fig.axes[1].lines[-1].get_ydata()),[.5,.5])
+            self.assertIn('FINAL-region endpoint MAE',axis.get_title())
+        finally:plt.close(fig)
+
+    def test_cli_locks_every_algorithm_in_both_modes_before_test_read(self):
+        import tempfile
+        from pathlib import Path
+        from unittest.mock import patch
+        from app import pipeline
+        from tests.test_notebook_protocol import tiny_dataset
+        with tempfile.TemporaryDirectory() as temporary:
+            root=Path(temporary); tiny_dataset(root)
+            events=[]
+            real_fit,real_load=pipeline.fit_training_model,pipeline.load_audio_folder
+            def fit(algorithm,records,**kwargs):
+                result=real_fit(algorithm,records,**kwargs)
+                events.append(('fit',algorithm,kwargs['endpoint_mode']))
+                return result
+            def load(folder):
+                if folder==root/'test':
+                    self.assertEqual(set(events),{('fit',algorithm,mode) for algorithm in ('tt1','tt2','tt3') for mode in ('core','enhanced')})
+                return real_load(folder)
+            with patch.multiple(pipeline,TRAIN_DIR=root/'train',TEST_DIR=root/'test',OUTPUT_DIR=root/'outputs'), \
+                 patch.object(pipeline,'fit_training_model',side_effect=fit),patch.object(pipeline,'load_audio_folder',side_effect=load), \
+                 patch.object(pipeline,'make_file_figure',return_value=None),patch.object(pipeline,'plot_gaussian_training'):
+                pipeline.run_experiment(parse_args(['--evaluate-all','--compare-endpoint-modes']))
+            self.assertTrue((root/'outputs/endpoint_modes/comparison/tables/all_metrics.csv').is_file())
+            self.assertFalse((root/'outputs/models').exists())
+
+    def test_default_main_dispatches_once_and_demo_retains_four_test_figures(self):
+        import contextlib,io,tempfile
+        from pathlib import Path
+        from unittest.mock import patch
+        from app import cli,pipeline
+        from tests.test_notebook_protocol import tiny_dataset
+        with patch('matplotlib.use'),patch.object(pipeline,'run_experiment') as run:
+            cli.main([])
+            run.assert_called_once()
+            self.assertEqual(run.call_args.args[0].endpoint_mode,'enhanced')
+        with tempfile.TemporaryDirectory() as temporary:
+            root=Path(temporary);tiny_dataset(root)
+            with patch.multiple(pipeline,TRAIN_DIR=root/'train',TEST_DIR=root/'test',OUTPUT_DIR=root/'outputs'), \
+                 patch.object(pipeline,'make_file_figure',return_value=None),patch.object(pipeline,'plot_gaussian_training'), \
+                 patch.object(pipeline,'show_figures',return_value=[]) as show,contextlib.redirect_stdout(io.StringIO()):
+                pipeline.run_experiment(parse_args([]))
+            show.assert_called_once()
+            self.assertEqual(len(show.call_args.args[0]),4)
+
+    def test_fixed_algorithm_all_dataset_preserves_shared_all_benchmarks(self):
+        import contextlib,csv,io,tempfile
+        from pathlib import Path
+        from unittest.mock import patch
+        from app import pipeline
+        from tests.test_notebook_protocol import tiny_dataset
+        with tempfile.TemporaryDirectory() as temporary:
+            root=Path(temporary);tiny_dataset(root)
+            with patch.multiple(pipeline,TRAIN_DIR=root/'train',TEST_DIR=root/'test',OUTPUT_DIR=root/'outputs'), \
+                 patch.object(pipeline,'make_file_figure',return_value=None),patch.object(pipeline,'plot_gaussian_training'), \
+                 contextlib.redirect_stdout(io.StringIO()):
+                pipeline.run_experiment(parse_args(['--evaluate-all','--compare-endpoint-modes']))
+                sentinels={}
+                for mode in ('core','enhanced'):
+                    target=root/'outputs/endpoint_modes'/mode/'tables/all'
+                    for name in ('test_metrics.csv','summary.csv'):
+                        path=target/name;sentinels[path]=path.read_bytes()
+                for algorithm in ('tt1','tt2','tt3'):
+                    pipeline.run_experiment(parse_args(['--evaluate-all','--compare-endpoint-modes'],fixed_algorithm=algorithm))
+                    for path,original in sentinels.items():
+                        self.assertEqual(path.read_bytes(),original, f'{algorithm} must preserve {path.name} shared benchmark')
+                    for mode in ('core','enhanced'):
+                        path=root/'outputs/endpoint_modes'/mode/'tables'/f'{algorithm}_all_dataset'/'test_metrics.csv'
+                        with path.open(encoding='utf-8-sig') as handle:rows=list(csv.DictReader(handle))
+                        self.assertEqual(len(rows),8)
+                        self.assertEqual({row['algorithm'] for row in rows},{algorithm})
+
+    def test_histogram_metadata_names_mean_squared_energy(self):
+        from app import pipeline
+        features=dict(ste_norm=[0.,.5,1.],energy=[0.,2.,4.],starts=[0.,.01,.02],ends=[.025,.035,.045])
+        _,diagnostic=pipeline.algorithm_decision('tt2',features,dict(bins=1,smooth_radius=0,W=5.,padding_frames=25))
+        self.assertEqual(diagnostic['native_threshold_units'],'mean squared sample amplitude')
diff --git a/tests/test_endpoint_modes.py b/tests/test_endpoint_modes.py
index fabf727..00f4079 100644
--- a/tests/test_endpoint_modes.py
+++ b/tests/test_endpoint_modes.py
@@ -30,21 +30,21 @@ class EndpointModesTests(unittest.TestCase):
                                         dict(threshold=.5,speech_direction=direction))
                 self.assertEqual(mask, want)
                 self.assertEqual(d['native_threshold'], .5)
                 self.assertEqual(d['native_threshold_units'], 'normalized STE')
 
     def test_tt2_native_energy_is_strict_and_excludes_candidate_padding(self):
         mask, d = self.decision('tt2', dict(energy=[0.,2.,4.]),
                                dict(bins=1,smooth_radius=0,W=5.,padding_frames=25))
         self.assertEqual(mask, [0,0,1])  # one peak -> midpoint 2, equality is silence
         self.assertEqual(d['native_threshold'], 2.)
-        self.assertEqual(d['native_threshold_units'], 'sum of squared samples')
+        self.assertEqual(d['native_threshold_units'], 'mean squared sample amplitude')
 
     def test_context_native_decision_uses_normalized_ste(self):
         mask, d = self.decision('tt2-context', dict(ste_norm=[0.,.5,1.]),
                                dict(variant='context',bins=1,smooth_radius=0,W=5.))
         self.assertEqual(mask, [0,0,1])
         self.assertEqual(d['native_threshold_units'], 'normalized STE')
 
     def test_core_support_gap_threshold_keeps_exact_200ms(self):
         # Wrong gap comparator or using frame count would merge the 200ms case.
         for gap, want in ((.19,[(.1,.605)]),(.2,[(.1,.325),(.525,.615)]),
diff --git a/tools/build_notebooks.py b/tools/build_notebooks.py
index e32a7a1..6dd7de4 100644
--- a/tools/build_notebooks.py
+++ b/tools/build_notebooks.py
@@ -501,21 +501,21 @@ def plot_record(record, result):
     mae_text = f"{mae:.2f} ms" if mae is not None else "N/A"
     figure, axes = plt.subplots(2, 1, figsize=(12.5, 5.5), sharex=True,
                                gridspec_kw={"height_ratios": [1, 1.25]})
     time = [index / record["sample_rate"] for index in range(len(record["samples"]))]
     axes[0].plot(time, record["samples"], color="#444444", linewidth=0.6)
     axes[0].set_ylabel("PCM amplitude")
     axes[1].plot(features["centers"], features["ste_norm"], color="#263238",
                  linewidth=1, label="Normalized STE")
     if diagnostic["endpoint_mode"] == "core":
         native = diagnostic["native_threshold"]
-        if diagnostic["native_threshold_units"] == "sum of squared samples":
+        if diagnostic["native_threshold_units"] == "mean squared sample amplitude":
             peak = max(features["energy"], default=0.)
             native = native / peak if peak else 0.
         axes[1].axhline(native, color="#9b6700", linestyle=":", label="Native T (display normalized)")
     else:
         axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060", linestyle="--", label="LOW")
         axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700", linestyle=":", label="HIGH")
     for axis in axes:
         for index, (start, end) in enumerate(result["ground_truth_regions"]):
             axis.axvspan(start, end, color="red", alpha=0.05)
             axis.axvline(start, color="red", linestyle="--", linewidth=1.25,
