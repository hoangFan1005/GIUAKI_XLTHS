from pathlib import Path
p=Path('app/config.py');s=p.read_text(encoding='utf-8-sig');s+='''\n\ndef endpoint_mode_root(endpoint_mode, output_dir=None):
    """Return the isolated production root for a declared endpoint mode."""
    if endpoint_mode not in ('core', 'enhanced', 'comparison'):
        raise ValueError('Unknown endpoint_mode')
    return (OUTPUT_DIR if output_dir is None else Path(output_dir)) / 'endpoint_modes' / endpoint_mode
''';p.write_text(s,encoding='utf-8')
p=Path('app/cli.py');s=p.read_text(encoding='utf-8-sig');s=s.replace('    parser.add_argument("--file",','    parser.add_argument("--endpoint-mode", choices=("enhanced", "core"), default="enhanced", help="enhanced (default): TRAIN noise HIGH/LOW; core: native decisions and support gaps.")\n    parser.add_argument("--compare-endpoint-modes", action="store_true", help="Fit both modes on TRAIN before TEST; export headless comparison.")\n    parser.add_argument("--file",');s=s.replace('    if args.evaluate_all:args.no_show=True','    if args.evaluate_all or args.compare_endpoint_modes:args.no_show=True');p.write_text(s,encoding='utf-8')
p=Path('app/pipeline.py');s=p.read_text(encoding='utf-8-sig');s=s.replace('from app.config import (PROJECT_ROOT','from app.config import endpoint_mode_root\nfrom app.config import (PROJECT_ROOT');s=s.replace('    for algorithm in dict.fromkeys(row["algorithm"] for row in metrics):\n        selected = [row for row in metrics if row["algorithm"] == algorithm]','    for algorithm, mode in dict.fromkeys((row["algorithm"], row.get("endpoint_mode", "enhanced")) for row in metrics):\n        selected = [row for row in metrics if row["algorithm"] == algorithm and row.get("endpoint_mode", "enhanced") == mode]');s=s.replace('rows.append(dict(algorithm=algorithm, metrics_schema_version=2,','rows.append(dict(algorithm=algorithm, endpoint_mode=mode, metrics_schema_version=2,');s=s.replace('mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,','mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,\n                         valid_files_mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,');s=s.replace('mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,','mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,\n                         valid_files_mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,');s=s.replace('pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,','pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count and len(valid)==len(selected) else None,\n                         valid_files_pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,');start=s.index('def run_experiment(args):');body=s[start:];body=body.replace('    models, sweeps = {}, {}\n    for key in selected:\n        models[key], sweeps[key] = fit_training_model(key, train_common)','''    modes = ('core', 'enhanced') if getattr(args, 'compare_endpoint_modes', False) else (getattr(args, 'endpoint_mode', 'enhanced'),)
    locked_models, locked_sweeps = {}, {}
    for mode in modes:
        locked_models[mode], locked_sweeps[mode] = {}, {}
        for key in selected:
            locked_models[mode][key], locked_sweeps[mode][key] = fit_training_model(key, train_common, endpoint_mode=mode)''');split=body.index('    tables = OUTPUT_DIR / "tables"');prefix=body[:split];rest=body[split:];rest=rest.replace('OUTPUT_DIR', 'output_root');rest=rest.replace('write_csv(run_folder / "test_metrics.csv", metric_rows)','all_mode_rows.extend(metric_rows)\n    write_csv(run_folder / "test_metrics.csv", metric_rows)\n    if evaluate_all:\n        write_csv(tables / "all" / "test_metrics.csv", [row for row in metric_rows if row["split"]=="test"])\n        write_csv(tables / "all" / "summary.csv", summarize([row for row in metric_rows if row["split"]=="test"]))');rest=rest.replace('algorithm=key, **result["metrics"]','algorithm=key, endpoint_mode=mode, **result["metrics"]');rest=rest.replace('algorithm=key,\n                                       **{','algorithm=key, endpoint_mode=mode,\n                                       **{');rest=rest.replace('dict(algorithm=args.algorithm, selected=selected,','dict(algorithm=args.algorithm, endpoint_mode=mode, selected=selected,');rest=rest.replace('minimum_speech_ms=MIN_SPEECH_SECONDS*1000,','minimum_speech_ms=0. if mode=="core" else MIN_SPEECH_SECONDS*1000,');rest=rest.replace('boundary_convention="final confirmed regions; union of active frame supports"','boundary_convention="union of active frame supports"');s=s[:start]+prefix+'    all_mode_rows = []\n    for mode in modes:\n        models, sweeps = locked_models[mode], locked_sweeps[mode]\n        output_root = endpoint_mode_root(mode, OUTPUT_DIR)\n'+''.join('    '+line if line.strip() else line for line in rest.splitlines(keepends=True))+'''\n    if len(modes) == 2:
        comparison = endpoint_mode_root('comparison', OUTPUT_DIR) / 'tables'
        write_csv(comparison / 'all_metrics.csv', all_mode_rows)
        write_csv(comparison / 'all_summary.csv', summarize(all_mode_rows))
        test_rows = [row for row in all_mode_rows if row['split']=='test']
        write_csv(comparison / 'test_metrics.csv', test_rows)
        write_csv(comparison / 'test_summary.csv', summarize(test_rows))
''';p.write_text(s,encoding='utf-8')
p=Path('app/plotting.py');s=p.read_text(encoding='utf-8-sig');a=s.index('    # These are the exact thresholds');b=s.index('    energy_axis.set_ylim',a);s=s[:a]+'''    diagnostic = result['diagnostic']
    mode = diagnostic.get('endpoint_mode', 'enhanced')
    threshold_handles = []
    if mode == 'core':
        native = diagnostic['native_threshold']
        if diagnostic['native_threshold_units'] == 'sum of squared samples':
            peak = max(record['features']['energy'], default=0.)
            native = native / peak if peak else 0.
        energy_axis.axhline(native, color='#8E44AD', linestyle='-.', linewidth=1.2)
        threshold_handles.append(Line2D([], [], color='#8E44AD', linestyle='-.', label=f'Native T ({diagnostic.get("native_threshold_units")}): {diagnostic["native_threshold"]:.5g}'))
    else:
        low, high = diagnostic['low_ste_threshold'], diagnostic['high_ste_threshold']
        energy_axis.axhline(high,color='#8E44AD',linestyle='-.',linewidth=1.2)
        energy_axis.axhline(low,color='#148F77',linestyle=':',linewidth=1.2)
        threshold_handles.extend([Line2D([], [], color='#8E44AD',linestyle='-.',label=f'High STE: {high:.5g}'),
                                  Line2D([], [], color='#148F77',linestyle=':',label=f'Low STE: {low:.5g}')])
'''+s[b:];s=s.replace('Outer boundary MAE','FINAL-region endpoint MAE');s=s.replace('{record[\'name\']} | {suffix}',"{record['name']} | {mode} | {suffix}");s=s.replace('                         Line2D([], [], color=\'#8E44AD\',linestyle=\'- .\',label=f\'High STE: {high:.5g}\'),','');a=s.index('    axis.legend(handles=');b=s.index('\n\n\ndef make_file_figure',a);s=s[:a]+'''    axis.legend(handles=[Line2D([], [], color="#555555", label="Waveform"),
                         Line2D([], [], color="#dd8b12", label="Normalized STE"),
                         *threshold_handles,
                         Line2D([], [], color="#d62728", label="Ground truth"),
                         Line2D([], [], color="#1766bd", linestyle="--", label="Prediction")],
                fontsize=8, ncol=3, loc="upper right")
'''+s[b:];p.write_text(s,encoding='utf-8')
