> Historical initial-integration evidence below predates review fix round1. Current AST has two intentional Energy metadata literal changes; see task-5-fix-round1-report.md and current artifact_audit.json. Arithmetic/API AST remains unchanged after normalizing exactly those literals.

# Task 5 integration report — 2026-10-07

Status: READY for root coordinated full-suite/review gate. No staging, commit or push performed.

## Scope and source contracts

Owned changes: app/cli.py, app/config.py, app/pipeline.py (run_experiment, summarize, score export metadata only), app/plotting.py, app/weight_selection.py geometry guard, tools/build_notebooks.py, tools/run_notebooks.py, tests/test_endpoint_mode_integration.py, tests/test_notebook_protocol.py; deliberate CLI path expectations in tests/test_framing.py and tests/test_training_protocol.py. README, notebooks/tools/outputs README and three algorithm explanations updated; algorithms/tt2_histogram.py module prose only.

AST comparison against 47cc00b confirms algorithm_decision, detect_regions and fit_training_model are identical, including every numeric/API node. Source/audio, slides/exporters, canonical legacy outputs, and old Python ZIPs were not modified. Active Task4 files are outside this worker's ownership.

## RED → GREEN and focused evidence

Initial 3 focused tests failed for absent CLI endpoint_mode, summarize combining two modes, and notebook fitting/locking only one model. Reviewer-minor RED separately failed because schema3 absent calibration digest was accepted and geometry disagreement was accepted. Both now reject. Final 68-test focused integration/notebook/weight/framing/training-protocol run passed in 10.837 s. An additional focused default-main/four-demo regression passed with the integration module's 8 tests (1.147 s); total distinct focused tests now 69. No full suite was run by this worker.

CLI flags: enhanced default; core selectable; --compare-endpoint-modes is headless. Both-mode runs lock all requested algorithm/mode TRAIN models before opening TEST (real synthetic loader guard asserts six fits first). Default main still dispatches once and retains four TEST figures. Core plot uses native T and nullable LOW/HIGH; enhanced uses actual LOW/HIGH. Both labels and FINAL-region endpoint MAE are visible.

Summary groups algorithm+endpoint_mode. A count error or undefined file leaves primary mean_file_mae_ms/mean_file_rmse_ms/pooled_endpoint_rmse_ms undefined; valid_files_* aggregate the valid subset separately. Large errors remain in extrema/highest-error files. Metric rows export actual sampled frame/hop timing, sample rounding, boundary convention, minimum speech/silence and padding policy.

## CLI and artifact evidence

Command: .venv/Scripts/python.exe main.py --evaluate-all --compare-endpoint-modes (PYTHONUTF8=1; Agg headless). Completed successfully after final source edits. New roots: outputs/endpoint_modes/core/, enhanced/, comparison/. All model/table/figure/diagnostic/prediction outputs routed through endpoint_mode_root helper. Each mode has24 score rows (8WAV×3algorithms), comparison48rows; separate TEST comparison24rows. TT2 sweep200 TRAIN rows each mode.

Core TEST counts: TT1 3/4, TT2 3/4, TT3 4/4. Primary TEST means: TT1/TT2 undefined; TT3 12.5ms. Enhanced TEST counts all4/4; means TT1 20ms, TT2 13.75ms, TT3 12.5ms. Eight-file core counts: TT1 7/8, TT2 6/8, TT3 8/8. Enhanced eight-file counts all8/8. Core TT1 retains large defined errors (297.5ms phone_M1,242.5ms phone_F1); they are not excluded from valid-only means.

Saved audit: outputs/endpoint_modes/comparison/artifact_audit.json. It confirms unchanged detector/fit AST,24rows/mode,200TRAINsweep/mode, all core LOW/HIGH null, valid sampled timing fields, and enhanced FINAL regions byte-for-value equal to preserved legacy diagnostics for all24file/algorithm cases.

## Notebooks and CODE package

Final tools/build_notebooks.py rebuilt three notebooks after source stabilized. tools/run_notebooks.py executed3fresh kernels with MPLBACKEND cleared. Every notebook audits16/16mode/file results, independently locked models/digests for core+enhanced, and exactly5inlinePNG (4selected enhanced TEST plots+1illustration). TT2 embeds/executes both200-row TRAIN sweeps. Selected-mode aliases are checked against actual corresponding mode evidence; runner recomputes self-excluded schema3 calibration digest and validates full diagnostic/model/result mode agreement against each mode's production files. Ordered code source digest remains separately checked. Independent Restart Kernel → Run All → Save workflow retained.

Final --validate-only passed all3saved outputs and recreated CODE ZIP. submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip contains exactly3ipynb entries, each byteequal to saved executed notebook. No audio payload/file packaged. Root must not rewrite notebook bytes after this package check without repackaging.

## Documentation and limitations

reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md includes all48rows and distinct four-TEST/eight-WAV summary tables. Guides explicitly label old numeric HIGH/LOW examples as enhanced, retain historical slide explanations/previous-version warning, and preserve historical_test_exposure=true. Core is native decision baseline; enhanced is project policy. Gaussian remains an approximation under the assignment; no gamma/lognormal fit and no sigma-only claim that T3>T1. No per-recording mode choice and no promised core improvement.

EOL matches repository index for owned sources: LF where prior Task2/3 source index isLF; original CRLF README/CLI/plotting/notebooks preserved. outputsREADME mixed endings preserved for unchanged lines. git -c core.whitespace=cr-at-eol diff --check passed (default diff --check treats existing CRLF as trailing whitespace and can dump notebook base64). No Git configuration changed.

Workspace helper refresh rejected default exec; approved continuing reads/writes/CLI/kernel operations used require_escalated. Temporary edit/audit scripts reside only under task scratch .superpowers/sdd/2026-10-07-algorithm-baseline-and-endpoint-review/ (not submission).
