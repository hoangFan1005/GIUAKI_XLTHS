# Task 5 review fixes round 1 — ready for scoped re-review

Reviewed task-5-review.md P2 and applied receiving-code-review guidance. No subagents, stage, commit, push or full-suite run.

## RED/GREEN

Three focused RED checks failed as intended: fixed TT1 all-dataset replaced shared all/test_metrics.csv, native Energy units said sum-of-squares, and core plot with the corrected unit fixture drew native T=2 instead of normalized T/peak=0.5. The production correction uses `if evaluate_all and {"tt1", "tt2", "tt3"}.issubset(selected)` for the shared TEST projection. The fixed run's own `<algorithm>_all_dataset` files continue to contain its eight results.

Regression starts with a full both-mode all-dataset run, preserves byte sentinels for both modes' shared tables/all/test_metrics.csv and summary.csv, then runs each fixed TT1/TT2/TT3 all-dataset CLI selection and asserts every sentinel unchanged. It also checks each algorithm's own eight-row output. GREEN: 43 focused tests (integration, endpoint modes, notebook protocol, weight selection) passed in4.624s.

## Energy units: narrow exact delta

Energy math remains STE/frame_size (mean squared amplitude). `algorithm_decision.native_threshold_units` changed only its descriptive literal from `sum of squared samples` to `mean squared sample amplitude`. `fit_training_model.feature_rule` changed only its descriptive literal from `Energy (sum of squared samples)` to `Energy (mean squared sample amplitude)`. App and standalone notebook core plot guards and fixtures consume the corrected string; T still divides by the recording's peak Energy only for display on normalized STE. The focused plot assertion verifies nativeT2/peak4 draws0.5. Production comment now explicitly qualifies enhanced HIGH/LOW.

Complete AST equality is intentionally false for algorithm_decision and fit_training_model because of those two metadata strings. After only those exact string substitutions in baseline47cc00b, full function ASTs match current algorithm_decision/detect_regions/fit_training_model. detect_regions remains fully AST-identical. No arithmetic, threshold, masks, policy, timing or function API nodes changed.

## Fresh artifacts and invariance

After source fixes: `main.py --evaluate-all --compare-endpoint-modes` completed, rebuild3notebooks completed, tools/run_notebooks.py executed3fresh kernels with MPLBACKEND cleared. Each notebook audited16/16mode/file results and exactly5PNG; TT2 eachmode TRAIN200rows. Model/source digests were freshly computed. Final --validate-only passed3saved notebooks and recreated CODE ZIP with exactly3byteequal notebooks.

Updated outputs/endpoint_modes/comparison/artifact_audit.json includes exact metadata delta, normalized AST preservation, numeric regression checks, and touched source/model/notebook/ZIP SHA256 values. Against the before-fix snapshot, both modes'24prediction CSVs are byteequal and24metrics/status row CSVs byteequal; all24diagnostics/mode differ only by the allowed Energy unit label. All24enhanced FINAL regions still match preserved canonical legacy diagnostics. New metadata/digests occur in TT2 models/manifests/threshold diagnostics; core PNG legends now show correct units. No canonical historical outputs, Source/audio, slides, or legacy ZIP changes appear in the scoped Git diff.

Touched source/fixture files: app/pipeline.py, app/plotting.py, tools/build_notebooks.py, tests/test_endpoint_mode_integration.py, tests/test_endpoint_modes.py. Generated notebooks, CODE ZIP and isolated mode metadata/figures/audit refreshed. git -c core.whitespace=cr-at-eol diff --check passes; existing file EOL preserved.
