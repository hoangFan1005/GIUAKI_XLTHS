# SDD ledger — plan: docs/superpowers/plans/2026-10-07-algorithm-baseline-and-endpoint-review.md

## Execution authorization and backup

User approved implementation on 2026-10-07, requiring current state pushed first to a separate backup branch, then edits directly in local checkout. Slides remain excluded.
Backup: codex/backup-before-endpoint-modes-20261007, commit 5ceb289c51079d53b977f5316bcc70971d119c47. Remote ls-remote matches local commit. Local working branch: codex/endpoint-modes, same checkout H:/GIUAKI_XLTHS.
Baseline full suite: 133 tests in 10.719s, OK. No worktree created because user explicitly requested in-place local edits. No further push of implementation requested.
Spec reachable in Source/assignment; external critique is review evidence rather than authoritative assignment text. Plan inspected for shared interfaces before dispatch.

## Preflight table

| Tasks | Producer / consumer | Resolution |
| --- | --- | --- |
| 1 | baseline vs prose fixes | Capture existing models and all 24 predictions before code edits; README corrections cannot change numeric results. |
| 2 | raw mask vs FINAL policy | Preserve enhanced padded candidate diagnostics; core uses unpadded TT2 native Energy decisions. Equality stays algorithm-specific. |
| 3 | schema-v3 models vs legacy | Fresh mode metadata; legacy schema1/2 resolves enhanced with old numeric params and provenance. |
| 4 | experimental cells vs physical silence | Characterize errors honestly; do not install experimental timing or LOW in default pipeline. |
| 5 | CLI/plots/notebooks vs mode models | Core LOW/HIGH/noise are null; all consumers handle nullable fields. Notebook locks both mode models before TEST. |
| 6 | reported results vs exact regression | Compare enhanced numeric masks/endpoints/metrics/status, allowing intentional schema metadata changes. |
| 2 + 3 | detect_regions / fit_training_model in pipeline | Sequential file ownership; mode from model, native decision helper reused. |
| 2 + 5 | core diagnostic nullable thresholds / plot and audit | Pass explicit contracts to Task5; do not create fake LOW/HIGH. |
| 3 + 4 | mode-specific W / experiment W | Experiment recalibrates W for each branch on 3 fit TRAIN files per fold. |
| 3 + 5 | model3 / notebook source & lock auditor | Rebuild standalone copies only after mode fitting interface stabilizes. |
| 1 + 5 + 6 | shared README/current report | Sequential ownership; preserve historical acceptance reports. |
| 2 + 4 | tests of support vs experimental cell gap | Different modules and semantics; current support exact200 rule retained. |

## Tasks

- Task 1: complete (baseline + stale README, c7f1b0e)
- Task 2: complete (core/enhanced decisions, 116384e)
- Task 3: review in progress (47cc00b)
- Task 4: pending (TRAIN timing research, no default change)
- Task 5: pending (CLI, figures, notebooks, docs)
- Task 6: pending (regression, final review, report)

## Notes / rulings

Preflight confirmed zero-audio assertions must use valid positive/high fitted TRAIN models; an artificial threshold0 or inverted low-direction model need not classify zero as silence under the native algorithm.
Use PowerShell equivalents for SDD brief/workspace helpers: bash parser expects 'Task 1' whereas approved plan headings are 'Task1'. Same scoped workspace, identity marker and self-ignore are retained.

Task 1: complete (commits 5ceb289..c7f1b0e, review clean). Independent reviewer verified models/cases/results/digest/hash preservation. Fullsuite137/137 in11.152s. Baseline artifact: outputs/tables/endpoint_modes_oct07/baseline.json. Task2 authorized minimal standalone generator bridge only if actual helper dependency fails intermediate suite; generated notebooks remain Task5.
Task 2: in progress. BASE=c7f1b0e1cb9a650d80e52c3ab2de19d61249efa2.
Task 2: complete (commits c7f1b0e..116384e, review clean for spec and quality; minor prose follow-up assigned Task5). Fullsuite147/147 in11.845s; focused41; generated5. 24 enhanced masks/FINAL/metrics/status/old diagnostics exact. Minor: generated comments imply core requires noise/rejects lowTT3; Task5 must qualify enhanced-only.
Task 3: in progress. BASE=116384e31a8027926cdc1131dc79d85bedd682bd.

Resume 2026-10-07: agent registry reset after user continue, prior Task3 source/report persisted. Root reran153tests11.470s OK and committed47cc00b. Prior completedTasks1/2 not repeated. Sandbox default exec helper fails setup refresh; require_escalated works for authorized operations. Task3 reviewer dispatched against116384e..47cc00b.
Task 3: complete (commits116384e..47cc00b, specPASS/qualityPASS with two minor follow-ups). Root fresh153tests11.470s;24fresh enhanced numeric cases exact. Minor assignedTask5: schema3 missing calibration_digest rejected; calibration predictor boundary_convention must agree with diagnostic geometry.
Task 4: in progress. BASE=47cc00b. Preflight timing matrix task-4-preflight.md:76held-out rows and3600TT2 branch calibration scores, noTEST/default changes.
Ruling: run Task4 research and Task5 integration concurrently with disjoint file ownership and root-controlled commit/full-suite gates — the approved design states timing research does not block core/enhanced integration, and current native/model interfaces are stable. Task4 owns decision_timing, check_endpoint_robustness, focusedtests, researchoutputs; Task5 owns appCLI/config/run_experiment/summary/plotting, notebooktools/docs and geometry audit guard. Neither changes production native/model arithmetic. Cost if interface drift occurs: focused integration fixes and rerun complete regression; no production timing/default changes authorized. Fullsuite will run after both worktrees sources stabilize; agents must not stage/commit concurrently.
Task 5: in progress. BASE47cc00b, parallel research does not enter production defaults.
Task 4: implementation27dc471, scoped21tests pass4.145s and diffcheck clean; independent review in progress. Global suite/24/protected gates belong coordinatedTask6.
Task 4: complete (47cc00b..27dc471 plus9227b1d provenancefix; specPASS/qualityAPPROVE scopedrereview). P3 row-to-model lookup addressed19configs/1216rows/7CSVunchanged; root22focused4.107s. Task6 still owns globalgates.
Task 5: fix round1 in progress; reviewed27dc471..b38d640 specPASS/qualityREQUESTCHANGES for P2 shared all TEST table overwritten by singlealgorithm evaluate_all. Root visual15notebook +3core PNG found additional unitslabel: Energy=STE/N but metadata sayssum. Authorized exactstringmetadata correction and matchingplotguard, noarithmetic changes; models/digests/notebooks/ZIP regenerated afterward. Full171tests14.812s andfresh24exact/48score audits are PRE-FIX, finalgate must rerun afterSTABLE.
Task 5: fix round1 committedc5e82dd; rootfreshnotebook --validate-only3PASS, scopedrereviewpending. Task6secondSTABLEfresh173tests15.200sPASS/all48/enhanced24exact/124protected/noarithchanges(exact2metadataliterals)/3notebookZIPPASS. Rootvisual15notebook+3corefigures+correctedTT2legend inspected.
Task 5: complete (27dc471..b38d640 plus c5e82dd fixround1; scoped rereview specPASS/qualityAPPROVE). All3deferredminors addressed, P2writer fixed, units corrected with exact2metadata-onlyASTallowlist. Task6fresh173/full48/enhanced24/protected124/notebookZIP allPASS.
Task 6: implementationd6b616c, fresh173test15.200s/numericartifactgatesPASS; final broadreview in progress. Scratch archive/visualnotes/cleanup afterreview only.
Resume after user continue: finalreview recovered without rerunning prior checks, final-review.md saved. Final broadreview numericPASS/qualityREQUESTCHANGES: comparisonwriter overwrites sharedbenchmark on partialscopes; currententrydocs stale;3guideCSVlinks absent; inheriteddatasetstatsduplicate follow-up. ONEfinalfixagent final_fix_oct07 dispatched, BASEd6b616c.
Ruling: single-file dataset_statistics contains only the evaluated source WAV in its scoped run, while full mode statistics and training_frames retain TRAIN context — this makes the single-file export match the requested inspection scope and avoids repeated training records — cost if wrong: a reader expecting TRAIN+target must also open the unchanged full statistics/training_frames; detector/calibration unchanged.
Final broadreviewfixwavecomplete: d6b616c..7271fb2 scoped specPASS/qualityAPPROVE; all4findings addressed, no newbreakage, no parkedfinding. Rootfastpostcommitacceptance24enhancedexact/48score/124protected PASS1.4751575s; sourcefullsuite177PASS19.208s unchanged since gate. Final review/visual/rulings saved to permanentreport and verification archive next; safe ownedworkspace cleanup after exact archiveSHA verification.
