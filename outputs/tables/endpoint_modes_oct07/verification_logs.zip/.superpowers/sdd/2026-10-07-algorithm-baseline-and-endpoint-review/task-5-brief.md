### Task5 — Chạy hai mode, bảng/figure và notebook đồng bộ

**Files:** sửa `app/cli.py`, `app/pipeline.py`, `app/plotting.py`, `tools/build_notebooks.py`, `tools/run_notebooks.py`, các README/hướng dẫn3 thuật toán và `tests/test_notebook_protocol.py`. Main1/2/3 giữ riêng. Output mới dưới thư mục mode, không ghi đè evidence/legacy outputs cũ; cập nhật CODE ZIP sau fresh execution.

**Interfaces:** CLI `--endpoint-mode {enhanced,core}`, defaultenhanced; thêm `--compare-endpoint-modes` xuất bảng headless2 modes, fit tất cả TRAIN trước đọc TEST. Notebook giữ một config mode chọn4 figure; tính/khóa `MODELS={'core':..., 'enhanced':...}` trước TEST, lưu model digests theo mode và source digest chung.

- [ ] Viết RED: đường chạy mặc định vẫn 4 figure/một main call; figure metric FINAL của mode chọn; core plot Tnative và không giả vờ HIGH/LOW quyết định; enhanced plot HIGH/LOW thực.
- [ ] Bảng gồm filename/split/algorithm/mode/GT-count/pred-count/START/END/primaryMAE/RMSE/status và các trường timing/filter/padding đã khóa; summarize group theo algorithm+mode, không gom hai mode thành một mean. Core LOW/HIGH null phải được export/audit đúng và không vẽ như threshold có tham gia detector.
- [ ] Report so sánh bốn TEST riêng, támWAV riêng; raw/core và enhanced không gọi cùng là thuật toán gốc. Dùng `FINAL-region endpoint MAE` nếu muốn làm rõ nhiều regions; metric chính vẫn không bỏ lỗi lớn.
- [ ] Notebook mỗi sinh viên chứa code riêng, bảng 8 WAV/mode, so sánh 4 TEST và threshold diagnostics; mỗi mode TT2 có 200 TRAIN rows. Generator phải nhúng cả `algorithm_decision` và các helper core được Task2 thêm vào, không chỉ ba hàm pipeline cũ. Giữ 4 TEST plots + 1 illustration của mode được chọn; runner kiểm tra models/mode/sweep/metrics/source digests đúng mode. RunAllSave độc lập vẫn được.
- [ ] Rebuild→ba kernel mới→validate savedoutputs→ZIP exact3 notebooks byteequal. Lưu24 kết quả/mode (48 cho2 modes); diễn giải Gaussian là xấp xỉ theo đề, không chuyển fit sang gamma/lognormal. T1/T3 objectives khác nhau, không gán T3>T1 cho sigma đơn lẻ.

### Global Constraints

- Giữ3 thuật toán, Python tự tính; TT2 chỉ Energy, không F0/Centroid, không thêm ZCR/thuật toán thứ 4.
- Analysis frame 25 ms, hop 10 ms, nearest samples/ties-to-even; Fs44.1k dùng1102/441samples, thời gian thực được báo cáo.
- Minimum internal silence 200 ms; exact estimated200 ms phải giữ, <200 ms mới nối. Silence đầu/cuối không ép kéo dài200 ms.
- Mỗi FINAL speech region có START/END; không candidate/debug trong primary figure/MAE.
- TRAIN chọn tham số và khóa model trước mở TEST; target LAB chỉ dùng scoring/plot. Không rule filename, GT snapping, TEST tuning hoặc bỏ lỗi lớn.
- Giữ `historical_test_exposure=true`; legacy TEST-calibrated model phải giữ provenance cũ. Đổi protocol không tạo holdout độc lập.
- Metric schema 2 tiếp tục `mae_ms`/`rmse_ms`; thiếu/thừa vùng làm primary undefined, không dùng mean subset thay mean đầy đủ.
- Không sửa slides/PPTX/PDF, dữ liệu Source/audio hoặc ZIP Python cũ. CODE notebook ZIP được cập nhật khi source notebook thay đổi.
- Không hứa MAE core thấp hơn enhanced hoặc timestamp mới làm mọi file tốt lên.



Integration contract: route all newly generated production outputs consistently to outputs/endpoint_modes/<endpoint_mode>/ (models/tables/figures/diagnostics/predictions). Both enhanced and core must use this new root; legacy canonical outputs remain historical and are not overwritten. Compare mode root is outputs/endpoint_modes/comparison/. Centralize a mode-root helper for CLI and runner. Existing slide exporter/package tools continue consuming preserved legacy schema2 files; do not modify slide builders/exporters or regenerate legacy Python ZIPs. Notebook auditor validates actual notebook models/digests against the new mode files, not synthesized pre-TEST lock evidence. Model mode indexes and result mode must agree. Preserve MODE=enhanced default with selected-mode aliases for demo and five image cells. Assertions using old CLI output locations need deliberate updated expectations.

Documentation audit: introductory/docstring claims such as algorithms/tt2_histogram.py 'FINAL endpoints use raw STE hysteresis' become mode-specific after core is added. You may update strictly prose-only headers/docstrings in algorithm files if needed to avoid stale claims, preserving all calculation AST/numeric functions. Preserve previous-version/historical slide explanations; do not claim slide parity. Reader must see defaultenhanced vs core labels clearly in plots/reports/main help. Record results for both modes rather than selecting a better mode per recording.
Task2 reviewer minor follow-up: generated stage comments currently imply all modes require noise/reject low TT3. Qualify enhanced-only and explain core native direction, keeping numerical AST unchanged.

Task3 reviewer minors to resolve during Task5 integration: tools/run_notebooks.py:117 currently accepts absent model and manifest calibration_digest because None==None; fresh schema3 must require nonempty valid digests and recompute/check the declared self-excluded calibration digest. app/weight_selection.py:95-99 checks mode/filter/padding agreement but not boundary_convention against diagnostic geometry; add consistent comparison and focused RED/GREEN test (source+standalone helper bridge if needed). Preserve legacy schema2 fixtures. Task4 experimental branches must declare matching geometry; do not infer geometry from file-specific errors.

Concurrency contract: Task4 is implementing only core/decision_timing.py, tools/check_endpoint_robustness.py, tests/test_decision_timing.py and endpoint robustness tests, with outputs/tables/endpoint_modes_oct07/timing_research/. Do not edit these files or read TEST from research. You own Task5 app/CLI/config/run_experiment/summary/plotting/notebooktools/documentation and weight geometry-audit minor. Do not alter native algorithm_decision/detect_regions/fit_training_model arithmetic or APIs. Fit/detect modes are stable at47cc00b. Run focused tests while other implementation active; request root stable fullsuite/commit gate before broad test/commit. No stage/commit until root coordinates. Fresh kernels/artifacts needed after your sources settle. Prior ENV caution: clear MPLBACKEND before notebook execution for inline PNGs; Agg only CLI/headless tests. New mode roots consistent all artifacts and auditor.
