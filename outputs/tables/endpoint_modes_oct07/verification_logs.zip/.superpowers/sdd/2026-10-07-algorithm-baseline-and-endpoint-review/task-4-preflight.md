# Task 4 preflight (read-only preparation)

Sources read: task-4-brief.md; tools/check_endpoint_robustness.py; core/endpoints.py; core/postprocess.py; core/features.py; stable algorithm_decision/detect_regions in app/pipeline.py; core/metrics.py; app/weight_selection.py.
No tests/probes run; no source/model/output/git edits.

## Small declared matrix

Use six common trial configurations, each evaluated for TT1/TT2/TT3:
| trial_id | endpoint_mode | geometry | min speech ms | LOW |
| --- | --- | --- | --- | --- |
| core_support_0 | core | support | 0 | native decisions |
| core_cells_0 | core | centered cells | 0 | native decisions |
| core_support_100 | core | support | 100 | native decisions |
| enhanced_support_100 | enhanced | support | 100 | existing endpoint_thresholds |
| enhanced_cells_100 | enhanced | centered cells | 100 | existing endpoint_thresholds |
| enhanced_support_0 | enhanced | support | 0 | existing endpoint_thresholds |

Add one TT1-only trial: enhanced_tt1_t1_support_100, LOW=T1, HIGH=max(1.5*T1, noise_upper).
Compare each alternate with its same-mode support baseline. This is one factor at a time, not all combinations. Total: 76 held-out rows across four folds (72 common + 4 TT1 LOW).
If fitted T1=0 produces invalid hysteresis thresholds, expose unsupported trial status explicitly; do not silently floor LOW and describe it as LOW=T1.

## Fold protocol and W

1. Load/prepare only TRAIN; require_train already checks split/path. Assert exactly four distinct TRAIN records. Fix deterministic fold ordering. Never call resolve_input, main/evaluate-all, or load TEST.
2. For each held-out file, fit native TT1/T3/noise only on the other three. Task 3's proposed fit_training_model(..., endpoint_mode=mode) must be called explicitly for each mode; do not assume its current two-argument signature or implicit enhanced default. Share native fit/noise within a fold when semantically compatible; preserve TT3 mode-specific direction rules.
3. Build one explicit diagnostic branch predictor from algorithm_decision plus branch geometry/cleanup/filter. Native TT2 must use only unpadded Energy decisions; padding stays candidate diagnostics. It must return metrics and diagnostic fields expected by sweep_final_weights (or use a compact local sweep adapter).
4. For EACH of the six TT2 branches and each fold, sweep all W=1..50 on its three fit records using that exact branch predictor, geometry, min speech, mode, and region_endpoint_metrics. Reuse select_final_weight: invalid-region count, worst per-file regret, valid mean MAE, declared W=20 tie preference, then smallest W. If fit_training_model made a support sweep, mark its W preliminary and replace it with this branch-specific selection.
5. Freeze a separate copy of params with W/finalW matching the branch selection; score the held-out TRAIN record once with the same predictor. Do not carry support-enhanced W or selection provenance into cells/core. No W is selected using held-out results.
6. Put every evidence artifact beneath outputs/tables/endpoint_modes_oct07/timing_research/. Manifest records trial_id, fold, three fit files and held-out file, input/model hashes, geometry, mode, LOW rule, filters, W candidates/selection rule, chosen W, selection scorer and branch predictor identity. Preserve historical_test_exposure=true. Candidate sweep arrays belong in separate tables, not repeated in each held-out row.

TT2 budget: 4 folds x 6 branches x 50 W x 3 fit files = 3600 branch evaluations, plus 24 held-out TT2 scores. This is bounded; avoid recomputing feature extraction/TT1/T3 fits per candidate.

## Geometry and membership traps

- decision_cells(features, duration): internal edge i is (center[i-1]+center[i])/2; edges[0]=0, edges[-1]=duration. Return (edges[:-1], edges[1:]); zero frames -> ([],[]), one frame -> ([0],[duration]). Validate finite/ordered centers and positive cells; no feature or frame support mutation.
- Derive from actual centers/sample-rounded hop. Fs=44100 has N=1102, H=441, so frame=24.988662...ms and hop=10ms; never hard-code 25ms offsets. Midpoint decisions may fall on half samples; no extra sample rounding was specified.
- Analysis still uses full N-sample windows and drops incomplete tail frames. Outer nearest-frame cells extend the first/last decision to 0/duration, including unanalysed short tail; disclose that convention and test it.
- Use the selected geometry for START, END, internal gap, merged span filter, final mask membership, and diagnostic last-active END. Subtracting 15ms from END only is inconsistent; jH is not frame j END.
- Existing hysteresis_regions accepts supplied starts/ends; a cells branch can pass cell boundaries. Existing mask_segments/fill_short_internal_silences can likewise use cell boundaries; their first-start=0 validator then remains satisfied.
- For cell FINAL regions use whole-cell containment with cell starts/ends (or equivalent half-open center membership justified by cells-aligned endpoints). Never call regions_to_mask(final, original 25ms starts/ends) for cells. Center LAB labels remain the unchanged scoring reference.
- Exact estimated 200ms gap is retained with existing 1e-12 tolerance; estimated 190 merges and 210 remains. Silence at edges is not subjected to an internal 200ms rule.
- Keep production detect_regions/default geometry untouched. Baseline enhanced_support_100 and core_support_0 should numerically reproduce current same-mode FINAL regions/mask using identical fitted params.

## Independent-oracle checks for implementer

- Hand-author expected midpoint edges and expected FINAL/masks, including multiple regions at both Fs, clipping, empty/one frame, audio edges and short tails. Do not generate expected cells by calling decision_cells or compute expected regions via hysteresis_regions itself.
- Isolate estimated-gap rule using constructed timing/value arrays with 190/200/210ms decision gaps. At 44.1k distinguish exact abstract 200ms from rounded physical sample durations; disclose actual duration.
- Preserve integer sample-overlap oracle for rectangular STE. Independently derive cell endpoints from literal sample centers; LOW uses >=, TT2 native Energy seeds use >, and HIGH requires the native seed.
- Characterize the existing 48 physical-gap waveforms (two Fs, six phases, 190/200/210/250ms) with fixed LOW=.1/HIGH=.5 separately from each declared core/enhanced production mode using valid locked TRAIN models. A four-TRAIN fit is acceptable for synthetic characterization only and must be labeled distinct from fold models.
- Add physical bursts 75/95/100/105ms, edge speech and weak tails. Keep physical duration characterization separate from constructed estimated span duration-rule assertions. Cells do not guarantee true physical 200ms silence preservation; never repair the 24 known physical200/210 support failures by changing GT or threshold.
- Existing waveform support_gap_ms derives oracle LOW support regions. In cells diagnostics derive the cell LOW gap independently and name it estimated_cell_gap_ms; do not relabel the support gap.

## Reporting

Retain per-region signed START/END errors (signed_endpoint_errors_ms + region_pairs), region counts/missing/extra/status, primary mae_ms/rmse_ms, and clearly named valid-only summaries. For multiple regions the single-region start_error_ms/end_error_ms fields are None; do not treat them as missing evidence.
Full means are undefined when a fold has a region mismatch; never substitute matched-boundary or valid subset mean. Distinguish mean-file RMSE from pooled-boundary RMSE.
Report every alternate vs matching same-mode support fold, including count regressions and metric regressions; undefined-vs-valid transitions need explicit status. Evidence supports a recommendation only; no TEST-based convention choice or automatic production update.

