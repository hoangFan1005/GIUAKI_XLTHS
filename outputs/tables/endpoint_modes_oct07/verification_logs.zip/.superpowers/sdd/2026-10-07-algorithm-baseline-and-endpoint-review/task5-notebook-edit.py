from pathlib import Path
p=Path('tools/build_notebooks.py');s=p.read_text(encoding='utf-8-sig')
s=s.replace('ALGORITHM = {algorithm!r}','ALGORITHM = {algorithm!r}\nMODE = "enhanced"  # selected mode for the four plots and illustration')
s=s.replace('MODEL, TT2W_SWEP_ROWS = fit_training_model(ALGORITHM, TRAIN_RECORDS)','xxx') if False else s
s=s.replace('MODEL, TT2W_SWEEP_ROWS = fit_training_model(ALGORITHM, TRAIN_RECORDS)','''MODELS, TT2W_SWEEPS = {}, {}
for endpoint_mode in ("core", "enhanced"):
    MODELS[endpoint_mode], TT2W_SWEEPS[endpoint_mode] = fit_training_model(
        ALGORITHM, TRAIN_RECORDS, endpoint_mode=endpoint_mode)
MODEL, TT2W_SWEEP_ROWS = MODELS[MODE], TT2W_SWEEPS[MODE]''')
s=s.replace('MODEL_LOCK_DIGEST = model_digest(MODEL)','MODEL_LOCK_DIGESTS = {mode: model_digest(model) for mode, model in MODELS.items()}\nMODEL_LOCK_DIGEST = MODEL_LOCK_DIGESTS[MODE]')
s=s.replace('    if model_digest(MODEL) != MODEL_LOCK_DIGEST:\n        raise ValueError("Frozen TRAIN model digest changed after calibration")','''    for mode, model in MODELS.items():
        if model.get("endpoint_mode") != mode or model_digest(model) != MODEL_LOCK_DIGESTS[mode]:
            raise ValueError("Frozen TRAIN model digest or mode changed after calibration")
    if MODEL is not MODELS[MODE] or model_digest(MODEL) != MODEL_LOCK_DIGEST:
        raise ValueError("Selected model alias changed after calibration")''')
s=s.replace('for key, value in MODEL["endpoint_noise"].items()', 'for key, value in (MODEL["endpoint_noise"] or {}).items()')
a=s.index('TEST_RESULTS = [predict_and_score');b=s.index('METRIC_COLUMNS = [',a)
s=s[:a]+'''TEST_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in TEST_RECORDS]
                        for mode, model in MODELS.items()}
assert_model_locked()
ALL_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in ALL_RECORDS]
                       for mode, model in MODELS.items()}
assert_model_locked()
TEST_RESULTS, ALL_RESULTS = TEST_RESULTS_BY_MODE[MODE], ALL_RESULTS_BY_MODE[MODE]

def metric_rows(records, results):
    return [dict(file=record["name"], split=record["split"], algorithm=ALGORITHM,
                 endpoint_mode=result["diagnostic"]["endpoint_mode"], **result["metrics"])
            for record, result in zip(records, results)]

TEST_METRICS_BY_MODE = {mode: metric_rows(TEST_RECORDS, results) for mode, results in TEST_RESULTS_BY_MODE.items()}
ALL_METRICS_BY_MODE = {mode: metric_rows(ALL_RECORDS, results) for mode, results in ALL_RESULTS_BY_MODE.items()}
TEST_SUMMARIES_BY_MODE = {mode: summarize(rows) for mode, rows in TEST_METRICS_BY_MODE.items()}
TEST_METRIC_ROWS = [row for rows in TEST_METRICS_BY_MODE.values() for row in rows]
ALL_METRIC_ROWS = [row for rows in ALL_METRICS_BY_MODE.values() for row in rows]
TEST_SUMMARY = TEST_SUMMARIES_BY_MODE[MODE]
'''+s[b:]
s=s.replace('("file", "File"), ("split", "Split"),','("file", "File"), ("split", "Split"), ("endpoint_mode", "Mode"),')
s=s.replace('display_table(TEST_SUMMARY,','display_table([row for rows in TEST_SUMMARIES_BY_MODE.values() for row in rows],')
s=s.replace('[("algorithm", "Algorithm"), ("files", "Files"),','[("algorithm", "Algorithm"), ("endpoint_mode", "Mode"), ("files", "Files"),')
a=s.index('    axes[1].axhline(diagnostic["low_ste_threshold"]');b=s.index('    for axis in axes:',a)
s=s[:a]+'''    if diagnostic["endpoint_mode"] == "core":
        native = diagnostic["native_threshold"]
        if diagnostic["native_threshold_units"] == "sum of squared samples":
            peak = max(features["energy"], default=0.)
            native = native / peak if peak else 0.
        axes[1].axhline(native, color="#9b6700", linestyle=":", label="Native T (display normalized)")
    else:
        axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060", linestyle="--", label="LOW")
        axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700", linestyle=":", label="HIGH")
'''+s[b:]
s=s.replace('Outer boundary MAE:', '{MODE} | FINAL-region endpoint MAE:')
s=s.replace('FINAL rejects explicit low/unknown models.', 'enhanced FINAL rejects low/unknown models; core retains native high/low direction.')
s=s.replace("' Require TRAIN noise before inference.'", "' Enhanced requires TRAIN noise; core uses native decisions.'")
s=s.replace('reject a non-high model before FINAL reuse.', 'enhanced rejects non-high models; core preserves native direction.')
s=s.replace('Final regions require HIGH confirmation and continue above LOW.', 'Default MODE=enhanced requires HIGH confirmation and continuation above LOW. Core uses native decisions without HIGH/LOW, final padding or duration filtering.')
s=s.replace('The noise floor is estimated from TRAIN silence only. HIGH confirms speech;', 'In enhanced mode the noise floor is estimated from TRAIN silence only. Core uses native decisions and merges internal support gaps below 200 ms. Enhanced HIGH confirms speech;')
s=s.replace('LOW/HIGH are the actual final confirmation thresholds.', 'Enhanced LOW/HIGH are actual confirmation thresholds; core plots native T and exports LOW/HIGH as null.')
s=s.replace('Schema 2 uses', 'Schema 3 model policy with schema 2 metrics uses')
# Display both TT2 calibration manifests, then retain selected aliases.
a=s.index('    code(CALIBRATE_W)');s=s[:a]+s[a:].replace('    code(CALIBRATE_W)','    code("for mode in (\"core\", \"enhanced\"):\\n    MODEL, TT2W_SWEEP_ROWS = MODELS[mode], TT2W_SWEEPS[mode]\\n" + textwrap.indent(clean_code(CALIBRATE_W), "    ") + "\\nMODEL, TT2W_SWEEP_ROWS = MODELS[MODE], TT2W_SWEEPS[MODE]")',1)
# Both-mode diagnostics supplement tables without additional images.
s=s.replace('display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings: final confirmed boundaries")','''display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings in each mode: FINAL-region endpoints")
THRESHOLD_ROWS = [dict(file=result["file"], endpoint_mode=mode,
                      **{key:result["diagnostic"].get(key) for key in
                         ("native_threshold", "native_threshold_units", "low_ste_threshold", "high_ste_threshold",
                          "geometry", "minimum_speech_ms", "padding_stage")})
                  for mode, results in ALL_RESULTS_BY_MODE.items() for result in results]
display_table(THRESHOLD_ROWS, [(key,key) for key in THRESHOLD_ROWS[0]], "Both-mode threshold and geometry diagnostics")''')
p.write_text(s,encoding='utf-8')
