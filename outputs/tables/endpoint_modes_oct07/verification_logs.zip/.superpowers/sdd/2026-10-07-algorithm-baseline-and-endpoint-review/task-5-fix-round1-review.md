# Task 5 fix round 1 scoped independent review

Scope: exact 9227b1d..c5e82dd. Read task-5-fix-round1-report.md and task-5-fix-round1-review-package.md, inspected five source/fixture diffs and regenerated notebook/model metadata. No suites, kernels, subagents, or implementation edits were performed. This scratch report is the sole write.

## Verdicts

Spec: PASS. Quality: APPROVE for the scoped fixes. Original P2: ADDRESSED. No new actionable finding in the fix diff.

## Shared benchmark correction

app/pipeline.py:623 now requires evaluate_all and all three primary algorithms in selected before projecting into tables/all/test_metrics.csv and tables/all/summary.csv. A fixed TT1/TT2/TT3 all-dataset run therefore cannot enter that writer; its dedicated run folder continues receiving its own metric/summary/threshold files. Full all-algorithm evaluation still refreshes the shared TEST projection.

The new regression test covers a full both-mode baseline followed sequentially by all three fixed algorithm invocations, checking byte sentinels for both shared files in both mode roots and checking eight rows in each fixed run's own folder. This directly covers the original reproduction and avoids an assertion that merely mirrors the guard. Root/worker RED-GREEN and fresh stable suite evidence was supplied; I reviewed this evidence without rerunning it.

## Units correction

core/features.py defines energy as squared/(end-start), while STE is the sum of squares. Thus mean squared sample amplitude is the correct TT2 native Energy unit. The only native-helper/fit changes are exactly native_threshold_units and feature_rule string metadata. App plotting and standalone notebook plotting now consume the same corrected unit string and still divide the raw native Energy threshold by peak Energy for display on normalized STE. This preserves the numeric plot conversion; the focused fixture asserts threshold2/peak4 draws0.5. TT1/TT3 normalized STE and enhanced HIGH/LOW paths are untouched.

The formerly unqualified production comment now explicitly says Enhanced endpoints require HIGH confirmation. Existing generated comments remain mode-aware.

## Independent bounded read-only evidence

- Metadata-normalized AST comparison of committed baseline/head: after substituting only the two precise old unit literals, complete algorithm_decision, detect_regions and fit_training_model ASTs compare equal. detect_regions has no AST change at all. Arithmetic and APIs are unchanged.
- All three actual saved notebooks retain five PNG outputs, both eight-file mode result sets, and ordered source digests matching execution metadata.
- Actual TT2 notebook plot code uses the corrected unit guard. Both TT2 notebook models equal their production mode JSON files, declare Energy (mean squared sample amplitude), and retain 200 sweep rows per mode.
- Actual CODE ZIP contains exactly three members, each byte equal to its executed notebook.
- artifact_audit.json reports 24 prediction CSVs/mode and full metric/status CSVs unchanged, with diagnostic changes confined to the Energy unit literal, and enhanced legacy FINAL regions preserved. Source and generated diff scope agrees with these invariance claims; this review did not independently rerun inference.
- Root supplied fresh validate-only PASS and stable 173-test acceptance evidence; Task 6 global gate remains owned by root.

No severity/file/line findings remain in this scoped patch.
