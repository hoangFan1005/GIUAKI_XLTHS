param([string]$TaskName, [string]$BaseCommit, [string]$HeadCommit = 'HEAD')
$ErrorActionPreference = 'Stop'
$taskReviewPath = Join-Path $PSScriptRoot ($TaskName + '-review-package.md')
Set-Content -LiteralPath $taskReviewPath -Encoding utf8 -Value "# Review $TaskName`nBase: $BaseCommit`nHead: $HeadCommit`n"
git log --oneline "$BaseCommit..$HeadCommit" | Add-Content -LiteralPath $taskReviewPath -Encoding utf8
if ($LASTEXITCODE -ne 0) { throw 'git log failed' }
git diff --stat $BaseCommit $HeadCommit | Add-Content -LiteralPath $taskReviewPath -Encoding utf8
if ($LASTEXITCODE -ne 0) { throw 'git diff stat failed' }
git diff -U10 $BaseCommit $HeadCommit | Add-Content -LiteralPath $taskReviewPath -Encoding utf8
if ($LASTEXITCODE -ne 0) { throw 'git diff failed' }
Write-Output $taskReviewPath
