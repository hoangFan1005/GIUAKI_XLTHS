# Review task-2
Base: c7f1b0e1cb9a650d80e52c3ab2de19d61249efa2
Head: 116384e31a8027926cdc1131dc79d85bedd682bd

116384e Separate native algorithm decisions from core and enhanced endpoints
 app/pipeline.py                 |  73 +++++++++++++++++++-------
 tests/test_endpoint_modes.py    | 113 ++++++++++++++++++++++++++++++++++++++++
 tests/test_notebook_protocol.py |  23 ++++++++
 tools/build_notebooks.py        |   8 +--
 4 files changed, 195 insertions(+), 22 deletions(-)
diff --git a/app/pipeline.py b/app/pipeline.py
index b92bfdd..b098858 100644
--- a/app/pipeline.py
+++ b/app/pipeline.py
@@ -122,62 +122,99 @@ def prepare_records(audio_records, source_histogram=False):
     records = []
     for base in audio_records:
         features = compute_features(base["samples"], base["sample_rate"],
                                     FRAME_MS, HOP_MS)
         record = dict(base, features=features,
                       labels=frame_labels(features["centers"], base["intervals"]))
         records.append(record)
     return records
 
 
+def algorithm_decision(algorithm: str, features: dict, params: dict) -> tuple[list[int], dict]:
+    """Return native unpadded decisions and thresholds without LAB or endpoint policy.
+
+    TT1/high TT3 include equality; low TT3 includes equality in the opposite
+    direction. TT2 uses strict raw Energy > threshold (context uses STE).
+    Existing TT2 padding diagnostics describe its candidate stage only.
+    """
+    if algorithm == 'tt1':
+        mask, diagnostic = tt1.predict(features, params), dict(threshold=params['threshold'])
+    elif algorithm == 'tt3':
+        if params.get('speech_direction', 'high') not in ('high', 'low'):
+            raise ValueError('Unknown TT3 speech_direction')
+        mask, diagnostic = tt3.predict(features, params), dict(threshold=params['threshold'])
+    elif algorithm in ('tt2', 'tt2-context'):
+        mask, diagnostic = tt2.predict(features, params)
+        if diagnostic['variant'] == 'source':
+            mask = [int(e > diagnostic['energy_threshold']) for e in features['energy']]
+    else:
+        raise ValueError(f'Unknown algorithm: {algorithm}')
+    source_histogram = algorithm in ('tt2', 'tt2-context') and diagnostic.get('variant') == 'source'
+    diagnostic.update(native_threshold=diagnostic['energy_threshold'] if algorithm in ('tt2', 'tt2-context') else params['threshold'],
+                      native_threshold_units='sum of squared samples' if source_histogram else 'normalized STE')
+    return mask, diagnostic
+
+
 def detect_regions(algorithm, features, duration, params):
     """Detect FINAL speech from features and a fitted model, without LAB or I/O.
 
     Input: algorithm, frame features/supports, duration and frozen TRAIN model.
     Output: mask/final_regions/diagnostic and derived predicted_boundaries.
-    Missing endpoint_noise requires explicit training before inference.
-    FINAL hysteresis supports speech-high energy only; inverted TT3 models
-    raise a clear error instead of silently losing every candidate region.
+    Core merges native support gaps below 200 ms without a duration filter.
+    Enhanced requires TRAIN noise and speech-high Gaussian direction.
     """
-    noise = params.get('endpoint_noise')
-    if noise is None:
+    mode = params.get('endpoint_mode', 'enhanced')
+    if mode not in ('core', 'enhanced'):
+        raise ValueError(f'Unknown endpoint_mode: {mode}')
+    noise = params.get('endpoint_noise') if mode == 'enhanced' else None
+    if mode == 'enhanced' and noise is None:
         raise ValueError('Fitted model requires endpoint_noise; call fit_training_model on TRAIN before inference')
     # The raw Gaussian classifier supports both directions. FINAL HIGH/LOW
     # requires speech-high, so reject an incompatible imported model early.
-    if algorithm == 'tt3' and params.get('speech_direction', 'high') != 'high':
+    if mode == 'enhanced' and algorithm == 'tt3' and params.get('speech_direction', 'high') != 'high':
         raise ValueError("FINAL endpoint detection requires TT3 speech_direction='high'; "
                          "inverted/unknown directions are not supported by energy hysteresis")
-    if algorithm == "tt1":
-        mask, diagnostic = tt1.predict(features, params), {"threshold": params["threshold"]}
-    elif algorithm == "tt3":
-        mask, diagnostic = tt3.predict(features, params), {"threshold": params["threshold"]}
-    elif algorithm in ('tt2', 'tt2-context'):
-        mask, diagnostic = tt2.predict(features, params)
-    else:
-        raise ValueError(f'Unknown algorithm: {algorithm}')
+    seed, diagnostic = algorithm_decision(algorithm, features, params)
+    source_histogram=algorithm=='tt2' and params.get('variant','source')=='source'
+    mask = tt2.pad_speech(seed, diagnostic['padding_frames']) if mode == 'enhanced' and source_histogram else seed
 
     # Algorithm masks are candidates. Final endpoints require HIGH confirmation,
     # LOW continuation, short-gap merging and duration filtering.
     candidate_regions=[(s,e) for s,e,state in mask_segments(mask,features['starts'],duration,features['ends']) if state]
-    source_histogram=algorithm=='tt2' and params.get('variant','source')=='source'
+    if mode == 'core':
+        final_regions = []
+        for start, end in candidate_regions:
+            if final_regions and start - final_regions[-1][1] < MIN_SILENCE_SECONDS - 1e-12:
+                final_regions[-1] = (final_regions[-1][0], end)
+            else:
+                final_regions.append((start, end))
+        mask = regions_to_mask(final_regions, features['starts'], features['ends'])
+        diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions,
+            low_ste_threshold=None, high_ste_threshold=None, endpoint_noise=None,
+            minimum_speech_ms=0., minimum_silence_ms=MIN_SILENCE_SECONDS*1000,
+            endpoint_mode=mode, geometry='union of active frame supports',
+            final_padding_ms=0., padding_stage='excluded from core FINAL',
+            endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding')
+        return dict(mask=mask, final_regions=final_regions, diagnostic=diagnostic,
+                    predicted_boundaries=[b for region in final_regions for b in region])
     if algorithm in ('tt1','tt3'):
-        base_threshold=params['threshold'];seed=mask
+        base_threshold=params['threshold']
     else:
         peak=max(features['energy'],default=0.)
         base_threshold=diagnostic['energy_threshold']/peak if source_histogram and peak>0 else diagnostic['energy_threshold'] if not source_histogram else 0.
-        seed=[int(e>diagnostic['energy_threshold'])
-              for e in features['energy']] if source_histogram else mask
     low,high=endpoint_thresholds(base_threshold,noise,histogram=algorithm in ('tt2','tt2-context'))
     final_regions=hysteresis_regions(features['ste_norm'],features['starts'],features['ends'],duration,
         low,high,MIN_SILENCE_SECONDS,MIN_SPEECH_SECONDS,seed_mask=seed)
     mask=regions_to_mask(final_regions,features['starts'],features['ends'])
     diagnostic.update(candidate_regions=candidate_regions,final_regions=final_regions,
+        endpoint_mode=mode,geometry='union of active frame supports',final_padding_ms=0.,
+        padding_stage='candidate diagnostics only' if source_histogram else 'none',
         low_ste_threshold=low,high_ste_threshold=high,endpoint_noise=noise,
         minimum_speech_ms=MIN_SPEECH_SECONDS*1000,minimum_silence_ms=MIN_SILENCE_SECONDS*1000,
         endpoint_policy='raw STE hysteresis; candidates/debug excluded; no fixed final padding')
     return dict(mask=mask, final_regions=final_regions, diagnostic=diagnostic,
                 predicted_boundaries=[b for region in final_regions for b in region])
 
 
 def predict_and_score(algorithm, record, params):
     """Invoke LAB-free detection, then score complete regions and frames.
 
diff --git a/tests/test_endpoint_modes.py b/tests/test_endpoint_modes.py
new file mode 100644
index 0000000..fabf727
--- /dev/null
+++ b/tests/test_endpoint_modes.py
@@ -0,0 +1,113 @@
+"""Native inequalities and policy behavior, with hand-derived support fixtures."""
+import copy
+import unittest
+
+from app import pipeline
+from core.features import compute_features
+
+
+NOISE = dict(noise_q95=.01, noise_upper=.03, high_multiplier=1.5)
+
+
+def features(values, starts=None, ends=None):
+    starts = starts if starts is not None else [i*.01 for i in range(len(values))]
+    ends = ends if ends is not None else [s+.025 for s in starts]
+    return dict(ste_norm=list(values), energy=[v*100 for v in values], starts=starts, ends=ends)
+
+
+class EndpointModesTests(unittest.TestCase):
+    def decision(self, algorithm, f, params):
+        self.assertTrue(callable(getattr(pipeline, 'algorithm_decision', None)),
+                        'Native classifier API must exist without endpoint policy dependencies')
+        return pipeline.algorithm_decision(algorithm, f, params)
+
+    def test_native_tt1_and_tt3_include_equality_and_support_low_direction(self):
+        # Changing >= / <= to strict comparisons loses the equality frame.
+        for a, direction, want in (('tt1','high',[0,1,1]), ('tt3','high',[0,1,1]),
+                                   ('tt3','low',[1,1,0])):
+            with self.subTest(algorithm=a, direction=direction):
+                mask, d = self.decision(a, dict(ste_norm=[.2,.5,.8]),
+                                        dict(threshold=.5,speech_direction=direction))
+                self.assertEqual(mask, want)
+                self.assertEqual(d['native_threshold'], .5)
+                self.assertEqual(d['native_threshold_units'], 'normalized STE')
+
+    def test_tt2_native_energy_is_strict_and_excludes_candidate_padding(self):
+        mask, d = self.decision('tt2', dict(energy=[0.,2.,4.]),
+                               dict(bins=1,smooth_radius=0,W=5.,padding_frames=25))
+        self.assertEqual(mask, [0,0,1])  # one peak -> midpoint 2, equality is silence
+        self.assertEqual(d['native_threshold'], 2.)
+        self.assertEqual(d['native_threshold_units'], 'sum of squared samples')
+
+    def test_context_native_decision_uses_normalized_ste(self):
+        mask, d = self.decision('tt2-context', dict(ste_norm=[0.,.5,1.]),
+                               dict(variant='context',bins=1,smooth_radius=0,W=5.))
+        self.assertEqual(mask, [0,0,1])
+        self.assertEqual(d['native_threshold_units'], 'normalized STE')
+
+    def test_core_support_gap_threshold_keeps_exact_200ms(self):
+        # Wrong gap comparator or using frame count would merge the 200ms case.
+        for gap, want in ((.19,[(.1,.605)]),(.2,[(.1,.325),(.525,.615)]),
+                          (.21,[(.1,.325),(.535,.625)]),(.25,[(.1,.325),(.575,.665)])):
+            with self.subTest(gap=gap):
+                right=.325+gap
+                f=features([0,1,0,1,0], [0,.1,.35,right,.8], [.025,.325,.375,right+.09,.825])
+                before=copy.deepcopy(f)
+                r=pipeline.detect_regions('tt1',f,.825,dict(threshold=.5,endpoint_mode='core'))
+                self.assertEqual(len(r['final_regions']),len(want))
+                for actual,expected in zip(r['final_regions'],want):
+                    for x,y in zip(actual,expected): self.assertAlmostEqual(x,y)
+                self.assertEqual(f,before)
+
+    def test_core_retains_80ms_support_without_noise_and_labels_metadata(self):
+        f=features([0,1,0],[0,.1,.3],[.025,.18,.325])
+        params=dict(threshold=.5,endpoint_mode='core')
+        before=copy.deepcopy(params)
+        r=pipeline.detect_regions('tt1',f,.325,params)
+        self.assertEqual(r['final_regions'],[(.1,.18)])
+        self.assertEqual(r['predicted_boundaries'],[.1,.18])
+        for key in ('low_ste_threshold','high_ste_threshold','endpoint_noise'):
+            self.assertIsNone(r['diagnostic'][key])
+        self.assertEqual(r['diagnostic']['endpoint_mode'],'core')
+        self.assertEqual(r['diagnostic']['minimum_speech_ms'],0.)
+        self.assertEqual(r['diagnostic']['final_padding_ms'],0.)
+        self.assertEqual(params,before)
+        enhanced=pipeline.detect_regions('tt1',f,.325,dict(params,endpoint_mode='enhanced',endpoint_noise=NOISE))
+        self.assertEqual(enhanced['final_regions'],[])
+
+    def test_core_low_gaussian_keeps_native_inequality(self):
+        r=pipeline.detect_regions('tt3', features([.8,.5,.2,.8]), .055,
+                                  dict(threshold=.5,speech_direction='low',endpoint_mode='core'))
+        self.assertEqual(r['final_regions'],[(.01,.045)])
+
+    def test_unknown_mode_and_gaussian_direction_are_rejected(self):
+        f=features([0.,1.])
+        with self.assertRaisesRegex(ValueError,'endpoint_mode'):
+            pipeline.detect_regions('tt1',f,.035,dict(threshold=.5,endpoint_mode='typo',endpoint_noise=NOISE))
+        for mode,direction in (('core','unknown'),('enhanced','unknown'),('enhanced','low')):
+            with self.subTest(mode=mode,direction=direction), self.assertRaisesRegex(ValueError,'direction'):
+                pipeline.detect_regions('tt3',f,.035,dict(threshold=.5,endpoint_mode=mode,
+                    speech_direction=direction,endpoint_noise=NOISE))
+
+    def test_legacy_mode_resolves_enhanced_and_noise_remains_required(self):
+        f=features([0.]*10+[1.]*20+[0.]*30)
+        p=dict(threshold=.5,endpoint_noise=NOISE)
+        self.assertEqual(pipeline.detect_regions('tt1',f,.615,p),
+                         pipeline.detect_regions('tt1',f,.615,dict(p,endpoint_mode='enhanced')))
+        with self.assertRaisesRegex(ValueError,'endpoint_noise'):
+            pipeline.detect_regions('tt1',f,.615,dict(threshold=.5))
+
+    def test_valid_train_models_do_not_detect_zero_waveform_or_empty_features(self):
+        train=[dict(features=dict(ste_norm=[.001,.002,.7,.9],energy=[.1,.2,70.,90.]), labels=[0,0,1,1])]
+        models={'tt1':pipeline.tt1.fit(train), 'tt3':pipeline.tt3.fit(train),
+                'tt2':dict(bins=64,smooth_radius=2,W=20.,padding_frames=25)}
+        for fs in (16000,44100):
+            f=compute_features([0.]*round(fs*.8),fs)
+            for a,p in models.items():
+                with self.subTest(fs=fs,algorithm=a):
+                    self.assertEqual(pipeline.detect_regions(a,f,.8,dict(p,endpoint_mode='core'))['final_regions'],[])
+                    self.assertEqual(pipeline.detect_regions(a,features([]),0.,dict(p,endpoint_mode='core'))['final_regions'],[])
+
+
+if __name__ == '__main__':
+    unittest.main()
diff --git a/tests/test_notebook_protocol.py b/tests/test_notebook_protocol.py
index 765dcfc..abbb7b7 100644
--- a/tests/test_notebook_protocol.py
+++ b/tests/test_notebook_protocol.py
@@ -30,20 +30,43 @@ def tiny_dataset(root):
             path = folder / (prefix + suffix + ".wav")
             values = [int((12000 if 200 <= i < 650 else 40) * math.sin(i * .47))
                       for i in range(1000)]
             with wave.open(str(path), "wb") as handle:
                 handle.setparams((1, 2, 1000, 0, "NONE", "not compressed"))
                 handle.writeframes(b"".join(value.to_bytes(2, "little", signed=True) for value in values))
             path.with_suffix(".lab").write_text("0 0.2 sil\n0.2 0.65 v\n0.65 1 sil\n")
 
 
 class NotebookGenerationTests(unittest.TestCase):
+    def test_extracted_decision_helper_and_core_policy_execute_without_project_imports(self):
+        # Missing extraction or algorithm namespace mapping breaks real calls.
+        for algorithm in ('tt1', 'tt2', 'tt3'):
+            with self.subTest(algorithm=algorithm):
+                namespace = {}
+                exec(builder.CONFIG.format(algorithm=algorithm), namespace)
+                # Function defaults reference this constant in the TT2 setup cell.
+                namespace['W_CANDIDATES'] = (1., 3., 5., 10., 20.)
+                for cell in self.generated(algorithm)['cells']:
+                    if cell['cell_type'] != 'code':
+                        continue
+                    tree = ast.parse(''.join(cell['source']))
+                    tree.body = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.Import, ast.ImportFrom))]
+                    exec(compile(tree, '<extracted-definitions>', 'exec'), namespace)
+                f = dict(ste_norm=[0.,.5,1.], energy=[0.,2.,4.],
+                         starts=[0.,.01,.02], ends=[.025,.035,.045])
+                p = dict(threshold=.5,speech_direction='high',endpoint_mode='core',
+                         bins=1,smooth_radius=0,W=5.,padding_frames=25)
+                raw, _ = namespace['algorithm_decision'](algorithm,f,p)
+                self.assertEqual(raw, [0,0,1] if algorithm=='tt2' else [0,1,1])
+                r = namespace['detect_regions'](algorithm,f,.045,p)
+                self.assertEqual(r['final_regions'], [(.02,.045)] if algorithm=='tt2' else [(.01,.045)])
+
     def generated(self, algorithm):
         try:
             return builder.build_notebook(algorithm)
         except (ValueError, StopIteration) as error:
             self.fail(f"Generator must adapt current public core interfaces: {error}")
 
     def test_stage_comments_preserve_nested_numeric_ast_and_multiline_docstrings(self):
         inject = getattr(builder, 'add_stage_comments', None)
         self.assertTrue(callable(inject), 'AST-coordinate stage comment injection is required')
         source = '''def first(values):
diff --git a/tools/build_notebooks.py b/tools/build_notebooks.py
index 99699c5..c9461db 100644
--- a/tools/build_notebooks.py
+++ b/tools/build_notebooks.py
@@ -108,22 +108,22 @@ def pipeline_stage_comments(algorithm: str) -> dict:
         'tt2': 'TT2 estimates raw energy threshold per file; padded masks remain candidate diagnostics.',
         'tt3': 'TT3 raw classification supports both directions; FINAL rejects explicit low/unknown models.'}
     comments = {
         'detect_regions': [
             ('@input', 'Input: frame features/supports, duration and fitted model; Output: FINAL regions, mask and diagnostics.'),
             ('noise', decisions[algorithm] + ' Require TRAIN noise before inference.'),
             ('candidate_regions', 'Retain candidate supports for inspection; only FINAL regions produce endpoint scores.'),
             ('base_threshold', 'Use the TRAIN normalized STE threshold and raw classifier seed.'
              if algorithm != 'tt2' else 'Normalize TT2 raw energy threshold and seed from unpadded raw energy decisions.'),
             ('low', 'Derive LOW/HIGH from the threshold and TRAIN silence noise statistics.'),
-            ('final_regions', 'Confirm with HIGH and continue above LOW; merge estimated support gaps below 200 ms.'),
-            ('@return', 'The 100 ms support-span filter is a heuristic; support bounds do not guarantee physical silence.')],
+            ('high', 'Confirm with HIGH and continue above LOW; merge estimated support gaps below 200 ms.'),
+            ('mode', 'The enhanced 100 ms support-span filter is a heuristic; core keeps native speech supports.')],
         'predict_and_score': [
             ('detected', 'Detect without LAB first; consult reference regions only after FINAL detection returns.'),
             ('region_scores', 'Score complete FINAL regions in time order; missing/extra regions leave primary MAE undefined.'),
             ('flags', 'Report missing/extra regions and large errors instead of hiding them in matched-only metrics.'),
             ('boundary', 'Inspect endpoint positions against audio bounds and reference silence for diagnostics.'),
             ('frames', 'Compute frame and tolerance-based event diagnostics separately from complete-region MAE.'),
             ('legacy_test_tuned', 'Retain provenance for imported historical models; fresh fits record TRAIN selection.'),
             ('@return', 'Output: FINAL detection, reference regions, scores, status and original detector diagnostics.')],
         'fit_training_model': [
             ('@input', 'Validate supplied TRAIN provenance before fitting; TEST reads occur after model locking.'),
@@ -199,21 +199,21 @@ def algorithm_code(algorithm: str) -> tuple[str, str]:
             node.body[0] = ast.Expr(ast.Constant(
                 "TRAIN candidate-frame F1 proposal; FINAL W is calibrated on TRAIN separately."
                 if node.name == "fit" else "Predict the source energy histogram candidate mask."))
     prediction = ast.unparse(ast.fix_missing_locations(tree))
     prediction = add_stage_comments(prediction, TT2_STAGE_COMMENTS)
     return helpers, prediction
 
 
 def standalone_pipeline(algorithm: str) -> str:
     """Adapt public production functions by AST, retaining their numeric logic."""
-    tree = ast.parse(functions("app/pipeline.py", "detect_regions", "predict_and_score", "fit_training_model"))
+    tree = ast.parse(functions("app/pipeline.py", "algorithm_decision", "detect_regions", "predict_and_score", "fit_training_model"))
     class LocalAlgorithm(ast.NodeTransformer):
         def visit_Compare(self, node):
             # The public guard fixes algorithm, so omit other dispatch branches
             # without rewriting any detector or calibration formula.
             if (isinstance(node.left, ast.Name) and node.left.id == "algorithm"
                     and len(node.ops) == 1):
                 right = ast.literal_eval(node.comparators[0])
                 operation = node.ops[0]
                 value = (algorithm == right if isinstance(operation, ast.Eq) else
                          algorithm != right if isinstance(operation, ast.NotEq) else
@@ -229,21 +229,21 @@ def standalone_pipeline(algorithm: str) -> str:
             return node
 
         def visit_IfExp(self, node):
             node = self.generic_visit(node)
             if isinstance(node.test, ast.Constant) and isinstance(node.test.value, bool):
                 return node.body if node.test.value else node.orelse
             return node
 
         def visit_Attribute(self, node):
             if (isinstance(node.value, ast.Name) and node.value.id in ("tt1", "tt2", "tt3")
-                    and node.attr in ("fit", "predict")):
+                    and node.attr in ("fit", "predict", "pad_speech")):
                 return ast.copy_location(ast.Name(node.attr, ast.Load()), node)
             return self.generic_visit(node)
 
         def visit_Name(self, node):
             if node.id == "TRAIN_DIR":
                 return ast.copy_location(ast.parse("(DATA_ROOT / 'train')", mode="eval").body, node)
             return node
 
     tree = LocalAlgorithm().visit(tree)
     guard = ast.parse('if algorithm != ALGORITHM:\n    raise ValueError("This notebook contains only " + ALGORITHM)').body[0]
