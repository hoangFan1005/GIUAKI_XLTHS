# Task 2 independent review

Reviewed range: `c7f1b0e1cb9a650d80e52c3ab2de19d61249efa2..116384e31a8027926cdc1131dc79d85bedd682bd`.

Scope: four changed source/test files, binding Task2 brief, report, review package, recorded logs and regression JSON. Focused unchanged-code reads covered TT2 prediction/padding, support geometry, endpoint arithmetic, and standalone extraction dependencies. No tests rerun; no source, Git state, or generated artifact modified.

## Strengths

- `app/pipeline.py:132`: the native API has no LAB/name/duration/noise dependency. TT1 and TT3 retain their native inclusive inequalities; TT3 rejects unknown directions. Source TT2 replaces padded predictions with strict raw Energy decisions while preserving threshold and candidate diagnostics. Context thresholds normalized STE and reports appropriate units.
- `app/pipeline.py:166`: mode validation and branch-local noise/direction guards allow core low-direction TT3 without weakening enhanced guards. Missing mode remains enhanced.
- `app/pipeline.py:183`: core uses unioned active supports from `mask_segments`, merges only internal gaps below `200 ms - 1e-12`, keeps exact estimated 200 ms separate, and retains short speech. The tolerance agrees with existing support/endpoint conventions. Core returns null LOW/HIGH/noise fields and explicit threshold units, geometry, minimum duration and padding metadata.
- `app/pipeline.py:177`: enhanced source TT2 reconstructs the same padded candidate mask from the native seed, then sends the unpadded seed to unchanged HIGH/LOW hysteresis. Threshold normalization and filtering arithmetic are preserved. The recorded JSON contains 24/24 exact comparisons for old diagnostics, masks, FINAL regions, boundaries, metrics and status.
- `tests/test_endpoint_modes.py:25`: tests assert independently derived equality masks/supports, exact-gap behavior, 80 ms retention, input preservation, direction/mode errors, legacy fallback, real zero-waveform features at 16 kHz and 44.1 kHz, and empty features. Existing enhanced peak-zero coverage remains in the focused suite.
- `tools/build_notebooks.py:209`: extracting the new API and mapping `pad_speech` resolves real standalone dependencies. The new test executes actual generated definitions for all three algorithms; recorded existing notebook protocol tests execute standalone cells and validate locking before TEST reads. The bridge stays within the authorized minimal scope.

## Issues

### Critical

None.

### Important

None within Task2 scope.

### Minor

1. `tools/build_notebooks.py:113` (also TT3 text at line 109): generated comments still say inference requires TRAIN noise and FINAL rejects low TT3 without qualifying these statements as enhanced-only. Generated core functions now accept missing noise and known low-direction TT3, so readers can infer an incorrect contract. Qualify the two comments during the scheduled notebook authoring task; no arithmetic change is needed. This does not block the minimal bridge.

## Evidence inspected

- `task2-green.txt`: 41 focused tests, OK.
- `task2-generator-green.txt`: 5 generation tests, OK.
- `task2-full-suite.txt`: 147 tests, OK.
- `task2-enhanced-regression.json` and `.txt`: 24 exact cases; 144 unchanged artifacts reported.
- Intermediate full-suite log records the generator failures described in the report, followed by the scoped bridge and recorded successful generation/full-suite evidence.

These are recorded execution results, not new independent runs. The comparison scratch script is not present among the repository evidence files; regression conclusions additionally rely on inspection of the preserved enhanced arithmetic and the saved comparison results.

## Declined to judge

- Mode-aware TRAIN calibration/model schema/W selection: explicitly assigned to Task3.
- Mode-aware exports/audits/plots: explicitly assigned to subsequent tasks; existing default enhanced behavior is the compatibility target here.
- Full dual-mode notebook authoring and regenerated deliverables: assigned to Task5; Task2 authorizes only the minimal extraction/comment-anchor bridge.
- Unchanged Gaussian fitting, histogram construction and feature arithmetic: preserved by the reviewed diff; unchanged reads were limited to the named integration risks.

## Verdicts

**Spec compliance: PASS for Task2.** Native decisions, core FINAL policy, enhanced compatibility, diagnostics and authorized standalone bridge satisfy the binding brief. Later integration scope remains explicitly deferred.

**Code quality: APPROVE with minor documentation follow-up.** No Critical or Important defect found. The recorded tests and exact enhanced comparison support proceeding to Task3; generated comments should be qualified when Task5 updates notebook explanations.
