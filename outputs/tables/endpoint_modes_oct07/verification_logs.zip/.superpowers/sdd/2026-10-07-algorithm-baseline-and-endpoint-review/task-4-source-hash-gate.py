import ast,hashlib,json,subprocess
from pathlib import Path
base='47cc00b'
def digest(data):return hashlib.sha256(data).hexdigest()
files=['core/features.py','core/endpoints.py','core/postprocess.py','core/metrics.py','algorithms/tt1_hodgkinson.py','algorithms/tt2_histogram.py','algorithms/tt3_gaussian.py']
rows=[]
for name in files:
 before=subprocess.check_output(['git','show',f'{base}:{name}'])
 after=Path(name).read_bytes()
 rows.append(dict(file=name,baseline_sha256=digest(before),current_sha256=digest(after),unchanged=before==after))
for name in ('algorithm_decision','detect_regions','fit_training_model'):
 before=ast.parse(subprocess.check_output(['git','show',f'{base}:app/pipeline.py']).decode('utf-8-sig'))
 after=ast.parse(Path('app/pipeline.py').read_text(encoding='utf-8-sig'))
 def function_dump(tree):return ast.dump(next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name),include_attributes=False).encode()
 left,right=function_dump(before),function_dump(after)
 rows.append(dict(file=f'app/pipeline.py::{name}',baseline_ast_sha256=digest(left),current_ast_sha256=digest(right),unchanged=left==right))
assert all(r['unchanged'] for r in rows)
payload=dict(baseline=base,scope='protected detector source only; no TEST/audio/canonical artifact reads',checks=rows,all_unchanged=True,enhanced24_and_global_hash_gate='deferred to root coordinated acceptance')
Path('outputs/tables/endpoint_modes_oct07/timing_research/protected_source_hashes.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
print('10 protected detector source/function hashes unchanged against 47cc00b')
