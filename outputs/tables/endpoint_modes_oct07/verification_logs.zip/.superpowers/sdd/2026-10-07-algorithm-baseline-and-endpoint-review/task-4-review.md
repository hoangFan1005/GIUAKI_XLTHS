# Independent Task 4 review

Reviewed scope: exact committed diff `47cc00b..27dc471` (four owned Python files), task-4-brief.md, task-4-report.md, task-4-review-package.md, and the existing timing_research evidence. Concurrent changes outside this diff are excluded. This is a Task 4 review; Task 6 retains whole-branch integration and fresh global regression acceptance.

## Verdicts

**Specification: PASS.** The committed implementation satisfies the bounded TRAIN timing research requirements. No blocking specification finding.

**Quality: APPROVE WITH NIT.** No correctness or production-regression defect found in the scoped diff. One low-severity provenance usability improvement is actionable below. It does not invalidate the evidence: all emitted synthetic hashes were independently reconstructed from the saved native models and trial definitions.

## Finding

### [P3] Persist the synthetic branch models named by the waveform row hashes

File: `tools/check_endpoint_robustness.py`, lines 496-508 (especially 505 and 507-508).

Each waveform row hashes `_branch_params(native, trial)`, while `synthetic_models` stores only the unmodified six native models. The CSV consequently has 19 distinct model hashes and the manifest has six synthetic-model hashes, with zero hashes in common. A reader cannot resolve a row hash by a direct manifest lookup and must reproduce the transformation in `_branch_params`, including removed native selection/digest fields and rewritten policy metadata. This is a provenance usability issue, not missing calibration data: a bounded independent reconstruction reproduced every one of the 1216 row hashes from the saved native models plus trials.

Suggested improvement: add a deduplicated manifest collection for the 19 actual synthetic branch configurations, keyed by row `model_sha256`, with algorithm/trial_id and source native model hash. Keep the six native calibration records to retain their locked TRAIN W selection provenance. No need to refit or rerun the study.

## Specification and code assessment

- `decision_cells` uses actual feature centers and adjacent-center midpoints, retains half-sample boundaries, and covers 0/duration with disjoint positive cells. Empty sequences and one-frame/tail behavior are explicit. It changes no analysis window or feature extraction. Tests contain literal sample-center/midpoint expectations at 16 kHz and 44.1 kHz, estimated 190/200/210 ms gap rules, 95/100/105 ms span rules, multiple regions, and audio-edge cases.
- The same selected starts/ends feed candidates, START/END, core merge gaps, enhanced hysteresis gaps, duration filtering, final mask containment and last native active END. Cells are not scored using full 25 ms supports. The 200 ms rule retains equality through the existing numerical tolerance.
- The trial matrix contains the six common one-factor branches plus one enhanced TT1-only LOW=T1 branch: 19 algorithm/trial combinations and 76 held-out rows. LOW=T1 uses the declared HIGH=max(1.5*T1,noise_upper) and explicitly rejects invalid zero LOW rather than flooring it.
- Each of four folds fits native TT1/TT3/noise models on the other three TRAIN records. Held-out records are absent from every saved fit_files list. Six TT2 branches separately sweep W=1..50 on those three fit records: 3600 fit evaluations. Candidate and held-out predictions call the same `timing_predictor`, so geometry, cleanup and scoring agree. Saved selected_W, W and finalW agree; selection policy geometry, mode, minimum speech, silence and scorer are retained. Native support W/digests are explicitly preliminary for fold experiments.
- The 24 same-mode support baseline scores check FINAL regions and masks against production `detect_regions`. Native core and enhanced semantics remain distinct. TT2 retains native Energy decisions without F0/Centroid or another algorithm.
- The research route loads TRAIN only, rejects non-TRAIN provenance before fitting, writes only its dedicated diagnostic folder, and does not persist canonical production models or change defaults. Filenames do not enter detector decisions; labels enter model fitting or scoring. No GT snapping or physical-label rewriting was found. Existing case-handling behavior is inherited from the shared loader; Task 4 introduces no new filename inference rule. No new case-insensitive loader claim is made by this review.
- Primary MAE/RMSE stay undefined on region count mismatch. Valid-only aggregates have separate names, and the RMSE aggregate is explicitly a mean of per-file RMSEs. Saved comparisons include all 52 alternate fold comparisons, 10 MAE regressions and 11 RMSE regressions. The recommendation reports regressions and does not infer universal improvement or choose defaults using TEST.

## Evidence inspection and bounded independent checks

No existing test suite or full study was rerun. The existing focused-green evidence reports 21 passing focused tests; this review treats it as supplied evidence rather than a newly reproduced suite result.

A bounded script read only existing JSON/CSV and exact Git source snapshots, then checked:

- 76 held-out rows, 3600 branch W fit rows, 1216 locked-model waveform rows, 48 fixed support oracle rows, 48 fixed cell oracle rows, and 52 comparisons.
- Four folds with three fit files and held-out exclusion; TT2 selection geometry/mode/filter fields and final W consistency.
- Physical 200/210 ms: fixed support merges 24/24 with undefined primary errors; fixed cells merges 23/24 with undefined primary errors on those 23. Across 19 locked-model algorithm/trial combinations, all 456 corresponding physical 200/210 ms rows merge. Physical GT and the 200 ms estimator threshold remain intact.
- Independently recomputed all 48 cell-gap estimates using integer sample overlap with LOW=.1, explicit actual frame/hop samples, and literal midpoint arithmetic. Zero mismatches against `fixed_oracle_cells.csv`. This calculation did not call `decision_cells`, hysteresis, or the research predictor.
- The synthetic study separately includes eight physical 75/95/100/105 ms bursts and eight start/end/both-edge/weak-tail cases, scored against physical intervals rather than asserted to satisfy estimated-duration rules. Locked calibration threshold provenance is separate from fixed .1/.5 diagnostics; actual detector thresholds appear in each row diagnostic.
- Independently reconstructed the 19 synthetic branch parameter hashes from manifest native models and trials; all 1216 row hashes resolve under this reconstruction.
- Exact `27dc471` source bytes match `47cc00b` for core/features.py, endpoints.py, postprocess.py, metrics.py and all three algorithm modules. Independently parsed ASTs of `algorithm_decision`, `detect_regions` and `fit_training_model` match across the two commits and match the supplied hash evidence. All ten protected hash records agree.

## Limits and handoff

This review does not certify the concurrently modified working tree or rerun enhanced24/global protected-artifact/full-suite gates. Those are explicitly Task 6 acceptance gates. No TEST audio/LAB was read by this review. The existing historical_test_exposure=true provenance remains truthful; these four TRAIN folds do not create an independent TEST holdout. Production timing/LOW approval remains with the user after the research result is presented.
