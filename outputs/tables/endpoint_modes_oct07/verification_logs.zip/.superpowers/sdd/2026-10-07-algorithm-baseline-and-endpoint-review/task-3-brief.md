### Task3 — Model và W phải khóa cùng policy

**Files:** sửa `app/pipeline.py`, `app/weight_selection.py`, `tests/test_training_protocol.py`, `tests/test_weight_selection.py`.

**Interfaces:**
- `fit_training_model(algorithm, train_records, *, endpoint_mode='enhanced') -> tuple[dict,list[dict]]`.
- Giữ `sweep_final_weights(records, model, predictor, ...)` nhưng model mang policy và mỗi row/selection mang mode; predictor đi đúng policy đó. Row/manifest khóa cả endpoint_mode, boundary_convention, minimum_speech_ms, minimum_silence_ms và padding_stage; LOW/HIGH nullable theo contract Task2, không index rồi ép float cho core.
- Model mới schema 3, metric schema 2; thêm endpoint_mode, feature/decision rule, minimum_speech_ms, boundary_convention và padding_stage. Model schema1/2 import resolve enhanced, không đổi provenance hoặc numeric params ngầm.

- [ ] Viết RED: calibrator dùng đúng core/enhanced scorer; TEST/external records bị từ chối; TT1/TT3 core không phụ thuộc noise-floor fit; W candidate F1 không tự trở thành FINAL W; core LOW/HIGH null đi qua sweep/export/audit/plot không lỗi hoặc hiện ngưỡng giả.
- [ ] Fit T1/T3 từ TRAIN như hiện tại, TT2 grid1…50 riêng mỗi policy; core min speech 0, enhanced100. Với enhanced, selectedW/T/noise và kết quả phải giữ như baseline. TT3 core-low được fit; enhanced vẫn reject ngay.
- [ ] Khóa tất cả model/mode/W/noise trước TEST; lưu digest từng mode và mode-specific selection manifests. Primary mean undefined nếu count mismatch; báo invalid count rõ.
- [ ] Chạy tests training/weight/modes. Gate: thay target TEST LAB không đổi detection/calibration; expected200 row TRAIN sweep mỗi mode TT2; không gọi W20 hoặc W1 là optimum duy nhất khi hòa.

### Global Constraints

- Giữ3 thuật toán, Python tự tính; TT2 chỉ Energy, không F0/Centroid, không thêm ZCR/thuật toán thứ 4.
- Analysis frame 25 ms, hop 10 ms, nearest samples/ties-to-even; Fs44.1k dùng1102/441samples, thời gian thực được báo cáo.
- Minimum internal silence 200 ms; exact estimated200 ms phải giữ, <200 ms mới nối. Silence đầu/cuối không ép kéo dài200 ms.
- Mỗi FINAL speech region có START/END; không candidate/debug trong primary figure/MAE.
- TRAIN chọn tham số và khóa model trước mở TEST; target LAB chỉ dùng scoring/plot. Không rule filename, GT snapping, TEST tuning hoặc bỏ lỗi lớn.
- Giữ `historical_test_exposure=true`; legacy TEST-calibrated model phải giữ provenance cũ. Đổi protocol không tạo holdout độc lập.
- Metric schema 2 tiếp tục `mae_ms`/`rmse_ms`; thiếu/thừa vùng làm primary undefined, không dùng mean subset thay mean đầy đủ.
- Không sửa slides/PPTX/PDF, dữ liệu Source/audio hoặc ZIP Python cũ. CODE notebook ZIP được cập nhật khi source notebook thay đổi.
- Không hứa MAE core thấp hơn enhanced hoặc timestamp mới làm mọi file tốt lên.



Intermediate compatibility gate: fresh model schema3 changes are consumed by generated standalone cells and repository auditor in the existing full suite. You may add only minimal schema3/mode/helper compatibility to tools/build_notebooks.py, tools/run_notebooks.py and their focused tests if failing tests demonstrate this dependency. Keep legacy schema2 audit fixtures/delivery untouched and accepted under their original contract; generated current models need mode validation. Full dual-mode locking, new artifact-root routing, CLI and notebook rebuilding remain Task5. Do not regenerate canonical model files or notebooks here. Use Task1 baseline to show all enhanced numeric results unchanged despite intentional new model metadata. Stage only owned/minimal bridge files.
