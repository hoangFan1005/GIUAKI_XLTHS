from pathlib import Path
import ast,csv,hashlib,json,subprocess,zipfile,difflib
root=Path.cwd();out=root/'outputs/endpoint_modes/comparison';evidence={}
base=subprocess.check_output(['git','show','47cc00b:app/pipeline.py']).decode('utf-8-sig');current=(root/'app/pipeline.py').read_text(encoding='utf-8-sig')
def nodes(source):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)}
evidence['stable_detector_fit_AST']={name:nodes(base)[name]==nodes(current)[name] for name in ('algorithm_decision','detect_regions','fit_training_model')}
normalized_base=base.replace('sum of squared samples','mean squared sample amplitude')
evidence['arithmetic_and_API_AST_preserved_after_two_metadata_literals']={name:nodes(normalized_base)[name]==nodes(current)[name] for name in ('algorithm_decision','detect_regions','fit_training_model')}
assert all(evidence['arithmetic_and_API_AST_preserved_after_two_metadata_literals'].values())
evidence['intentional_metadata_delta']={'algorithm_decision.native_threshold_units': ['sum of squared samples','mean squared sample amplitude'],
                                        'fit_training_model.feature_rule': ['Energy (sum of squared samples)','Energy (mean squared sample amplitude)']}
evidence['mode_rows']={};evidence['tt2_sweep_rows']={}
for mode in ('core','enhanced'):
    target=root/'outputs/endpoint_modes'/mode
    with (target/'tables/all_all_dataset/test_metrics.csv').open(encoding='utf-8-sig') as f:rows=list(csv.DictReader(f))
    assert len(rows)==24 and all(row['endpoint_mode']==mode for row in rows)
    assert all(row['actual_frame_ms'] and row['actual_hop_ms'] and row['padding_stage'] and row['minimum_speech_ms'] for row in rows)
    evidence['mode_rows'][mode]=len(rows)
    with (target/'tables/tt2_w_selection/sweep.csv').open(encoding='utf-8-sig') as f:sweep=list(csv.DictReader(f))
    assert len(sweep)==200;evidence['tt2_sweep_rows'][mode]=len(sweep)
    if mode=='core':
        for path in (target/'diagnostics').rglob('*.json'):
            diagnostic=json.loads(path.read_text(encoding='utf-8'));assert diagnostic['low_ste_threshold'] is None and diagnostic['high_ste_threshold'] is None
with (out/'tables/all_metrics.csv').open(encoding='utf-8-sig') as f:assert len(list(csv.DictReader(f)))==48
evidence['notebooks']={}
for number in (1,2,3):
    p=root/'notebooks'/f'THUAT_TOAN_{number}.ipynb';nb=json.loads(p.read_text(encoding='utf-8'))
    audit=nb['metadata']['endpoint_execution'];assert set(audit['models'])=={'core','enhanced'}
    images=sum('image/png' in output.get('data',{}) for cell in nb['cells'] for output in cell.get('outputs',[]));assert images==5
    evidence['notebooks'][p.name]=dict(pngs=images,mode_rows={mode:len(rows) for mode,rows in audit['all_results_by_mode'].items()},code_source_sha256=audit['code_source_sha256'],model_lock_digests=audit['model_lock_digests'])
with zipfile.ZipFile(root/'submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip') as z:
    assert len(z.namelist())==3
    evidence['notebook_zip_exact_three_byteequal']=all(z.read(name)==(root/'notebooks'/Path(name).name).read_bytes() for name in z.namelist())
assert evidence['notebook_zip_exact_three_byteequal']
evidence['enhanced_legacy_endpoint_regression']={}
for algorithm in ('tt1','tt2','tt3'):
    unchanged=True
    for path in (root/'outputs/endpoint_modes/enhanced/diagnostics'/algorithm).glob('*.json'):
        legacy=root/'outputs/diagnostics'/algorithm/path.name
        old=json.loads(legacy.read_text(encoding='utf-8-sig'));new=json.loads(path.read_text(encoding='utf-8'))
        unchanged=unchanged and old['final_regions']==new['final_regions']
    evidence['enhanced_legacy_endpoint_regression'][algorithm]=unchanged
assert all(evidence['enhanced_legacy_endpoint_regression'].values())
before=json.loads((root/'.superpowers/sdd/2026-10-07-algorithm-baseline-and-endpoint-review/task5-round1-before.json').read_text(encoding='utf-8'))
evidence['round1_numeric_regression']={}
for mode,old in before.items():
    target=root/'outputs/endpoint_modes'/mode
    for relative,old_diag in old['diagnostics'].items():
        new_diag=json.loads((target/relative).read_text(encoding='utf-8'))
        expected=json.loads(json.dumps(old_diag).replace('sum of squared samples','mean squared sample amplitude'))
        assert new_diag==expected
    assert all(hashlib.sha256((target/relative).read_bytes()).hexdigest()==digest for relative,digest in old['predictions'].items())
    assert hashlib.sha256((target/'tables/all_all_dataset/test_metrics.csv').read_bytes()).hexdigest()==old['metrics']
    evidence['round1_numeric_regression'][mode]={'all24_diagnostics_equal_except_unit_label': True,'all24_prediction_CSVs_byteequal': True,'all24_metrics_status_rows_CSV_byteequal': True}
touched=['app/pipeline.py','app/plotting.py','tools/build_notebooks.py','tests/test_endpoint_modes.py','tests/test_endpoint_mode_integration.py',
         'notebooks/THUAT_TOAN_1.ipynb','notebooks/THUAT_TOAN_2.ipynb','notebooks/THUAT_TOAN_3.ipynb','submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip']
touched.extend(str(path.relative_to(root)).replace('\\','/') for mode in ('core','enhanced') for path in (root/'outputs/endpoint_modes'/mode/'models').glob('*.json'))
evidence['touched_sha256']={relative:hashlib.sha256((root/relative).read_bytes()).hexdigest() for relative in touched}
(out/'artifact_audit.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')
# Preserve original mixed line endings for unchanged outputs README lines.
p=root/'outputs/README.md';old=subprocess.check_output(['git','show','47cc00b:outputs/README.md']).decode('utf-8-sig');new=p.read_text(encoding='utf-8-sig');oldlines=old.splitlines(keepends=True);newlines=new.splitlines(keepends=True);oldplain=[line.rstrip('\r\n') for line in oldlines];newplain=[line.rstrip('\r\n') for line in newlines]
for block in difflib.SequenceMatcher(None,oldplain,newplain).get_matching_blocks():
    for i in range(block.size):newlines[block.b+i]=oldlines[block.a+i]
p.write_bytes(''.join(newlines).encode('utf-8'))
print(json.dumps({key:value for key,value in evidence.items() if key!='notebooks'},indent=2))
