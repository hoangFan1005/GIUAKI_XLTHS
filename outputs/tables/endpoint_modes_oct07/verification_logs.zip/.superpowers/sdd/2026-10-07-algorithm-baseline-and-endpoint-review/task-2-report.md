# Task 2 report

Status: implemented and verified on `codex/endpoint-modes`, starting at `c7f1b0e`.

## Changes

- `app/pipeline.py` exposes `algorithm_decision(algorithm, features, params)` returning native, unpadded masks plus threshold diagnostics without LAB, filename, duration, or endpoint noise.
- TT1 and high TT3 keep `>=`; low TT3 keeps `<=`; TT2 source uses raw energy `>` and context uses normalized STE `>`. Unknown TT3 directions now fail at the native pipeline API instead of falling through to high.
- `detect_regions` validates `endpoint_mode`, defaults missing mode to enhanced, and makes noise/high-direction guards enhanced-only.
- Core FINAL regions are unions of raw active frame supports, followed by direct merging of internal estimated support gaps strictly below 200 ms (1e-12 roundoff tolerance). Exact 200 ms stays separate. Core has no 100 ms filter, no padding, and no synthetic LOW/HIGH/noise values.
- Enhanced uses the prior threshold, seed, hysteresis, merge, and filter arithmetic. Source TT2 retains exactly its padded candidate diagnostics and unpadded seeds.
- Both modes add diagnostic fields `endpoint_mode`, `native_threshold`, `native_threshold_units`, `geometry`, `final_padding_ms`, and `padding_stage`. Existing `minimum_speech_ms` is 0 for core and remains 100 for enhanced; `minimum_silence_ms` remains 200. Core LOW/HIGH/noise values are Python None / JSON null.
- No algorithm source, Gaussian arithmetic, feature/framing, calibration, model schema, W-selection, generated notebook, slides, audio, or archives changed.

## Tests and evidence

TDD and writing-good-tests instructions read before writing tests. Fixtures derive literal masks and support boundaries independently. Tests catch wrong equality operators, padded native masks, noise leakage into core, wrong gap comparator, short-speech filtering in core, unknown policy/direction fallthrough, input mutation, zero division, and synthetic zero-waveform speech.

- RED: `outputs/tables/endpoint_modes_oct07/task2-red.txt`, 9 test methods, 6 failure subcases and 12 error subcases. Missing native API is reported as an explicit assertion failure; core calls fail because the old detector still requires noise. Unknown endpoint mode fails because it is not validated. The existing legacy enhanced/noise contract passes as characterization.
- Focused GREEN: `python -m unittest tests.test_endpoint_modes tests.test_endpoints tests.test_endpoint_robustness tests.test_gaussian_direction_contract -v`: 41 tests passed, 1.263 s. Log `task2-green.txt`.
- Intermediate full suite: `task2-full-suite-intermediate.txt`: 146 tests, 4 failures and 3 errors, all notebook generation subcases. Concrete failure: `detect_regions: stage 'final_regions' must resolve exactly once` after introducing the second branch.
- Authorized minimal generator bridge: extract `algorithm_decision`, map TT2 `pad_speech` to the standalone function, replace ambiguous FINAL/return stage anchors with unique HIGH/mode anchors. No production notebook rebuild. `tests/test_notebook_protocol.py` adds one real generated-definition execution test covering native decisions and core supports for all three algorithms. Its initial TT2 setup failed with missing `W_CANDIDATES`; the test fixture now supplies the function-default constant, without modifying production logic.
- Generator GREEN: 5 tests passed, 2.144 s, `task2-generator-green.txt`.
- Final full suite: `python -m unittest discover -v`: 147 tests passed, 11.845 s. Log `task2-full-suite.txt`.
- Exact enhanced regression: scratch `task2-compare.py` reads Task1's locked baseline/models/features and invokes real `predict_and_score` without fitting or regeneration. All 24 cases match masks, FINAL regions, predicted/reference boundaries, region pairs, every numeric metric and status, and every old diagnostic field exactly after JSON normalization. New metadata is allowed. Records/models remain unchanged. Evidence `task2-enhanced-regression.json` and `.txt`.
- Artifact preservation: 144 captured artifacts unchanged; only explicitly owned pipeline/generator and Task1's three prior documentation edits are excluded from this comparison. Baseline JSON remains unchanged.
- `git diff --check`: clean.

Python used `.venv/Scripts/python.exe`, `PYTHONUTF8=1`, and `MPLBACKEND=Agg`. Initial sandbox invocation was access denied; authorized runs used require_escalated. No push performed.

## Remaining integration scope

Mode-aware training calibration/schema/W selection is Task3; exports/audits/plots and full dual-mode notebook authoring remain subsequent tasks. Their clients must consume diagnostic mode and null core LOW/HIGH/noise fields. Existing default enhanced clients and generated execution remain compatible. Native TT2 still calls its existing threshold/padding implementation then returns an unpadded mask; this avoids histogram rewrites and preserves old candidate diagnostics, at the cost of computing candidate padding internally.

Commit: `116384e31a8027926cdc1131dc79d85bedd682bd` (four owned source/test files only; evidence logs remain untracked for later consolidation).
