# Task 4 provenance fix: independent scoped re-review

Scope: exact diff `b38d640..9227b1d`, updated task-4-report.md and task-4-provenance-fix-review-package.md. Re-review is limited to the original P3 synthetic branch hash lookup finding and potential breakage introduced by this fix. No source edits, refit, study rerun or suites were performed.

**Finding disposition: RESOLVED.**

**Specification verdict: PASS. Quality verdict: APPROVE.** No new actionable findings in the fix diff. The earlier Task 4 numerical findings and Task 6 acceptance boundary remain unchanged.

The new `synthetic_branch_configs` helper uses the same `_branch_params` and `_digest` as waveform row generation. It records full actual branch parameters under their SHA256, algorithm, trial_id and source native model SHA256; native calibration entries remain present. The helper reconstructs parameters without audio, fitting or scoring. Its collision guard rejects ambiguous provenance rather than silently overwriting an entry. Wiring adds the configurations to waveform payloads and the final manifest without changing the predictor, selection, scoring, fixtures or CSV writers.

Bounded independent checks on saved evidence confirmed:

- 19 branch configuration entries, six native models and 1216 waveform rows.
- Every waveform row resolves directly to an entry whose algorithm/trial match that row.
- Every branch key and model_sha256 equals an independently calculated SHA256 of its full saved model.
- Every source native hash resolves to the matching algorithm/mode native record; all six native hashes also independently match their saved models.
- Geometry, endpoint_mode and minimum_speech_ms agree between every row and its referenced model.
- All seven current CSV byte hashes equal both the before and after inventories in provenance-reconstruction-check.json. Thus the saved numerical evidence was preserved.

The added unit test uses an independent literal expected branch configuration, checks parameter hash lookup and source linkage, and checks that native inputs are unmodified. The supplied provenance-focused-green.txt reports 22 passing tests in 4.207 seconds; parent additionally reports a fresh 22-test pass in 4.107 seconds. These are supplied execution results, not tests rerun by this reviewer.

This re-review certifies the scoped provenance fix. It does not extend to whole-branch/global regression acceptance, which remains Task 6.
