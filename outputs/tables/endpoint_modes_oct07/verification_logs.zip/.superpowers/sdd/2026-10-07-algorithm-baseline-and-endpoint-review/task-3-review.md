# Task 3 review

Reviewed range: 116384e31a8027926cdc1131dc79d85bedd682bd..47cc00b.

Spec verdict: PASS within the approved Task 3 scope and minimal compatibility bridge.
Quality verdict: PASS with two minor hardening follow-ups; no Critical or Important findings.

## Strengths

- Fresh models use schema 3 / metrics schema 2, explicitly lock core or enhanced policy, and hash the calibrated model including TRAIN provenance. Legacy inference and imported schema 1/2 parameter/provenance behavior are unchanged by this diff.
- Core fitting skips noise-floor calibration, preserves native TT3 speech-low decisions, uses 0 ms speech filtering and unpadded full-frame support geometry. Enhanced preserves TRAIN noise, 100 ms filtering and immediate TT3 speech-low rejection.
- TT2 evaluates all 50 W values on the four explicit TRAIN records independently for each mode. Rows/manifests carry policy metadata; candidate frame-F1 W is retained separately from selected FINAL W. Invalid region counts make the primary mean undefined while the valid-files-only mean remains explicitly labeled.
- Nullable core LOW/HIGH values are preserved through sweep and CSV/JSON export. The new selection/predictor checks reject mixed mode/filter/padding combinations.
- The recorded full-suite log ends in 153 tests / OK. The regression evidence records 24 fresh enhanced cases matching the baseline in masks, FINAL boundaries, numeric metrics/status and original diagnostics, and protected artifact hashes. These are reviewed existing evidence, not a newly rerun suite.
- Notebook changes are limited to generated definitions/schema expectations and audit acceptance of schema 3. Core figure rendering, CLI routing and full dual-mode notebook kernels remain explicit Task 5 dependencies and are not counted as Task 3 defects.

## Findings

Critical: none.
Important: none.

Minor 1 — Require an actual calibration digest in schema 3 audit.
Location: tools/run_notebooks.py:117 (also schema-3 gate at line 95).
The comparison uses selection.get('calibration_digest') != model.get('calibration_digest'), so two missing values compare equal. A bounded read-only reproduction using a policy-consistent schema-3 TT2-shaped model with both digest fields absent passed audit_model_protocol. The independently supplied model_lock_digest still checks post-lock mutation, and fresh fit_training_model always emits calibration_digest, so this does not break the current fitting path. Require a valid SHA256 field for schema 3 and its selection manifest; ideally verify it against the pre-digest model using the documented stripping/serialization rule. Keep schema 2 acceptance unchanged.

Minor 2 — Check boundary metadata against the predictor geometry in the sweep bridge.
Location: app/weight_selection.py:95-99.
The sweep checks endpoint mode, minimum durations and padding but copies boundary_convention from the supplied model without comparing it with diagnostic.geometry. Thus an externally supplied model labeled with a different boundary convention can produce rows bearing that label while the scorer still uses union-of-frame-support geometry. Fresh Task 3 fit always writes the correct fixed convention, and the schema-3 auditor rejects a different convention, so current generated results remain consistent. Extend the predictor-policy agreement check to the boundary field/geometry when present.

## Review limits

Read-only source/evidence review plus one bounded audit reproduction; no full-suite repetition, source changes, model/notebook generation, Git mutation or subagents. Only this designated scratch report was written.
