### Task2 — Tách quyết định lõi và FINAL policy

**Files:** sửa `app/pipeline.py`, `core/postprocess.py` nếu cần helper vùng trực tiếp; tạo `tests/test_endpoint_modes.py`. Giữ `algorithms/tt1_hodgkinson.py`, số học TT3 và `core/features.py`. Chỉ sửa TT2 helper nếu cần public API unpadded, không rewrite histogram.

**Interfaces:**
- Thêm `algorithm_decision(algorithm: str, features: dict, params: dict) -> tuple[list[int], dict]` trong pipeline: trả native raw decision và threshold diagnostics, không cần LAB/name/duration.
- Giữ `detect_regions(algorithm, features, duration, params) -> dict`; đọc `params['endpoint_mode']`, thiếu mode resolve enhanced. Policy ngoài `{core,enhanced}` báo lỗi.
- Output hiện có mask/final_regions/predicted_boundaries/diagnostic giữ nguyên; thêm mode, native threshold/units, geometry, min speech và padding stage để không nhập nhằng. Ở `core`, `low_ste_threshold`/`high_ste_threshold`/`endpoint_noise` là `None` (JSON null, CSV ô trống), không tạo HIGH/LOW giả; threshold trực tiếp vẫn có trong native threshold/units. Sweep/export/auditor/plot phải đọc theo mode và chấp nhận các trường không áp dụng này.

- [ ] Viết tests: TT1/TT3 equality làspeech; TT2 Energy equality làsilence theo dấu `>`; TT3 core-low giữ đúng raw inequality; core chạy không có endpoint_noise; enhanced vẫn reject low/unknown; legacy thiếu mode bằng enhanced.
- [ ] Viết tests: estimated gap 190→gộp,200/210/250→giữ2; core vùng support80ms vẫn giữ, enhanced loại; không đổi input. WAV zero với model TRAIN hợp lệ không tạo vùng giả; empty features cho emptyregions; TT2 peak0 tránh divide-by-zero.
- [ ] Chạy RED; thêm helper và branch core=raw decisions→merge internal gap 200→FINAL regions, không filter 100. Enhanced dùng logic hiện tại và noise guard của riêng branch đó.
- [ ] Chạy tests mục tiêu: `python -m unittest tests.test_endpoint_modes tests.test_endpoints tests.test_endpoint_robustness tests.test_gaussian_direction_contract -v`. Gate: raw phù hợp inequalities, final không chứa padding/debug, enhanced giữ numeric baseline24 cases.

### Global Constraints

- Giữ3 thuật toán, Python tự tính; TT2 chỉ Energy, không F0/Centroid, không thêm ZCR/thuật toán thứ 4.
- Analysis frame 25 ms, hop 10 ms, nearest samples/ties-to-even; Fs44.1k dùng1102/441samples, thời gian thực được báo cáo.
- Minimum internal silence 200 ms; exact estimated200 ms phải giữ, <200 ms mới nối. Silence đầu/cuối không ép kéo dài200 ms.
- Mỗi FINAL speech region có START/END; không candidate/debug trong primary figure/MAE.
- TRAIN chọn tham số và khóa model trước mở TEST; target LAB chỉ dùng scoring/plot. Không rule filename, GT snapping, TEST tuning hoặc bỏ lỗi lớn.
- Giữ `historical_test_exposure=true`; legacy TEST-calibrated model phải giữ provenance cũ. Đổi protocol không tạo holdout độc lập.
- Metric schema 2 tiếp tục `mae_ms`/`rmse_ms`; thiếu/thừa vùng làm primary undefined, không dùng mean subset thay mean đầy đủ.
- Không sửa slides/PPTX/PDF, dữ liệu Source/audio hoặc ZIP Python cũ. CODE notebook ZIP được cập nhật khi source notebook thay đổi.
- Không hứa MAE core thấp hơn enhanced hoặc timestamp mới làm mọi file tốt lên.



Concrete current-code dependencies: enhanced requires endpoint_noise and TT3 high guard; these become branch-local. TT2 source predict supplies padded candidates but native seed must remain Energy>diagnostic.energy_threshold; retain padded enhanced candidate_regions diagnostics so old reports still match. The tt2-context adaptation thresholds ste_norm directly and remains compatible. Do not change Gaussian arithmetic or feature/framing functions. CORE empty/zero assertions use fitted positive/high TRAIN models; synthetic threshold0/low direction still follows its native inequality. Validate both TT3 known directions in core and reject unknown direction (tt3.predict currently falls through unknown directions to the high inequality). Include algorithm-specific native threshold units in diagnostics. Save task-specific RED/GREEN/full suite logs and 24-case enhanced exact comparison against Task1 baseline (new metadata allowed). Stage only owned source/tests and local commit, no push.


Intermediate integration: when introducing a new helper used by detect_regions, existing standalone notebook generation may need its extraction list updated before Task5. If focused/full suite exposes this dependency, you are authorized to add only the minimal source extraction/comment-anchor bridge in tools/build_notebooks.py and its focused generation test, leaving generated notebooks and full dual-mode notebook redesign to Task5. Report the concrete failure and minimal bridge separately; no production notebook rebuild here.
