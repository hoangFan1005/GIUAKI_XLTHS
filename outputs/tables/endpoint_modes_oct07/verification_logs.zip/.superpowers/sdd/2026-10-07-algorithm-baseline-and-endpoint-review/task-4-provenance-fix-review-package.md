# Review task-4-provenance-fix
Base: b38d640
Head: HEAD

9227b1d Make timing research branch hashes directly traceable
 tests/test_endpoint_robustness.py  | 32 ++++++++++++++++++++++++++++++++
 tools/check_endpoint_robustness.py | 27 +++++++++++++++++++++++++--
 2 files changed, 57 insertions(+), 2 deletions(-)
diff --git a/tests/test_endpoint_robustness.py b/tests/test_endpoint_robustness.py
index a1e735d..6fac93c 100644
--- a/tests/test_endpoint_robustness.py
+++ b/tests/test_endpoint_robustness.py
@@ -308,12 +308,44 @@ class TimingFoldIntegrationTests(unittest.TestCase):
                 self.assertEqual(chosen['candidate_W'],[float(i) for i in range(1,51)])
                 self.assertEqual(chosen['minimum_speech_ms'],model['minimum_speech_ms'])
                 self.assertEqual(chosen['boundary_convention'],model['boundary_convention'])
                 self.assertEqual(model['W'],model['finalW'])
         for summary in payload['summary']:
             if summary['invalid_count']:
                 self.assertIsNone(summary['mean_mae_ms'])
                 self.assertIsNone(summary['mean_file_rmse_ms'])
         self.assertEqual(len(payload['comparisons']),52)
 
+
+
+class SyntheticBranchProvenanceTests(unittest.TestCase):
+    def test_row_hashes_resolve_to_deduplicated_actual_configs_with_native_sources(self):
+        import hashlib
+        tool=importlib.import_module('tools.check_endpoint_robustness')
+        self.assertTrue(hasattr(tool,'synthetic_branch_configs'),'Actual synthetic branch configs must be persisted')
+        digest=lambda value:hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False).encode('utf-8')).hexdigest()
+        native=[]
+        for mode in ('core','enhanced'):
+            for algorithm in ('tt1','tt2','tt3'):
+                model=dict(threshold={'tt1':.2,'tt2':.3,'tt3':.4}[algorithm],endpoint_mode=mode,calibration_digest='native-only',W_selection_train=dict(selected_W=20.))
+                if algorithm=='tt2':model['variant']='source'
+                native.append(dict(mode=mode,algorithm=algorithm,model=model,model_sha256=digest(model)))
+        before=copy.deepcopy(native)
+        configs=tool.synthetic_branch_configs(native)
+        self.assertEqual(native,before)
+        self.assertEqual(len(configs),19)
+        expected=dict(threshold=.2,endpoint_mode='enhanced',trial_id='enhanced_cells_100',geometry='cells',
+            minimum_speech_ms=100.,low_rule='native',boundary_convention='nearest-frame centered decision cells',
+            minimum_silence_ms=200.,endpoint_policy='diagnostic native/hysteresis branch; merge estimated gaps below 200 ms',padding_stage='none')
+        entry=configs[digest(expected)]
+        self.assertEqual(entry['model'],expected)
+        self.assertEqual(entry['algorithm'],'tt1')
+        self.assertEqual(entry['trial_id'],'enhanced_cells_100')
+        source=next(r for r in native if r['mode']=='enhanced' and r['algorithm']=='tt1')
+        self.assertEqual(entry['source_native_model_sha256'],source['model_sha256'])
+        for key,entry in configs.items():
+            self.assertEqual(key,digest(entry['model']))
+            self.assertEqual(entry['model_sha256'],key)
+            self.assertIn(entry['source_native_model_sha256'],[r['model_sha256'] for r in native])
+
 if __name__ == '__main__':
     unittest.main()
diff --git a/tools/check_endpoint_robustness.py b/tools/check_endpoint_robustness.py
index 7cbb3e5..c03581b 100644
--- a/tools/check_endpoint_robustness.py
+++ b/tools/check_endpoint_robustness.py
@@ -439,20 +439,40 @@ def _synthetic_record(samples,fs,speech,name):
     intervals=[];cursor=0.
     for a,b in speech:
         start,end=a/fs,b/fs
         if start>cursor:intervals.append((cursor,start,'sil'))
         intervals.append((start,end,'v'));cursor=end
     if cursor<duration:intervals.append((cursor,duration,'sil'))
     return prepare_records([dict(name=name,split='train',samples=samples,sample_rate=fs,
                                  duration=duration,intervals=intervals)])[0]
 
 
+def synthetic_branch_configs(native_models, trials=TIMING_TRIALS):
+    """Resolve waveform row hashes directly while retaining native calibration sources.
+
+    Reconstruction is deterministic and needs neither audio, fitting nor scoring.
+    Stored branch parameters are exactly those hashed by synthetic waveform rows.
+    """
+    native={(entry['mode'],entry['algorithm']):entry for entry in native_models}
+    configs={}
+    for trial in trials:
+        for algorithm in trial['algorithms']:
+            source=native[trial['endpoint_mode'],algorithm]
+            params=_branch_params(source['model'],trial)
+            digest=_digest(params)
+            entry=dict(model_sha256=digest,algorithm=algorithm,trial_id=trial['trial_id'],
+                       source_native_model_sha256=source['model_sha256'],model=params)
+            if digest in configs and configs[digest] != entry:
+                raise ValueError('Synthetic branch model hash has ambiguous algorithm/trial provenance')
+            configs[digest]=entry
+    return configs
+
 def timing_waveform_study(records):
     """Characterize physical GT separately using locked four-TRAIN models."""
     require_train(records)
     native={(mode,a):fit_training_model(a,records,endpoint_mode=mode)[0]
             for mode in ('core','enhanced') for a in ALGORITHMS}
     rows=[];oracle_cells=[];fixtures=[]
     for fs in (16000,44100):
         hop=round(fs*.01)
         for gap in (190,200,210,250):
             for phase in (0,1,hop//4,hop//2,3*hop//4,hop-1):
@@ -497,22 +517,24 @@ def timing_waveform_study(records):
                 try:
                     result=timing_predictor(a,record,params)
                     extra=dict(final_regions=result['final_regions'],diagnostic=result['diagnostic'],**result['metrics'])
                 except ValueError as error:
                     if 'unsupported LOW=T1' not in str(error):raise
                     extra=dict(status=str(error),mae_ms=None,rmse_ms=None,final_regions=None)
                 rows.append(dict(**metadata,trial_id=trial['trial_id'],algorithm=a,geometry=trial['geometry'],
                     endpoint_mode=trial['endpoint_mode'],minimum_speech_ms=trial['minimum_speech_ms'],
                     model_sha256=_digest(params),threshold_source='locked four-TRAIN calibration; synthetic characterization only',
                     ground_truth_regions=ground_truth_regions(record['intervals']),**extra))
-    return dict(waveforms=rows,oracle_cells=oracle_cells,synthetic_models=[dict(mode=mode,algorithm=a,model=model,
-        model_sha256=_digest(model)) for (mode,a),model in native.items()])
+    synthetic_models=[dict(mode=mode,algorithm=a,model=model,model_sha256=_digest(model))
+                      for (mode,a),model in native.items()]
+    return dict(waveforms=rows,oracle_cells=oracle_cells,synthetic_models=synthetic_models,
+                synthetic_branch_configs=synthetic_branch_configs(synthetic_models))
 
 
 def _write_research_table(name,rows):
     fields=list(dict.fromkeys(k for row in rows for k in row))
     with (TIMING_DESTINATION/f'{name}.csv').open('w',encoding='utf-8-sig',newline='') as handle:
         writer=csv.DictWriter(handle,fieldnames=fields);writer.writeheader()
         for row in rows:writer.writerow({k:_json_value(v) if v is None or isinstance(v,(tuple,list,dict)) else v for k,v in row.items()})
 
 
 def timing_research_main():
@@ -529,20 +551,21 @@ def timing_research_main():
                       ('locked_model_waveforms',synthetic['waveforms']),('fixed_oracle_support',old_oracle),
                       ('fixed_oracle_cells',synthetic['oracle_cells'])):
         _write_research_table(name,rows)
     manifest=dict(parameter_selection_set='train',historical_test_exposure=True,
         evaluation_protocol='four_fold_train_holdout',input_sha256=hashes,trials=TIMING_TRIALS,
         heldout_rows=len(payload['heldout']),tt2_fit_branch_evaluations=len(payload['sweep']),
         declared_TT2_W_candidates=list(range(1,51)),heldout_used_for_selection=False,
         preliminary_native_support_sweeps_are_not_branch_selection=True,
         branch_predictor='tools.check_endpoint_robustness.timing_predictor',selection_scorer='core.metrics.region_endpoint_metrics',
         models=payload['models'],synthetic_models=synthetic['synthetic_models'],
+        synthetic_branch_configs=synthetic['synthetic_branch_configs'],
         limitations=['Cells extend nearest decisions to audio edges and unanalysed tail.',
             'Full analysis windows remain 25 ms (1102 samples at 44.1 kHz).',
             'Cells do not guarantee preservation of physical 200 ms silence.',
             'Physical GT has not been changed; estimated gaps below 200 ms still merge.',
             'Primary full mean remains undefined whenever any held-out score is undefined.',
             'Four TRAIN folds and historically exposed data do not create an independent TEST set.',
             'No default/convention/LOW automatically selected or applied.'])
     (TIMING_DESTINATION/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
     print(f"Research: {len(payload['heldout'])} heldout rows; {len(payload['sweep'])} branch W fit evaluations; {len(synthetic['waveforms'])} locked-model synthetic rows",flush=True)
     return dict(**payload,**synthetic,manifest=manifest)
