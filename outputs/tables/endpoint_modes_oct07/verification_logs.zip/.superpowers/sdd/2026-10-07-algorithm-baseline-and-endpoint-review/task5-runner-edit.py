from pathlib import Path
p=Path('app/weight_selection.py');s=p.read_text();s=s.replace("            for key in ('minimum_speech_ms'", "            if diag.get('geometry', policy['boundary_convention']) != policy['boundary_convention']:\n                raise ValueError('Predictor geometry disagrees with calibration boundary_convention')\n            for key in ('minimum_speech_ms'");p.write_text(s)
p=Path('tools/run_notebooks.py');s=p.read_text();s=s.replace('import argparse','import argparse\nimport copy\nimport os',1);s=s.replace("NOTEBOOK_DIR = ROOT / 'notebooks'", "from app.config import endpoint_mode_root\nNOTEBOOK_DIR = ROOT / 'notebooks'")
s=s.replace("    'algorithm': ALGORITHM,", "    'algorithm': ALGORITHM,\n    'selected_mode': MODE,\n    'models': MODELS,\n    'model_lock_digests': MODEL_LOCK_DIGESTS,\n    'tt2_w_sweeps': TT2W_SWEEPS,\n    'test_results_by_mode': {mode: [_compact_result(result) for result in results] for mode, results in TEST_RESULTS_BY_MODE.items()},\n    'all_results_by_mode': {mode: [_compact_result(result) for result in results] for mode, results in ALL_RESULTS_BY_MODE.items()},\n    'test_summaries_by_mode': TEST_SUMMARIES_BY_MODE,")
s=s.replace("    if model['schema_version'] == 3:", """    if model['schema_version'] == 3:
        declared = model.get('calibration_digest')
        if not isinstance(declared, str) or not re.fullmatch('[0-9a-f]{64}', declared):
            raise ValueError('Model calibration digest must be a nonempty SHA256')
        payload = copy.deepcopy(model)
        payload.pop('calibration_digest', None)
        if 'W_selection_train' in payload:
            payload['W_selection_train'].pop('calibration_digest', None)
        computed = hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False,
                                             allow_nan=False).encode('utf-8')).hexdigest()
        if computed != declared:
            raise ValueError('Model calibration digest differs from self-excluded calibration')""")
s=s.replace("    target = ROOT / 'outputs/tables/tt2_w_selection'", "    target = ((endpoint_mode_root(model['endpoint_mode'], ROOT / 'outputs') / 'tables/tt2_w_selection')\n              if model.get('schema_version') == 3 else ROOT / 'outputs/tables/tt2_w_selection')")
s=s.replace("    scores = [result['metrics'] for result in results]", """    if 'endpoint_mode' in summary:
        from app.pipeline import summarize
        mode = summary['endpoint_mode']
        expected = summarize([dict(file=result['file'],algorithm=algorithm,endpoint_mode=mode,**result['metrics']) for result in results])
        compare_structure(summary, expected[0], 'TEST summary')
        return
    scores = [result['metrics'] for result in results]""")
s=s.replace("def audit_results(audit):\n    algorithm", """def audit_results(audit):
    if 'models' in audit:
        required = {'core', 'enhanced'}
        for key in ('models', 'model_lock_digests', 'tt2_w_sweeps', 'test_results_by_mode', 'all_results_by_mode', 'test_summaries_by_mode'):
            if set(audit.get(key, {})) != required:
                raise ValueError('Both endpoint modes must have independent model/result evidence')
        selected = audit.get('selected_mode')
        if selected not in required:
            raise ValueError('Invalid selected endpoint mode')
        means = {}
        for mode in ('core', 'enhanced'):
            if audit['models'][mode].get('endpoint_mode') != mode:
                raise ValueError('Model mode index disagrees with model')
            item = dict(audit)
            item.pop('models')
            item.update(model=audit['models'][mode],model_lock_digest=audit['model_lock_digests'][mode],
                        tt2_w_sweep_rows=audit['tt2_w_sweeps'][mode],test_results=audit['test_results_by_mode'][mode],
                        all_results=audit['all_results_by_mode'][mode],test_summary=audit['test_summaries_by_mode'][mode])
            means[mode] = audit_results(item)
        for key, expected in (('model',audit['models'][selected]),('model_lock_digest',audit['model_lock_digests'][selected]),
                              ('test_results',audit['test_results_by_mode'][selected]),('all_results',audit['all_results_by_mode'][selected]),
                              ('test_summary',audit['test_summaries_by_mode'][selected]),('tt2_w_sweep_rows',audit['tt2_w_sweeps'][selected])):
            compare_structure(audit.get(key),expected,'Selected mode alias/'+key)
        return means[selected]
    algorithm""")
s=s.replace("    test = audit['test_results']", "    mode = model.get('endpoint_mode', 'enhanced')\n    output_root = endpoint_mode_root(mode, ROOT / 'outputs') if model.get('schema_version') == 3 else ROOT / 'outputs'\n    test = audit['test_results']")
s=s.replace("ROOT / 'outputs/tables/all_all_dataset/test_metrics.csv'", "output_root / 'tables/all_all_dataset/test_metrics.csv'")
s=s.replace("{'file', 'split', 'algorithm'}", "{'file', 'split', 'algorithm', 'endpoint_mode'}")
s=s.replace("        diagnostic = json.loads((ROOT / f'outputs/diagnostics/{algorithm}/{name}.json')", "        if model.get('schema_version') == 3 and result['diagnostic'].get('endpoint_mode') != mode:\n            raise ValueError('Result endpoint mode disagrees with model')\n        diagnostic = json.loads((output_root / f'diagnostics/{algorithm}/{name}.json')")
s=s.replace("ROOT / f'outputs/models/{algorithm}.json'", "output_root / f'models/{algorithm}.json'")
s=s.replace("ROOT / 'outputs/tables/all/summary.csv'", "output_root / 'tables/all/summary.csv'")
s=s.replace("    manager = KernelManager(kernel_name='python3')", "    os.environ.pop('MPLBACKEND', None)  # fresh notebook kernels must render inline PNGs\n    manager = KernelManager(kernel_name='python3')")
s=s.replace("{mean:.2f} ms", "{mean if mean is not None else 'N/A'} ms")
p.write_text(s)
