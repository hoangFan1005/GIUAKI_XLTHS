# Final scoped re-review — 2026-10-07

Reviewed exact fix wave: `d6b616c..7271fb2` (`Isolate partial comparison exports and align handoff docs`). This is one scoped re-review of the four consolidated findings in final-review.md against final-fix-brief.md, final-fix-report.md and final-fix-review-package.md. No implementation edits, subagents, suites, inference runs, notebook kernels, research reruns, staging, commits or cleanup were performed. The only write is this requested scratch review record.

## Verdicts

- **Finding 1 / P2 comparison namespace: ADDRESSED.**
- **Finding 2 / P2 current handoff entry points: ADDRESSED.**
- **Finding 3 / P3 guide metric links: ADDRESSED.**
- **Finding 4 / inherited P3 statistics metadata: ADDRESSED.**
- **New breakage in this diff: none found.**
- **Fix-wave specification: PASS.** All four correction contracts are met within the approved scope.
- **Fix-wave code/documentation quality: APPROVE.** No actionable finding remains in this scoped diff.
- **Whole-branch review blockers from final-review.md: cleared by this fix wave.** Numeric/runtime/artifact acceptance continues to PASS on inspected evidence. Final Task 6 handoff completion still requires the controller-owned archive, scoped cleanup, status and plan-checkbox steps; those are acknowledged sequencing work, not new implementation findings.

## Finding-by-finding assessment

### 1. Complete comparison namespace — ADDRESSED

At app/pipeline.py:668-671 the four canonical comparison CSVs are selected only when evaluate_all is true, input_path is None and selected is exactly the three native algorithms. Other comparisons use comparison/tables/<run_name>, with single/<inputstem> added for a selected file. This preserves useful all_metrics/all_summary/test_metrics/test_summary outputs for fixed-all-dataset, default TEST-only and all/fixed single-file commands while keeping the full benchmark namespace exclusive to the intended full run. The printed comparison path identifies the resulting destination. The shared per-mode TEST benchmark guard at line 628 has the same no-file/exact-algorithm protection.

The new integration regression runs the real tiny-fixture pipeline, creates the full 48-row comparison and captures bytes of all four canonical comparison CSVs plus both modes' shared TEST metric/summary tables. It subsequently runs each fixed algorithm with evaluate-all, default four-TEST comparison and all plus each fixed single-file comparison; it checks unchanged canonical bytes, partial algorithms/modes/file identity and row counts in all four scoped CSVs. A later full run must replace deliberately changed canonical sentinel bytes with the complete original benchmark. This exercises the actual prior failure path and restoration behavior. The existing context-specific run naming remains distinct; selected sets containing tt2-context cannot claim the native canonical namespace.

### 2. Current handoff entry points — ADDRESSED

The outputs and submission README diffs now identify six model-schema-3 models, metric schema 2, 48 algorithm-mode-file cases, three regenerated dual-mode notebooks with 16 mode-file rows each and five PNGs each, TT2 200 TRAIN sweep rows per mode, exact three-notebook CODE ZIP and current permanent acceptance report/final_verification links. Both give the actual 177-test gate, 19.208 seconds unittest / 21.030 seconds wall, exit 0. The older 133-test/schema-2/no-regeneration facts are explicitly historical, and the legacy canonical output inventory is labeled historical. The outputs README describes partial routing and the existing artifact_audit snapshot as pre-final-routing history.

The permanent acceptance report preserves prior gate history and adds the final routing, statistics, source/notebook reuse ruling and evidence. Pending controller handoff wording is intentional at this review checkpoint. The corresponding new bounded documentation regression checks the new current evidence links and markers; it does not reject unrelated historical or future-generated links.

### 3. Guide metric links — ADDRESSED

The three introduced guide links now resolve to outputs/endpoint_modes/enhanced/tables/all/test_metrics.csv. Independent read-only inspection confirms that file exists. TT1 line 279, TT2 line 340 and TT3 line 361 explain algorithm=tt1/tt2/tt3 filtering beside the shared link. The regression checks these exact links and filter notes. No new numeric artifact is needed for the correction.

### 4. Fresh statistics metadata — ADDRESSED

At app/pipeline.py:565-569, the writer uses only the evaluated record for single-file runs; other runs use TRAIN plus evaluated sources. It deduplicates by resolved wav_path and calls unchanged data_statistics with each record's actual split. load_audio_file already resolves the input path and assigns train/test/external based on its actual parent directory. A source with the same basename as a TRAIN WAV remains distinct when its path differs.

The new regression checks eight unique full-run records, four TRAIN/four TEST, one external single-file record with a TRAIN basename, and a full statistics set retaining both the TRAIN and external source with that basename. The approved single-file ruling is satisfied: its scoped CSV describes only its evaluated WAV, while full statistics/training_frames provide TRAIN context. Independent reads of both delivered fresh mode CSVs confirm eight rows, eight unique filenames, four train and four test rows. The CSV diff removes duplicated TRAIN/evaluation copies and replaces all_dataset labels on actual TEST rows with test; retained numerical statistics are unchanged. Old canonical CSVs are outside the changed paths.

## Evidence and regression boundaries

The exact commit diff contains 11 files, 175 insertions and 53 deletions. The production change is limited to run_experiment export routing/statistics. The added tests use real run_experiment fixtures with figure operations suppressed and temporary output roots. No detector feature/decision/detection/fit/metric arithmetic, thresholds, W, calibration or CLI defaults are changed.

Inspected retained evidence:

- task6-full-suite.txt ends `Ran 177 tests in 19.208s` / `OK`; task6-full-suite.json records exit 0, passed true and 21.0301513 seconds wall time.
- final-fix-report.md retains the RED failures and the completed 14-test focused GREEN (4.378 seconds), plus final bounded documentation GREEN.
- final-fix-source-audit.json records all seven pipeline functions AST-identical to d6b616c (prepare_records, algorithm_decision, detect_regions, predict_and_score, fit_training_model, summarize, data_statistics); notebook code/full hashes and CODE ZIP hash are unchanged, with five images and a passing dual-model audit for each saved notebook.
- Metadata refresh evidence records exactly the two intentional fresh dataset_statistics CSV changes, with the other 195 of 197 fresh artifacts unchanged. The reviewed diff has no notebook or CODE ZIP change.
- The live final_verification.json reports 24 enhanced exact cases, 48 scored cases, six models locked before TEST and unchanged after inference, saved/fresh native calibration exact, and 124 protected hashes out of 148 baseline entries. The post-commit acceptance runtime is 1.4751575 seconds. Its unstaged delta relative to 7271fb2 is confined to verification time, refreshed current README hash snapshots and runtime, matching the controller's declared intentional metadata refresh after packaging the diff.

The controller also supplied three saved-notebook validate-only PASS after commit. That supplied observation was not repeated here. This reviewer inspected saved audit evidence and unchanged artifact scope rather than claiming fresh kernels or independently rerunning acceptance.

## Remaining work and limitations

No new correctness, preservation, source-provenance or documentation blocker was found in this fix diff. Native math and the previously accepted numeric/standalone artifact evidence remain intact. Known core count failures, undefined primary metrics, physical-silence limitations, historical TEST exposure and unverified Python 3.10 runtime remain disclosed; none is introduced by this diff.

Controller-owned archive/cleanup/final status and plan checkboxes remain pending after this review. This report approves the scoped fixes and clears the four review findings; it does not assert those final controller actions have already occurred. No additional suite, notebook execution or research rerun is justified by this review.

Read/review tool calls used require_escalated under the authorized review scope because the controller reported default helper setup failures. No approval rejection or blocked review action occurred here.
