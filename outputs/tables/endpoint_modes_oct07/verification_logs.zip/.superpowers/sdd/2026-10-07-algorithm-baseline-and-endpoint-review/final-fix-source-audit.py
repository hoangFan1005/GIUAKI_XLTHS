"""Read-only compatibility audit against the reviewed pre-fix revision."""
import ast,csv,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'outputs/tables/endpoint_modes_oct07'
before=ast.parse(subprocess.check_output(['git','show','d6b616c:app/pipeline.py'],cwd=ROOT).decode('utf-8-sig'))
after=ast.parse((ROOT/'app/pipeline.py').read_text(encoding='utf-8-sig'))
names=('prepare_records','algorithm_decision','detect_regions','predict_and_score','fit_training_model','summarize','data_statistics')
def source(tree,name):return ast.dump(next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name),include_attributes=False)
unchanged={name:source(before,name)==source(after,name) for name in names}
assert all(unchanged.values()),unchanged
prior=json.loads((OUT/'final_verification-before-final-review-fix.json').read_text(encoding='utf-8'))
current=json.loads((OUT/'final_verification.json').read_text(encoding='utf-8'))
assert prior['code_zip_sha256']==current['code_zip_sha256']
for old,new in zip(prior['notebooks'],current['notebooks']):
    assert old['file']==new['file'] and old['sha256']==new['sha256'] and old['code_source_sha256']==new['code_source_sha256']
stats={}
for mode in ('core','enhanced'):
    with (ROOT/f'outputs/endpoint_modes/{mode}/tables/dataset_statistics.csv').open(encoding='utf-8-sig') as handle:rows=list(csv.DictReader(handle))
    stats[mode]=dict(rows=len(rows),unique_files=len({r['file'] for r in rows}),train=sum(r['split']=='train' for r in rows),test=sum(r['split']=='test' for r in rows))
    assert stats[mode]==dict(rows=8,unique_files=8,train=4,test=4)
result=dict(reviewed_reference='d6b616c',embedded_pipeline_functions_and_statistics_arithmetic_unchanged=unchanged,notebook_bytes_and_code_digests_exact_before_after=True,code_zip_sha256=current['code_zip_sha256'],notebooks=current['notebooks'],fresh_statistics=stats,current_pipeline_sha256=hashlib.sha256((ROOT/'app/pipeline.py').read_bytes()).hexdigest())
(OUT/'final-fix-source-audit.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps(dict(unchanged_functions=unchanged,notebook_and_zip_exact=True,statistics=stats)))
