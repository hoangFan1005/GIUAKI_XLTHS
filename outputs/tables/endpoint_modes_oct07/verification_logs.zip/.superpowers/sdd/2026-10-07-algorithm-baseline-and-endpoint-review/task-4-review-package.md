# Review task-4
Base: 47cc00b
Head: HEAD

27dc471 Add TRAIN-only endpoint timing research
 core/decision_timing.py            |  25 ++++
 tests/test_decision_timing.py      |  71 ++++++++++
 tests/test_endpoint_robustness.py  |  62 ++++++++
 tools/check_endpoint_robustness.py | 283 ++++++++++++++++++++++++++++++++++++-
 4 files changed, 438 insertions(+), 3 deletions(-)
diff --git a/core/decision_timing.py b/core/decision_timing.py
new file mode 100644
index 0000000..dbaf532
--- /dev/null
+++ b/core/decision_timing.py
@@ -0,0 +1,25 @@
+"""Experimental nearest-frame decision cells; production supports stay unchanged.
+
+Internal edges use actual center midpoints, including half samples. The outer
+cells extend to audio edges and include the unanalysed incomplete frame tail.
+Analysis windows are never changed by this timing convention.
+"""
+import math
+
+
+def decision_cells(features: dict, duration: float) -> tuple[list[float], list[float]]:
+    """Return one disjoint, positive cell per finite ordered in-audio center."""
+    if not math.isfinite(duration) or duration < 0:
+        raise ValueError('Duration must be finite and nonnegative')
+    centers = features['centers']
+    previous = -1.
+    for center in centers:
+        if not math.isfinite(center) or not 0 <= center < duration or center <= previous:
+            raise ValueError('Centers must be finite, strictly ordered and inside audio')
+        previous = center
+    if not centers:
+        return [], []
+    edges = [0.] + [(a+b)/2 for a,b in zip(centers,centers[1:])] + [duration]
+    if any(b <= a for a,b in zip(edges,edges[1:])):
+        raise ValueError('Decision cells must have positive duration')
+    return edges[:-1], edges[1:]
diff --git a/tests/test_decision_timing.py b/tests/test_decision_timing.py
new file mode 100644
index 0000000..b6da1da
--- /dev/null
+++ b/tests/test_decision_timing.py
@@ -0,0 +1,71 @@
+"""Independent midpoint and duration-rule oracles for diagnostic decision cells."""
+import importlib
+import unittest
+
+class DecisionTimingTests(unittest.TestCase):
+    def helper(self):
+        self.assertIsNotNone(importlib.util.find_spec('core.decision_timing'), 'Decision-cell helper is required')
+        return importlib.import_module('core.decision_timing').decision_cells
+
+    def test_midpoints_cover_audio_and_extend_unanalysed_tail(self):
+        cells = self.helper()
+        for fs, centers, middle in ((16000, [.0125,.0225,.0325], [.0175,.0275]),
+                                    (44100, [551/44100,992/44100,1433/44100], [771.5/44100,1212.5/44100])):
+            with self.subTest(fs=fs):
+                starts, ends = cells(dict(centers=centers), .049)
+                self.assertEqual(starts, [0.,*middle])
+                self.assertEqual(ends, [*middle,.049])
+                self.assertAlmostEqual(sum(e-s for s,e in zip(starts,ends)), .049)
+
+    def test_empty_one_frame_and_invalid_centers(self):
+        cells = self.helper()
+        self.assertEqual(cells(dict(centers=[]), 0.), ([],[]))
+        self.assertEqual(cells(dict(centers=[.0125]), .03), ([0.],[.03]))
+        for centers,duration in (([.02,.01],.1),([.01,.01],.1),([float('nan')],.1),([-.01],.1),([.2],.1),([.01],0.),([],float('inf'))):
+            with self.subTest(centers=centers), self.assertRaises(ValueError):
+                cells(dict(centers=centers),duration)
+
+    def test_cell_gap_190_merges_exact_200_and_210_survive(self):
+        from core.endpoints import hysteresis_regions, regions_to_mask
+        cells = self.helper()
+        for fs in (16000,44100):
+            offset = round(fs*.025)/(2*fs)-.0125
+            for gap,count in ((.19,1),(.2,2),(.21,2)):
+                # Literal midpoints yield [.1,.2] and [.2+gap,.3+gap].
+                centers = [x+offset for x in [.05,.15,.25,.15+2*gap,.45+2*gap]]
+                starts,ends = cells(dict(centers=centers), 1.)
+                values=[0.,.8,0.,.8,0.]
+                result=hysteresis_regions(values,starts,ends,1.,.1,.5,.2,0.)
+                expected=[(.1+offset,.3+2*gap+offset)] if count==1 else [(.1+offset,.2+offset),(.2+gap+offset,.3+2*gap+offset)]
+                self.assertEqual(len(result),count)
+                for pair,want in zip(result,expected):
+                    for x,y in zip(pair,want):self.assertAlmostEqual(x,y)
+                self.assertEqual(regions_to_mask(result,starts,ends),[0,1,1,1,0] if count==1 else [0,1,0,1,0])
+
+
+
+
+class EstimatedCellSpanTests(unittest.TestCase):
+    def test_estimated_95_removed_exact_100_and_105_retained(self):
+        from core.decision_timing import decision_cells
+        from core.endpoints import hysteresis_regions
+        for span,expected in ((.095,[]),(.100,[(.1,.2)]),(.105,[(.1,.205)])):
+            centers=[.05,.15,.05+2*span,.35+2*span]
+            starts,ends=decision_cells(dict(centers=centers),.8)
+            result=hysteresis_regions([0.,.8,0.,0.],starts,ends,.8,.1,.5,.2,.1)
+            self.assertEqual(len(result),len(expected))
+            for pair,want in zip(result,expected):
+                for a,b in zip(pair,want):self.assertAlmostEqual(a,b)
+
+    def test_speech_at_edges_uses_0_duration_and_last_cell_tail(self):
+        from core.decision_timing import decision_cells
+        from core.endpoints import hysteresis_regions,regions_to_mask
+        for centers in ([.0125,.0225,.0325],[551/44100,992/44100,1433/44100]):
+            starts,ends=decision_cells(dict(centers=centers),.049)
+            for values,want_mask in (([.8,0.,0.],[1,0,0]),([0.,0.,.8],[0,0,1])):
+                result=hysteresis_regions(values,starts,ends,.049,.1,.5,.2,0.)
+                self.assertEqual(regions_to_mask(result,starts,ends),want_mask)
+                if values[0]:self.assertEqual(result[0][0],0.)
+                else:self.assertEqual(result[0][1],.049)
+
+if __name__=='__main__':unittest.main()
diff --git a/tests/test_endpoint_robustness.py b/tests/test_endpoint_robustness.py
index 367b686..a1e735d 100644
--- a/tests/test_endpoint_robustness.py
+++ b/tests/test_endpoint_robustness.py
@@ -246,12 +246,74 @@ class DiagnosticToolTests(unittest.TestCase):
             payload = self.tool.main()
         self.assertEqual(calls, [TRAIN_DIR])
         self.assertEqual(len(payload['ablation']), 48)
         writer.assert_called_once()
         self.assertEqual(payload['manifest']['parameter_selection_set'], 'train')
         self.assertTrue(payload['manifest']['historical_test_exposure'])
         self.assertEqual(payload['manifest']['training_files'], [r['name'] for r in records])
         self.assertEqual(models['tt2']['W'], 20.)
 
 
+
+
+class TimingResearchTests(unittest.TestCase):
+    def setUp(self):
+        self.tool=importlib.import_module('tools.check_endpoint_robustness')
+
+    def test_cells_branch_scores_cell_membership_and_audio_edges(self):
+        self.assertTrue(hasattr(self.tool,'timing_predictor'), 'Shared research predictor required')
+        f=dict(centers=[.0125,.0225,.0325],starts=[0.,.01,.02],ends=[.025,.035,.045],ste_norm=[1.,0.,1.])
+        record=dict(name='edge',split='train',features=f,duration=.05,labels=[1,1,1],intervals=[(0.,.05,'v')])
+        params=dict(endpoint_mode='core',threshold=.5,geometry='cells',minimum_speech_ms=0.)
+        result=self.tool.timing_predictor('tt1',record,params)
+        self.assertEqual(result['final_regions'],[(0.,.05)])
+        self.assertEqual(result['mask'],[1,1,1])
+        self.assertEqual(result['metrics']['mae_ms'],0.)
+
+    def test_trial_matrix_is_bounded_one_factor_and_rejects_nontrain(self):
+        self.assertTrue(hasattr(self.tool,'TIMING_TRIALS'), 'Declared matrix required')
+        trials=self.tool.TIMING_TRIALS
+        self.assertEqual(len(trials),7)
+        self.assertEqual(sum(len(t['algorithms']) for t in trials)*4,76)
+        self.assertNotIn(('cells',0.,'enhanced'),{(t['geometry'],t['minimum_speech_ms'],t['endpoint_mode']) for t in trials})
+        with self.assertRaisesRegex(ValueError,'TRAIN'):
+            self.tool.timing_training_study([dict(split='test')])
+
+    def test_t1_zero_is_explicitly_unsupported_without_floor(self):
+        self.assertTrue(hasattr(self.tool,'timing_predictor'))
+        f=dict(centers=[.0125],starts=[0.],ends=[.025],ste_norm=[1.])
+        record=dict(name='zero',split='train',features=f,duration=.03,labels=[1],intervals=[(0.,.03,'v')])
+        params=dict(endpoint_mode='enhanced',threshold=0.,geometry='support',minimum_speech_ms=100.,low_rule='T1',
+                    endpoint_noise=dict(noise_upper=.03))
+        with self.assertRaisesRegex(ValueError,'unsupported LOW=T1'):
+            self.tool.timing_predictor('tt1',record,params)
+
+class TimingFoldIntegrationTests(unittest.TestCase):
+    def test_real_train_folds_budget_locked_geometry_and_full_undefined_scores(self):
+        tool=importlib.import_module('tools.check_endpoint_robustness')
+        records=prepare_records(load_audio_folder(TRAIN_DIR))
+        before=copy.deepcopy(records)
+        with redirect_stdout(io.StringIO()):payload=tool.timing_training_study(records)
+        self.assertEqual(records,before)
+        self.assertEqual(len(payload['heldout']),76)
+        self.assertEqual(len(payload['sweep']),3600)
+        self.assertEqual(len(payload['models']),76)
+        for entry in payload['models']:
+            self.assertEqual(len(entry['fit_files']),3)
+            self.assertNotIn(entry['heldout_file'],entry['fit_files'])
+            model=entry['model']
+            self.assertEqual(model['historical_test_exposure'],True)
+            self.assertEqual(model['boundary_convention'],'nearest-frame centered decision cells' if model['geometry']=='cells' else 'union of active frame supports')
+            if entry['algorithm']=='tt2':
+                chosen=model['W_selection_train']
+                self.assertEqual(chosen['candidate_W'],[float(i) for i in range(1,51)])
+                self.assertEqual(chosen['minimum_speech_ms'],model['minimum_speech_ms'])
+                self.assertEqual(chosen['boundary_convention'],model['boundary_convention'])
+                self.assertEqual(model['W'],model['finalW'])
+        for summary in payload['summary']:
+            if summary['invalid_count']:
+                self.assertIsNone(summary['mean_mae_ms'])
+                self.assertIsNone(summary['mean_file_rmse_ms'])
+        self.assertEqual(len(payload['comparisons']),52)
+
 if __name__ == '__main__':
     unittest.main()
diff --git a/tools/check_endpoint_robustness.py b/tools/check_endpoint_robustness.py
index 8bc8819..7cbb3e5 100644
--- a/tools/check_endpoint_robustness.py
+++ b/tools/check_endpoint_robustness.py
@@ -1,15 +1,15 @@
 """Bounded synthetic characterization and four-arm TRAIN endpoint ablation.
 
-Run: python tools/check_endpoint_robustness.py
+Run: python tools/check_endpoint_robustness.py [--timing-research]
 Reads only TRAIN WAV/LABs. Writes diagnostic CSV/JSON only beneath
-outputs/tables/endpoint_robustness; never changes fitted production artifacts.
+outputs/tables/endpoint_robustness (legacy) or endpoint_modes_oct07/timing_research; never changes fitted production artifacts.
 Support gaps are estimates: true 200/210ms zero intervals can still be merged.
 """
 from __future__ import annotations
 
 import csv
 import hashlib
 import json
 import sys
 from pathlib import Path
 
@@ -263,12 +263,289 @@ def main():
                    ablation=ablate_training(records,models),manifest=manifest)
     payload['summary'] = ablation_summary(payload['ablation'])
     write_diagnostics(payload)
     known = sum(r['status']=='known_limitation' for r in payload['waveforms'])
     print(f"Synthetic: {len(payload['waveforms'])} gap cases; {known} known true200/210ms limitations.")
     print(f"TRAIN: {len(payload['ablation'])} fixed-model rows; W={models['tt2']['W']:g}; "
           f"invalid counts remain explicit. Diagnostics: {DESTINATION}")
     return payload
 
 
+
+
+# Task 4 diagnostic branches: one factor at a time, never production policy.
+from copy import deepcopy
+from core.decision_timing import decision_cells
+from app.pipeline import algorithm_decision
+from app.weight_selection import select_final_weight
+
+TIMING_DESTINATION = OUTPUT_DIR / 'tables' / 'endpoint_modes_oct07' / 'timing_research'
+TIMING_TRIALS = [
+    dict(trial_id=trial_id,endpoint_mode=mode,geometry=geometry,minimum_speech_ms=minimum,
+         low_rule=low_rule,algorithms=ALGORITHMS if low_rule=='native' else ('tt1',))
+    for trial_id,mode,geometry,minimum,low_rule in (
+        ('core_support_0','core','support',0.,'native'),
+        ('core_cells_0','core','cells',0.,'native'),
+        ('core_support_100','core','support',100.,'native'),
+        ('enhanced_support_100','enhanced','support',100.,'native'),
+        ('enhanced_cells_100','enhanced','cells',100.,'native'),
+        ('enhanced_support_0','enhanced','support',0.,'native'),
+        ('enhanced_tt1_t1_support_100','enhanced','support',100.,'T1'))]
+
+
+def timing_predictor(algorithm, record, params):
+    """Same LAB-free experimental detector for fit W candidates and held-out scores.
+
+    Geometry controls every start/end, merge, duration filter and final mask.
+    Labels enter only the scorer after final detection. Native TT2 is unpadded.
+    """
+    f,duration=record['features'],record['duration']
+    geometry=params['geometry']; mode=params['endpoint_mode']
+    if geometry not in ('support','cells') or mode not in ('core','enhanced'):
+        raise ValueError('Unknown research geometry or endpoint mode')
+    starts,ends=decision_cells(f,duration) if geometry=='cells' else (f['starts'],f['ends'])
+    seed,diag=algorithm_decision(algorithm,f,params)
+    minimum=params['minimum_speech_ms']/1000
+    candidate=[(s,e) for s,e,k in mask_segments(seed,starts,duration,ends) if k]
+    low=high=None
+    if mode=='core':
+        merged=[]
+        for start,end in candidate:
+            if merged and start-merged[-1][1]<.2-1e-12:merged[-1]=(merged[-1][0],end)
+            else:merged.append((start,end))
+        final=[(s,e) for s,e in merged if e-s>=minimum-1e-12]
+    else:
+        if algorithm=='tt3' and params.get('speech_direction','high')!='high':
+            raise ValueError('Enhanced requires speech-high TT3')
+        if algorithm=='tt2':
+            peak=max(f['energy'],default=0.)
+            base=diag['energy_threshold']/peak if peak else 0.
+        else:base=params['threshold']
+        if params.get('low_rule')=='T1':
+            low=base; high=max(1.5*base,params['endpoint_noise']['noise_upper'])
+            if not 0<low<high:raise ValueError('unsupported LOW=T1: invalid hysteresis thresholds')
+        else:low,high=endpoint_thresholds(base,params['endpoint_noise'],histogram=algorithm=='tt2')
+        final=hysteresis_regions(f['ste_norm'],starts,ends,duration,low,high,.2,minimum,seed_mask=seed)
+    # Passing the chosen timing arrays provides whole-cell containment for cells.
+    mask=regions_to_mask(final,starts,ends)
+    diag.update(endpoint_mode=mode,geometry=geometry,boundary_convention=params.get('boundary_convention','nearest-frame centered decision cells' if geometry=='cells' else 'union of active frame supports'),
+        minimum_speech_ms=params['minimum_speech_ms'],minimum_silence_ms=200.,
+        padding_stage=params.get('padding_stage','excluded from core FINAL' if mode=='core' else 'none'),low_ste_threshold=low,high_ste_threshold=high,
+        candidate_regions=candidate,raw_speech_frames=sum(seed),final_regions=final,
+        last_native_active_end_s=_last_support(seed,ends))
+    reference=ground_truth_regions(record['intervals'])
+    return dict(mask=mask,final_regions=final,diagnostic=diag,metrics=region_endpoint_metrics(reference,final),
+                frame_metrics=frame_metrics(record['labels'],mask))
+
+
+def _branch_params(native,trial):
+    params=deepcopy(native)
+    # Native calibration digest and support W provenance are preliminary only.
+    params.pop('calibration_digest',None)
+    params.pop('W_selection_train',None)
+    params.update({k:v for k,v in trial.items() if k!='algorithms'})
+    params.update(boundary_convention='nearest-frame centered decision cells' if trial['geometry']=='cells'
+                  else 'union of active frame supports',minimum_silence_ms=200.,
+                  endpoint_policy='diagnostic native/hysteresis branch; merge estimated gaps below 200 ms',
+                  padding_stage='excluded from core FINAL' if trial['endpoint_mode']=='core'
+                  else 'candidate diagnostics only' if native.get('variant')=='source' else 'none')
+    return params
+
+
+def _digest(value):
+    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False).encode('utf-8')).hexdigest()
+
+
+def timing_training_study(records):
+    """Four deterministic TRAIN folds; separate W=1..50 selection per branch."""
+    require_train(records)
+    records=sorted(records,key=lambda r:r['name'])
+    if len(records)!=4 or len({r['name'] for r in records})!=4:
+        raise ValueError('Exactly four distinct TRAIN records required')
+    heldout_rows=[]; sweep_rows=[]; models=[]
+    for fold,heldout in enumerate(records,1):
+        fit=[r for r in records if r is not heldout]
+        native={(mode,a):fit_training_model(a,fit,endpoint_mode=mode)[0]
+                for mode in ('core','enhanced') for a in ALGORITHMS}
+        for trial in TIMING_TRIALS:
+            for algorithm in trial['algorithms']:
+                params=_branch_params(native[trial['endpoint_mode'],algorithm],trial)
+                selection=None
+                if algorithm=='tt2':
+                    branch_rows=[]
+                    for w in range(1,51):
+                        candidate_params=dict(params,W=float(w),finalW=float(w))
+                        for record in fit:
+                            result=timing_predictor(algorithm,record,candidate_params)
+                            metrics=result['metrics']
+                            branch_rows.append(dict(filename=record['name'],W=float(w),
+                                endpoint_mode=trial['endpoint_mode'],boundary_convention=params['boundary_convention'],
+                                minimum_speech_ms=trial['minimum_speech_ms'],minimum_silence_ms=200.,
+                                padding_stage=params['padding_stage'],final_region_mae_ms=metrics['mae_ms'],
+                                ground_truth_region_count=metrics['ground_truth_region_count'],
+                                predicted_region_count=metrics['predicted_region_count'],status=metrics['status']))
+                    selection=select_final_weight(branch_rows)
+                    selection.update(trial_id=trial['trial_id'],geometry=trial['geometry'],low_rule=trial['low_rule'],
+                                     branch_predictor='tools.check_endpoint_robustness.timing_predictor',
+                                     selection_scorer='core.metrics.region_endpoint_metrics',evaluated_files=[r['name'] for r in fit])
+                    params.update(W=selection['selected_W'],finalW=selection['selected_W'],
+                                  W_selection_train=selection,parameter_rule=selection['selection_rule'])
+                    sweep_rows.extend(dict(fold=fold,trial_id=trial['trial_id'],geometry=trial['geometry'],**r) for r in branch_rows)
+                params.update(training_files=[r['name'] for r in fit],evaluation_protocol='four_fold_train_holdout',
+                              branch_predictor='tools.check_endpoint_robustness.timing_predictor',selection_scorer='core.metrics.region_endpoint_metrics')
+                digest=_digest(params)
+                models.append(dict(fold=fold,algorithm=algorithm,trial_id=trial['trial_id'],heldout_file=heldout['name'],
+                    fit_files=params['training_files'],model_sha256=digest,model=params,
+                    preliminary_native_W=native[trial['endpoint_mode'],algorithm].get('W'),
+                    preliminary_native_digest=native[trial['endpoint_mode'],algorithm].get('calibration_digest')))
+                try:
+                    result=timing_predictor(algorithm,heldout,params)
+                    scores=result['metrics']
+                    row=dict(**scores,final_regions=result['final_regions'],diagnostic=result['diagnostic'],
+                             **{f'frame_{k}':v for k,v in result['frame_metrics'].items()})
+                    if trial['trial_id'] in ('core_support_0','enhanced_support_100'):
+                        production=detect_regions(algorithm,heldout['features'],heldout['duration'],params)
+                        if production['final_regions']!=result['final_regions'] or production['mask']!=result['mask']:
+                            raise AssertionError('Matching support baseline differs from production')
+                except ValueError as error:
+                    if 'unsupported LOW=T1' not in str(error):raise
+                    row=dict(status=str(error),mae_ms=None,rmse_ms=None,missing_region_count=0,
+                             extra_region_count=0,signed_endpoint_errors_ms=[],region_pairs=[],final_regions=None)
+                heldout_rows.append(dict(fold=fold,file=heldout['name'],algorithm=algorithm,
+                    trial_id=trial['trial_id'],arm=trial['trial_id'],geometry=trial['geometry'],endpoint_mode=trial['endpoint_mode'],
+                    low_rule=trial['low_rule'],minimum_speech_ms=trial['minimum_speech_ms'],W=params.get('W'),
+                    model_sha256=digest,fit_files=params['training_files'],**row))
+        print(f'Timing TRAIN fold {fold}/4 complete',flush=True)
+    if len(heldout_rows)!=76 or len(sweep_rows)!=3600:raise AssertionError('Declared evaluation budget changed')
+    comparisons=[]
+    for row in heldout_rows:
+        baseline_id='core_support_0' if row['endpoint_mode']=='core' else 'enhanced_support_100'
+        if row['trial_id']==baseline_id:continue
+        baseline=next(r for r in heldout_rows if r['fold']==row['fold'] and r['algorithm']==row['algorithm'] and r['trial_id']==baseline_id)
+        a,b=row['mae_ms'],baseline['mae_ms']
+        comparisons.append(dict(fold=row['fold'],file=row['file'],algorithm=row['algorithm'],trial_id=row['trial_id'],
+            baseline_trial_id=baseline_id,baseline_status=baseline['status'],status=row['status'],
+            baseline_mae_ms=b,mae_ms=a,delta_mae_ms=a-b if a is not None and b is not None else None,
+            baseline_rmse_ms=baseline['rmse_ms'],rmse_ms=row['rmse_ms'],
+            delta_rmse_ms=row['rmse_ms']-baseline['rmse_ms'] if row['rmse_ms'] is not None and baseline['rmse_ms'] is not None else None,
+            validity_transition=f'{"valid" if b is not None else "undefined"}->{"valid" if a is not None else "undefined"}',
+            count_regression=row['missing_region_count']+row['extra_region_count']>baseline['missing_region_count']+baseline['extra_region_count'],
+            metric_regression=a is not None and b is not None and a>b+1e-8,
+            rmse_regression=row['rmse_ms'] is not None and baseline['rmse_ms'] is not None and row['rmse_ms']>baseline['rmse_ms']+1e-8))
+    return dict(heldout=heldout_rows,sweep=sweep_rows,models=models,comparisons=comparisons,summary=ablation_summary(heldout_rows))
+
+
+def _synthetic_record(samples,fs,speech,name):
+    duration=len(samples)/fs
+    intervals=[];cursor=0.
+    for a,b in speech:
+        start,end=a/fs,b/fs
+        if start>cursor:intervals.append((cursor,start,'sil'))
+        intervals.append((start,end,'v'));cursor=end
+    if cursor<duration:intervals.append((cursor,duration,'sil'))
+    return prepare_records([dict(name=name,split='train',samples=samples,sample_rate=fs,
+                                 duration=duration,intervals=intervals)])[0]
+
+
+def timing_waveform_study(records):
+    """Characterize physical GT separately using locked four-TRAIN models."""
+    require_train(records)
+    native={(mode,a):fit_training_model(a,records,endpoint_mode=mode)[0]
+            for mode in ('core','enhanced') for a in ALGORITHMS}
+    rows=[];oracle_cells=[];fixtures=[]
+    for fs in (16000,44100):
+        hop=round(fs*.01)
+        for gap in (190,200,210,250):
+            for phase in (0,1,hop//4,hop//2,3*hop//4,hop-1):
+                samples,speech=rectangular_case(fs,phase,gap)
+                record=_synthetic_record(samples,fs,speech,f'gap_{fs}_{gap}_{phase}')
+                metadata=dict(case='physical_gap',sample_rate_hz=fs,phase_samples=phase,
+                              true_gap_ms=(speech[1][0]-speech[0][1])/fs*1000)
+                fixtures.append((record,metadata))
+                f=record['features'];starts,ends=decision_cells(f,record['duration'])
+                values,supports=_overlap_oracle(speech,len(starts),f['frame_size'],f['hop_size'],fs)
+                # Independent cell LOW gap from literal integer-overlap active indices.
+                runs=[]
+                for i in range(len(starts)):
+                    count=sum(max(0,min(i*f['hop_size']+f['frame_size'],b)-max(i*f['hop_size'],a)) for a,b in speech)
+                    if count*10>=f['frame_size']:
+                        if runs and i==runs[-1][1]+1:runs[-1]=(runs[-1][0],i)
+                        else:runs.append((i,i))
+                left=runs[0][1];right=runs[1][0]
+                left_edge=((left+.5)*f['hop_size']+f['frame_size']/2)/fs
+                right_edge=((right-.5)*f['hop_size']+f['frame_size']/2)/fs
+                final=hysteresis_regions(values,starts,ends,record['duration'],.1,.5,.2,.1)
+                oracle_cells.append(dict(**metadata,geometry='cells',threshold_source='fixed diagnostic LOW=.1 HIGH=.5',
+                    estimated_cell_gap_ms=(right_edge-left_edge)*1000,support_gap_ms=(supports[1][0]-supports[0][1])*1000,
+                    low=.1,high=.5,final_regions=final,**region_endpoint_metrics(ground_truth_regions(record['intervals']),final)))
+        for burst in (75,95,100,105):
+            a=round(fs*.1);b=a+round(fs*burst/1000)
+            samples=[0.]*a+[1.]*(b-a)+[0.]*round(fs*.3)
+            fixtures.append((_synthetic_record(samples,fs,[(a,b)],f'burst_{fs}_{burst}'),
+                dict(case='physical_burst',sample_rate_hz=fs,true_speech_ms=(b-a)/fs*1000)))
+        for edge in ('start','end','both','weak_tail'):
+            n=round(fs*.6);a=0 if edge in ('start','both') else round(fs*.1)
+            b=n if edge in ('end','both','weak_tail') else round(fs*.4)
+            samples=[0.]*n
+            samples[a:b]=[1.]*(b-a)
+            if edge=='weak_tail':samples[round(fs*.4):b]=[.05]*(b-round(fs*.4))
+            fixtures.append((_synthetic_record(samples,fs,[(a,b)],f'edge_{fs}_{edge}'),
+                dict(case='physical_edge_or_tail',sample_rate_hz=fs,edge=edge,weak_tail_amplitude=.05 if edge=='weak_tail' else None)))
+    for record,metadata in fixtures:
+        for trial in TIMING_TRIALS:
+            for a in trial['algorithms']:
+                params=_branch_params(native[trial['endpoint_mode'],a],trial)
+                try:
+                    result=timing_predictor(a,record,params)
+                    extra=dict(final_regions=result['final_regions'],diagnostic=result['diagnostic'],**result['metrics'])
+                except ValueError as error:
+                    if 'unsupported LOW=T1' not in str(error):raise
+                    extra=dict(status=str(error),mae_ms=None,rmse_ms=None,final_regions=None)
+                rows.append(dict(**metadata,trial_id=trial['trial_id'],algorithm=a,geometry=trial['geometry'],
+                    endpoint_mode=trial['endpoint_mode'],minimum_speech_ms=trial['minimum_speech_ms'],
+                    model_sha256=_digest(params),threshold_source='locked four-TRAIN calibration; synthetic characterization only',
+                    ground_truth_regions=ground_truth_regions(record['intervals']),**extra))
+    return dict(waveforms=rows,oracle_cells=oracle_cells,synthetic_models=[dict(mode=mode,algorithm=a,model=model,
+        model_sha256=_digest(model)) for (mode,a),model in native.items()])
+
+
+def _write_research_table(name,rows):
+    fields=list(dict.fromkeys(k for row in rows for k in row))
+    with (TIMING_DESTINATION/f'{name}.csv').open('w',encoding='utf-8-sig',newline='') as handle:
+        writer=csv.DictWriter(handle,fieldnames=fields);writer.writeheader()
+        for row in rows:writer.writerow({k:_json_value(v) if v is None or isinstance(v,(tuple,list,dict)) else v for k,v in row.items()})
+
+
+def timing_research_main():
+    """Run Task 4 diagnostics explicitly; no TEST reads or automatic selection."""
+    TIMING_DESTINATION.mkdir(parents=True,exist_ok=True)
+    records=prepare_records(load_audio_folder(TRAIN_DIR));require_train(records)
+    hashes={str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest()
+        for r in records for path in (Path(r['wav_path']),Path(r['wav_path']).with_suffix('.lab'))}
+    payload=timing_training_study(records)
+    synthetic=timing_waveform_study(records)
+    old_oracle=waveform_characterization()
+    for name,rows in (('heldout_scores',payload['heldout']),('tt2_branch_fit_sweep',payload['sweep']),
+                      ('fold_comparisons',payload['comparisons']),('heldout_summary',payload['summary']),
+                      ('locked_model_waveforms',synthetic['waveforms']),('fixed_oracle_support',old_oracle),
+                      ('fixed_oracle_cells',synthetic['oracle_cells'])):
+        _write_research_table(name,rows)
+    manifest=dict(parameter_selection_set='train',historical_test_exposure=True,
+        evaluation_protocol='four_fold_train_holdout',input_sha256=hashes,trials=TIMING_TRIALS,
+        heldout_rows=len(payload['heldout']),tt2_fit_branch_evaluations=len(payload['sweep']),
+        declared_TT2_W_candidates=list(range(1,51)),heldout_used_for_selection=False,
+        preliminary_native_support_sweeps_are_not_branch_selection=True,
+        branch_predictor='tools.check_endpoint_robustness.timing_predictor',selection_scorer='core.metrics.region_endpoint_metrics',
+        models=payload['models'],synthetic_models=synthetic['synthetic_models'],
+        limitations=['Cells extend nearest decisions to audio edges and unanalysed tail.',
+            'Full analysis windows remain 25 ms (1102 samples at 44.1 kHz).',
+            'Cells do not guarantee preservation of physical 200 ms silence.',
+            'Physical GT has not been changed; estimated gaps below 200 ms still merge.',
+            'Primary full mean remains undefined whenever any held-out score is undefined.',
+            'Four TRAIN folds and historically exposed data do not create an independent TEST set.',
+            'No default/convention/LOW automatically selected or applied.'])
+    (TIMING_DESTINATION/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
+    print(f"Research: {len(payload['heldout'])} heldout rows; {len(payload['sweep'])} branch W fit evaluations; {len(synthetic['waveforms'])} locked-model synthetic rows",flush=True)
+    return dict(**payload,**synthetic,manifest=manifest)
+
 if __name__ == '__main__':
-    main()
+    timing_research_main() if '--timing-research' in sys.argv else main()
