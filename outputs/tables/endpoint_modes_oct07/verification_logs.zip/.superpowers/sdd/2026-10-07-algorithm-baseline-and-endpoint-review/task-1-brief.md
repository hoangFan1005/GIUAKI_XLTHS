### Task1 — Khóa baseline hiện tại, sửa diễn giải còn cũ

**Files:** sửa `outputs/README.md`, `submission/README.md`, `reports/KET_QUA_HIEN_TAI.md`; thêm tests metadata/documentation phù hợp trong `tests/test_training_protocol.py`/`tests/test_notebook_protocol.py`. Dùng một thư mục evidence của đợt thực thi trong outputs, không lưu nhiều snapshot project.

**Interfaces:** baseline capture gồm **3 model enhanced hiện tại và 24 kết quả** (8 WAV × 3 thuật toán), input/artifact hashes và versions. Core models mới chỉ có từ Task3.

- [ ] Viết assertion cho W sweep current có TRAIN names, casefold-unique metric headers và README không gọi bảng current là TEST.
- [ ] Chạy test RED cho hai README stale; khóa bảng trước sửa gồm FINAL/masks/metrics/T/W/LOW/HIGH và hash Source/data/slides/ZIP cũ.
- [ ] Sửa đúng mô tả current TRAIN/schema 2; đưa thông tin05/10 về lịch sử, giữ historical exposure. Không đổi metric names/công thức.
- [ ] Chạy tests mục tiêu và suite hiện có. Gate: số trước sửa khớp nghiệm thu07/10, docs phản ánh current artifacts; không regenerate số liệu chỉ vì đổi prose.

### Global Constraints

- Giữ3 thuật toán, Python tự tính; TT2 chỉ Energy, không F0/Centroid, không thêm ZCR/thuật toán thứ 4.
- Analysis frame 25 ms, hop 10 ms, nearest samples/ties-to-even; Fs44.1k dùng1102/441samples, thời gian thực được báo cáo.
- Minimum internal silence 200 ms; exact estimated200 ms phải giữ, <200 ms mới nối. Silence đầu/cuối không ép kéo dài200 ms.
- Mỗi FINAL speech region có START/END; không candidate/debug trong primary figure/MAE.
- TRAIN chọn tham số và khóa model trước mở TEST; target LAB chỉ dùng scoring/plot. Không rule filename, GT snapping, TEST tuning hoặc bỏ lỗi lớn.
- Giữ `historical_test_exposure=true`; legacy TEST-calibrated model phải giữ provenance cũ. Đổi protocol không tạo holdout độc lập.
- Metric schema 2 tiếp tục `mae_ms`/`rmse_ms`; thiếu/thừa vùng làm primary undefined, không dùng mean subset thay mean đầy đủ.
- Không sửa slides/PPTX/PDF, dữ liệu Source/audio hoặc ZIP Python cũ. CODE notebook ZIP được cập nhật khi source notebook thay đổi.
- Không hứa MAE core thấp hơn enhanced hoặc timestamp mới làm mọi file tốt lên.



Execution details: backup has been pushed at 5ceb289c51079d53b977f5316bcc70971d119c47, local branch codex/endpoint-modes. Capture baseline at outputs/tables/endpoint_modes_oct07/baseline.json: all3 saved models, all24 detections using those models (features/record identifier, FINAL regions, full mask, numeric metrics/status, threshold diagnostics), source/data/slides/legacy ZIP SHA256 and environment. Existing baseline expected133tests. Store reference artifacts without overwriting existing model/tables/evidence. Correct stale README to actual Oct07 acceptance (133tests, no new numerical improvement). Keep historical results and slides. Stage only your owned files and commit locally after verification. No push. Report RED/GREEN commands and full suite evidence. You may create a temporary capture script within this plan's scratch workspace, not a new production helper.
