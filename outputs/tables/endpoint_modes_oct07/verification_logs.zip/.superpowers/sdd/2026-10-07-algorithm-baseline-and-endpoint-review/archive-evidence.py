from pathlib import Path
import hashlib, json, zipfile
root = Path('H:/GIUAKI_XLTHS').resolve()
run = root / 'outputs/tables/endpoint_modes_oct07'
scratch = root / '.superpowers/sdd/2026-10-07-algorithm-baseline-and-endpoint-review'
archive = run / 'verification_logs.zip'
selected = sorted(p for p in run.glob('task[1-6]-*') if p.is_file())
selected += sorted(p for p in run.glob('task[1-6]-*.*') if p.is_file() and p not in selected)
research = run / 'timing_research'
selected += sorted(p for p in research.glob('*.txt') if p.is_file())
provenance = research / 'provenance-reconstruction-check.json'
if provenance.exists(): selected.append(provenance)
selected += sorted(p for p in run.glob('final-fix-*') if p.is_file())
selected += sorted(p for p in scratch.rglob('*') if p.is_file() and p.suffix.lower() != '.png')
selected = sorted(set(selected))
entries = {}
for p in selected:
    resolved = p.resolve()
    if not (resolved.is_relative_to(run) or resolved.is_relative_to(scratch)):
        raise RuntimeError(f'Outside authorized evidence roots: {resolved}')
    relative = p.relative_to(root).as_posix()
    data = p.read_bytes()
    entries[relative] = {'sha256': hashlib.sha256(data).hexdigest(), 'size': len(data)}
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in selected: z.writestr(p.relative_to(root).as_posix(), p.read_bytes())
    z.writestr('ARCHIVE_MANIFEST.json', json.dumps(entries, ensure_ascii=False, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, expected in entries.items():
        data = z.read(name)
        assert len(data) == expected['size'] and hashlib.sha256(data).hexdigest() == expected['sha256'], name
payload = {'archive': archive.relative_to(root).as_posix(),
           'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'exact_entries_verified': len(entries), 'entries': entries,
           'loose_run_files_to_remove': [str(p.resolve()) for p in selected if p.is_relative_to(run)],
           'scratch_to_remove_after_final_review': str(scratch)}
(run / 'verification_archive_manifest.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'archive_sha256': payload['archive_sha256'], 'exact_entries_verified':len(entries), 'loose_run_files_to_remove':len(payload['loose_run_files_to_remove'])}))

