import csv,json,collections
from pathlib import Path
p=Path('outputs/tables/endpoint_modes_oct07/timing_research')
comparisons=list(csv.DictReader((p/'fold_comparisons.csv').open(encoding='utf-8-sig')))
print('Metric regressions',[(r['trial_id'],r['algorithm'],r['file'],r['delta_mae_ms']) for r in comparisons if r['metric_regression']=='True'])
print('Count regressions',[(r['trial_id'],r['algorithm'],r['file']) for r in comparisons if r['count_regression']=='True'])
for fname in ('fixed_oracle_support','fixed_oracle_cells'):
 rows=list(csv.DictReader((p/f'{fname}.csv').open(encoding='utf-8-sig')))
 print(fname,dict(collections.Counter((r['true_gap_ms'],r['predicted_region_count']) for r in rows)))
rows=list(csv.DictReader((p/'locked_model_waveforms.csv').open(encoding='utf-8-sig')))
print('Locked-model 200/210',dict(collections.Counter((r['trial_id'],r['algorithm'],r['predicted_region_count']) for r in rows if r['case']=='physical_gap' and float(r['true_gap_ms']) in (200,210))))
