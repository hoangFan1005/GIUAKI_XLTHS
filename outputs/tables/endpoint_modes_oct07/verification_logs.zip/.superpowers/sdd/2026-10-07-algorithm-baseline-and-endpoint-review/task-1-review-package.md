# Task1 review: 5ceb289..c7f1b0e — full source/documentation/manifest diff; large numeric baseline and suite log are evidence files linked below.
c7f1b0e Lock current enhanced baseline and correct TRAIN artifact documentation
 .../task-1-report.md                               |    63 +
 outputs/README.md                                  |    12 +-
 outputs/tables/endpoint_modes_oct07/baseline.json  | 36611 +++++++++++++++++++
 .../endpoint_modes_oct07/task1-full-suite.txt      |   142 +
 .../endpoint_modes_oct07/task1-verification.json   |    31 +
 reports/KET_QUA_HIEN_TAI.md                        |     6 +-
 submission/README.md                               |    14 +-
 tests/test_training_protocol.py                    |    51 +
 8 files changed, 36924 insertions(+), 6 deletions(-)
diff --git a/.superpowers/sdd/2026-10-07-algorithm-baseline-and-endpoint-review/task-1-report.md b/.superpowers/sdd/2026-10-07-algorithm-baseline-and-endpoint-review/task-1-report.md
new file mode 100644
index 0000000..783c0a6
--- /dev/null
+++ b/.superpowers/sdd/2026-10-07-algorithm-baseline-and-endpoint-review/task-1-report.md
@@ -0,0 +1,63 @@
+# Task1 implementation report — 07/10/2026
+
+Task1 is complete on `codex/endpoint-modes`. Scope: current-artifact documentation, four assertions in `tests/test_training_protocol.py`, and one execution evidence directory `outputs/tables/endpoint_modes_oct07/`. No detector/model numeric source, canonical models/tables/diagnostics/predictions, notebooks, slides, source/data inputs or ZIP files were regenerated or changed. No push was performed.
+
+## Baseline captured before prose edits
+
+`baseline.json` was captured using `.venv/Scripts/python.exe` from all three saved enhanced models, without fitting. It contains eight records with complete features/labels, 24 detections with full masks, FINAL regions, all numeric metrics/status, threshold diagnostics and explicit T/W/LOW/HIGH, all saved model fields, Python/platform/package versions, Git HEAD, and 148 SHA256 entries. It is one reference evidence file, not a project snapshot.
+
+Read-only inference verified exact equality against all 24 saved diagnostic JSON objects and every metric field in the current 24-row metrics CSV. FINAL regions, MAE and status also match all 24 `hotfix_oct06/regression.csv` acceptance rows. Mean four TEST MAE is TT1 `19.999999999999993`, TT2 `13.749999999999986`, TT3 `12.50000000000001` ms (displayed 20.00/13.75/12.50). All 38 protected Source/data/slides/legacy ZIP hashes recorded in the Oct07 evidence match. After documentation/tests/full-suite execution, all 145 captured non-document artifacts retain their hashes; three owned documents are the intentional differences. Details and baseline digest are in `task1-verification.json`.
+
+Capture command (scratch script retained beside this report, not a production helper):
+
+```powershell
+$env:PYTHONUTF8='1'; $env:MPLBACKEND='Agg'
+.venv/Scripts/python.exe .superpowers/sdd/2026-10-07-algorithm-baseline-and-endpoint-review/capture-baseline.py
+```
+
+The capture writes exclusively using file mode `x` and refuses to overwrite an existing baseline. It must not be rerun to replace this baseline after later implementation tasks.
+
+## Assertions and RED/GREEN evidence
+
+Read `superpowers:test-driven-development/SKILL.md` and `writing-good-tests.md`. The brief explicitly requires README assertions, overriding the general skill advisory that human prose normally earns no tests. Breaks covered: accidentally labeling the TRAIN W sweep as TEST; ambiguous casefold metric headers/schema drift; obsolete metric aliases in current guidance; and treating Oct05 acceptance/Git history as current. Tests consume real existing CSVs and documents, without mocks or regenerated artifacts. The existing notebook protocol tests already check model-lock and TRAIN sweep behavior and were rerun without modification.
+
+RED command:
+
+```powershell
+$env:PYTHONUTF8='1'; $env:MPLBACKEND='Agg'
+.venv/Scripts/python.exe -m unittest tests.test_training_protocol.CurrentArtifactDocumentationTests -v
+```
+
+Result: **4 tests, 2 passed, 2 expected assertion failures**, exit 1, 0.003 s. `test_outputs_readme_labels_current_sweep_as_train_and_schema_two` failed because the linked W-sweep line said `4 test` and had no `TRAIN`. `test_submission_readme_separates_current_acceptance_from_oct05_history` failed because the README had no dated history section and still presented 98/98 as current. These were assertion failures, not collection/runtime errors. Existing artifact header/sweep checks passed immediately as characterization coverage.
+
+GREEN command:
+
+```powershell
+$env:PYTHONUTF8='1'; $env:MPLBACKEND='Agg'
+.venv/Scripts/python.exe -m unittest tests.test_training_protocol tests.test_notebook_protocol -v
+```
+
+Result: **27/27 passed**, exit 0, 4.427 s, including both formerly failing README assertions.
+
+Full-suite command:
+
+```powershell
+$env:PYTHONUTF8='1'; $env:MPLBACKEND='Agg'
+.venv/Scripts/python.exe -m unittest discover -s tests -v 2>&1 | Out-File -Encoding utf8 outputs/tables/endpoint_modes_oct07/task1-full-suite.txt
+```
+
+Result: **137/137 passed**, exit 0, 11.152 s. This includes the accepted existing 133 tests plus four added assertions. Complete per-test output is in `task1-full-suite.txt`; there were no omitted suite failures. One initial sandboxed Python-launch attempt failed with Windows `Access is denied`; the authorized launcher commands then succeeded with `require_escalated`. No alternate interpreter was used for project test/inference execution.
+
+## Documentation changes and self-review
+
+`outputs/README.md` now identifies the current 200-row W sweep as four TRAIN files, distinguishes FINAL W20 from candidate diagnostics, names schema 2 primary `mae_ms` / `rmse_ms` and separate tolerance metrics, retains historical TEST exposure and legacy provenance, and links the accepted 133-test result and locked baseline.
+
+`submission/README.md` now leads with Oct07 acceptance (133 tests, unchanged 24 results, current source/ZIP byte audit), TRAIN/schema 2, historical exposure and delivery limitations. The original Oct05 text and branch/push statements remain under a dated historical section. `reports/KET_QUA_HIEN_TAI.md` adds the baseline reference and explicitly labels its Oct05 section as history. Metric formulas/names and historical numbers were preserved.
+
+Self-review inspected the source/test/doc diff, baseline content and count, full-suite log and preservation hash probe. `git diff --check` passes. Existing line endings were preserved on unchanged prose to keep the diff limited; added/changed lines have no trailing whitespace. Assertions use literal hand-checked TRAIN names and accepted test count. Numerical production/model files do not appear in the change list. Current baseline hashes also cover canonical output artifacts, saved notebooks and the CODE ZIP for later regression gates.
+
+## Remaining concerns
+
+No new Task1 blocker or numeric regression. Existing limitations remain: five late END cases, historical TEST exposure (no new independent holdout), estimated gap support rather than a physical silence guarantee, speech duration measured as support span, FINAL low-direction Gaussian rejection, unverified Python3.10 runtime, placeholders and old slide/Python ZIP versions. No new core model exists at this Task1 gate.
+
+Stage only the three owned documents, `tests/test_training_protocol.py`, this report and the three evidence files (`baseline.json`, `task1-verification.json`, `task1-full-suite.txt`). The scratch capture script is excluded from the commit. Local commit is permitted; no push.
diff --git a/outputs/README.md b/outputs/README.md
index 503d80b..943bdac 100644
--- a/outputs/README.md
+++ b/outputs/README.md
@@ -1,15 +1,19 @@
-# Kết quả hiện hành
+# Kết quả hiện hành — nghiệm thu 07/10/2026
 
-- `models/`: model TT1/TT2/TT3; TT2 Energy-only, W = 20.
+- `models/`: ba model enhanced TT1/TT2/TT3 hiện tại, fit TRAIN và khóa trước TEST; TT2 Energy-only, W = 20. Chưa có model core riêng.
 - `tables/all/`: 4 test × 3 thuật toán.
 - `tables/all_all_dataset/`: 8 WAV × 3 thuật toán, gồm cả train nên không phải 8 test độc lập.
 - `tables/tt1/`, `tt2/`, `tt3/`: batch riêng.
-- `tables/tt2_w_selection/`: W nguyên 1–50 trên đủ 4 test, 200 trường hợp.
+- `tables/tt2_w_selection/`: W nguyên 1–50 trên đủ 4 TRAIN (`phone_F1`, `phone_M1`, `studio_F1`, `studio_M1`), 200 trường hợp; chấm FINAL, chọn W20 bằng tie preference 20 khi hòa.
 - `tables/training_frames.csv`, `dataset_statistics.csv`: dữ liệu thống kê.
 - `figures/`: 4 test, hình so sánh và phân phối Gaussian train.
 - `diagnostics/`: candidate/final regions, ngưỡng và fallback của từng WAV.
 - `predictions/`: các đoạn speech/sil được xuất cho từng WAV.
 
-MAE chính là `mae_ms`/`boundary_MAE_ms`. Cột phụ `boundary_mae_ms` chỉ ghép biên trong dung sai 100 ms; không dùng thay metric chính. Đọc [báo cáo kết quả](../reports/KET_QUA_HIEN_TAI.md) để phân biệt train/test, counts và bất thường.
+Metric schema 2 dùng MAE/RMSE chính `mae_ms` / `rmse_ms`. Thiếu/thừa vùng làm metric chính không xác định. `matched_boundary_mae_ms` chấm vùng ghép theo thứ tự; `tolerance_boundary_*` là diagnostic sự kiện trong dung sai 100 ms, không thay metric chính. Đọc [báo cáo kết quả](../reports/KET_QUA_HIEN_TAI.md) để phân biệt TRAIN/TEST, counts và bất thường.
+
+Model schema 2 ghi `parameter_selection_set=train`, `evaluation_protocol=train_selected_reused_test`, `historical_test_exposure=true`. TEST đã được xem trong phát triển và được dùng lại; không phải holdout mới độc lập. Model legacy hiệu chỉnh bằng TEST vẫn phải giữ provenance cũ.
+
+Nghiệm thu 07/10: **133/133 tests**, 24/24 trường hợp giữ nguyên và 0 regression; mean bốn TEST TT1/TT2/TT3 vẫn **20.00/13.75/12.50 ms**. Xem [bằng chứng nghiệm thu](tables/hotfix_oct06/verification.json). [Baseline khóa trước sửa tài liệu](tables/endpoint_modes_oct07/baseline.json) giữ ba model, 24 FINAL/masks/metrics/T/W/LOW/HIGH, đặc trưng, hashes và môi trường. Đợt khóa baseline không tái tạo bảng/model hoặc tuyên bố cải thiện số liệu; năm cờ END muộn vẫn còn.
 
 Chạy lại main cập nhật kết quả tương ứng. Các lượt `--file`, `--snr-study` hoặc `--compare-context` sinh thêm thư mục/bảng mới; bản dọn hiện tại chỉ giữ các batch chính.
diff --git a/outputs/tables/endpoint_modes_oct07/task1-verification.json b/outputs/tables/endpoint_modes_oct07/task1-verification.json
new file mode 100644
index 0000000..afd3bba
--- /dev/null
+++ b/outputs/tables/endpoint_modes_oct07/task1-verification.json
@@ -0,0 +1,31 @@
+{
+  "baseline_sha256": "e2ea1b39d2abd8f69cc1e09daa51055ca058350b698d169797abf06d1f355396",
+  "unchanged_captured_artifact_hashes": 145,
+  "intended_document_changes": [
+    "outputs/README.md",
+    "submission/README.md",
+    "reports/KET_QUA_HIEN_TAI.md"
+  ],
+  "red": {
+    "passed": 2,
+    "tests": 4,
+    "failures": [
+      "test_outputs_readme_labels_current_sweep_as_train_and_schema_two",
+      "test_submission_readme_separates_current_acceptance_from_oct05_history"
+    ]
+  },
+  "targeted_green": {
+    "exit_code": 0,
+    "tests": 27,
+    "seconds": 4.427
+  },
+  "full_suite": {
+    "previous_tests": 133,
+    "log": "task1-full-suite.txt",
+    "exit_code": 0,
+    "added_tests": 4,
+    "seconds": 11.152,
+    "tests": 137
+  },
+  "whitespace_check_exit_code": 0
+}
diff --git a/reports/KET_QUA_HIEN_TAI.md b/reports/KET_QUA_HIEN_TAI.md
index b171bbe..8f2aca3 100644
--- a/reports/KET_QUA_HIEN_TAI.md
+++ b/reports/KET_QUA_HIEN_TAI.md
@@ -2,20 +2,22 @@
 
 ## Cập nhật sửa lỗi ngày 06/10, nghiệm thu ngày 07/10/2026
 
 [Báo cáo sửa lỗi chi tiết](KET_QUA_SUA_LOI_2026_10_06.md) ghi root cause, hàm đã sửa, TRAIN ablation, synthetic timing và nghiệm thu notebook. Solver TT3 đã dịch tâm/chia scale, kiểm tra log-density và sửa ca gần biên phụ thuộc thứ tự lớp; FINAL từ chối rõ hướng Gaussian `low`/không hợp lệ, chưa hỗ trợ hướng đó ở HIGH/LOW. Nghiệm thu lại ngày 07/10 đạt **133/133 tests trong 13.862 s**; ba notebook đã chạy bằng kernel mới, khớp 24/24 WAV, lưu 15 hình và ZIP CODE đã kiểm tra nguồn/bytes. Review độc lập cuối đã hoàn tất, không còn finding trọng yếu trong phạm vi sửa; bằng chứng tại [verification.json](../outputs/tables/hotfix_oct06/verification.json).
 
 [Before/after 24 trường hợp](../outputs/tables/hotfix_oct06/regression.csv) có **0 regression**: MAE/biên/số vùng đều không đổi, mean bốn TEST vẫn 20.00/13.75/12.50 ms. Năm cờ END muộn trong mục 4 vẫn còn. Có thêm 48 ca waveform tổng hợp và 48 dòng ablation chỉ TRAIN; giữ tham số production.
 
 Điều kiện 200 ms hiện đo **gap support ước lượng**, không bảo đảm giữ mọi silence vật lý ≥200 ms: silence thực 200/210 ms vẫn có thể bị gộp do frame chồng lấn. 100 ms lọc span support sau merge, không phải thời lượng voiced samples. Giới hạn này đã được kiểm tra/công bố, chưa sửa bằng estimator mới. Frame 25/hop 10 ms được giữ; Fs44,1k dùng 1102/441 samples, frame thực 24.988662 ms. Slide/PDF và ba ZIP Python cũ giữ nguyên theo yêu cầu, là previous version; notebook ZIP là gói CODE được làm mới. Các đoạn ngày 05/10 bên dưới là lịch sử, bao gồm trạng thái Git ở thời điểm đó.
 
 ## 1. Phiên bản đang dùng
+
+Baseline cho đợt đánh giá thuật toán/endpoint ngày 07/10 được khóa tại [baseline.json](../outputs/tables/endpoint_modes_oct07/baseline.json): **ba model enhanced hiện tại và 24 kết quả (8 WAV × 3 thuật toán)**, gồm FINAL regions, full masks, metrics/status, T/W/LOW/HIGH, record/features, SHA256 input/artifacts và versions môi trường. Đối chiếu trước sửa tài liệu khớp đủ 24 diagnostics/metric rows hiện hành và FINAL/MAE/status của nghiệm thu 07/10; mean TEST vẫn 20.00/13.75/12.50 ms. Đây là capture bằng model đã lưu, không fit lại hoặc tái tạo số liệu. Model core riêng chưa được tạo trong đợt khóa baseline.
 
 - TT1: Binary Search cân bằng diện tích nhầm lẫn trên normalized STE.
 - TT2: Histogram **chỉ Energy** theo yêu cầu mới của thầy; W = 20 chung, 64 bins, smoothing radius 2.
 - TT3: thống kê Gaussian population trên normalized STE, ngưỡng giao hai mật độ.
 - Chung: frame 25 ms, hop 10 ms; HIGH/LOW hysteresis; nối silence dưới 200 ms; loại speech dưới 100 ms. Không tính F0.
 
 Tất cả endpoint chính lấy từ FINAL speech regions. Candidate/debug và padding 250 ms của TT2 không được dùng làm biên cuối. Dataset gốc có một vùng nói trong mỗi WAV; code hỗ trợ nhiều vùng khi có khoảng lặng đủ dài.
 
 ## 2. Bốn file test — MAE biên ngoài (ms)
 
@@ -92,21 +94,23 @@ Nhiều vùng được ghép theo thời gian. Thiếu/thừa vùng làm MAE ch
 - [8 WAV](../outputs/tables/all_all_dataset/test_metrics.csv)
 - [Summary 8 WAV](../outputs/tables/all_all_dataset/summary.csv)
 - [200 trường hợp W](../outputs/tables/tt2_w_selection/sweep.csv)
 - [Model TT2](../outputs/models/tt2.json)
 - [Giải thích TT1](TT1_BINARY_SEARCH_GIAI_THICH.md)
 - [Giải thích TT2](TT2_HISTOGRAM_GIAI_THICH.md)
 - [Giải thích TT3](TT3_GAUSSIAN_GIAI_THICH.md)
 
 Các bảng là kết quả pipeline hiện hành đã tính sau chuyển TT2 Energy-only. Việc dọn thư mục, tách tài liệu và đổi ngôn ngữ slide không thay đổi code thuật toán.
 
-## 8. Stage1: thay đổi và bằng chứng hồi quy
+## 8. Lịch sử 05/10/2026 — Stage1 và bằng chứng hồi quy
+
+Mục này giữ nguyên bằng chứng Stage1/Stage4 ngày 05/10; số 98 tests và branch/trạng thái push dưới đây chỉ áp dụng thời điểm đó. Nghiệm thu hiện hành 07/10 là 133 tests trong mục cập nhật đầu báo cáo.
 
 Stage1 tách detector khỏi chấm LAB, fit toàn bộ TRAIN trước TEST, hiệu chỉnh W trên TRAIN FINAL, khóa mô hình khi đánh giá và chuyển sang schema 2. Các main Python hiện hành đã đồng bộ.
 
 [Bảng before/after](../outputs/tables/all_all_dataset/regression_before_after.csv) lưu đối chiếu 24 file/thuật toán. Lượt tái tạo Python do tác vụ tích hợp chạy xác nhận FINAL regions, LOW/HIGH, MAE/RMSE, frame F1, số vùng và status không đổi so với baseline. Mean TEST vẫn 20.00 / 13.75 / 12.50 ms; năm trường hợp END muộn trong mục 4 vẫn còn. Thay đổi giao thức không tạo tuyên bố cải thiện độ chính xác.
 
 Đã hoàn tất Stage1 và Stage4 bắt buộc ngày 05/10/2026 tại thư mục chính `H:/GIUAKI_XLTHS`. Bộ test cuối khi tiếp tục công việc đạt **98/98 trong 21.788 s**. Ba notebook đã chạy bằng **ba kernel mới**, mỗi notebook khớp đầy đủ model/metric/FINAL/ngưỡng với Python ở 8/8 WAV, tổng **24/24**; TT2 kiểm tra 200 dòng TRAIN và digest model đã khóa. Auditor xác nhận saved outputs hợp lệ.
 
 Các lệnh nghiệm thu đã chạy bằng Python trong `.venv/Scripts/python.exe`: `-m unittest discover -s tests -v`; `tools/build_notebooks.py`; `tools/run_notebooks.py`; `tools/run_notebooks.py --validate-only`. Các lệnh trên đều hoàn tất thành công; đối chiếu hồi quy, hash input và manifest ZIP được kiểm tra riêng trong tác vụ tích hợp.
 
 Cả **15 PNG nhúng** đã được xem trực quan. [ZIP CODE](../submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip) chứa đúng **ba notebook đã thực thi**, byte trùng các file ngoài ZIP, không WAV/LAB/audio; xem [hướng dẫn notebook](../notebooks/README.md). Trước đó, cả ba notebook cũng chạy bằng kernel mới trong ba thư mục độc lập, mỗi thư mục chỉ có notebook tương ứng và data, không có module Python của dự án. Runtime thực tế là **Python 3.14**; source cells chỉ được kiểm tra cú pháp theo Python 3.10, chưa xác minh runtime 3.10.
diff --git a/submission/README.md b/submission/README.md
index 7bb1552..879ad3b 100644
--- a/submission/README.md
+++ b/submission/README.md
@@ -1,11 +1,23 @@
-# Gói CODE chính và artifacts trước Stage1
+# Gói CODE chính — nghiệm thu 07/10/2026
+
+[JUPYTER_NOTEBOOKS_CODE_ONLY.zip](JUPYTER_NOTEBOOKS_CODE_ONLY.zip) là gói CODE hiện hành đã được kiểm tra nguồn/bytes ngày **07/10/2026**: đúng ba notebook đã thực thi, byte trùng file ngoài ZIP, không WAV/LAB/audio/module Python/slide. Ba notebook khớp model/metric/FINAL/ngưỡng với Python ở **24/24** trường hợp trên tám WAV, lưu tổng 15 PNG. Xem [hướng dẫn notebook](../notebooks/README.md) và [bằng chứng nghiệm thu](../outputs/tables/hotfix_oct06/verification.json).
+
+Nghiệm thu hiện hành đạt **133/133 tests trong 13.862 s**, 0 regression trên 24 trường hợp; mean bốn TEST TT1/TT2/TT3 vẫn **20.00/13.75/12.50 ms**. Đợt sửa tài liệu và [khóa baseline](../outputs/tables/endpoint_modes_oct07/baseline.json) giữ số liệu này, không tái tạo notebook/ZIP. Năm trường hợp END muộn vẫn còn; không có tuyên bố cải thiện MAE.
+
+Ba model enhanced dùng giao thức TRAIN/schema 2: model/noise/W fit TRAIN trước TEST, TT2 W1–50 chấm FINAL trên bốn TRAIN (200 dòng), chọn W20 bằng tie preference 20 khi hòa. Candidate W1/F1 ≈ 0.898698 là diagnostic riêng. Metric chính là `mae_ms` / `rmse_ms`; thiếu/thừa vùng làm primary undefined. TEST đã được xem trong phát triển: `train_selected_reused_test`, `historical_test_exposure=true`; đổi protocol không tạo holdout độc lập.
+
+`THUAT_TOAN_1.zip`, `THUAT_TOAN_2.zip`, `THUAT_TOAN_3.zip` và PPTX/PDF là **previous version (trước Stage1)**, cả chín binary giữ nguyên byte, chưa đồng bộ giao thức TRAIN/schema 2. Runtime đã chạy là Python 3.14; Python 3.10 chỉ kiểm tra cú pháp. CLI chấm cần WAV/LAB cùng tên. STT nhóm/họ tên/MSSV còn placeholder. Các trạng thái branch/push ngày 05/10 dưới đây là lịch sử, không mô tả trạng thái Git hiện tại.
+
+## Lịch sử 05/10/2026
+
+Các số test, thời gian chạy và trạng thái tích hợp trong mục này là bằng chứng lịch sử Stage1/Stage4.
 
 [JUPYTER_NOTEBOOKS_CODE_ONLY.zip](JUPYTER_NOTEBOOKS_CODE_ONLY.zip) là gói CODE chính đã tái tạo và kiểm tra ngày **05/10/2026**: đúng ba notebook đã chạy, byte trùng file ngoài ZIP, không WAV/LAB/audio/module Python/slide. Xem [hướng dẫn notebook](../notebooks/README.md).
 
 Ba notebook chạy bằng ba kernel mới tại thư mục chính, khớp đầy đủ model/metric/FINAL/ngưỡng với Python ở **24/24** trường hợp trên tám WAV. TT2 có 200 dòng TRAIN, kiểm tra digest khóa model; saved outputs hợp lệ, tổng 15 PNG đã được xem trực quan. Trước đó ba notebook cũng chạy độc lập, mỗi thư mục chỉ có notebook riêng và data. Runtime thực tế **Python 3.14**; Python 3.10 mới được kiểm tra cú pháp, chưa chạy runtime.
 
 Bộ test cuối **98/98 đạt trong 22.091 s**; 24/24 trường hợp giữ nguyên so với `111ab37`, 0 regression, mean TEST 20.00/13.75/12.50 ms. SHA256 của 28 file data/Source không đổi. Xem [bảng hồi quy](../outputs/tables/all_all_dataset/regression_before_after.csv) và [kết quả hiện tại](../reports/KET_QUA_HIEN_TAI.md).
 
 `THUAT_TOAN_1.zip`, `THUAT_TOAN_2.zip`, `THUAT_TOAN_3.zip` và PPTX/PDF hiện có là **previous version (trước Stage1)**, cả chín binary giữ nguyên byte, chưa đồng bộ giao thức TRAIN/schema 2; không dùng chúng như gói nộp hiện hành. Các main Python trong dự án đã đồng bộ Stage1.
 
 Model/noise/W fit TRAIN trước TEST; TT2 W1–50 hòa trên TRAIN FINAL, chọn W20 bằng tie preference 20. Candidate W1/F1 ≈ 0.898698 là diagnostic riêng. TEST đã được xem trong phát triển, protocol `train_selected_reused_test`, `historical_test_exposure=true`. CLI chấm cần WAV/LAB cùng tên. Họ tên/MSSV và STT nhóm thật còn placeholder, chờ thông tin người dùng theo hướng dẫn notebook.
diff --git a/tests/test_training_protocol.py b/tests/test_training_protocol.py
index 3088f48..cf83915 100644
--- a/tests/test_training_protocol.py
+++ b/tests/test_training_protocol.py
@@ -19,20 +19,71 @@ def synthetic_record():
     values = [0.] * 80
     values[10:50] = [.8] * 40
     starts = [i * .01 for i in range(80)]
     ends = [start + .025 for start in starts]
     intervals = [(0., .1, 'sil'), (.1, .515, 'v'), (.515, .82, 'sil')]
     return dict(name='array_fold', split='train', duration=.82, intervals=intervals,
                 features=dict(energy=values, ste_norm=values, starts=starts, ends=ends),
                 labels=frame_labels([(s + e) / 2 for s, e in zip(starts, ends)], intervals))
 
 
+class CurrentArtifactDocumentationTests(unittest.TestCase):
+    """Prevent current artifact labels from drifting to legacy TEST/schema 1."""
+    root = Path(__file__).resolve().parents[1]
+
+    def test_current_w_sweep_contains_train_names_and_unique_headers(self):
+        with (self.root / 'outputs/tables/tt2_w_selection/sweep.csv').open(
+                encoding='utf-8-sig', newline='') as handle:
+            reader = csv.DictReader(handle)
+            fields = reader.fieldnames
+            rows = list(reader)
+        self.assertEqual(len(rows), 200)
+        self.assertEqual({row['filename'] for row in rows},
+                         {'phone_F1', 'phone_M1', 'studio_F1', 'studio_M1'})
+        self.assertEqual(len(fields), len({key.casefold() for key in fields}))
+        self.assertIn('final_region_mae_ms', fields)
+
+    def test_current_metric_exports_have_schema_two_unique_headers(self):
+        for folder in ('all', 'all_all_dataset', 'tt1', 'tt2', 'tt3'):
+            with self.subTest(folder=folder):
+                with (self.root / 'outputs/tables' / folder / 'test_metrics.csv').open(
+                        encoding='utf-8-sig', newline='') as handle:
+                    reader = csv.DictReader(handle)
+                    fields = reader.fieldnames
+                    rows = list(reader)
+                self.assertEqual(len(fields), len({key.casefold() for key in fields}))
+                self.assertTrue({'mae_ms', 'rmse_ms', 'tolerance_boundary_mae_ms'} <= set(fields))
+                self.assertNotIn('boundary_MAE_ms', fields)
+                self.assertTrue(all(row['metrics_schema_version'] == '2' for row in rows))
+
+    def test_outputs_readme_labels_current_sweep_as_train_and_schema_two(self):
+        text = (self.root / 'outputs/README.md').read_text(encoding='utf-8')
+        sweep_line = next(line for line in text.splitlines() if '`tables/tt2_w_selection/`' in line)
+        self.assertIn('TRAIN', sweep_line)
+        self.assertNotIn('test', sweep_line.casefold())
+        self.assertIn('`mae_ms` / `rmse_ms`', text)
+        self.assertNotIn('`boundary_MAE_ms`', text)
+        self.assertNotIn('`boundary_mae_ms`', text)
+        self.assertIn('historical_test_exposure=true', text)
+
+    def test_submission_readme_separates_current_acceptance_from_oct05_history(self):
+        text = (self.root / 'submission/README.md').read_text(encoding='utf-8')
+        self.assertIn('## Lịch sử 05/10/2026', text)
+        current, history = text.split('## Lịch sử 05/10/2026', 1)
+        self.assertIn('07/10/2026', current)
+        self.assertIn('133/133', current)
+        self.assertNotIn('98/98', current)
+        self.assertIn('98/98', history)
+        self.assertIn('historical_test_exposure=true', current)
+        self.assertIn('schema 2', current)
+
+
 class DetectionContractTests(unittest.TestCase):
     def test_lab_free_detection_and_changed_lab_only_change_scoring(self):
         self.assertTrue(callable(getattr(pipeline, 'detect_regions', None)),
                         'A detector accepting features/duration/model without LAB is required')
         record = synthetic_record()
         params = dict(threshold=.1, endpoint_noise=dict(noise_q95=.02, noise_upper=.15))
         detected = pipeline.detect_regions('tt1', record['features'], record['duration'], params)
         scored = pipeline.predict_and_score('tt1', record, params)
         changed = dict(record, intervals=[(0., .2, 'sil'), (.2, .615, 'v'), (.615, .82, 'sil')],
                        labels=[0] * 80)
Large evidence: outputs/tables/endpoint_modes_oct07/baseline.json (all3models,24detections,hashes), task1-full-suite.txt. Review structure/count/preservation against task1-verification.json via bounded JSON projections if needed; do not print entire full-mask arrays.
