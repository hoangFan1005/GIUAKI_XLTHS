# Review final-fix
Base: d6b616c
Head: HEAD

7271fb2 Isolate partial comparison exports and align handoff docs
 app/pipeline.py                                    |  14 ++-
 outputs/README.md                                  |  16 ++-
 .../core/tables/dataset_statistics.csv             |  12 +--
 .../enhanced/tables/dataset_statistics.csv         |  12 +--
 .../endpoint_modes_oct07/final_verification.json   |  39 +++-----
 reports/KET_QUA_NGHIEM_THU_2026_10_07.md           |  12 ++-
 reports/TT1_BINARY_SEARCH_GIAI_THICH.md            |   2 +-
 reports/TT2_HISTOGRAM_GIAI_THICH.md                |   2 +-
 reports/TT3_GAUSSIAN_GIAI_THICH.md                 |   2 +-
 submission/README.md                               |  10 +-
 tests/test_endpoint_mode_integration.py            | 107 +++++++++++++++++++++
 11 files changed, 175 insertions(+), 53 deletions(-)
diff --git a/app/pipeline.py b/app/pipeline.py
index 16958ab..b03f43d 100644
--- a/app/pipeline.py
+++ b/app/pipeline.py
@@ -555,21 +555,26 @@ def run_experiment(args):
             write_json(output_root / "models" / f"{key}.json", model)
 
         # Lưu dữ liệu thống kê giúp kiểm tra lại mean/std, normalization và LAB.
         training_frames = []
         for record in train_common:
             for center, value, label in zip(record["features"]["centers"], record["features"]["ste_norm"], record["labels"]):
                 training_frames.append(dict(file=record["name"], center_s=center, ste_norm=value,
                                             label="unlabeled" if label is None else "speech" if label else "silence"))
         write_csv(tables / "training_frames.csv", training_frames)
         statistics_path = run_folder / "dataset_statistics.csv" if input_path else tables / "dataset_statistics.csv"
-        write_csv(statistics_path, data_statistics(audio_train, "train") + data_statistics(audio_test, evaluation_split))
+        statistics_sources = audio_test if input_path else audio_train + audio_test
+        unique_sources = {str(Path(record["wav_path"]).resolve()): record for record in statistics_sources}
+        statistics_rows = []
+        for record in unique_sources.values():
+            statistics_rows.extend(data_statistics([record], record["split"]))
+        write_csv(statistics_path, statistics_rows)
         if "tt3" in models:
             values_by_class = {0: [], 1: []}
             for record in train_common:
                 for value, label in zip(record["features"]["ste_norm"], record["labels"]):
                     if label is not None:
                         values_by_class[label].append(value)
             training_figures = figures_root / "training"
             training_figures.mkdir(exist_ok=True)
             plot_gaussian_training(values_by_class, models["tt3"], training_figures / "gaussian_distributions.png")
 
@@ -613,21 +618,21 @@ def run_experiment(args):
                 if args.no_show:
                     plt.close(figure)
                 else:
                     demo_figures.append(figure)
         else:
             demo_figures.sort(key=lambda figure: display_order.index(figure._suptitle.get_text()))
 
         # Lưu từng run độc lập; demo một thuật toán không ghi đè bảng tổng hợp all.
         all_mode_rows.extend(metric_rows)
         write_csv(run_folder / "test_metrics.csv", metric_rows)
-        if evaluate_all and {"tt1", "tt2", "tt3"}.issubset(selected):
+        if evaluate_all and input_path is None and set(selected) == {"tt1", "tt2", "tt3"}:
             write_csv(tables / "all" / "test_metrics.csv", [row for row in metric_rows if row["split"]=="test"])
             write_csv(tables / "all" / "summary.csv", summarize([row for row in metric_rows if row["split"]=="test"]))
         write_csv(run_folder / "summary.csv", summarize(metric_rows))
         write_csv(run_folder / "test_thresholds.csv", threshold_rows)
         if args.snr_study:
             write_csv(run_folder / "snr_study.csv", noise_rows)
         if args.compare_context:
             write_csv(tables / "context_benchmark_check.csv", context_benchmark(test_common))
         write_json(run_folder / "run_config.json", dict(algorithm=args.algorithm, endpoint_mode=mode, selected=selected,
                    input_file=str(input_path) if input_path else None, evaluated_files=evaluated_names,
@@ -653,15 +658,20 @@ def run_experiment(args):
         if not args.no_show:
             positions = show_figures(demo_figures, args.show_seconds)
             write_json(run_folder / "demo_layout.json", positions)
             if len(demo_figures) == 4:
                 print(f"Demo đã bố trí {len(positions)} cửa sổ tại bốn góc.")
             else:
                 print(f"Đã hiển thị {len(demo_figures)} figure cho WAV đã chọn.")
 
     if len(modes) == 2:
         comparison = endpoint_mode_root('comparison', OUTPUT_DIR) / 'tables'
+        if not (evaluate_all and input_path is None and set(selected) == {"tt1", "tt2", "tt3"}):
+            comparison = comparison / run_name
+            if input_path:
+                comparison = comparison / 'single' / input_path.stem
         write_csv(comparison / 'all_metrics.csv', all_mode_rows)
         write_csv(comparison / 'all_summary.csv', summarize(all_mode_rows))
         test_rows = [row for row in all_mode_rows if row['split']=='test']
         write_csv(comparison / 'test_metrics.csv', test_rows)
         write_csv(comparison / 'test_summary.csv', summarize(test_rows))
+        print(f"Bảng so sánh endpoint: {comparison}")
diff --git a/outputs/README.md b/outputs/README.md
index be92cd5..0d02bd0 100644
--- a/outputs/README.md
+++ b/outputs/README.md
@@ -4,32 +4,42 @@
 
 Mặc định `enhanced`: ngưỡng native tạo seed; noise TRAIN và HIGH/LOW xác nhận, giữ speech; nối gap support dưới 200 ms và lọc span dưới 100 ms. `core` giữ quyết định native và chỉ nối gap support dưới 200 ms, không lọc duration hoặc padding FINAL; LOW/HIGH là null. Gap ước lượng đúng 200 ms được giữ riêng. TT1 dùng STE ≥ T, TT2 dùng Energy > T, TT3 giữ hướng high/low của Gaussian native. Đây là hai chế độ endpoint của cùng ba thuật toán; enhanced là phần bổ sung của dự án.
 
 ```powershell
 python main_tt1.py --endpoint-mode core
 python main.py --evaluate-all --compare-endpoint-modes
 ```
 
 Mỗi mode fit và khóa model độc lập trên bốn TRAIN trước đọc TEST. Kết quả mới ở `outputs/endpoint_modes/core/` và `outputs/endpoint_modes/enhanced/`; bảng so sánh ở `outputs/endpoint_modes/comparison/tables/`. Model schema 3 giữ policy/digest, metric schema 2 tiếp tục `mae_ms`/`rmse_ms`. Thiếu/thừa vùng làm primary mean toàn bộ file undefined; `valid_files_*` là thống kê subset riêng. TEST có `historical_test_exposure=true`, không phải holdout độc lập. Không chọn mode tốt hơn riêng cho từng WAV.
 
-Notebook dùng `MODE="enhanced"` mặc định cho bốn TEST figure và một illustration; luôn fit/khóa `MODELS` cả hai mode trước TEST, xuất 16 dòng tám WAV/mode và bảng bốn TEST/mode. TT2 có 200 TRAIN sweep rows mỗi mode. Core plot native T; Energy TT2 được chuẩn hóa chỉ ở bước hiển thị. Source digest và model lock digests độc lập kiểm tra nguồn/outputs và model; Restart Kernel → Run All → Save vẫn chạy độc lập.
+Ba notebook đã tái tạo và thực thi mới, dùng `MODE="enhanced"` mặc định cho bốn TEST figure và một illustration (5 PNG mỗi notebook); luôn fit/khóa `MODELS` cả hai mode trước TEST, xuất 16 dòng mode-file trên tám WAV (8 dòng mỗi mode) và bảng bốn TEST/mode. TT2 có 200 TRAIN sweep rows mỗi mode. Tổng 48 trường hợp và 15 PNG; [CODE ZIP hiện hành](../submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip) có đúng ba notebook byte trùng bản ngoài ZIP. Core plot native T; Energy TT2 được chuẩn hóa chỉ ở bước hiển thị. Source digest và model lock digests độc lập kiểm tra nguồn/outputs và model; Restart Kernel → Run All → Save vẫn chạy độc lập.
+
+Nghiệm thu hiện hành: **177/177 tests trong 19.208 s** (21.030 s wall), exit 0; [báo cáo đầy đủ](../reports/KET_QUA_NGHIEM_THU_2026_10_07.md) và [final_verification.json](tables/endpoint_modes_oct07/final_verification.json) ghi số thực tế, 24 enhanced exact và 48 trường hợp hai mode. Sáu model hiện hành ở `endpoint_modes/{core,enhanced}/models/`; các bảng mode dùng `tables/all/` (bốn TEST) và `tables/all_all_dataset/` (tám WAV). `dataset_statistics.csv` mỗi mode giữ tám nguồn duy nhất, bốn TRAIN/bốn TEST.
+
+`endpoint_modes/comparison/artifact_audit.json` là snapshot lịch sử sau sửa units Task5, trước sửa routing final review; full-file source hashes trong snapshot không mô tả writer hiện hành. Audit hiện hành nằm trong `final_verification.json` nêu trên; source digest notebook, saved output và CODE ZIP vẫn khớp vì writer không được nhúng vào notebook.
+
+`python main.py --evaluate-all --compare-endpoint-modes` ghi bốn bảng benchmark đầy đủ ở `endpoint_modes/comparison/tables/{all_metrics,all_summary,test_metrics,test_summary}.csv`. Lượt partial giữ bảng riêng tại `comparison/tables/<run_name>/`: mặc định bốn TEST là `all/`; thuật toán cố định đánh giá tám WAV là `ttN_all_dataset/`; `--file` thêm `single/<inputstem>/` dưới `all/` hoặc `ttN/`. Các lượt partial giữ nguyên bốn bảng benchmark đầy đủ. Thống kê một file nằm trong thư mục run mode tương ứng, chỉ ghi nguồn đã chọn.
 
 PPTX/PDF và ZIP Python cũ giữ nguyên previous version. Các bảng, noise và ví dụ HIGH/LOW bên dưới mô tả enhanced; không phải công thức quyết định FINAL của core. Xem [báo cáo hai mode](../reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md).
 
 
-- `models/`: ba model enhanced TT1/TT2/TT3 hiện tại, fit TRAIN và khóa trước TEST; TT2 Energy-only, W = 20. Chưa có model core riêng.
+## Lịch sử thư mục canonical / hotfix trước hai mode
+
+Danh sách dưới đây mô tả outputs canonical cũ, được giữ nguyên byte làm evidence lịch sử. Các thư mục hiện hành là `endpoint_modes/` nêu trên.
+
+- `models/`: ba model enhanced TT1/TT2/TT3 lịch sử, fit TRAIN và khóa trước TEST; TT2 Energy-only, W = 20. Khi đó chưa có model core riêng.
 - `tables/all/`: 4 test × 3 thuật toán.
 - `tables/all_all_dataset/`: 8 WAV × 3 thuật toán, gồm cả train nên không phải 8 test độc lập.
 - `tables/tt1/`, `tt2/`, `tt3/`: batch riêng.
 - `tables/tt2_w_selection/`: W nguyên 1–50 trên đủ 4 TRAIN (`phone_F1`, `phone_M1`, `studio_F1`, `studio_M1`), 200 trường hợp; chấm FINAL, chọn W20 bằng tie preference 20 khi hòa.
 - `tables/training_frames.csv`, `dataset_statistics.csv`: dữ liệu thống kê.
 - `figures/`: 4 test, hình so sánh và phân phối Gaussian train.
 - `diagnostics/`: candidate/final regions, ngưỡng và fallback của từng WAV.
 - `predictions/`: các đoạn speech/sil được xuất cho từng WAV.
 
 Metric schema 2 dùng MAE/RMSE chính `mae_ms` / `rmse_ms`. Thiếu/thừa vùng làm metric chính không xác định. `matched_boundary_mae_ms` chấm vùng ghép theo thứ tự; `tolerance_boundary_*` là diagnostic sự kiện trong dung sai 100 ms, không thay metric chính. Đọc [báo cáo kết quả](../reports/KET_QUA_HIEN_TAI.md) để phân biệt TRAIN/TEST, counts và bất thường.
 
 Model schema 3 với metric schema 2 ghi `parameter_selection_set=train`, `evaluation_protocol=train_selected_reused_test`, `historical_test_exposure=true`. TEST đã được xem trong phát triển và được dùng lại; không phải holdout mới độc lập. Model legacy hiệu chỉnh bằng TEST vẫn phải giữ provenance cũ.
 
-Nghiệm thu 07/10: **133/133 tests**, 24/24 trường hợp giữ nguyên và 0 regression; mean bốn TEST TT1/TT2/TT3 vẫn **20.00/13.75/12.50 ms**. Xem [bằng chứng nghiệm thu](tables/hotfix_oct06/verification.json). [Baseline khóa trước sửa tài liệu](tables/endpoint_modes_oct07/baseline.json) giữ ba model, 24 FINAL/masks/metrics/T/W/LOW/HIGH, đặc trưng, hashes và môi trường. Đợt khóa baseline không tái tạo bảng/model hoặc tuyên bố cải thiện số liệu; năm cờ END muộn vẫn còn.
+Nghiệm thu hotfix / baseline lịch sử 07/10: **133/133 tests**, 24/24 trường hợp giữ nguyên và 0 regression; mean bốn TEST TT1/TT2/TT3 **20.00/13.75/12.50 ms**. Xem [bằng chứng hotfix lịch sử](tables/hotfix_oct06/verification.json). [Baseline khóa trước sửa tài liệu](tables/endpoint_modes_oct07/baseline.json) giữ ba model, 24 FINAL/masks/metrics/T/W/LOW/HIGH, đặc trưng, hashes và môi trường. Đợt khóa baseline khi đó không tái tạo bảng/model hoặc tuyên bố cải thiện số liệu; năm cờ END muộn vẫn còn.
 
 Chạy lại main cập nhật kết quả tương ứng. Các lượt `--file`, `--snr-study` hoặc `--compare-context` sinh thêm thư mục/bảng mới; bản dọn hiện tại chỉ giữ các batch chính.
diff --git a/outputs/endpoint_modes/core/tables/dataset_statistics.csv b/outputs/endpoint_modes/core/tables/dataset_statistics.csv
index d6f5999..7d7b9ac 100644
--- a/outputs/endpoint_modes/core/tables/dataset_statistics.csv
+++ b/outputs/endpoint_modes/core/tables/dataset_statistics.csv
@@ -1,13 +1,9 @@
 ﻿split,file,sample_rate_hz,duration_s,gt_start_s,gt_end_s,silence_power,speech_plus_noise_power,snr_proxy_db
 train,phone_F1,16000,3.24,0.53,2.75,9.141032524074953e-05,0.021789419132039405,23.77250398687938
 train,phone_M1,16000,4.16,0.46,3.52,1.2266908135743589e-05,0.0026134448302293414,23.284782236347723
 train,studio_F1,44100,2.8631972789115645,0.68,2.15,7.634926525659181e-07,0.005750358902982303,38.7689008959662
 train,studio_M1,44100,2.7301587301587302,0.87,2.06,5.867565756954236e-07,0.00353874442223819,37.80391232466751
-all_dataset,phone_F1,16000,3.24,0.53,2.75,9.141032524074953e-05,0.021789419132039405,23.77250398687938
-all_dataset,phone_M1,16000,4.16,0.46,3.52,1.2266908135743589e-05,0.0026134448302293414,23.284782236347723
-all_dataset,studio_F1,44100,2.8631972789115645,0.68,2.15,7.634926525659181e-07,0.005750358902982303,38.7689008959662
-all_dataset,studio_M1,44100,2.7301587301587302,0.87,2.06,5.867565756954236e-07,0.00353874442223819,37.80391232466751
-all_dataset,phone_F2,16000,4.8,1.02,4.04,3.8275436636876695e-06,0.0011487046762605488,24.772882353154234
-all_dataset,phone_M2,16000,2.8,0.53,2.52,4.693177344714418e-06,0.002352835165615189,27.001245369954997
-all_dataset,studio_F2,44100,3.1494784580498867,0.77,2.37,2.471333443170639e-07,0.021013740538669615,49.295720193481
-all_dataset,studio_M2,44100,2.381859410430839,0.45,1.93,7.569253478461112e-07,0.004428432266960596,37.67196957419809
+test,phone_F2,16000,4.8,1.02,4.04,3.8275436636876695e-06,0.0011487046762605488,24.772882353154234
+test,phone_M2,16000,2.8,0.53,2.52,4.693177344714418e-06,0.002352835165615189,27.001245369954997
+test,studio_F2,44100,3.1494784580498867,0.77,2.37,2.471333443170639e-07,0.021013740538669615,49.295720193481
+test,studio_M2,44100,2.381859410430839,0.45,1.93,7.569253478461112e-07,0.004428432266960596,37.67196957419809
diff --git a/outputs/endpoint_modes/enhanced/tables/dataset_statistics.csv b/outputs/endpoint_modes/enhanced/tables/dataset_statistics.csv
index d6f5999..7d7b9ac 100644
--- a/outputs/endpoint_modes/enhanced/tables/dataset_statistics.csv
+++ b/outputs/endpoint_modes/enhanced/tables/dataset_statistics.csv
@@ -1,13 +1,9 @@
 ﻿split,file,sample_rate_hz,duration_s,gt_start_s,gt_end_s,silence_power,speech_plus_noise_power,snr_proxy_db
 train,phone_F1,16000,3.24,0.53,2.75,9.141032524074953e-05,0.021789419132039405,23.77250398687938
 train,phone_M1,16000,4.16,0.46,3.52,1.2266908135743589e-05,0.0026134448302293414,23.284782236347723
 train,studio_F1,44100,2.8631972789115645,0.68,2.15,7.634926525659181e-07,0.005750358902982303,38.7689008959662
 train,studio_M1,44100,2.7301587301587302,0.87,2.06,5.867565756954236e-07,0.00353874442223819,37.80391232466751
-all_dataset,phone_F1,16000,3.24,0.53,2.75,9.141032524074953e-05,0.021789419132039405,23.77250398687938
-all_dataset,phone_M1,16000,4.16,0.46,3.52,1.2266908135743589e-05,0.0026134448302293414,23.284782236347723
-all_dataset,studio_F1,44100,2.8631972789115645,0.68,2.15,7.634926525659181e-07,0.005750358902982303,38.7689008959662
-all_dataset,studio_M1,44100,2.7301587301587302,0.87,2.06,5.867565756954236e-07,0.00353874442223819,37.80391232466751
-all_dataset,phone_F2,16000,4.8,1.02,4.04,3.8275436636876695e-06,0.0011487046762605488,24.772882353154234
-all_dataset,phone_M2,16000,2.8,0.53,2.52,4.693177344714418e-06,0.002352835165615189,27.001245369954997
-all_dataset,studio_F2,44100,3.1494784580498867,0.77,2.37,2.471333443170639e-07,0.021013740538669615,49.295720193481
-all_dataset,studio_M2,44100,2.381859410430839,0.45,1.93,7.569253478461112e-07,0.004428432266960596,37.67196957419809
+test,phone_F2,16000,4.8,1.02,4.04,3.8275436636876695e-06,0.0011487046762605488,24.772882353154234
+test,phone_M2,16000,2.8,0.53,2.52,4.693177344714418e-06,0.002352835165615189,27.001245369954997
+test,studio_F2,44100,3.1494784580498867,0.77,2.37,2.471333443170639e-07,0.021013740538669615,49.295720193481
+test,studio_M2,44100,2.381859410430839,0.45,1.93,7.569253478461112e-07,0.004428432266960596,37.67196957419809
diff --git a/outputs/tables/endpoint_modes_oct07/final_verification.json b/outputs/tables/endpoint_modes_oct07/final_verification.json
index 5a5e445..432e3d2 100644
--- a/outputs/tables/endpoint_modes_oct07/final_verification.json
+++ b/outputs/tables/endpoint_modes_oct07/final_verification.json
@@ -1,13 +1,13 @@
 {
   "handoff_status": "numeric and artifact acceptance passed; independent final review pending",
-  "verified_utc": "2026-10-07T10:41:00.670310+00:00",
+  "verified_utc": "2026-10-07T11:00:26.190854+00:00",
   "environment": {
     "python": "3.14.7 (tags/v3.14.7:823f032, Aug  5 2026, 10:51:32) [MSC v.1944 64 bit (AMD64)]",
     "executable": "H:\\GIUAKI_XLTHS\\.venv\\Scripts\\python.exe",
     "platform": "Windows-11-10.0.26200-SP0",
     "python310_verified": false,
     "packages": {
       "numpy": "2.5.2",
       "matplotlib": "3.11.1",
       "nbformat": "5.11.1",
       "nbclient": "0.11.0",
@@ -1825,60 +1825,56 @@
       },
       "endpoint_policy": "hysteresis final regions; no fixed final padding",
       "feature_rule": "normalized STE",
       "decision_rule": "STE >= threshold",
       "padding_stage": "none",
       "boundary_convention": "union of active frame supports",
       "calibration_digest": "39e7feb3b03610601085d94794b45e4f3c3b3a2024ed178b564f30e5e7409955"
     }
   },
   "research_audit": {
+    "native_full_hashes_validated": 6,
+    "heldout_fit_provenance_models_validated": 76,
     "branch_config_count": 19,
     "native_models": 6,
     "resolved_waveform_rows": 1216,
     "resolved_heldout_rows": 76,
     "tt2_calibration_rows": 3600,
     "low_t1_phone_m1_regression_ms": 204.99999999999983,
     "artifact_sha256": {
       "fixed_oracle_cells.csv": "9842601c52af1ec25682975323eab2bd03a45889ccad27dd7edf89d443acd9a4",
       "fixed_oracle_support.csv": "4369e17ac9f1276962b7eeaa64329be630fbf8746593a1dc6e2cbc71a77fd2a4",
       "fold_comparisons.csv": "54bf6bf896547877634aafd4cb4e726efd915bdf53a7ba34f12482395e06eeb3",
       "heldout_scores.csv": "c289f64d29f051b3e32f67e850969fac5802d7bb8d61d407ef60fc6716b8adda",
       "heldout_summary.csv": "6b64773034f9676a60e556350e040ef14374c751072eadc1b37a040efaa2e3a9",
       "locked_model_waveforms.csv": "72f3cfbf44e1cb9c6703c7305b2a8703fd60080fd97bd0e8d6bdc256d89ccd3e",
       "manifest.json": "e80cf96c18376095e538032bde7fddc4adeafe1ed86ed500edf6d8d8580be278",
       "protected_source_hashes.json": "88822173ede2b177a5e05ce25e6b54be7934d644494066a2a2817378f4f66cf9",
       "provenance-reconstruction-check.json": "a29f91708b5997dafcf688a7d2c7f037d946fca67ab063c94288b6bdbfc3bd01",
       "tt2_branch_fit_sweep.csv": "d74ee67cd5721d6529b52dcf9c76f6c5d7679d7e3a6e77a8e920383a649fb6b2"
-    },
-    "native_full_hashes_validated": 6,
-    "heldout_fit_provenance_models_validated": 76
+    }
   },
   "full_suite": {
     "command": [
       "H:\\GIUAKI_XLTHS\\.venv\\Scripts\\python.exe",
       "-m",
       "unittest",
       "discover",
       "-s",
       "tests",
       "-v"
     ],
     "exit_code": 0,
-    "test_count": 173,
-    "unittest_runtime_seconds": 15.2,
-    "wall_runtime_seconds": 16.794428799999878,
-    "passed": true,
-    "superseded_pre_fix_gate_archive_entries": [
-      "outputs/tables/endpoint_modes_oct07/task6-full-suite-before-writer-fix.txt",
-      "outputs/tables/endpoint_modes_oct07/task6-full-suite-before-writer-fix.json"
-    ]
+    "test_count": 177,
+    "unittest_runtime_seconds": 19.208,
+    "wall_runtime_seconds": 21.030151299999943,
+    "passed": true
   },
   "protected_production_source_checks": [
     {
       "path": "core/features.py",
       "sha256": "69a18cddb11bee3bd76386065fed15171e4470759644e997c29ce534a320a5bd",
       "baseline_byte_exact": true,
       "arithmetic_ast_unchanged": true,
       "allowed_change": null
     },
     {
@@ -2062,23 +2058,23 @@
     "outputs/tables/tt3/summary.csv": "091027e0024463cfde531d43464526bcc959d82c58806b2312001d7f9a575480",
     "outputs/tables/tt3/test_metrics.csv": "9b2a437d9badda845deff908917c98a1d6e48fdc9a53dfd5b8141466222fc140",
     "outputs/tables/tt3/test_thresholds.csv": "ac92f19bce5af6189203220de03f9b3e3dfe16d1750e98528c0f7f1563be8eb1",
     "slides/README.md": "f7b96e2feb8077e6e7a9b5ecb3c3b3bed11ee33458880230d625c89d9a6c6441",
     "slides/THUAT_TOAN_1/THUAT_TOAN_1.pdf": "2b785d4022b76bd245966ffd11999d76551c01a0e02c8a86f50793d5cbbf2f57",
     "slides/THUAT_TOAN_1/THUAT_TOAN_1.pptx": "a884311657fec428d6dbbafce9786a3c8d40b5578263d217fbc338ae366e3018",
     "slides/THUAT_TOAN_2/THUAT_TOAN_2.pdf": "e47856ba82240c5011073c0c9d3f223c5d78efc26c46dcdafabf155e4cebce5a",
     "slides/THUAT_TOAN_2/THUAT_TOAN_2.pptx": "a44be7ebc60cac33c40f8eb00fed88c03923d1576fe8ee44bb6f698a450c2ee9",
     "slides/THUAT_TOAN_3/THUAT_TOAN_3.pdf": "6730cd19744e92682fa54f16dd081de43f30f12bf316589c597aedc065955cba",
     "slides/THUAT_TOAN_3/THUAT_TOAN_3.pptx": "2c42d708cfc953a8f454e3d78944bfe7ae893f356c6248e07022682faabb7ebd",
-    "Source/assignment/HÃ†Â°Ã¡Â»â€ºng dÃ¡ÂºÂ«n BT - PhÃƒÂ¢n Ã„â€˜oÃ¡ÂºÂ¡n tÃƒÂ­n hiÃ¡Â»â€¡u thÃƒÂ nh tiÃ¡ÂºÂ¿ng nÃƒÂ³i vÃƒÂ  khoÃ¡ÂºÂ£ng lÃ¡ÂºÂ·ng_XLTHS_GK 2026.docx": "9eb6032de0c8cecac3d88d2825ca98fcfd956ce4d674c5dacd3544fec2899eab",
-    "Source/assignment/HÃ†Â°Ã¡Â»â€ºng dÃ¡ÂºÂ«n BT thi GK nhÃƒÂ³m 3-4 SV_PhÃƒÂ¢n Ã„â€˜oÃ¡ÂºÂ¡n tÃƒÂ­n hiÃ¡Â»â€¡u thÃƒÂ nh tiÃ¡ÂºÂ¿ng nÃƒÂ³i vÃƒÂ  khoÃ¡ÂºÂ£ng lÃ¡ÂºÂ·ng_XLTHS_GK 2026.docx": "d4adfb5c5100ab64a72cb390b6137b84bf3156c9475ecbbecc7fdc4b27b26005",
-    "Source/assignment/HÃ†Â°Ã¡Â»â€ºng dÃ¡ÂºÂ«n trÃƒÂ¬nh bÃƒÂ y slide vÃƒÂ  nÃ¡Â»â„¢p bÃƒÂ i thi.pdf": "6b3d0f7c16298f870f0626d8c35567e8a29985313db5a6c1d9d2561ddebf6e95",
+    "Source/assignment/Hướng dẫn BT - Phân đoạn tín hiệu thành tiếng nói và khoảng lặng_XLTHS_GK 2026.docx": "9eb6032de0c8cecac3d88d2825ca98fcfd956ce4d674c5dacd3544fec2899eab",
+    "Source/assignment/Hướng dẫn BT thi GK nhóm 3-4 SV_Phân đoạn tín hiệu thành tiếng nói và khoảng lặng_XLTHS_GK 2026.docx": "d4adfb5c5100ab64a72cb390b6137b84bf3156c9475ecbbecc7fdc4b27b26005",
+    "Source/assignment/Hướng dẫn trình bày slide và nộp bài thi.pdf": "6b3d0f7c16298f870f0626d8c35567e8a29985313db5a6c1d9d2561ddebf6e95",
     "Source/context/BAO_CAO_NGU_CANH_GIUA_KY.pdf": "0b953dcc887ca001cd81f6457800b1f6c2b4fad21b5f710010d6f5f44875641b",
     "Source/course_slides/Chapter6_AUDIO-SPEECH SIGNAL PROCESSING.pdf": "ad59aa3da530777b64cab70c5522cac12df2cbbdfecbff10623f69109c923747",
     "Source/examples/sampleFigure.bmp": "c08799016d7a932f0fa6fe823032feb19bdd03ac844703a2940d453a9626e4de",
     "Source/examples/sampleFigure.eps": "5e086918e58d43d65c3624a26731193d71cbf050b822fdec9e76ed2fff4bfb8c",
     "Source/README.md": "6b4e4ec60d4f4adcd2c7cf990811ee2dc7abc20f36e9374a13e29fc276f34fb2",
     "Source/references/A method for silence removal and segmentation of speech signals_Giannakopoulos_2014.pdf": "570106e8d3f9eedadbd3f3294a9e18a167f6c5b116ffcb9ecb7f6b8c9b261952",
     "Source/references/CS425 Audio and Speech Processing_Hodgkinson_2012.pdf": "242057d219ffe219ef9f5ade2cbbfd4a55af21dcd08ca03061127d2ba184c413",
     "submission/THUAT_TOAN_1.zip": "ae00f2bb91b3313012b70fe50c35ca9197af9d9f39deb1becde6f9357eecca67",
     "submission/THUAT_TOAN_2.zip": "6433afd142ad99f8fa2ceabf89fa6108078616224f56bd90eaa368d9d3a99e22",
     "submission/THUAT_TOAN_3.zip": "40f9f5f9af273c84ce16f99a13ab16705c974e6db3f057da855125cfc9f11073"
@@ -2091,21 +2087,21 @@
     "app/cli.py": {
       "before": "60e5a6ac505b8de109f1149bc66aaf2863ee578db93042c6720b879fa0fe7a8f",
       "after": "1cfdfa2d07bfe4a9da1245644178016abf064d1bcec9f6d1095724daf519eec9"
     },
     "app/config.py": {
       "before": "639455a4fcd6ac30d8a2ff8d79c1fce2f4d31b5e3564e537fe692fcbee3643e8",
       "after": "1c13684bce50de23324510f4050fedd8f1ebea21ae575bc4cfc90f389faf3863"
     },
     "app/pipeline.py": {
       "before": "731eb6713b06a2cf1afedcb709aa3ba0d1ac0f40cbf6d1ce198e82e64fc5e4b9",
-      "after": "7bd39fd5a85dd5710624dfc8cd861a3bba5dce4f9b52b8afe401a50b70a5378b"
+      "after": "b478575982de890f28c230e97fdd800afde9a6fb089f2326727a8ecf3e6b91f2"
     },
     "app/plotting.py": {
       "before": "6305984bf9c47375433d3209d0ab19537436622843b9fb46a1c226f1c9155188",
       "after": "56f9a58050273898361e8384845d25f86b06a06ce3782d6b411d2d094a85aaa2"
     },
     "app/weight_selection.py": {
       "before": "7ed3304e21f1e034cafaf91ab5d4b5ab80a3828a787931d6d906000aafce644d",
       "after": "e9eb0c6e32ffc12e30163bdd2a44979ea4e4ae1de18e511fc94437ed048b7647"
     },
     "notebooks/README.md": {
@@ -2119,33 +2115,33 @@
     "notebooks/THUAT_TOAN_2.ipynb": {
       "before": "992863f7c0acdf590423bfc2162ee0d9fc4570007a0f467d14e6ddf4d3d5e8be",
       "after": "f2904adc854002217c4873b0b39eba40379e4ea2a9d7e64857551824fd5160fc"
     },
     "notebooks/THUAT_TOAN_3.ipynb": {
       "before": "ac03ba7a1fc39f92ed88b6719f9499c0572d5ade8a6cc1e3254ca634390b5e20",
       "after": "c7fbea5ab82dfa2db62493d50692e8310cd46f421709c86a2d91da45217bb605"
     },
     "outputs/README.md": {
       "before": "e1d5067162ff8348fc4120ed23e6a78bcad720ac143cbf40a9ffac50fb584ae5",
-      "after": "a7293cb60f60c64ab6c8d44c2f0bea5bcc518dfff02b6b83d427fd1878f72f81"
+      "after": "b2becd009b07330128caf19b7a80f8cd9165f161b41d0499f0c9823be30bc0ec"
     },
     "reports/KET_QUA_HIEN_TAI.md": {
       "before": "f18145e934c0289f833cb7a167587564828ee2f82d2230372278f5ff4f6eef99",
       "after": "c70777e23cb230966c5069929419e5ff9d51ba6dc6ac92a75dcd66e4dda6ad6c"
     },
     "submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip": {
       "before": "dfebe61bb7af41a76761d29cdf0260e0c1af568a5e4b7f6d1cfc1523c501ed84",
       "after": "c4c668bafa97db7f8ab0364ad1aa23e6e7f08c15c8f59ec1f2b0e87fda4e437e"
     },
     "submission/README.md": {
       "before": "aed0d370ae6a24803dcf913fcd350fb8d35276925d5f9208ef44b00509a4aaa8",
-      "after": "f0ba7bb961af36f09ef2ba83f5e5f11fbed3680fd0510b4ceba38f836f1c4672"
+      "after": "df229130c4f80c83ae11d63de91686305b4c3e3e4d5be714862afd6f6d03aba6"
     }
   },
   "notebooks": [
     {
       "file": "THUAT_TOAN_1.ipynb",
       "sha256": "cc3bfd3f3abf5f7b7e74b8edf5973f1972f42e084652362e41d68de16a5c8c4c",
       "images": 5,
       "enhanced_test_mean_mae_ms": 19.999999999999993,
       "code_source_sha256": "4275ea2687f52a07b5df13efd22729407e2923257f22face217de054fa415b78",
       "dual_model_audit_pass": true,
@@ -2465,15 +2461,12 @@
       "median_defined_mae_ms": 7.50283446712019,
       "min_defined_mae_ms": 7.494331065759696,
       "max_defined_mae_ms": 27.499999999999968,
       "mean_file_rmse_ms": 14.078275245327559,
       "missing_regions": 0,
       "extra_regions": 0,
       "worst_defined_files": "[\"test/phone_F2\"]",
       "invalid_file_names": "[]"
     }
   ],
-  "acceptance_runtime_seconds": 1.2192042000001493,
-  "verified_git_head": "c5e82dddf331145e8a9183019448b1b81a7b59d8",
-  "verification_logs_archive": "outputs/tables/endpoint_modes_oct07/verification_logs.zip",
-  "review_and_visual_status": "controller-owned independent final review/visual/archive pending"
-}
+  "acceptance_runtime_seconds": 1.4142099000000599
+}
\ No newline at end of file
diff --git a/reports/KET_QUA_NGHIEM_THU_2026_10_07.md b/reports/KET_QUA_NGHIEM_THU_2026_10_07.md
index cc1d5db..9ded5a6 100644
--- a/reports/KET_QUA_NGHIEM_THU_2026_10_07.md
+++ b/reports/KET_QUA_NGHIEM_THU_2026_10_07.md
@@ -1,25 +1,25 @@
 # Nghiệm thu endpoint core/enhanced — 07/10/2026
 
-Gate tích hợp sau sửa writer/units đã PASS; bàn giao cuối chờ root hoàn tất review độc lập và archive. Không push/merge implementation.
+Gate tích hợp sau sửa final review đã PASS; bàn giao cuối chờ root hoàn tất scoped re-review, commit và archive. Không push/merge implementation.
 
 ## Phạm vi và các hàm đã thay đổi
 
 Ba thuật toán giữ nguyên: TT1 Binary Search cân bằng diện tích nhầm lẫn trên normalized STE; TT2 Histogram chỉ Energy; TT3 Gaussian equal-density xấp xỉ theo đề. Không thêm F0/Centroid/ZCR hay thuật toán thứ tư.
 
 `app.pipeline.algorithm_decision` tách quyết định native; `detect_regions` chọn policy khóa trong model: core quyết định native, merge internal support gap <200 ms, không lọc minimum speech/padding FINAL; enhanced giữ noise/HIGH–LOW hysteresis và 100 ms span filter. `fit_training_model` fit riêng từng mode trên TRAIN, chọn FINAL W theo mode và khóa schema3/calibration digest trước TEST. `app.weight_selection.sweep_final_weights`/`select_final_weight` giữ primary undefined nếu count sai; `summarize` nhóm theo algorithm+mode. `run_experiment`, CLI/config/output routing, plotting và notebook builder/runner xử lý cả hai mode và audit provenance. `core.decision_timing.decision_cells` cùng `tools.check_endpoint_robustness` chỉ phục vụ nghiên cứu opt-in, chưa đổi timing/LOW production.
 
 Đối chiếu Task3 `47cc00b`: 7 module tính toán có AST không đổi (TT2 chỉ sửa module docstring), 3 API `algorithm_decision`/`detect_regions`/`fit_training_model` có mọi AST node không đổi ngoài đúng hai string metadata: `sum of squared samples` → `mean squared sample amplitude`, và `Energy (sum of squared samples)` → `Energy (mean squared sample amplitude)`. Occurrence mỗi replacement phải đúng1; không dùng generic ignore AST. Task5 nâng phần consumer/metadata, không đổi native arithmetic. Initial byte gate TT2 fail do docstring đã được duyệt; diff thật được kiểm tra, gate sửa thành AST bỏ module docstring. Log fail được giữ, không che lỗi.
 
 ## Gate thực thi và môi trường
 
-Fresh suite sau second STABLE: **173 tests PASS**, 15.200 s unittest, 16.794 s wall, exit0. Baseline133 và Task1 gate137 là số lịch sử; số mới lấy từ output thật. Acceptance numeric/audit: 1.219 s.
+Fresh suite sau final-review-fix STABLE: **177 tests PASS**, 19.208 s unittest, 21.030 s wall, exit0. Baseline133, Task1 gate137 và pre-final-review-fix gate173 là số lịch sử; số mới lấy từ output thật. Acceptance numeric/audit: 1.414 s.
 
 Môi trường: Python **3.14.7**, Windows11; numpy 2.5.2, matplotlib 3.11.1, nbformat 5.11.1, nbclient 0.11.0. Python3.10 **chưa kiểm** vì không có môi trường3.10; không suy diễn từ3.14.
 
 Commands: `.venv/Scripts/python.exe -m unittest discover -s tests -v`; `.venv/Scripts/python.exe .superpowers/sdd/2026-10-07-algorithm-baseline-and-endpoint-review/task6-acceptance.py`. Sau cleanup, scratch script và full raw command logs nằm trong [verification_logs.zip](../outputs/tables/endpoint_modes_oct07/verification_logs.zip); archive entry names giữ nguyên đường dẫn gốc. Root lưu review/rulings trước cleanup.
 
 ## Enhanced trước/sau baseline
 
 **24/24 exact, 0 numeric regression**: full masks, FINAL regions, predicted/GT boundaries, region pairs, mọi metric cũ trừ intentional `model_schema_version` 2→3, status và mọi diagnostic cũ. T/W/noise/candidate W/F1 giữ nguyên. Bốn TEST enhanced mean MAE TT1/TT2/TT3 vẫn20.00/13.75/12.50 ms. Metadata schema/provenance mới không được dùng làm cớ để đổi số.
 
 Chi tiết before/after đầy đủ: [final_regression.csv](../outputs/tables/endpoint_modes_oct07/final_regression.csv); [baseline.json](../outputs/tables/endpoint_modes_oct07/baseline.json); [final_verification.json](../outputs/tables/endpoint_modes_oct07/final_verification.json).
@@ -90,11 +90,17 @@ LOW=T1 TT1 phone_M1 fold xấu thêm **+205ms**, fullmean54.997→106.247ms; kh
 | enhanced_cells_100 | tt1 | studio_M1 | +2.505669 |
 | enhanced_cells_100 | tt2 | studio_M1 | +2.505669 |
 | enhanced_cells_100 | tt3 | studio_M1 | +7.494331 |
 
 Tổng10MAE fold regressions,52alternative comparisons; count regression không xảy ra. Undefined core means được giữ. Bằng chứng: [fold_comparisons.csv](../outputs/tables/endpoint_modes_oct07/timing_research/fold_comparisons.csv), [heldout_summary.csv](../outputs/tables/endpoint_modes_oct07/timing_research/heldout_summary.csv), [manifest.json](../outputs/tables/endpoint_modes_oct07/timing_research/manifest.json), [physical waveforms](../outputs/tables/endpoint_modes_oct07/timing_research/locked_model_waveforms.csv).
 
 ## Coordination, review và archive
 
 Ruling cho Task4/5 chạy song song vì research không chặn integration, native/model interfaces đã ổn định và file ownership tách rõ. Task4 sở hữu decision_timing/check_endpoint_robustness/research/focusedtests; Task5 sở hữu CLI/config/run_experiment/summary/plotting/notebooktools/docs/geometry audit guard. Cost nếu interface drift: focused integration fixes và rerun complete regression. Gate fullsuite/regression chỉ chạy sau root STABLE; không stage/commit cùng lúc. Không production timing/default change được phép. Reviewer tìm P2: `main_tt1 --evaluate-all` có thể ghi đè shared `tables/all` bằng subset. Writer nay chỉ ghi shared benchmark khi selected chứa đủ3algorithms; demo1algorithm giữ run riêng, regression test kiểm cả3fixed-entrypoints và shared bytes. Root còn sửa label units từ sum thành mean-square đúng với Energy=STE/N; số học không đổi,6models/digests/plots và3freshkernel notebooks+ZIP đã regenerate. Gate171tests trướcfix được giữ riêng; saufix freshsuite173PASS và acceptance48casesPASS. Đây là rerun có lý do source mới, không lặp suite không cần thiết.
 
-Root lưu final independent review và artifact visual acceptance ở mục bàn giao dưới đây trước cleanup. RED/GREEN các Task1–5, reviewer packages/reports và intermediate taskN logs được bảo toàn exact bytes/digests trong [verification_logs.zip](../outputs/tables/endpoint_modes_oct07/verification_logs.zip). Standalone retained: baseline.json/final_verification.json/final_regression.csv/final_core_enhanced.csv/final_summary.csv/timing_research CSV+JSON và báo cáo này. Không xóa protected hoặc unowned artifacts.
+Final review phát hiện shared comparison bị partial run ghi đè, entrypoint docs cũ và ba link guide thiếu file. Routing nay giữ canonical comparison chỉ cho đủ ba thuật toán/evaluate-all/no-file; partial xuất `comparison/tables/<run_name>[/single/<inputstem>]`, không bỏ kết quả. Bốn comparison CSV và shared TEST CSV mỗi mode được kiểm byte qua fixed-all-dataset, default TEST-only và all/fixed single-file; full command vẫn cập nhật benchmark. Ba guide dùng shared `tables/all/test_metrics.csv` hiện có và lọc cột algorithm.
+
+Ruling single-file statistics: chỉ ghi evaluated WAV trong dataset_statistics.csv scoped của run. Full mode statistics/training_frames đã có TRAIN; không lặp TRAIN trong single-file. Dedup theo resolved wav_path, không theo filename; nguồn external trùng basename TRAIN vẫn phân biệt. Cost là focused fixture tests và một refresh metadata-only bằng run_experiment thật; không đổi arithmetic/tuning hoặc chạy lại notebook kernels. Full mode statistics sửa 12 dòng trùng/all_dataset thành 8 nguồn unique với 4TRAIN/4TEST; hai CSV này là intentional deltas, 195/197 fresh artifacts còn lại byte exact. Old canonical CSV và 124 protected hashes giữ nguyên.
+
+Final fix RED: ba regression tests ghi 11 failures cho partial routing/statistics/guide links; doc RED riêng fail1. GREEN14 integration tests; một fresh fullsuite sau source STABLE. Gate173 trước fix và acceptance trước fix được giữ thành before-final-review-fix evidence. Saved audit cả ba notebook/15PNG, exact ba CODE ZIP entries và source digests PASS; run_experiment writer không được nhúng, notebook/ZIP bytes không đổi. `outputs/endpoint_modes/comparison/artifact_audit.json` là snapshot lịch sử Task5 units/pre-final-routing; source toàn file trong snapshot không được tuyên bố hiện hành. Xem final_verification.json cho arithmetic/native/model/notebook audit hiện hành và final-fix-metadata-refresh.json trong verification archive cho hashes hai intentional CSV.
+
+Root lưu final independent review và artifact visual acceptance ở mục bàn giao dưới đây trước cleanup. RED/GREEN các Task1–5, final-fix evidence, reviewer packages/reports và intermediate taskN logs được bảo toàn exact bytes/digests trong [verification_logs.zip](../outputs/tables/endpoint_modes_oct07/verification_logs.zip). Standalone retained: baseline.json/final_verification.json/final_regression.csv/final_core_enhanced.csv/final_summary.csv/timing_research CSV+JSON và báo cáo này. Không xóa protected hoặc unowned artifacts.
diff --git a/reports/TT1_BINARY_SEARCH_GIAI_THICH.md b/reports/TT1_BINARY_SEARCH_GIAI_THICH.md
index c3f5a10..f4e2164 100644
--- a/reports/TT1_BINARY_SEARCH_GIAI_THICH.md
+++ b/reports/TT1_BINARY_SEARCH_GIAI_THICH.md
@@ -269,19 +269,19 @@ Mở terminal tại thư mục gốc của dự án:
 ```powershell
 python main_tt1.py
 python main_tt1.py --file phone_F2.wav
 python main_tt1.py --no-show
 python main_tt1.py --evaluate-all
 ```
 
 Mặc định chạy bốn test. `--file` chọn một WAV có LAB cùng tên. `--no-show` chỉ xuất file; `--evaluate-all` chấm cả tám WAV train/test và tự tắt cửa sổ.
 
 - [Model học được](../outputs/endpoint_modes/enhanced/models/tt1.json): ngưỡng, overlap, số vòng, noise.
-- [Bảng bốn test](../outputs/endpoint_modes/enhanced/tables/tt1/test_metrics.csv): MAE, RMSE, số vùng và status.
+- [Bảng bốn test chung](../outputs/endpoint_modes/enhanced/tables/all/test_metrics.csv): lọc `algorithm=tt1`; MAE, RMSE, số vùng và status.
 - [Ảnh phone_F2](../outputs/endpoint_modes/enhanced/figures/tt1/phone_F2.png): waveform, STE, High/Low, GT và final prediction.
 - [Diagnostic phone_F2](../outputs/endpoint_modes/enhanced/diagnostics/tt1/phone_F2.json): candidate và final được lưu riêng.
 
 ## 9. Cách giải thích ngắn khi thuyết trình
 
 “Em học một ngưỡng normalized STE từ các khung train có nhãn. Binary Search thu hẹp miền chồng lấn theo dấu của hiệu diện tích nhầm lẫn, dừng khi hai số đếm không đổi. Khi chạy test, ngưỡng tạo ứng viên; High/Low xác nhận và duy trì tiếng nói, nối gap dưới 200 ms, loại vùng dưới 100 ms. Biên cuối lấy theo support khung và MAE chỉ tính trên các vùng đã xác nhận.”
 
 Giới hạn cần hiểu: nguồn dùng MA còn project dùng STE; điều kiện dừng không giải diện tích chính xác; chuẩn hóa theo đỉnh mỗi WAV và noise train có thể hạn chế khả năng áp dụng sang môi trường nhiễu khác. Với bộ hiện tại, noise floor quyết định nhiều phần của biên cuối TT1.
diff --git a/reports/TT2_HISTOGRAM_GIAI_THICH.md b/reports/TT2_HISTOGRAM_GIAI_THICH.md
index e17c4aa..9913ae8 100644
--- a/reports/TT2_HISTOGRAM_GIAI_THICH.md
+++ b/reports/TT2_HISTOGRAM_GIAI_THICH.md
@@ -330,20 +330,20 @@ Tại thư mục gốc của dự án:
 ```powershell
 python main_tt2.py
 python main_tt2.py --file phone_F2.wav
 python main_tt2.py --no-show
 python main_tt2.py --evaluate-all
 ```
 
 Mặc định bốn test; `--file` chọn một WAV có LAB cùng tên; `--evaluate-all` chấm tám WAV và không mở cửa sổ. Chế độ một file fit bốn TRAIN trước khi đọc file đã chọn; không nạp bốn TEST để calibration.
 
 - [Model TT2](../outputs/endpoint_modes/enhanced/models/tt2.json): W train, W cuối, cấu hình histogram, noise.
-- [Bảng metric](../outputs/endpoint_modes/enhanced/tables/tt2/test_metrics.csv).
+- [Bảng metric chung](../outputs/endpoint_modes/enhanced/tables/all/test_metrics.csv): lọc `algorithm=tt2` để đọc bốn TEST của thuật toán này.
 - [Khảo sát W](../outputs/endpoint_modes/enhanced/tables/tt2_w_selection/sweep.csv): 200 lần chấm final regions.
 - [Diagnostic phone_F2](../outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_F2.json): M1/M2, TE, High/Low, candidate/final.
 - [Ảnh phone_F2](../outputs/endpoint_modes/enhanced/figures/tt2/phone_F2.png).
 
 ## 10. Cách giải thích ngắn và giới hạn
 
 “Em tính Energy từng khung 25 ms, tạo histogram 64 bin, làm trơn số đếm bằng tối đa 5 bin và lấy hai đỉnh đầu theo chiều năng lượng tăng. Ngưỡng là `(20*M1+M2)/21`. Bản này chỉ dùng Energy theo yêu cầu thầy. Sau khi tạo ứng viên, em dùng High/Low STE và điều kiện 200/100 ms để tạo final regions; chỉ các biên cuối mới được chấm MAE.”
 
 Energy-only nhẹ và dễ giải thích hơn, nhưng không có đặc trưng phổ để loại một số loại nhiễu. Histogram một đỉnh phải dùng fallback; hai đỉnh đầu có thể không đại diện đúng hai lớp. W20 không duy nhất trong khảo sát hiện tại. High/Low là phần cải tiến chung, còn 100 ms là tham số bổ sung; TEST có historical exposure và được dùng lại để đánh giá, nên cần trình bày giới hạn này.
diff --git a/reports/TT3_GAUSSIAN_GIAI_THICH.md b/reports/TT3_GAUSSIAN_GIAI_THICH.md
index 86ab433..afcfa7e 100644
--- a/reports/TT3_GAUSSIAN_GIAI_THICH.md
+++ b/reports/TT3_GAUSSIAN_GIAI_THICH.md
@@ -351,20 +351,20 @@ Tại thư mục gốc của dự án:
 ```powershell
 python main_tt3.py
 python main_tt3.py --file phone_F2.wav
 python main_tt3.py --no-show
 python main_tt3.py --evaluate-all
 ```
 
 Mặc định chạy bốn test; `--file` chọn một WAV có LAB cùng tên; `--no-show` chỉ xuất file; `--evaluate-all` chấm cả tám WAV và không mở cửa sổ.
 
 - [Model TT3](../outputs/endpoint_modes/enhanced/models/tt3.json): mean/std, nghiệm, sigma floor, T3, noise.
-- [Bảng metric TT3](../outputs/endpoint_modes/enhanced/tables/tt3/test_metrics.csv).
+- [Bảng metric chung TT3](../outputs/endpoint_modes/enhanced/tables/all/test_metrics.csv): lọc `algorithm=tt3` để đọc bốn TEST của thuật toán này.
 - [Ảnh phân phối train](../outputs/endpoint_modes/enhanced/figures/training/gaussian_distributions.png): minh họa mật độ từ tham số đã học, không chứng minh phân phối thực đúng Gaussian.
 - [Diagnostic phone_F2](../outputs/endpoint_modes/enhanced/diagnostics/tt3/phone_F2.json).
 - [Ảnh kết quả phone_F2](../outputs/endpoint_modes/enhanced/figures/tt3/phone_F2.png).
 
 ## 11. Cách giải thích ngắn và giới hạn
 
 “Em gom normalized STE của silence và speech trên train, tự tính mean và population standard deviation. Em giả định hai lớp có mật độ Gaussian, giải phương trình hai mật độ bằng nhau và chọn nghiệm giữa hai mean. Ngưỡng tạo ứng viên; High/Low cùng điều kiện thời lượng tạo final speech regions. MAE chỉ chấm START/END của các vùng cuối.”
 
 Giới hạn cần nêu: dữ liệu STE không được kiểm định Gaussian; normalized STE bị giới hạn [0,1] còn Gaussian trải trên toàn trục thực. Code dùng equal density không xét class priors. Một ngưỡng cố định học từ train có thể nhạy khi noise hoặc cách thu thay đổi. Hysteresis là phần bổ sung chung nên kết quả cuối không thể quy hoàn toàn cho một ngưỡng T3.
diff --git a/submission/README.md b/submission/README.md
index 879ad3b..364e2bc 100644
--- a/submission/README.md
+++ b/submission/README.md
@@ -1,20 +1,24 @@
 # Gói CODE chính — nghiệm thu 07/10/2026
 
-[JUPYTER_NOTEBOOKS_CODE_ONLY.zip](JUPYTER_NOTEBOOKS_CODE_ONLY.zip) là gói CODE hiện hành đã được kiểm tra nguồn/bytes ngày **07/10/2026**: đúng ba notebook đã thực thi, byte trùng file ngoài ZIP, không WAV/LAB/audio/module Python/slide. Ba notebook khớp model/metric/FINAL/ngưỡng với Python ở **24/24** trường hợp trên tám WAV, lưu tổng 15 PNG. Xem [hướng dẫn notebook](../notebooks/README.md) và [bằng chứng nghiệm thu](../outputs/tables/hotfix_oct06/verification.json).
+[JUPYTER_NOTEBOOKS_CODE_ONLY.zip](JUPYTER_NOTEBOOKS_CODE_ONLY.zip) là gói CODE hiện hành ngày **07/10/2026**: đúng ba notebook đã tái tạo và thực thi mới cho `core` và `enhanced`, byte trùng file ngoài ZIP, không WAV/LAB/audio/module Python/slide. Mỗi notebook lưu 16 dòng mode-file trên tám WAV (8 dòng mỗi mode) và 5 PNG, tổng 48 trường hợp thuật toán-mode-file và 15 PNG. Xem [hướng dẫn notebook](../notebooks/README.md), [báo cáo nghiệm thu hiện hành](../reports/KET_QUA_NGHIEM_THU_2026_10_07.md) và [final_verification.json](../outputs/tables/endpoint_modes_oct07/final_verification.json).
 
-Nghiệm thu hiện hành đạt **133/133 tests trong 13.862 s**, 0 regression trên 24 trường hợp; mean bốn TEST TT1/TT2/TT3 vẫn **20.00/13.75/12.50 ms**. Đợt sửa tài liệu và [khóa baseline](../outputs/tables/endpoint_modes_oct07/baseline.json) giữ số liệu này, không tái tạo notebook/ZIP. Năm trường hợp END muộn vẫn còn; không có tuyên bố cải thiện MAE.
+Gate suite mới sau sửa final review đạt **177/177 tests trong 19.208 s** (21.030 s wall), exit 0; số thực tế và bằng chứng nằm trong báo cáo/JSON nghiệm thu trên. Enhanced giữ **24/24** trường hợp exact, 0 numeric regression; mean bốn TEST TT1/TT2/TT3 vẫn **20.00/13.75/12.50 ms**. Core giữ các lỗi count/primary undefined trong đủ 48 trường hợp; không có tuyên bố cải thiện MAE cho mọi file.
 
-Ba model enhanced dùng giao thức TRAIN/schema 2: model/noise/W fit TRAIN trước TEST, TT2 W1–50 chấm FINAL trên bốn TRAIN (200 dòng), chọn W20 bằng tie preference 20 khi hòa. Candidate W1/F1 ≈ 0.898698 là diagnostic riêng. Metric chính là `mae_ms` / `rmse_ms`; thiếu/thừa vùng làm primary undefined. TEST đã được xem trong phát triển: `train_selected_reused_test`, `historical_test_exposure=true`; đổi protocol không tạo holdout độc lập.
+Sáu model (ba thuật toán × hai mode) dùng model schema 3 và metric schema 2: fit và khóa TRAIN trước đọc TEST. TT2 W1–50 chấm FINAL trên bốn TRAIN, **200 dòng mỗi mode**, enhanced chọn W20 bằng tie preference 20 khi hòa. Candidate W1/F1 ≈ 0.898698 là diagnostic riêng. Metric chính là `mae_ms` / `rmse_ms`; thiếu/thừa vùng làm primary undefined. TEST đã được xem trong phát triển: `train_selected_reused_test`, `historical_test_exposure=true`; đổi protocol không tạo holdout độc lập.
 
 `THUAT_TOAN_1.zip`, `THUAT_TOAN_2.zip`, `THUAT_TOAN_3.zip` và PPTX/PDF là **previous version (trước Stage1)**, cả chín binary giữ nguyên byte, chưa đồng bộ giao thức TRAIN/schema 2. Runtime đã chạy là Python 3.14; Python 3.10 chỉ kiểm tra cú pháp. CLI chấm cần WAV/LAB cùng tên. STT nhóm/họ tên/MSSV còn placeholder. Các trạng thái branch/push ngày 05/10 dưới đây là lịch sử, không mô tả trạng thái Git hiện tại.
 
+## Lịch sử hotfix / khóa baseline 07/10/2026
+
+Gate trước triển khai hai mode đạt **133/133 tests trong 13.862 s**, 24/24 trường hợp, ba model enhanced schema 2; mean TEST **20.00/13.75/12.50 ms**. Đợt sửa tài liệu và [khóa baseline](../outputs/tables/endpoint_modes_oct07/baseline.json) khi đó không tái tạo notebook/ZIP. Đây là bằng chứng lịch sử; CODE hiện hành đã được tái tạo cho hai mode. Xem [hotfix verification](../outputs/tables/hotfix_oct06/verification.json). Năm trường hợp END muộn vẫn còn.
+
 ## Lịch sử 05/10/2026
 
 Các số test, thời gian chạy và trạng thái tích hợp trong mục này là bằng chứng lịch sử Stage1/Stage4.
 
 [JUPYTER_NOTEBOOKS_CODE_ONLY.zip](JUPYTER_NOTEBOOKS_CODE_ONLY.zip) là gói CODE chính đã tái tạo và kiểm tra ngày **05/10/2026**: đúng ba notebook đã chạy, byte trùng file ngoài ZIP, không WAV/LAB/audio/module Python/slide. Xem [hướng dẫn notebook](../notebooks/README.md).
 
 Ba notebook chạy bằng ba kernel mới tại thư mục chính, khớp đầy đủ model/metric/FINAL/ngưỡng với Python ở **24/24** trường hợp trên tám WAV. TT2 có 200 dòng TRAIN, kiểm tra digest khóa model; saved outputs hợp lệ, tổng 15 PNG đã được xem trực quan. Trước đó ba notebook cũng chạy độc lập, mỗi thư mục chỉ có notebook riêng và data. Runtime thực tế **Python 3.14**; Python 3.10 mới được kiểm tra cú pháp, chưa chạy runtime.
 
 Bộ test cuối **98/98 đạt trong 22.091 s**; 24/24 trường hợp giữ nguyên so với `111ab37`, 0 regression, mean TEST 20.00/13.75/12.50 ms. SHA256 của 28 file data/Source không đổi. Xem [bảng hồi quy](../outputs/tables/all_all_dataset/regression_before_after.csv) và [kết quả hiện tại](../reports/KET_QUA_HIEN_TAI.md).
 
diff --git a/tests/test_endpoint_mode_integration.py b/tests/test_endpoint_mode_integration.py
index 7b52707..c687eb3 100644
--- a/tests/test_endpoint_mode_integration.py
+++ b/tests/test_endpoint_mode_integration.py
@@ -131,10 +131,117 @@ class EndpointModeIntegrationTests(unittest.TestCase):
                         path=root/'outputs/endpoint_modes'/mode/'tables'/f'{algorithm}_all_dataset'/'test_metrics.csv'
                         with path.open(encoding='utf-8-sig') as handle:rows=list(csv.DictReader(handle))
                         self.assertEqual(len(rows),8)
                         self.assertEqual({row['algorithm'] for row in rows},{algorithm})
 
     def test_histogram_metadata_names_mean_squared_energy(self):
         from app import pipeline
         features=dict(ste_norm=[0.,.5,1.],energy=[0.,2.,4.],starts=[0.,.01,.02],ends=[.025,.035,.045])
         _,diagnostic=pipeline.algorithm_decision('tt2',features,dict(bins=1,smooth_radius=0,W=5.,padding_frames=25))
         self.assertEqual(diagnostic['native_threshold_units'],'mean squared sample amplitude')
+
+    def test_partial_comparisons_preserve_complete_benchmark_and_export_scope(self):
+        import contextlib,csv,io,tempfile
+        from pathlib import Path
+        from unittest.mock import patch
+        from app import pipeline
+        from tests.test_notebook_protocol import tiny_dataset
+        def rows(path):
+            with path.open(encoding='utf-8-sig') as handle:return list(csv.DictReader(handle))
+        with tempfile.TemporaryDirectory() as temporary:
+            root=Path(temporary);tiny_dataset(root)
+            base=root/'outputs/endpoint_modes'
+            comparison=base/'comparison/tables'
+            with patch.multiple(pipeline,TRAIN_DIR=root/'train',TEST_DIR=root/'test',OUTPUT_DIR=root/'outputs'), \
+                 patch.object(pipeline,'make_file_figure',return_value=None),patch.object(pipeline,'plot_gaussian_training'), \
+                 contextlib.redirect_stdout(io.StringIO()):
+                full=parse_args(['--evaluate-all','--compare-endpoint-modes'])
+                pipeline.run_experiment(full)
+                canonical=rows(comparison/'all_metrics.csv')
+                self.assertEqual(len(canonical),8*3*2)
+                protected=[comparison/name for name in ('all_metrics.csv','all_summary.csv','test_metrics.csv','test_summary.csv')]
+                protected += [base/mode/'tables/all'/name for mode in ('core','enhanced') for name in ('test_metrics.csv','summary.csv')]
+                sentinels={path:path.read_bytes() for path in protected}
+                cases=[(parse_args(['--evaluate-all','--compare-endpoint-modes'],fixed_algorithm=algorithm),f'{algorithm}_all_dataset',8,{algorithm},None) for algorithm in ('tt1','tt2','tt3')]
+                cases.append((parse_args(['--compare-endpoint-modes']),'all',4,{'tt1','tt2','tt3'},None))
+                for algorithm in (None,'tt1','tt2','tt3'):
+                    args=parse_args(['--file',str(root/'test/phone_F2.wav'),'--compare-endpoint-modes'],fixed_algorithm=algorithm)
+                    cases.append((args,f'{algorithm or "all"}/single/phone_F2',1,{algorithm} if algorithm else {'tt1','tt2','tt3'},'phone_F2'))
+                for args,scope,count,algorithms,file in cases:
+                    with self.subTest(scope=scope):
+                        pipeline.run_experiment(args)
+                        for path,original in sentinels.items():self.assertEqual(path.read_bytes(),original,str(path))
+                        scoped=rows(comparison/scope/'all_metrics.csv')
+                        self.assertEqual(len(scoped),count*len(algorithms)*2)
+                        self.assertEqual({row['algorithm'] for row in scoped},algorithms)
+                        self.assertEqual({row['endpoint_mode'] for row in scoped},{'core','enhanced'})
+                        self.assertEqual(len(rows(comparison/scope/'all_summary.csv')),len(algorithms)*2)
+                        self.assertEqual(len(rows(comparison/scope/'test_metrics.csv')),min(count,4)*len(algorithms)*2)
+                        self.assertEqual(len(rows(comparison/scope/'test_summary.csv')),len(algorithms)*2)
+                        if file:self.assertEqual({row['file'] for row in scoped},{file})
+                self.assertEqual(rows(comparison/'all_metrics.csv'),canonical)
+                for path in protected[:4]:path.write_bytes(b'complete-benchmark-sentinel')
+                pipeline.run_experiment(full)
+                for path in protected[:4]:self.assertEqual(path.read_bytes(),sentinels[path])
+
+    def test_fresh_statistics_have_unique_sources_and_actual_splits(self):
+        import contextlib,csv,io,shutil,tempfile
+        from pathlib import Path
+        from unittest.mock import patch
+        from app import pipeline
+        from tests.test_notebook_protocol import tiny_dataset
+        def rows(path):
+            with path.open(encoding='utf-8-sig') as handle:return list(csv.DictReader(handle))
+        with tempfile.TemporaryDirectory() as temporary:
+            root=Path(temporary);tiny_dataset(root)
+            external=root/'external';external.mkdir()
+            for suffix in ('.wav','.lab'):shutil.copyfile(root/'train'/('phone_F1'+suffix),external/('phone_F1'+suffix))
+            with patch.multiple(pipeline,TRAIN_DIR=root/'train',TEST_DIR=root/'test',OUTPUT_DIR=root/'outputs'), \
+                 patch.object(pipeline,'make_file_figure',return_value=None),patch.object(pipeline,'plot_gaussian_training'), \
+                 contextlib.redirect_stdout(io.StringIO()):
+                pipeline.run_experiment(parse_args(['--evaluate-all','--compare-endpoint-modes']))
+                for mode in ('core','enhanced'):
+                    statistics=rows(root/'outputs/endpoint_modes'/mode/'tables/dataset_statistics.csv')
+                    self.assertEqual(len(statistics),8)
+                    self.assertEqual(len({row['file'] for row in statistics}),8)
+                    self.assertEqual([row['split'] for row in statistics].count('train'),4)
+                    self.assertEqual([row['split'] for row in statistics].count('test'),4)
+                pipeline.run_experiment(parse_args(['--file',str(external/'phone_F1.wav'),'--compare-endpoint-modes']))
+                for mode in ('core','enhanced'):
+                    scoped=rows(root/'outputs/endpoint_modes'/mode/'tables/all/single/phone_F1/dataset_statistics.csv')
+                    self.assertEqual(len(scoped),1)
+                    self.assertEqual((scoped[0]['file'],scoped[0]['split']),('phone_F1','external'))
+                real_load=pipeline.load_audio_folder
+                def load_with_external(folder):
+                    records=real_load(folder)
+                    return records+[pipeline.load_audio_file(external/'phone_F1.wav')] if folder==root/'test' else records
+                with patch.object(pipeline,'load_audio_folder',side_effect=load_with_external):
+                    pipeline.run_experiment(parse_args(['--compare-endpoint-modes']))
+                for mode in ('core','enhanced'):
+                    statistics=rows(root/'outputs/endpoint_modes'/mode/'tables/dataset_statistics.csv')
+                    self.assertEqual(len(statistics),9)
+                    self.assertEqual({row['split'] for row in statistics if row['file']=='phone_F1'},{'train','external'})
+
+    def test_current_guide_metric_links_exist_and_filter_algorithm(self):
+        from pathlib import Path
+        root=Path(__file__).resolve().parents[1]
+        for number,name in ((1,'BINARY_SEARCH'),(2,'HISTOGRAM'),(3,'GAUSSIAN')):
+            guide=root/f'reports/TT{number}_{name}_GIAI_THICH.md'
+            text=guide.read_text(encoding='utf-8-sig')
+            target='../outputs/endpoint_modes/enhanced/tables/all/test_metrics.csv'
+            self.assertIn(target,text)
+            self.assertTrue((guide.parent/target).is_file())
+            self.assertIn(f'algorithm=tt{number}',text)
+
+    def test_current_handoff_links_describe_dual_mode_artifacts(self):
+        import re
+        from pathlib import Path
+        root=Path(__file__).resolve().parents[1]
+        for relative in ('outputs/README.md','submission/README.md'):
+            path=root/relative;text=path.read_text(encoding='utf-8-sig')
+            current=text.split('## Lịch sử')[0]
+            for marker in ('48','schema 3','schema 2','200','16','5 PNG','final_verification.json','KET_QUA_NGHIEM_THU_2026_10_07.md'):
+                self.assertIn(marker,current,relative)
+            for target in re.findall(r'\]\(([^)]+)\)',current):
+                if target.endswith(('final_verification.json','KET_QUA_NGHIEM_THU_2026_10_07.md')):
+                    self.assertTrue((path.parent/target).is_file(),target)
+            self.assertNotIn('Chưa có model core riêng',current)
