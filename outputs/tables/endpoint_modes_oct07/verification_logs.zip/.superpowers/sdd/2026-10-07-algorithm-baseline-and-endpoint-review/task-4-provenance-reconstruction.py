import csv,hashlib,json,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from tools.check_endpoint_robustness import synthetic_branch_configs
folder=Path('outputs/tables/endpoint_modes_oct07/timing_research')
files=sorted(folder.glob('*.csv'))
def hashes():return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
before=hashes()
path=folder/'manifest.json'
manifest=json.loads(path.read_text(encoding='utf-8'))
native_before=manifest['synthetic_models']
configs=synthetic_branch_configs(native_before,manifest['trials'])
rows=list(csv.DictReader((folder/'locked_model_waveforms.csv').open(encoding='utf-8-sig')))
assert len(rows)==1216 and len(configs)==19 and len(native_before)==6
for row in rows:
 entry=configs[row['model_sha256']]
 assert entry['algorithm']==row['algorithm'] and entry['trial_id']==row['trial_id']
 assert entry['source_native_model_sha256'] in {r['model_sha256'] for r in native_before}
manifest['synthetic_branch_configs']=configs
path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
assert hashes()==before
assert json.loads(path.read_text(encoding='utf-8'))['synthetic_models']==native_before
payload=dict(reconstructed_from='saved manifest synthetic_models + trials; no refit, waveform scoring or audio reads',
 field='synthetic_branch_configs',branch_config_count=19,native_model_count=6,resolved_waveform_rows=1216,
 all_existing_csv_bytes_unchanged=True,csv_sha256_before=before,csv_sha256_after=hashes())
(folder/'provenance-reconstruction-check.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
print('19 direct branch configs; 6 native models retained; all 1216 waveform row hashes resolve; all 7 CSV byte hashes unchanged')
