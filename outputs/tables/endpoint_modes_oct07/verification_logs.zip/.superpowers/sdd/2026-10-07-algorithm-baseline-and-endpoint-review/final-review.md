# Final independent branch and Task 6 acceptance review

Reviewed revision: `d6b616c` on `codex/endpoint-modes`; comparison baseline: remote-backup revision `5ceb289c51079d53b977f5316bcc70971d119c47`. Review date: 2026-10-07. This report is the sole persistent review write. No implementation edits, subagents, suite reruns, notebook kernels, research reruns, canonical output regeneration, staging, commit, or push were performed by this reviewer.

## Verdicts

- **Whole-branch quality: REQUEST CHANGES.** Two Important/P2 findings and one Minor/P3 finding remain below; no Critical finding found.
- **Task 6 final handoff spec: FAIL at this checkpoint.** Quantitative/runtime/artifact acceptance clauses PASS on inspected evidence, but current-facing delivery documentation is inconsistent, the shared comparison writer can destroy its complete result set, and the explicitly controller-owned archive/cleanup/final-status steps remain pending. Pending cleanup is an acknowledged sequencing requirement rather than an unexpected implementation defect. Do not claim final Task 6 completion until these items are resolved.
- **Task 6 numeric/runtime/artifact evidence: PASS.** The findings do not invalidate the supplied 24-case enhanced regression, current 48-case saved evaluation, model lock, protected hashes, or fresh notebook/ZIP evidence at the reviewed revision.

## Review inputs and scope

Read the exact task-6-brief first, the approved plan, progress/rulings ledger, Task 6 implementation report, final review package and relevant actual source/artifact files. Inspected production changes in pipeline/CLI/config/plotting/weight selection, experimental decision timing and research branches, notebook builder/runner changes, integration/endpoint tests, current-facing documentation, final acceptance script/JSON and actual suite completion log. Prior scoped Task 5 fix review was consulted to distinguish already closed findings from the newly uncovered shared comparison case. Source stayed at d6b616c during the review.

Root supplied visual acceptance of all 15 saved notebook PNGs, three core phone_F2 figures and corrected TT2 mean-square legend; this reviewer inspected the visual record and code/metadata rather than claiming to have independently viewed those images. Broad suites, studies and notebook kernels were deliberately not repeated. The only inference execution was a bounded temporary-fixture reproduction for the concrete output-routing risk below.

## Strengths

1. Native algorithm decisions and endpoint policy are separated clearly. Core keeps TT1/TT3 native equality/direction and strict TT2 Energy inequality, with no fake LOW/HIGH/noise values, no final padding and no minimum speech filter. Enhanced defaults and legacy missing-mode behavior remain explicit.
2. The supplied actual suite ends `Ran 173 tests in 15.200s` / `OK`; JSON records exit 0 and 16.7944288 seconds wall time. Relevant tests exercise equality, exact estimated 200 ms separation, low-direction core Gaussian, empty/zero input, model-policy mismatch, nullable plotting, source digests and pre-TEST fit order.
3. The acceptance script compares every old enhanced metric except the deliberately changed model schema, all old diagnostics, full masks, FINAL regions, boundaries and region pairs against the captured baseline. It freshly fits all six models before TEST, verifies saved calibration/digests, scores 48 cases, and checks model immutability afterward. Reported results are 24 exact enhanced cases and 48 total scored cases.
4. Core count failures and large errors are retained: TT1 TEST phone_F2 predicts three regions, TT2 phone_F2/phone_F1 can predict two, primary MAE/RMSE and full means become undefined, and TT1 TRAIN 297.5/242.5 ms errors remain visible. Per-scope counts, defined-only median/min/max, worst files and valid-only means are explicitly distinguished.
5. Experimental timing remains opt-in and TRAIN-only. The code recalibrates each held-out TT2 branch on its three fitting files, keeps physical GT fixed, stores complete model provenance and does not silently install LOW=T1 or cells in production. The report discloses the +205 ms LOW=T1 regression and persistent physical 200/210 ms merges.
6. Protected-source arithmetic checks use a precise two-literal metadata allowlist rather than hiding arbitrary AST changes. Energy is correctly labeled mean squared sample amplitude in fresh production outputs. Historical research metadata remains explicitly tied to the older source rather than being rewritten as new evidence.
7. Notebook construction fits/locks both modes before TEST, embeds algorithm-specific standalone computation, preserves selected-mode figures, and reports both mode results. The supplied independent audits verify three fresh notebooks with five PNGs each and exactly three byte-equal notebook ZIP entries; 124 protected artifact hashes remain exact.
8. Historical TEST exposure, lack of Python 3.10 runtime verification, physical-silence limitations and scope boundaries are candidly retained. No claim of universal MAE improvement or independent reused TEST holdout is introduced.

## Actionable findings

### Important / P2 — Protect the complete comparison namespace from partial runs

**Location:** `app/pipeline.py:661-667`, particularly unconditional writes at 663-667. Related scope inputs are at 503-524 and run-folder selection at 535-540.

Every invocation with `--compare-endpoint-modes` writes the same `outputs/endpoint_modes/comparison/tables/{all_metrics,all_summary,test_metrics,test_summary}.csv` names, regardless of algorithm selection, file selection or dataset scope. After a full three-algorithm/eight-WAV comparison, a fixed-algorithm comparison replaces the shared tables with that algorithm only. An allowed default four-TEST comparison or `--file ... --compare-endpoint-modes` also replaces the all-dataset comparison with a subset. This silently removes results from the documented shared benchmark namespace even though the caller asked to inspect only a subset.

**Bounded independent reproduction:** in a `TemporaryDirectory`, created `tests.test_notebook_protocol.tiny_dataset`; patched pipeline TRAIN_DIR/TEST_DIR/OUTPUT_DIR to that temporary root and disabled plotting only. Executed the normal pipeline once with `parse_args(['--evaluate-all','--compare-endpoint-modes'])`, then once with the same args and `fixed_algorithm='tt1'`. Read the real CSV produced by each run. Result:

```json
{"comparison_file":"outputs/endpoint_modes/comparison/tables/all_metrics.csv","before_rows":48,"before_algorithms":["tt1","tt2","tt3"],"after_rows":16,"after_algorithms":["tt1"]}
```

No repository artifact was touched. This was a focused reproduction, not a suite or dataset study rerun.

The prior fix at 623-625 protects per-mode `tables/all` but does not protect these four comparison files. The existing integration sentinel test observes only the former paths, so it passes while the latter are overwritten.

**Requested correction:** keep complete canonical comparison tables scoped to a full three-algorithm/all-dataset run, and route fixed-algorithm, single-file and TEST-only comparison runs into explicitly scoped directories (or equivalently protect each full table according to its scope). Preserve useful outputs for partial runs. Add a meaningful byte-preservation regression covering complete comparison followed by fixed algorithms, default TEST-only and single-file runs. A defensive `input_path is None` check for canonical writers is reasonable; public CLI already rejects `--evaluate-all --file`, so that particular combination is not currently a reachable CLI bug.

### Important / P2 — Make the submission and outputs entry points describe the actual current deliverable

**Locations:** `submission/README.md:3-7`; `outputs/README.md:19` and `:33`.

The submission README labels 133 tests / 24 cases / schema-2 models / no notebook regeneration as the current 07/10 CODE acceptance and links the older hotfix evidence. The delivered ZIP now contains notebooks rebuilt and executed for both modes, with six schema-3 models and 48 scored cases; final supplied suite evidence is 173 tests. In the outputs README, the directory inventory still says there is no separate core model and calls old `models/` paths current, despite the newly added mode section and current six models. Its unqualified acceptance paragraph also links the older 133-test gate.

These are the entry points a recipient uses to identify the package and reproduce its provenance. Accurate permanent acceptance reports elsewhere do not resolve their contradictory current-status claims. The approved work explicitly required stale current documentation to be corrected while preserving history.

**Requested correction:** add/update the current handoff description with both modes, model schema 3 versus metric schema 2, actual final gate, current 48-case evidence and regenerated notebook/ZIP provenance. Label the baseline/hotfix 133-test paragraphs and old canonical directory inventory as historical; preserve their facts and links as historical evidence. Link current acceptance to `KET_QUA_NGHIEM_THU_2026_10_07.md` / `final_verification.json`. Use the new actual gate count if the routing fix increases it.

### Minor / P3 — Point the algorithm guides to tables present in the delivered tree

**Locations:** `reports/TT1_BINARY_SEARCH_GIAI_THICH.md:279`, `reports/TT2_HISTOGRAM_GIAI_THICH.md:340`, `reports/TT3_GAUSSIAN_GIAI_THICH.md:361`.

The newly changed metric links target `outputs/endpoint_modes/enhanced/tables/tt1/test_metrics.csv`, `tt2/test_metrics.csv` and `tt3/test_metrics.csv`. All three `Test-Path` checks returned False in the actual delivered tree. The current generated artifacts contain the common `tables/all/test_metrics.csv` and `tables/all_all_dataset/test_metrics.csv`; the algorithm-specific paths are only created after the reader runs an additional command.

**Requested correction:** link to an existing shared table and name the algorithm column/filter, or provide the promised per-algorithm tables without changing protected legacy artifacts. Existing shared tables are sufficient; new numerical regeneration is unnecessary solely to repair links.

## Task 6 clause assessment

| Criterion | Assessment |
| --- | --- |
| Targeted RED/GREEN and integrated suite with actual count | PASS on preserved task trace and actual 173-test completion log. No duplicate suite run by reviewer. |
| Enhanced 24 masks/FINAL/count/quantitative metrics/status unchanged | PASS on inspected baseline comparison code and final evidence; no numerical finding discovered. |
| Honest core missing/extra counts and undefined primary statistics | PASS. Reports retain invalid files and all worse core cases. |
| Six models locked before TEST; four TEST/eight WAV scoring; separate statistics | PASS for current saved artifacts. Shared comparison writer preservation is the P2 regression above. |
| Fresh standalone notebook source/output/model evidence and CODE ZIP exactness | PASS on supplied fresh execution/audit and actual source changes. |
| Source/data/slides/legacy Python ZIP/old canonical output preservation | PASS: acceptance records 124 protected exact hashes from 148 baseline paths. |
| Permanent report includes changes, before/after, worse files, timing/physical and runtime limitations | PASS. Submission/output entry-point alignment still fails as detailed above. |
| Independent final review, final plan/status, archive and scoped scratch cleanup | This review is delivered here. Controller archive/cleanup/status work was explicitly pending and must finish after findings are resolved. |

## Scope and follow-up guidance

No new detector arithmetic, W selection, Gaussian solver, frame geometry, TEST leakage or metric regression was found. Known physical-silence behavior is an explicitly disclosed research result, not a new regression requiring an unauthorized timing change. The existing two metadata literal corrections are appropriate; do not roll them back or rewrite historical research bytes.

Address the findings in one focused fix wave, run the relevant routing preservation tests and appropriate integrated gate because code will change, and perform a scoped rereview of those fixes. Updating links/prose alone does not require kernels or research reruns. If only run_experiment routing changes, embedded notebook detection/fit functions are unaffected; source/output evidence should be checked for actual dependency impact before deciding to regenerate notebooks. Preserve this review, the bounded reproduction details, all RED/GREEN and superseded gate traces in the final verification archive, then update the handoff report and final status truthfully.

A read-only tool call was interrupted once by automatic approval review being unable to complete because workspace credits were exhausted. It did not execute. After the user requested continuation, the review resumed from the prior checkpoint; no completed suite/study/check was repeated.

## Additional root-raised triage: inherited dataset-statistics duplication

**Minor/P3 follow-up, inherited from backup rather than a new branch regression.** At `app/pipeline.py:564-565`, the dataset-statistics writer concatenates four TRAIN rows with `audio_test`. In `--evaluate-all`, `audio_test` already contains all eight WAVs, producing 12 rows: four TRAIN duplicated, with the evaluation copy and actual TEST rows labeled `all_dataset`. Read-only inspection confirmed this exact pattern in the current core CSV and confirmed the identical writer expression exists at backup `5ceb289`. This does not change the correct 48 scoring rows or MAEs and does not add another new branch blocker.

If addressed in the same authorized handoff fix wave, write fresh mode statistics with each source WAV once and its actual TRAIN/TEST split; retain an explicit run scope separately if needed. Keep protected legacy canonical CSV bytes unchanged. The test should check eight unique files with four TRAIN/four TEST for an all-dataset run and appropriate scoped behavior for single-file runs. This is artifact metadata hygiene, not detector/tuning work.
