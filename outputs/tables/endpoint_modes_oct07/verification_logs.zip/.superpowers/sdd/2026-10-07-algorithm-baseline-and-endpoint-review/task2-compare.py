import copy
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from app.pipeline import predict_and_score

b = json.loads((ROOT/'outputs/tables/endpoint_modes_oct07/baseline.json').read_text(encoding='utf-8'))
records = {r['record_id']:r for r in b['records']}
checked=[]
for old in b['detections']:
    record=records[old['record_id']]
    model=b['models'][old['algorithm']]
    before=copy.deepcopy((record,model))
    new=json.loads(json.dumps(predict_and_score(old['algorithm'],record,dict(model,endpoint_mode='enhanced'))))
    for key,value in new.items():
        if key=='diagnostic':
            for name, previous in old[key].items():
                assert value[name]==previous,(old['record_id'],old['algorithm'],name)
        else:
            assert value==old[key],(old['record_id'],old['algorithm'],key)
    assert (record,model)==before
    checked.append(dict(record_id=old['record_id'],algorithm=old['algorithm'],old_diagnostics_exact=True,
                        mask_final_boundaries_metrics_status_exact=True))
assert len(checked)==24
allowed={'app/pipeline.py','tools/build_notebooks.py','outputs/README.md','submission/README.md','reports/KET_QUA_HIEN_TAI.md'}
unchanged=[]
for path,digest in b['sha256'].items():
    if path in allowed: continue
    assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest,path
    unchanged.append(path)
payload=dict(cases=checked,exact_cases=len(checked),unchanged_artifacts=len(unchanged))
(ROOT/'outputs/tables/endpoint_modes_oct07/task2-enhanced-regression.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
print(json.dumps(dict(exact_cases=len(checked),unchanged_artifacts=len(unchanged))))
