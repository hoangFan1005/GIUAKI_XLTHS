"""Task6 scratch acceptance; execute only after controller STABLE release."""
import ast, copy, csv, hashlib, importlib.metadata, json, platform, statistics, subprocess, sys, time, zipfile
from datetime import datetime, timezone
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))
from app import pipeline
from app.config import TRAIN_DIR, TEST_DIR
from tools import run_notebooks as runner
import nbformat
OUT = ROOT/'outputs/tables/endpoint_modes_oct07'
def norm(x): return json.loads(json.dumps(x))
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def check(x,label):
    if not x: raise AssertionError(label)
started=time.perf_counter()
baseline=json.loads((OUT/'baseline.json').read_text(encoding='utf-8'))
train=pipeline.prepare_records(pipeline.load_audio_folder(TRAIN_DIR))
models={}
for mode in ('core','enhanced'):
    for alg in ('tt1','tt2','tt3'):
        models[mode,alg],_=pipeline.fit_training_model(alg,train,endpoint_mode=mode)
        saved=json.loads((ROOT/f'outputs/endpoint_modes/{mode}/models/{alg}.json').read_text(encoding='utf-8'))
        check(norm(models[mode,alg])==saved,f'{mode}/{alg} fresh calibration differs from saved')
        m=models[mode,alg]
        check(m['parameter_selection_set']=='train' and m['historical_test_exposure'] is True and 'W_selection_test' not in m,f'{mode}/{alg} provenance')
        stripped=copy.deepcopy(m); locked=stripped.pop('calibration_digest')
        if alg=='tt2': stripped['W_selection_train'].pop('calibration_digest')
        calculated=hashlib.sha256(json.dumps(stripped,sort_keys=True,ensure_ascii=False,allow_nan=False).encode()).hexdigest()
        check(calculated==locked,f'{mode}/{alg} calibration digest')
# All six models locked before TEST file loading.
lock_before={k:json.dumps(v,sort_keys=True) for k,v in models.items()}
test=pipeline.prepare_records(pipeline.load_audio_folder(TEST_DIR))
records={f"{r['split']}/{r['name']}":r for r in train+test}
results={}
for (mode,alg),model in models.items():
    for rid,r in records.items():
        results[mode,alg,rid]=norm(pipeline.predict_and_score(alg,r,model))
check(all(json.dumps(models[k],sort_keys=True)==v for k,v in lock_before.items()),'model mutation during scoring')
regression=[]
for old in baseline['detections']:
    rid,alg=old['record_id'],old['algorithm']; actual=results['enhanced',alg,rid]
    for key in ('mask','final_regions','predicted_boundaries','ground_truth_regions','ground_truth_boundaries','region_pairs'):
        check(actual[key]==old[key],f'{rid}/{alg}/{key}')
    for key,value in old['metrics'].items():
        if key!='model_schema_version': check(actual['metrics'][key]==value,f'{rid}/{alg}/metric/{key}')
    for key,value in old['diagnostic'].items(): check(actual['diagnostic'][key]==value,f'{rid}/{alg}/diagnostic/{key}')
    regression.append(dict(record_id=rid,algorithm=alg,before_mae_ms=old['metrics']['mae_ms'],after_mae_ms=actual['metrics']['mae_ms'],before_regions=json.dumps(old['final_regions']),after_regions=json.dumps(actual['final_regions']),status=actual['metrics']['status'],numeric_mask_final_diagnostic_exact=True))
for alg,old in baseline['models'].items():
    for key in ('threshold','W','endpoint_noise','candidate_frame_selected_W','candidate_frame_f1'):
        if key in old: check(models['enhanced',alg][key]==old[key],f'enhanced/{alg}/numeric/{key}')
protected={}; intentional={}
for rel,expected in baseline['sha256'].items():
    actual=digest(ROOT/rel)
    protect=rel.startswith(('Source/','data/','slides/','outputs/models/','outputs/tables/','outputs/diagnostics/','outputs/predictions/')) or rel.startswith('submission/THUAT_TOAN_') and rel.endswith('.zip')
    if protect:
        check(actual==expected,f'protected hash changed: {rel}'); protected[rel]=actual
    elif actual!=expected: intentional[rel]=dict(before=expected,after=actual)
comparison=[]; summaries=[]
for (mode,alg,rid),r in results.items():
    m=r['metrics']; gt=len(r['ground_truth_regions']); predicted=len(r['final_regions'])
    check(m['ground_truth_region_count']==gt and m['predicted_region_count']==predicted,f'{mode}/{alg}/{rid}/counts')
    if gt!=predicted: check(m['mae_ms'] is None and m['rmse_ms'] is None,f'{mode}/{alg}/{rid}/undefined')
    if mode=='core': check(r['diagnostic']['low_ste_threshold'] is None and r['diagnostic']['high_ste_threshold'] is None,f'core LOW/HIGH {alg}/{rid}')
    comparison.append(dict(mode=mode,algorithm=alg,record_id=rid,gt_regions=gt,predicted_regions=predicted,missing=m['missing_region_count'],extra=m['extra_region_count'],mae_ms=m['mae_ms'],rmse_ms=m['rmse_ms'],status=m['status'],final_regions=json.dumps(r['final_regions'])))
for mode in ('core','enhanced'):
    for alg in ('tt1','tt2','tt3'):
        for split in ('all','test'):
            rows=[r for r in comparison if r['mode']==mode and r['algorithm']==alg and (split=='all' or r['record_id'].startswith('test/'))]
            defined=[r for r in rows if r['mae_ms'] is not None]; values=[r['mae_ms'] for r in defined]
            summaries.append(dict(mode=mode,algorithm=alg,scope=split,total_files=len(rows),defined_files=len(defined),invalid_files=len(rows)-len(defined),mean_mae_ms=statistics.mean(values) if len(defined)==len(rows) else None,valid_only_mean_mae_ms=statistics.mean(values) if values else None,median_defined_mae_ms=statistics.median(values) if values else None,min_defined_mae_ms=min(values) if values else None,max_defined_mae_ms=max(values) if values else None,mean_file_rmse_ms=statistics.mean(r['rmse_ms'] for r in defined) if len(defined)==len(rows) else None,missing_regions=sum(r['missing'] for r in rows),extra_regions=sum(r['extra'] for r in rows),worst_defined_files=json.dumps([r['record_id'] for r in defined if r['mae_ms']==max(values)]),invalid_file_names=json.dumps([r['record_id'] for r in rows if r['mae_ms'] is None])))
notebooks=[]
with zipfile.ZipFile(ROOT/'submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip') as archive:
    names=archive.namelist(); check(len(names)==3 and all(n.endswith('.ipynb') for n in names),'CODE ZIP must contain exactly 3 notebooks')
    for n in range(1,4):
        path=ROOT/f'notebooks/THUAT_TOAN_{n}.ipynb'; notebook=nbformat.read(path,as_version=4)
        images,mean=runner.audit_notebook(notebook,path.name)
        match=[name for name in names if Path(name).name==path.name]; check(len(match)==1 and archive.read(match[0])==path.read_bytes(),f'ZIP bytes {path.name}')
        notebooks.append(dict(file=path.name,sha256=digest(path),images=images,enhanced_test_mean_mae_ms=mean,code_source_sha256=runner.code_source_digest(notebook),dual_model_audit_pass=True,fresh_execution_counts=[c.execution_count for c in notebook.cells if c.cell_type=='code']))
source_checks=[]
for relative in ('core/features.py','core/endpoints.py','core/postprocess.py','core/metrics.py','algorithms/tt1_hodgkinson.py','algorithms/tt2_histogram.py','algorithms/tt3_gaussian.py'):
    before=subprocess.check_output(['git','show',f'47cc00b:{relative}']); after=(ROOT/relative).read_bytes()
    left_tree=ast.parse(before.decode('utf-8-sig')); right_tree=ast.parse(after.decode('utf-8-sig'))
    for tree in (left_tree,right_tree):
        if tree.body and isinstance(tree.body[0],ast.Expr) and isinstance(tree.body[0].value,ast.Constant) and isinstance(tree.body[0].value.value,str): tree.body.pop(0)
    same_ast=ast.dump(left_tree,include_attributes=False)==ast.dump(right_tree,include_attributes=False)
    check(same_ast,f'protected production arithmetic AST {relative}')
    source_checks.append(dict(path=relative,sha256=hashlib.sha256(after).hexdigest(),baseline_byte_exact=before==after,arithmetic_ast_unchanged=same_ast,allowed_change='module documentation only' if before!=after else None))
before=ast.parse(subprocess.check_output(['git','show','47cc00b:app/pipeline.py']).decode('utf-8-sig'))
after=ast.parse((ROOT/'app/pipeline.py').read_text(encoding='utf-8-sig'))
for name in ('algorithm_decision','detect_regions','fit_training_model'):
    def fn(tree): return ast.dump(next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name),include_attributes=False).encode()
    original_left=fn(before)
    reference=copy.deepcopy(before)
    allowed={'algorithm_decision':('sum of squared samples','mean squared sample amplitude'), 'fit_training_model':('Energy (sum of squared samples)','Energy (mean squared sample amplitude)')}
    edits=[]
    if name in allowed:
        old_label,new_label=allowed[name]
        function=next(n for n in reference.body if isinstance(n,ast.FunctionDef) and n.name==name)
        for node in ast.walk(function):
            if isinstance(node,ast.Constant) and node.value==old_label:
                node.value=new_label; edits.append(dict(before=old_label,after=new_label))
        check(len(edits)==1,f'exact metadata allowlist occurrence {name}')
    left,right=fn(reference),fn(after); check(left==right,f'protected pipeline AST except exact Energy unit label {name}')
    source_checks.append(dict(path='app/pipeline.py::'+name,baseline_ast_sha256=hashlib.sha256(original_left).hexdigest(),ast_sha256=hashlib.sha256(right).hexdigest(),arithmetic_ast_unchanged=True,exact_metadata_allowlist=edits))
research=OUT/'timing_research'
manifest=json.loads((research/'manifest.json').read_text(encoding='utf-8'))
branch_models=manifest['synthetic_branch_configs']
def full_model_hash(model): return hashlib.sha256(json.dumps(model,sort_keys=True,ensure_ascii=False,allow_nan=False).encode('utf-8')).hexdigest()
check(len(branch_models)==19,'research expected 19 branch configurations')
native_hashes={item['model_sha256'] for item in manifest['synthetic_models']}
for item in manifest['synthetic_models']: check(item['model_sha256']==full_model_hash(item['model']),'research native full model hash')
for sha,item in branch_models.items():
    check(sha==item['model_sha256']==full_model_hash(item['model']),'research branch full model hash')
    check(item['source_native_model_sha256'] in native_hashes,'research branch native source hash')
for item in manifest['models']:
    check(len(item['fit_files'])==3 and item['heldout_file'] not in item['fit_files'] and item['model']['training_files']==item['fit_files'],'research heldout fit provenance')
    check(item['model_sha256']==full_model_hash(item['model']),'research heldout model hash')
heldout_hashes={item['model_sha256'] for item in manifest['models']}
def read_rows(name):
    with (research/name).open(encoding='utf-8-sig',newline='') as handle: return list(csv.DictReader(handle))
waveform_rows=read_rows('locked_model_waveforms.csv'); heldout_rows=read_rows('heldout_scores.csv'); sweep_rows=read_rows('tt2_branch_fit_sweep.csv')
check(len(waveform_rows)==1216 and len(heldout_rows)==76 and len(sweep_rows)==3600,'research declared evaluation budgets')
for row in waveform_rows:
    item=branch_models.get(row['model_sha256']); check(item is not None,'research waveform unresolved SHA')
    check(item['trial_id']==row['trial_id'] and item['algorithm']==row['algorithm'],'research waveform branch identity')
for row in heldout_rows: check(row['model_sha256'] in heldout_hashes,'research heldout unresolved SHA')
fold_rows=read_rows('fold_comparisons.csv')
low_regressions=[r for r in fold_rows if r['trial_id']=='enhanced_tt1_t1_support_100' and r['file']=='phone_M1' and r['algorithm']=='tt1']
check(len(low_regressions)==1 and abs(float(low_regressions[0]['delta_mae_ms'])-205)<1e-8,'research LOW=T1 +205ms regression')
research_audit=dict(native_full_hashes_validated=len(native_hashes),heldout_fit_provenance_models_validated=len(manifest['models']),branch_config_count=len(branch_models),native_models=len(native_hashes),resolved_waveform_rows=len(waveform_rows),resolved_heldout_rows=len(heldout_rows),tt2_calibration_rows=len(sweep_rows),low_t1_phone_m1_regression_ms=float(low_regressions[0]['delta_mae_ms']),artifact_sha256={p.name:digest(p) for p in sorted(research.glob('*')) if p.suffix in ('.csv','.json')})
pipeline.write_csv(OUT/'final_regression.csv',regression)
pipeline.write_csv(OUT/'final_core_enhanced.csv',comparison)
pipeline.write_csv(OUT/'final_summary.csv',summaries)
result=dict(handoff_status='numeric and artifact acceptance passed; independent final review pending',verified_utc=datetime.now(timezone.utc).isoformat(),environment=dict(python=sys.version,executable=sys.executable,platform=platform.platform(),python310_verified=sys.version_info[:2]==(3,10),packages={n:importlib.metadata.version(n) for n in ('numpy','matplotlib','nbformat','nbclient','ipython')}),enhanced_exact_cases=len(regression),scored_cases=len(results),all_models_locked_before_test=True,models_unchanged_after_inference=True,native_calibration_saved_fresh_exact=True,models={f'{mode}/{alg}':model for (mode,alg),model in models.items()},research_audit=research_audit,full_suite=json.loads((OUT/'task6-full-suite.json').read_text(encoding='utf-8')),protected_production_source_checks=source_checks,baseline_hash_count=len(baseline['sha256']),protected_hash_count=len(protected),protected_unchanged=protected,intentional_changed_baseline_paths=intentional,notebooks=notebooks,code_zip_sha256=digest(ROOT/'submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip'),summary=summaries,acceptance_runtime_seconds=time.perf_counter()-started)
pipeline.write_json(OUT/'final_verification.json',result)
print(json.dumps({k:result[k] for k in ('enhanced_exact_cases','scored_cases','baseline_hash_count','protected_hash_count','native_calibration_saved_fresh_exact','acceptance_runtime_seconds')},ensure_ascii=False))
print(json.dumps(summaries,ensure_ascii=False))
