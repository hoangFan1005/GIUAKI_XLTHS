### Task6 — Nghiệm thu và báo cáo để bàn giao

**Files:** tạo một report kết quả thực thi trong `reports/`, một bảng before/after enhanced và một bảng core/enhanced trong outputs; cập nhật currentreport với link, không sửa lịch sử thành dữ liệu mới.

- [ ] Chạy tests mục tiêu sau mỗi thay đổi lớn, toàn suite sau tích hợp; unit tests phải có RED/GREEN khi thêm hành vi. Số133 là baseline, không ấn định sốtests tương lai phải bằng133.
- [ ] Enhanced: mọi24 FINAL/count/mask/quantitative metric/status trước–sau phải giữ; schema/provenance mới được đổi có chủ đích. Mọi thay đổi numeric bất ngờ là regression cần xử lý trước bàn giao.
- [ ] Core: báo đúng số vùng, thiếu/thừa, MAE undefined; có thể cao hơn enhanced. Không chọn nhánh báo cáo theo file để chỉ lấy điểm tốt.
- [ ] Chạy4 TEST sau khóa model, đánh giá8 WAV để regression; mean/median/min/max, counts và worstfiles riêng từng mode/algorithm. TEST đã được nhìn ở nhiều lượt phát triển, giữ disclosure.
- [ ] Kiểm tra notebook độc lập/fresh source–output digests, model lock, ZIP không WAV/LAB; hash Source/data/slides/ZIP Python giữ nguyên. Dọn scratch do tác vụ tạo sau khi lưu evidence cần thiết.
- [ ] Reviewer độc lập kiểm code+spec+actualartifacts; report rõ hàm sửa, before/after, mọi file xấu đi, giới hạn physical200/shortspeech và runtime3.10 chưa kiểm nếu không có môi trường.

### Global Constraints

- Giữ3 thuật toán, Python tự tính; TT2 chỉ Energy, không F0/Centroid, không thêm ZCR/thuật toán thứ 4.
- Analysis frame 25 ms, hop 10 ms, nearest samples/ties-to-even; Fs44.1k dùng1102/441samples, thời gian thực được báo cáo.
- Minimum internal silence 200 ms; exact estimated200 ms phải giữ, <200 ms mới nối. Silence đầu/cuối không ép kéo dài200 ms.
- Mỗi FINAL speech region có START/END; không candidate/debug trong primary figure/MAE.
- TRAIN chọn tham số và khóa model trước mở TEST; target LAB chỉ dùng scoring/plot. Không rule filename, GT snapping, TEST tuning hoặc bỏ lỗi lớn.
- Giữ `historical_test_exposure=true`; legacy TEST-calibrated model phải giữ provenance cũ. Đổi protocol không tạo holdout độc lập.
- Metric schema 2 tiếp tục `mae_ms`/`rmse_ms`; thiếu/thừa vùng làm primary undefined, không dùng mean subset thay mean đầy đủ.
- Không sửa slides/PPTX/PDF, dữ liệu Source/audio hoặc ZIP Python cũ. CODE notebook ZIP được cập nhật khi source notebook thay đổi.
- Không hứa MAE core thấp hơn enhanced hoặc timestamp mới làm mọi file tốt lên.



Final delivery details: baseline snapshot remote backup branch codex/backup-before-endpoint-modes-20261007 at5ceb289c51079d53b977f5316bcc70971d119c47. Implementation stays local codex/endpoint-modes, no final push or merge requested. Update approved plan status/header to reflect actual execution (historical pending text may remain clearly dated). New artifact roots outputs/endpoint_modes/enhanced and /core; legacy outputs protected. Compare 24 current enhanced detections vs Task1 baseline actual numeric fields (metadata intentionally changes from model2 to3). Keep candidate diagnostics comparable. Current 137tests is Task1 gate, final future count from actual suite. Save review/rulings/verification summary in permanent report before scratch cleanup. Report core invalid scores faithfully and that TT1 enhanced threshold role is still the old noise/hysteresis policy; fix is separate faithful core reporting, not unproven automatic LOW replacement. Timing research findings need not automatically lower all MAEs; no default timing change authorized in plan.

Folder cleanup before final delivery: consolidate controller/implementer/reviewer evidence logs and intermediate taskN-* artifacts into a single verification_logs.zip under this run's evidence folder, preserving exact bytes/digests and full RED/GREEN/report trace. Retain standalone baseline.json, final_verification.json, final regression and core/enhanced comparison tables, and declared timing_research results; avoid dozens of loose intermediate logs/duplicate model dumps. Do not delete pre-existing hotfix/endpoint_robustness evidence, any protected canonical artifact, or any unowned file. Check all resolved deletion targets within exact run/scratch directories before native PowerShell deletion. Update only current report links as needed and explain archived logs location. Root will save final review record before plan scratch cleanup.
Controller coordination: prepare verification scripts in this plan scratch while Task5 regenerates; wait for root STABLE release before running fullsuite/regression/notebookaudit. You own final acceptance evidence/report/planstatus, not production code or notebooks. Root will stage/commit and perform final visual review, independent review and scratch cleanup. Do NOT stage/commit/delete or spawn agents. Single fullsuite fresh gate owned by you after STABLE; root will inspect actual logs. Preserve Task5 report KET_QUA_ENDPOINT_MODES_2026_10_07.md, add final acceptance report KET_QUA_NGHIEM_THU_2026_10_07.md and update current report link only after STABLE. You may use existing scratch task3-regression.py/capture-baseline.py as references, update regression script for intentional new metadata. Baseline preserves 148sha digests with intended docs/notebooks/CODEZIP changed; protected Source/data/slides/legacy ZIPs and oldcanonicaloutputs must remain exact. No implementation fixing: raise findings to root. Cleanup final evidence archive/SDDworkspace belongs root after final broadreview.
