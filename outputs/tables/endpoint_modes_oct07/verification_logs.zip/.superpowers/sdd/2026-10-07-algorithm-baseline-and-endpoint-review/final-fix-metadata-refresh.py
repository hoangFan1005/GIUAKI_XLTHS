"""Exercise the real full run writer, refreshing only the two statistics CSVs."""
import hashlib,json,os,sys
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))
os.environ['MPLBACKEND']='Agg'
from app import pipeline
from app.cli import parse_args
OUT=ROOT/'outputs/endpoint_modes'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def snapshot():return {p.relative_to(ROOT).as_posix():digest(p) for p in OUT.rglob('*') if p.is_file()}
before=snapshot()
targets={OUT/mode/'tables/dataset_statistics.csv' for mode in ('core','enhanced')}
real_write=pipeline.write_csv
def write_statistics_only(path,rows):
    if path in targets:real_write(path,rows)
with patch.object(pipeline,'write_csv',side_effect=write_statistics_only),patch.object(pipeline,'write_json'), \
     patch.object(pipeline,'make_file_figure',return_value=None),patch.object(pipeline,'plot_gaussian_training'):
    pipeline.run_experiment(parse_args(['--evaluate-all','--compare-endpoint-modes']))
after=snapshot()
changes={name:dict(before=before.get(name),after=after.get(name)) for name in before.keys()|after.keys() if before.get(name)!=after.get(name)}
assert set(changes)=={p.relative_to(ROOT).as_posix() for p in targets},changes
result=dict(command='real run_experiment(parse_args([--evaluate-all,--compare-endpoint-modes])) with statistics-only I/O',fresh_artifact_count=len(before),unchanged_fresh_artifacts=len(before)-len(changes),intentional_dataset_statistics_changes=changes,no_model_metric_prediction_diagnostic_figure_changes=True)
path=ROOT/'outputs/tables/endpoint_modes_oct07/final-fix-metadata-refresh.json'
path.write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps(result,indent=2))
