"""Controller-gated single fresh full suite; call only after STABLE."""
import json, os, re, subprocess, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
out=ROOT/'outputs/tables/endpoint_modes_oct07'
env=dict(os.environ,PYTHONIOENCODING='utf-8',MPLBACKEND='Agg')
command=[sys.executable,'-m','unittest','discover','-s','tests','-v']
started=time.perf_counter()
run=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,text=True,encoding='utf-8')
output=run.stdout+run.stderr
(out/'task6-full-suite.txt').write_text(output,encoding='utf-8')
match=re.search(r'Ran (\d+) tests in ([\d.]+)s',output)
result=dict(command=command,exit_code=run.returncode,test_count=int(match[1]) if match else None,unittest_runtime_seconds=float(match[2]) if match else None,wall_runtime_seconds=time.perf_counter()-started,passed=run.returncode==0 and bool(re.search(r'^OK\s*$',output,re.M)))
(out/'task6-full-suite.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
sys.exit(run.returncode if run.returncode else (0 if result['passed'] else 1))
