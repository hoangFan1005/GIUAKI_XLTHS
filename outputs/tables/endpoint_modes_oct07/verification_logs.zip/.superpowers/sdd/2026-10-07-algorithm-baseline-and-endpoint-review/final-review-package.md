# Final review — backup5ceb289..d6b616c
d6b616c Record full endpoint acceptance and TRAIN timing findings
c5e82dd Preserve shared benchmarks and correct Energy units
9227b1d Make timing research branch hashes directly traceable
b38d640 Integrate core and enhanced modes across CLI and notebooks
27dc471 Add TRAIN-only endpoint timing research
47cc00b Calibrate and lock TRAIN models and histogram weights by endpoint mode
116384e Separate native algorithm decisions from core and enhanced endpoints
c7f1b0e Lock current enhanced baseline and correct TRAIN artifact documentation
 .../task-1-report.md                               |    63 +
 README.md                                          |    22 +-
 algorithms/tt2_histogram.py                        |     2 +-
 app/cli.py                                         |     4 +-
 app/config.py                                      |     7 +
 app/pipeline.py                                    |   407 +-
 app/plotting.py                                    |    29 +-
 app/weight_selection.py                            |    25 +-
 core/decision_timing.py                            |    25 +
 ...10-07-algorithm-baseline-and-endpoint-review.md |     4 +-
 notebooks/README.md                                |    20 +-
 notebooks/THUAT_TOAN_1.ipynb                       |  4074 ++-
 notebooks/THUAT_TOAN_2.ipynb                       | 19632 +++++++++-
 notebooks/THUAT_TOAN_3.ipynb                       |  4100 ++-
 outputs/README.md                                  |    28 +-
 .../endpoint_modes/comparison/artifact_audit.json  |   103 +
 .../comparison/tables/all_metrics.csv              |    49 +
 .../comparison/tables/all_summary.csv              |     7 +
 .../comparison/tables/test_metrics.csv             |    25 +
 .../comparison/tables/test_summary.csv             |     7 +
 .../core/diagnostics/tt1/phone_F1.json             |    63 +
 .../core/diagnostics/tt1/phone_F2.json             |    55 +
 .../core/diagnostics/tt1/phone_M1.json             |    43 +
 .../core/diagnostics/tt1/phone_M2.json             |    35 +
 .../core/diagnostics/tt1/studio_F1.json            |    35 +
 .../core/diagnostics/tt1/studio_F2.json            |    35 +
 .../core/diagnostics/tt1/studio_M1.json            |    35 +
 .../core/diagnostics/tt1/studio_M2.json            |    31 +
 .../core/diagnostics/tt2/phone_F1.json             |   110 +
 .../core/diagnostics/tt2/phone_F2.json             |   100 +
 .../core/diagnostics/tt2/phone_M1.json             |   106 +
 .../core/diagnostics/tt2/phone_M2.json             |    98 +
 .../core/diagnostics/tt2/studio_F1.json            |    98 +
 .../core/diagnostics/tt2/studio_F2.json            |    80 +
 .../core/diagnostics/tt2/studio_M1.json            |    88 +
 .../core/diagnostics/tt2/studio_M2.json            |    78 +
 .../core/diagnostics/tt3/phone_F1.json             |    51 +
 .../core/diagnostics/tt3/phone_F2.json             |    51 +
 .../core/diagnostics/tt3/phone_M1.json             |    35 +
 .../core/diagnostics/tt3/phone_M2.json             |    43 +
 .../core/diagnostics/tt3/studio_F1.json            |    39 +
 .../core/diagnostics/tt3/studio_F2.json            |    35 +
 .../core/diagnostics/tt3/studio_M1.json            |    35 +
 .../core/diagnostics/tt3/studio_M2.json            |    35 +
 .../core/figures/comparison/phone_F1.png           |   Bin 0 -> 572786 bytes
 .../core/figures/comparison/phone_F2.png           |   Bin 0 -> 490404 bytes
 .../core/figures/comparison/phone_M1.png           |   Bin 0 -> 588886 bytes
 .../core/figures/comparison/phone_M2.png           |   Bin 0 -> 594824 bytes
 .../core/figures/comparison/studio_F1.png          |   Bin 0 -> 553808 bytes
 .../core/figures/comparison/studio_F2.png          |   Bin 0 -> 494272 bytes
 .../core/figures/comparison/studio_M1.png          |   Bin 0 -> 434986 bytes
 .../core/figures/comparison/studio_M2.png          |   Bin 0 -> 583835 bytes
 .../figures/training/gaussian_distributions.png    |   Bin 0 -> 94318 bytes
 .../endpoint_modes/core/figures/tt1/phone_F1.png   |   Bin 0 -> 209579 bytes
 .../endpoint_modes/core/figures/tt1/phone_F2.png   |   Bin 0 -> 178832 bytes
 .../endpoint_modes/core/figures/tt1/phone_M1.png   |   Bin 0 -> 215957 bytes
 .../endpoint_modes/core/figures/tt1/phone_M2.png   |   Bin 0 -> 216761 bytes
 .../endpoint_modes/core/figures/tt1/studio_F1.png  |   Bin 0 -> 203186 bytes
 .../endpoint_modes/core/figures/tt1/studio_F2.png  |   Bin 0 -> 183739 bytes
 .../endpoint_modes/core/figures/tt1/studio_M1.png  |   Bin 0 -> 161452 bytes
 .../endpoint_modes/core/figures/tt1/studio_M2.png  |   Bin 0 -> 212945 bytes
 .../endpoint_modes/core/figures/tt2/phone_F1.png   |   Bin 0 -> 210911 bytes
 .../endpoint_modes/core/figures/tt2/phone_F2.png   |   Bin 0 -> 177002 bytes
 .../endpoint_modes/core/figures/tt2/phone_M1.png   |   Bin 0 -> 216344 bytes
 .../endpoint_modes/core/figures/tt2/phone_M2.png   |   Bin 0 -> 218477 bytes
 .../endpoint_modes/core/figures/tt2/studio_F1.png  |   Bin 0 -> 204395 bytes
 .../endpoint_modes/core/figures/tt2/studio_F2.png  |   Bin 0 -> 183770 bytes
 .../endpoint_modes/core/figures/tt2/studio_M1.png  |   Bin 0 -> 160419 bytes
 .../endpoint_modes/core/figures/tt2/studio_M2.png  |   Bin 0 -> 212897 bytes
 .../endpoint_modes/core/figures/tt3/phone_F1.png   |   Bin 0 -> 209392 bytes
 .../endpoint_modes/core/figures/tt3/phone_F2.png   |   Bin 0 -> 176480 bytes
 .../endpoint_modes/core/figures/tt3/phone_M1.png   |   Bin 0 -> 216271 bytes
 .../endpoint_modes/core/figures/tt3/phone_M2.png   |   Bin 0 -> 217017 bytes
 .../endpoint_modes/core/figures/tt3/studio_F1.png  |   Bin 0 -> 202800 bytes
 .../endpoint_modes/core/figures/tt3/studio_F2.png  |   Bin 0 -> 183406 bytes
 .../endpoint_modes/core/figures/tt3/studio_M1.png  |   Bin 0 -> 160794 bytes
 .../endpoint_modes/core/figures/tt3/studio_M2.png  |   Bin 0 -> 212223 bytes
 outputs/endpoint_modes/core/models/tt1.json        |    42 +
 outputs/endpoint_modes/core/models/tt2.json        |   717 +
 outputs/endpoint_modes/core/models/tt3.json        |    47 +
 .../core/predictions/tt1/phone_F1.csv              |     4 +
 .../core/predictions/tt1/phone_F2.csv              |     8 +
 .../core/predictions/tt1/phone_M1.csv              |     4 +
 .../core/predictions/tt1/phone_M2.csv              |     4 +
 .../core/predictions/tt1/studio_F1.csv             |     4 +
 .../core/predictions/tt1/studio_F2.csv             |     4 +
 .../core/predictions/tt1/studio_M1.csv             |     4 +
 .../core/predictions/tt1/studio_M2.csv             |     4 +
 .../core/predictions/tt2/phone_F1.csv              |     6 +
 .../core/predictions/tt2/phone_F2.csv              |     6 +
 .../core/predictions/tt2/phone_M1.csv              |     4 +
 .../core/predictions/tt2/phone_M2.csv              |     4 +
 .../core/predictions/tt2/studio_F1.csv             |     4 +
 .../core/predictions/tt2/studio_F2.csv             |     4 +
 .../core/predictions/tt2/studio_M1.csv             |     4 +
 .../core/predictions/tt2/studio_M2.csv             |     4 +
 .../core/predictions/tt3/phone_F1.csv              |     4 +
 .../core/predictions/tt3/phone_F2.csv              |     4 +
 .../core/predictions/tt3/phone_M1.csv              |     4 +
 .../core/predictions/tt3/phone_M2.csv              |     4 +
 .../core/predictions/tt3/studio_F1.csv             |     4 +
 .../core/predictions/tt3/studio_F2.csv             |     4 +
 .../core/predictions/tt3/studio_M1.csv             |     4 +
 .../core/predictions/tt3/studio_M2.csv             |     4 +
 outputs/endpoint_modes/core/tables/all/summary.csv |     4 +
 .../core/tables/all/test_metrics.csv               |    13 +
 .../core/tables/all_all_dataset/run_config.json    |    48 +
 .../core/tables/all_all_dataset/summary.csv        |     4 +
 .../core/tables/all_all_dataset/test_metrics.csv   |    25 +
 .../tables/all_all_dataset/test_thresholds.csv     |    25 +
 .../core/tables/dataset_statistics.csv             |    13 +
 .../endpoint_modes/core/tables/training_frames.csv |  1292 +
 .../core/tables/tt2_w_selection/best_by_file.csv   |     5 +
 .../core/tables/tt2_w_selection/selection.json     |   634 +
 .../core/tables/tt2_w_selection/summary.csv        |    51 +
 .../core/tables/tt2_w_selection/sweep.csv          |   201 +
 .../enhanced/diagnostics/tt1/phone_F1.json         |    71 +
 .../enhanced/diagnostics/tt1/phone_F2.json         |    55 +
 .../enhanced/diagnostics/tt1/phone_M1.json         |    51 +
 .../enhanced/diagnostics/tt1/phone_M2.json         |    43 +
 .../enhanced/diagnostics/tt1/studio_F1.json        |    43 +
 .../enhanced/diagnostics/tt1/studio_F2.json        |    43 +
 .../enhanced/diagnostics/tt1/studio_M1.json        |    43 +
 .../enhanced/diagnostics/tt1/studio_M2.json        |    39 +
 .../enhanced/diagnostics/tt2/phone_F1.json         |    86 +
 .../enhanced/diagnostics/tt2/phone_F2.json         |    76 +
 .../enhanced/diagnostics/tt2/phone_M1.json         |    86 +
 .../enhanced/diagnostics/tt2/phone_M2.json         |    78 +
 .../enhanced/diagnostics/tt2/studio_F1.json        |    86 +
 .../enhanced/diagnostics/tt2/studio_F2.json        |    72 +
 .../enhanced/diagnostics/tt2/studio_M1.json        |    80 +
 .../enhanced/diagnostics/tt2/studio_M2.json        |    78 +
 .../enhanced/diagnostics/tt3/phone_F1.json         |    59 +
 .../enhanced/diagnostics/tt3/phone_F2.json         |    59 +
 .../enhanced/diagnostics/tt3/phone_M1.json         |    43 +
 .../enhanced/diagnostics/tt3/phone_M2.json         |    51 +
 .../enhanced/diagnostics/tt3/studio_F1.json        |    47 +
 .../enhanced/diagnostics/tt3/studio_F2.json        |    43 +
 .../enhanced/diagnostics/tt3/studio_M1.json        |    43 +
 .../enhanced/diagnostics/tt3/studio_M2.json        |    43 +
 .../enhanced/figures/comparison/phone_F1.png       |   Bin 0 -> 576309 bytes
 .../enhanced/figures/comparison/phone_F2.png       |   Bin 0 -> 492262 bytes
 .../enhanced/figures/comparison/phone_M1.png       |   Bin 0 -> 592586 bytes
 .../enhanced/figures/comparison/phone_M2.png       |   Bin 0 -> 597914 bytes
 .../enhanced/figures/comparison/studio_F1.png      |   Bin 0 -> 555792 bytes
 .../enhanced/figures/comparison/studio_F2.png      |   Bin 0 -> 496950 bytes
 .../enhanced/figures/comparison/studio_M1.png      |   Bin 0 -> 438811 bytes
 .../enhanced/figures/comparison/studio_M2.png      |   Bin 0 -> 587499 bytes
 .../figures/training/gaussian_distributions.png    |   Bin 0 -> 94318 bytes
 .../enhanced/figures/tt1/phone_F1.png              |   Bin 0 -> 210613 bytes
 .../enhanced/figures/tt1/phone_F2.png              |   Bin 0 -> 177839 bytes
 .../enhanced/figures/tt1/phone_M1.png              |   Bin 0 -> 216936 bytes
 .../enhanced/figures/tt1/phone_M2.png              |   Bin 0 -> 218113 bytes
 .../enhanced/figures/tt1/studio_F1.png             |   Bin 0 -> 203862 bytes
 .../enhanced/figures/tt1/studio_F2.png             |   Bin 0 -> 184308 bytes
 .../enhanced/figures/tt1/studio_M1.png             |   Bin 0 -> 161890 bytes
 .../enhanced/figures/tt1/studio_M2.png             |   Bin 0 -> 214282 bytes
 .../enhanced/figures/tt2/phone_F1.png              |   Bin 0 -> 211137 bytes
 .../enhanced/figures/tt2/phone_F2.png              |   Bin 0 -> 178406 bytes
 .../enhanced/figures/tt2/phone_M1.png              |   Bin 0 -> 217945 bytes
 .../enhanced/figures/tt2/phone_M2.png              |   Bin 0 -> 218911 bytes
 .../enhanced/figures/tt2/studio_F1.png             |   Bin 0 -> 204066 bytes
 .../enhanced/figures/tt2/studio_F2.png             |   Bin 0 -> 184382 bytes
 .../enhanced/figures/tt2/studio_M1.png             |   Bin 0 -> 162298 bytes
 .../enhanced/figures/tt2/studio_M2.png             |   Bin 0 -> 213644 bytes
 .../enhanced/figures/tt3/phone_F1.png              |   Bin 0 -> 210895 bytes
 .../enhanced/figures/tt3/phone_F2.png              |   Bin 0 -> 178591 bytes
 .../enhanced/figures/tt3/phone_M1.png              |   Bin 0 -> 217701 bytes
 .../enhanced/figures/tt3/phone_M2.png              |   Bin 0 -> 218874 bytes
 .../enhanced/figures/tt3/studio_F1.png             |   Bin 0 -> 204676 bytes
 .../enhanced/figures/tt3/studio_F2.png             |   Bin 0 -> 184958 bytes
 .../enhanced/figures/tt3/studio_M1.png             |   Bin 0 -> 162727 bytes
 .../enhanced/figures/tt3/studio_M2.png             |   Bin 0 -> 214192 bytes
 outputs/endpoint_modes/enhanced/models/tt1.json    |    50 +
 outputs/endpoint_modes/enhanced/models/tt2.json    |   899 +
 outputs/endpoint_modes/enhanced/models/tt3.json    |    55 +
 .../enhanced/predictions/tt1/phone_F1.csv          |     4 +
 .../enhanced/predictions/tt1/phone_F2.csv          |     4 +
 .../enhanced/predictions/tt1/phone_M1.csv          |     4 +
 .../enhanced/predictions/tt1/phone_M2.csv          |     4 +
 .../enhanced/predictions/tt1/studio_F1.csv         |     4 +
 .../enhanced/predictions/tt1/studio_F2.csv         |     4 +
 .../enhanced/predictions/tt1/studio_M1.csv         |     4 +
 .../enhanced/predictions/tt1/studio_M2.csv         |     4 +
 .../enhanced/predictions/tt2/phone_F1.csv          |     4 +
 .../enhanced/predictions/tt2/phone_F2.csv          |     4 +
 .../enhanced/predictions/tt2/phone_M1.csv          |     4 +
 .../enhanced/predictions/tt2/phone_M2.csv          |     4 +
 .../enhanced/predictions/tt2/studio_F1.csv         |     4 +
 .../enhanced/predictions/tt2/studio_F2.csv         |     4 +
 .../enhanced/predictions/tt2/studio_M1.csv         |     4 +
 .../enhanced/predictions/tt2/studio_M2.csv         |     4 +
 .../enhanced/predictions/tt3/phone_F1.csv          |     4 +
 .../enhanced/predictions/tt3/phone_F2.csv          |     4 +
 .../enhanced/predictions/tt3/phone_M1.csv          |     4 +
 .../enhanced/predictions/tt3/phone_M2.csv          |     4 +
 .../enhanced/predictions/tt3/studio_F1.csv         |     4 +
 .../enhanced/predictions/tt3/studio_F2.csv         |     4 +
 .../enhanced/predictions/tt3/studio_M1.csv         |     4 +
 .../enhanced/predictions/tt3/studio_M2.csv         |     4 +
 .../endpoint_modes/enhanced/tables/all/summary.csv |     4 +
 .../enhanced/tables/all/test_metrics.csv           |    13 +
 .../tables/all_all_dataset/run_config.json         |    48 +
 .../enhanced/tables/all_all_dataset/summary.csv    |     4 +
 .../tables/all_all_dataset/test_metrics.csv        |    25 +
 .../tables/all_all_dataset/test_thresholds.csv     |    25 +
 .../enhanced/tables/dataset_statistics.csv         |    13 +
 .../enhanced/tables/training_frames.csv            |  1292 +
 .../tables/tt2_w_selection/best_by_file.csv        |     5 +
 .../enhanced/tables/tt2_w_selection/selection.json |   808 +
 .../enhanced/tables/tt2_w_selection/summary.csv    |    51 +
 .../enhanced/tables/tt2_w_selection/sweep.csv      |   201 +
 outputs/tables/endpoint_modes_oct07/baseline.json  | 36611 +++++++++++++++++++
 .../endpoint_modes_oct07/final_core_enhanced.csv   |    49 +
 .../endpoint_modes_oct07/final_regression.csv      |    25 +
 .../tables/endpoint_modes_oct07/final_summary.csv  |    13 +
 .../endpoint_modes_oct07/final_verification.json   |  2479 ++
 .../endpoint_modes_oct07/task1-full-suite.txt      |   142 +
 .../endpoint_modes_oct07/task1-verification.json   |    31 +
 .../timing_research/fixed_oracle_cells.csv         |    49 +
 .../timing_research/fixed_oracle_support.csv       |    49 +
 .../timing_research/fold_comparisons.csv           |    53 +
 .../timing_research/heldout_scores.csv             |    77 +
 .../timing_research/heldout_summary.csv            |    20 +
 .../timing_research/locked_model_waveforms.csv     |  1217 +
 .../timing_research/manifest.json                  | 25603 +++++++++++++
 .../timing_research/protected_source_hashes.json   |    68 +
 .../endpoint_modes_oct07/timing_research/report.md |    84 +
 .../timing_research/tt2_branch_fit_sweep.csv       |  3601 ++
 reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md       |    82 +
 reports/KET_QUA_HIEN_TAI.md                        |    12 +-
 reports/KET_QUA_NGHIEM_THU_2026_10_07.md           |   100 +
 reports/TT1_BINARY_SEARCH_GIAI_THICH.md            |    26 +-
 reports/TT2_HISTOGRAM_GIAI_THICH.md                |    28 +-
 reports/TT3_GAUSSIAN_GIAI_THICH.md                 |    30 +-
 submission/JUPYTER_NOTEBOOKS_CODE_ONLY.zip         |   Bin 1644686 -> 1729936 bytes
 submission/README.md                               |    14 +-
 tests/test_decision_timing.py                      |    71 +
 tests/test_endpoint_mode_integration.py            |   140 +
 tests/test_endpoint_modes.py                       |   113 +
 tests/test_endpoint_robustness.py                  |    94 +
 tests/test_framing.py                              |     4 +-
 tests/test_notebook_protocol.py                    |    79 +-
 tests/test_training_protocol.py                    |   119 +-
 tests/test_weight_selection.py                     |    12 +
 tools/README.md                                    |    16 +
 tools/build_notebooks.py                           |    98 +-
 tools/check_endpoint_robustness.py                 |   306 +-
 tools/run_notebooks.py                             |   102 +-
 249 files changed, 107182 insertions(+), 2714 deletions(-)
diff --git a/.superpowers/sdd/2026-10-07-algorithm-baseline-and-endpoint-review/task-1-report.md b/.superpowers/sdd/2026-10-07-algorithm-baseline-and-endpoint-review/task-1-report.md
new file mode 100644
index 0000000..783c0a6
--- /dev/null
+++ b/.superpowers/sdd/2026-10-07-algorithm-baseline-and-endpoint-review/task-1-report.md
@@ -0,0 +1,63 @@
+# Task1 implementation report — 07/10/2026
+
+Task1 is complete on `codex/endpoint-modes`. Scope: current-artifact documentation, four assertions in `tests/test_training_protocol.py`, and one execution evidence directory `outputs/tables/endpoint_modes_oct07/`. No detector/model numeric source, canonical models/tables/diagnostics/predictions, notebooks, slides, source/data inputs or ZIP files were regenerated or changed. No push was performed.
+
+## Baseline captured before prose edits
+
+`baseline.json` was captured using `.venv/Scripts/python.exe` from all three saved enhanced models, without fitting. It contains eight records with complete features/labels, 24 detections with full masks, FINAL regions, all numeric metrics/status, threshold diagnostics and explicit T/W/LOW/HIGH, all saved model fields, Python/platform/package versions, Git HEAD, and 148 SHA256 entries. It is one reference evidence file, not a project snapshot.
+
+Read-only inference verified exact equality against all 24 saved diagnostic JSON objects and every metric field in the current 24-row metrics CSV. FINAL regions, MAE and status also match all 24 `hotfix_oct06/regression.csv` acceptance rows. Mean four TEST MAE is TT1 `19.999999999999993`, TT2 `13.749999999999986`, TT3 `12.50000000000001` ms (displayed 20.00/13.75/12.50). All 38 protected Source/data/slides/legacy ZIP hashes recorded in the Oct07 evidence match. After documentation/tests/full-suite execution, all 145 captured non-document artifacts retain their hashes; three owned documents are the intentional differences. Details and baseline digest are in `task1-verification.json`.
+
+Capture command (scratch script retained beside this report, not a production helper):
+
+```powershell
+$env:PYTHONUTF8='1'; $env:MPLBACKEND='Agg'
+.venv/Scripts/python.exe .superpowers/sdd/2026-10-07-algorithm-baseline-and-endpoint-review/capture-baseline.py
+```
+
+The capture writes exclusively using file mode `x` and refuses to overwrite an existing baseline. It must not be rerun to replace this baseline after later implementation tasks.
+
+## Assertions and RED/GREEN evidence
+
+Read `superpowers:test-driven-development/SKILL.md` and `writing-good-tests.md`. The brief explicitly requires README assertions, overriding the general skill advisory that human prose normally earns no tests. Breaks covered: accidentally labeling the TRAIN W sweep as TEST; ambiguous casefold metric headers/schema drift; obsolete metric aliases in current guidance; and treating Oct05 acceptance/Git history as current. Tests consume real existing CSVs and documents, without mocks or regenerated artifacts. The existing notebook protocol tests already check model-lock and TRAIN sweep behavior and were rerun without modification.
+
+RED command:
+
+```powershell
+$env:PYTHONUTF8='1'; $env:MPLBACKEND='Agg'
+.venv/Scripts/python.exe -m unittest tests.test_training_protocol.CurrentArtifactDocumentationTests -v
+```
+
+Result: **4 tests, 2 passed, 2 expected assertion failures**, exit 1, 0.003 s. `test_outputs_readme_labels_current_sweep_as_train_and_schema_two` failed because the linked W-sweep line said `4 test` and had no `TRAIN`. `test_submission_readme_separates_current_acceptance_from_oct05_history` failed because the README had no dated history section and still presented 98/98 as current. These were assertion failures, not collection/runtime errors. Existing artifact header/sweep checks passed immediately as characterization coverage.
+
+GREEN command:
+
+```powershell
+$env:PYTHONUTF8='1'; $env:MPLBACKEND='Agg'
+.venv/Scripts/python.exe -m unittest tests.test_training_protocol tests.test_notebook_protocol -v
+```
+
+Result: **27/27 passed**, exit 0, 4.427 s, including both formerly failing README assertions.
+
+Full-suite command:
+
+```powershell
+$env:PYTHONUTF8='1'; $env:MPLBACKEND='Agg'
+.venv/Scripts/python.exe -m unittest discover -s tests -v 2>&1 | Out-File -Encoding utf8 outputs/tables/endpoint_modes_oct07/task1-full-suite.txt
+```
+
+Result: **137/137 passed**, exit 0, 11.152 s. This includes the accepted existing 133 tests plus four added assertions. Complete per-test output is in `task1-full-suite.txt`; there were no omitted suite failures. One initial sandboxed Python-launch attempt failed with Windows `Access is denied`; the authorized launcher commands then succeeded with `require_escalated`. No alternate interpreter was used for project test/inference execution.
+
+## Documentation changes and self-review
+
+`outputs/README.md` now identifies the current 200-row W sweep as four TRAIN files, distinguishes FINAL W20 from candidate diagnostics, names schema 2 primary `mae_ms` / `rmse_ms` and separate tolerance metrics, retains historical TEST exposure and legacy provenance, and links the accepted 133-test result and locked baseline.
+
+`submission/README.md` now leads with Oct07 acceptance (133 tests, unchanged 24 results, current source/ZIP byte audit), TRAIN/schema 2, historical exposure and delivery limitations. The original Oct05 text and branch/push statements remain under a dated historical section. `reports/KET_QUA_HIEN_TAI.md` adds the baseline reference and explicitly labels its Oct05 section as history. Metric formulas/names and historical numbers were preserved.
+
+Self-review inspected the source/test/doc diff, baseline content and count, full-suite log and preservation hash probe. `git diff --check` passes. Existing line endings were preserved on unchanged prose to keep the diff limited; added/changed lines have no trailing whitespace. Assertions use literal hand-checked TRAIN names and accepted test count. Numerical production/model files do not appear in the change list. Current baseline hashes also cover canonical output artifacts, saved notebooks and the CODE ZIP for later regression gates.
+
+## Remaining concerns
+
+No new Task1 blocker or numeric regression. Existing limitations remain: five late END cases, historical TEST exposure (no new independent holdout), estimated gap support rather than a physical silence guarantee, speech duration measured as support span, FINAL low-direction Gaussian rejection, unverified Python3.10 runtime, placeholders and old slide/Python ZIP versions. No new core model exists at this Task1 gate.
+
+Stage only the three owned documents, `tests/test_training_protocol.py`, this report and the three evidence files (`baseline.json`, `task1-verification.json`, `task1-full-suite.txt`). The scratch capture script is excluded from the commit. Local commit is permitted; no push.
diff --git a/README.md b/README.md
index 1a29a34..9dc6b58 100644
--- a/README.md
+++ b/README.md
@@ -1,11 +1,27 @@
 # Giữa kỳ XLTHS — phân đoạn tiếng nói và khoảng lặng
 
-Ba thuật toán Python: **TT1 Binary Search**, **TT2 Histogram chỉ Energy**, **TT3 Gaussian**. Đặc trưng, ngưỡng và metrics được tự tính; Matplotlib dùng để vẽ. Cấu hình chung: frame **25 ms**, hop **10 ms**; **200 ms** đo khoảng trống ước lượng giữa các support khung hoạt động; **100 ms** lọc theo span vùng support. Hai quy tắc này là heuristic, không bảo đảm khoảng lặng vật lý 200 ms hoặc tiếng nói thực 100 ms vì các khung có thể chồng lấn. Không tính F0.
+## Hai chế độ endpoint (07/10/2026)
+
+Mặc định `enhanced`: ngưỡng native tạo seed; noise TRAIN và HIGH/LOW xác nhận, giữ speech; nối gap support dưới 200 ms và lọc span dưới 100 ms. `core` giữ quyết định native và chỉ nối gap support dưới 200 ms, không lọc duration hoặc padding FINAL; LOW/HIGH là null. Gap ước lượng đúng 200 ms được giữ riêng. TT1 dùng STE ≥ T, TT2 dùng Energy > T, TT3 giữ hướng high/low của Gaussian native. Đây là hai chế độ endpoint của cùng ba thuật toán; enhanced là phần bổ sung của dự án.
+
+```powershell
+python main_tt1.py --endpoint-mode core
+python main.py --evaluate-all --compare-endpoint-modes
+```
+
+Mỗi mode fit và khóa model độc lập trên bốn TRAIN trước đọc TEST. Kết quả mới ở `outputs/endpoint_modes/core/` và `outputs/endpoint_modes/enhanced/`; bảng so sánh ở `outputs/endpoint_modes/comparison/tables/`. Model schema 3 giữ policy/digest, metric schema 2 tiếp tục `mae_ms`/`rmse_ms`. Thiếu/thừa vùng làm primary mean toàn bộ file undefined; `valid_files_*` là thống kê subset riêng. TEST có `historical_test_exposure=true`, không phải holdout độc lập. Không chọn mode tốt hơn riêng cho từng WAV.
+
+Notebook dùng `MODE="enhanced"` mặc định cho bốn TEST figure và một illustration; luôn fit/khóa `MODELS` cả hai mode trước TEST, xuất 16 dòng tám WAV/mode và bảng bốn TEST/mode. TT2 có 200 TRAIN sweep rows mỗi mode. Core plot native T; Energy TT2 được chuẩn hóa chỉ ở bước hiển thị. Source digest và model lock digests độc lập kiểm tra nguồn/outputs và model; Restart Kernel → Run All → Save vẫn chạy độc lập.
+
+PPTX/PDF và ZIP Python cũ giữ nguyên previous version. Các bảng, noise và ví dụ HIGH/LOW bên dưới mô tả enhanced; không phải công thức quyết định FINAL của core. Xem [báo cáo hai mode](reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md).
+
+
+Ba thuật toán Python: **TT1 Binary Search**, **TT2 Histogram chỉ Energy**, **TT3 Gaussian**. Đặc trưng, ngưỡng và metrics được tự tính; Matplotlib dùng để vẽ. Cấu hình chung: frame **25 ms**, hop **10 ms**; **200 ms** đo khoảng trống ước lượng giữa các support khung hoạt động; **100 ms** chỉ lọc theo span vùng support trong enhanced. Hai quy tắc này là heuristic, không bảo đảm khoảng lặng vật lý 200 ms hoặc tiếng nói thực 100 ms vì các khung có thể chồng lấn. Không tính F0.
 
 ## Mã nguồn Jupyter theo yêu cầu bổ sung
 
 Mỗi sinh viên có một notebook riêng, chứa toàn bộ code và kết quả đã chạy:
 
 - [TT1 — Binary Search](notebooks/THUAT_TOAN_1.ipynb)
 - [TT2 — Histogram Energy](notebooks/THUAT_TOAN_2.ipynb)
 - [TT3 — Gaussian](notebooks/THUAT_TOAN_3.ipynb)
@@ -48,19 +64,19 @@ Mỗi tài liệu gồm ý tưởng, ví dụ tính tay, công thức, các hàm
 | Thuật toán | Tài liệu |
 |---|---|
 | TT1 Binary Search | [Giải thích TT1](reports/TT1_BINARY_SEARCH_GIAI_THICH.md) |
 | TT2 Histogram Energy-only | [Giải thích TT2](reports/TT2_HISTOGRAM_GIAI_THICH.md) |
 | TT3 Gaussian | [Giải thích TT3](reports/TT3_GAUSSIAN_GIAI_THICH.md) |
 
 [Kết quả hiện tại và giới hạn](reports/KET_QUA_HIEN_TAI.md) tổng hợp 4 test và toàn bộ 8 WAV. [Báo cáo sửa lỗi ngày 06/10, nghiệm thu 07/10](reports/KET_QUA_SUA_LOI_2026_10_06.md) ghi hai sửa TT3, khảo sát timing/TRAIN, 133 tests và hồi quy 24 trường hợp không đổi.
 
-TT2 chỉ dùng **Energy**, không Centroid/F0. W20 chọn trên bốn TRAIN FINAL, khảo sát W1–50 với tie preference cố định 20; tất cả 50 W hòa trong TRAIN hiện tại (mean 13.747165532879801 ms). Candidate frame-F1 đề xuất W1 riêng. Mọi model/noise/W fit TRAIN trước TEST. Schema 2 ghi `train_selected_reused_test` và `historical_test_exposure=true`: TEST có lịch sử được xem, không khẳng định độc lập.
+TT2 chỉ dùng **Energy**, không Centroid/F0. Trong enhanced, W20 chọn trên bốn TRAIN FINAL, khảo sát W1–50 với tie preference cố định 20; tất cả 50 W hòa trong TRAIN hiện tại (mean 13.747165532879801 ms). Candidate frame-F1 đề xuất W1 riêng. Mọi model/noise/W fit TRAIN trước TEST. Model schema 3 và metric schema 2 ghi `train_selected_reused_test` và `historical_test_exposure=true`: TEST có lịch sử được xem, không khẳng định độc lập.
 
-TT3 giải giao điểm Gaussian bằng tọa độ được dịch tâm/chia scale, sigma floor `1e-9`, nghiệm quadratic ổn định và kiểm tra log-density. Hàm Gaussian thô `fit`/`predict` vẫn hỗ trợ hướng `low`; FINAL HIGH/LOW hiện yêu cầu `speech_direction='high'`. Model `low` hoặc hướng không hợp lệ bị từ chối rõ ràng khi fit model FINAL và khi detect, thay vì âm thầm mất vùng nói.
+TT3 giải giao điểm Gaussian bằng tọa độ được dịch tâm/chia scale, sigma floor `1e-9`, nghiệm quadratic ổn định và kiểm tra log-density. Hàm Gaussian thô `fit`/`predict` vẫn hỗ trợ hướng `low`; Enhanced FINAL HIGH/LOW yêu cầu `speech_direction='high'`; core giữ hướng native. Enhanced từ chối model `low` hoặc hướng không hợp lệ khi fit/detect FINAL; core dùng hướng high/low native đã học.
 
 ## 3. Bố trí thư mục
 
 ```text
 GIUAKI_XLTHS/
   main.py, main_tt1.py, main_tt2.py, main_tt3.py
   README.md, requirements.txt, .gitignore
   algorithms/       Ba thuật toán
diff --git a/algorithms/tt2_histogram.py b/algorithms/tt2_histogram.py
index c5076de..72f77b4 100644
--- a/algorithms/tt2_histogram.py
+++ b/algorithms/tt2_histogram.py
@@ -1,14 +1,14 @@
 """Energy-only histogram VAD, as requested by the teacher on 05/10/2026.
 
 Reference: Giannakopoulos PDF pp.1–2 supplies the histogram threshold method.
 This assignment uses energy only, not the reference's two-feature AND rule.
 Assignment adaptation: 25/10 ms framing; retain 250 ms candidate padding each
-side as 25 hop steps. FINAL endpoints use raw STE hysteresis without padding.
+side as 25 hop steps. Enhanced FINAL uses raw STE hysteresis without final padding; core FINAL uses native Energy decisions and support-gap merging.
 The paper does not fix bin count, smoothing window, W or fallback behavior.
 These engineering choices are exposed as parameters and diagnostics.
 """
 from __future__ import annotations
 
 import math
 
 from app.config import FRAME_MS, HOP_MS, MIN_SILENCE_SECONDS, SAMPLE_ROUNDING
diff --git a/app/cli.py b/app/cli.py
index ffea4c2..d63581f 100644
--- a/app/cli.py
+++ b/app/cli.py
@@ -17,33 +17,35 @@ def parse_args(argv=None, fixed_algorithm=None):
     if fixed_algorithm not in (None, "tt1", "tt2", "tt3"):
         raise ValueError("Main riêng phải là tt1, tt2 hoặc tt3")
     parser = argparse.ArgumentParser(description="Chạy endpoint detection; học ngưỡng/noise và chọn TT2 W bằng FINAL MAE trên TRAIN, sau đó chấm điểm TEST đã dùng trong lịch sử.")
     if fixed_algorithm is None:
         parser.add_argument("--algorithm", choices=("all", "tt1", "tt2", "tt3", "tt2-context"), default="all",
                             help="all so sánh ba thuật toán; mỗi tt chạy thuật toán tương ứng.")
     else:
         parser.set_defaults(algorithm=fixed_algorithm)
+    parser.add_argument("--endpoint-mode", choices=("enhanced", "core"), default="enhanced", help="enhanced (default): TRAIN noise HIGH/LOW; core: native decisions and support gaps.")
+    parser.add_argument("--compare-endpoint-modes", action="store_true", help="Fit both modes on TRAIN before TEST; export headless comparison.")
     parser.add_argument("--file", metavar="WAV", default=None,
                         help="Tên WAV trong data/test hoặc data/train, hoặc đường dẫn WAV có LAB cùng tên.")
     parser.add_argument("--no-show", action="store_true", help="Chỉ xuất ảnh/CSV; không mở cửa sổ.")
     parser.add_argument('--evaluate-all',action='store_true',help='Chạy cả 8 WAV train+test, headless. Mọi tham số và TT2 W chọn trên TRAIN; chấm điểm TRAIN/TEST bằng model đã khóa.')
     parser.add_argument("--snr-study", action="store_true", help="Thêm khảo sát nhiễu tổng hợp 20/10/0 dB.")
     # Benchmark ngữ cảnh cần đủ 4 test, còn main riêng chỉ chạy thuật toán được giao.
     if fixed_algorithm is None:
         parser.add_argument("--compare-context", action="store_true",
                             help="Xuất thêm biến thể histogram STE và kiểm benchmark 4 WAV test.")
     else:
         parser.set_defaults(compare_context=False)
     parser.add_argument("--show-seconds", type=float, default=None,
                         help="Tự đóng cửa sổ sau số giây chỉ định khi kiểm tra demo.")
     args = parser.parse_args(argv)
     if args.evaluate_all and (args.file or args.compare_context):
         parser.error('--evaluate-all không kết hợp --file hoặc --compare-context.')
-    if args.evaluate_all:args.no_show=True
+    if args.evaluate_all or args.compare_endpoint_modes:args.no_show=True
     if args.file and args.compare_context:
         parser.error("--compare-context cần đủ 4 WAV test; hãy bỏ --file.")
     if args.show_seconds is not None and args.show_seconds <= 0:
         parser.error("--show-seconds phải lớn hơn 0.")
     return args
 
 
 def main(argv=None, fixed_algorithm=None):
diff --git a/app/config.py b/app/config.py
index 786fb58..29e683b 100644
--- a/app/config.py
+++ b/app/config.py
@@ -20,8 +20,15 @@ NOISE_LEVELS_DB = (20, 10, 0)
 RANDOM_SEED = 20261001
 ALGORITHM_TITLES = {
     "tt1": "TT1 - Hodgkinson: binary search",
     "tt2": "TT2 - Histogram: energy only",
     "tt3": "TT3 - Gaussian distributions",
     "tt2-context": "Histogram STE - context report variant",
 }
 FILE_ORDER = ("phone_F2", "phone_M2", "studio_F2", "studio_M2")
+
+
+def endpoint_mode_root(endpoint_mode, output_dir=None):
+    """Return the isolated production root for a declared endpoint mode."""
+    if endpoint_mode not in ('core', 'enhanced', 'comparison'):
+        raise ValueError('Unknown endpoint_mode')
+    return (OUTPUT_DIR if output_dir is None else Path(output_dir)) / 'endpoint_modes' / endpoint_mode
diff --git a/app/pipeline.py b/app/pipeline.py
index b92bfdd..16958ab 100644
--- a/app/pipeline.py
+++ b/app/pipeline.py
@@ -1,21 +1,23 @@
 """Học tham số bằng train, dự đoán test, lưu kết quả và điều phối demo."""
 import csv
+import hashlib
 import json
 import math
 import random
 import zlib
 from pathlib import Path
 
 import matplotlib.pyplot as plt
 
 from algorithms import tt1_hodgkinson as tt1
 from algorithms import tt2_histogram as tt2
 from algorithms import tt3_gaussian as tt3
+from app.config import endpoint_mode_root
 from app.config import (PROJECT_ROOT, TRAIN_DIR, TEST_DIR, OUTPUT_DIR, FILE_ORDER,
                         FRAME_MS, HOP_MS, SAMPLE_ROUNDING,
                         MIN_SILENCE_SECONDS, MIN_SPEECH_SECONDS, BOUNDARY_TOLERANCE_SECONDS,
                         HISTOGRAM_W_TIE_PREFERENCE,
                         NOISE_LEVELS_DB, RANDOM_SEED)
 from app.plotting import make_file_figure, show_figures, plot_gaussian_training
 from core.io_utils import read_wav, read_lab
 from core.features import compute_features
@@ -124,58 +126,95 @@ def prepare_records(audio_records, source_histogram=False):
         features = compute_features(base["samples"], base["sample_rate"],
                                     FRAME_MS, HOP_MS)
         record = dict(base, features=features,
                       labels=frame_labels(features["centers"], base["intervals"]))
         records.append(record)
     return records
 
 
+def algorithm_decision(algorithm: str, features: dict, params: dict) -> tuple[list[int], dict]:
+    """Return native unpadded decisions and thresholds without LAB or endpoint policy.
+
+    TT1/high TT3 include equality; low TT3 includes equality in the opposite
+    direction. TT2 uses strict raw Energy > threshold (context uses STE).
+    Existing TT2 padding diagnostics describe its candidate stage only.
+    """
+    if algorithm == 'tt1':
+        mask, diagnostic = tt1.predict(features, params), dict(threshold=params['threshold'])
+    elif algorithm == 'tt3':
+        if params.get('speech_direction', 'high') not in ('high', 'low'):
+            raise ValueError('Unknown TT3 speech_direction')
+        mask, diagnostic = tt3.predict(features, params), dict(threshold=params['threshold'])
+    elif algorithm in ('tt2', 'tt2-context'):
+        mask, diagnostic = tt2.predict(features, params)
+        if diagnostic['variant'] == 'source':
+            mask = [int(e > diagnostic['energy_threshold']) for e in features['energy']]
+    else:
+        raise ValueError(f'Unknown algorithm: {algorithm}')
+    source_histogram = algorithm in ('tt2', 'tt2-context') and diagnostic.get('variant') == 'source'
+    diagnostic.update(native_threshold=diagnostic['energy_threshold'] if algorithm in ('tt2', 'tt2-context') else params['threshold'],
+                      native_threshold_units='mean squared sample amplitude' if source_histogram else 'normalized STE')
+    return mask, diagnostic
+
+
 def detect_regions(algorithm, features, duration, params):
     """Detect FINAL speech from features and a fitted model, without LAB or I/O.
 
     Input: algorithm, frame features/supports, duration and frozen TRAIN model.
     Output: mask/final_regions/diagnostic and derived predicted_boundaries.
-    Missing endpoint_noise requires explicit training before inference.
-    FINAL hysteresis supports speech-high energy only; inverted TT3 models
-    raise a clear error instead of silently losing every candidate region.
+    Core merges native support gaps below 200 ms without a duration filter.
+    Enhanced requires TRAIN noise and speech-high Gaussian direction.
     """
-    noise = params.get('endpoint_noise')
-    if noise is None:
+    mode = params.get('endpoint_mode', 'enhanced')
+    if mode not in ('core', 'enhanced'):
+        raise ValueError(f'Unknown endpoint_mode: {mode}')
+    noise = params.get('endpoint_noise') if mode == 'enhanced' else None
+    if mode == 'enhanced' and noise is None:
         raise ValueError('Fitted model requires endpoint_noise; call fit_training_model on TRAIN before inference')
     # The raw Gaussian classifier supports both directions. FINAL HIGH/LOW
     # requires speech-high, so reject an incompatible imported model early.
-    if algorithm == 'tt3' and params.get('speech_direction', 'high') != 'high':
+    if mode == 'enhanced' and algorithm == 'tt3' and params.get('speech_direction', 'high') != 'high':
         raise ValueError("FINAL endpoint detection requires TT3 speech_direction='high'; "
                          "inverted/unknown directions are not supported by energy hysteresis")
-    if algorithm == "tt1":
-        mask, diagnostic = tt1.predict(features, params), {"threshold": params["threshold"]}
-    elif algorithm == "tt3":
-        mask, diagnostic = tt3.predict(features, params), {"threshold": params["threshold"]}
-    elif algorithm in ('tt2', 'tt2-context'):
-        mask, diagnostic = tt2.predict(features, params)
-    else:
-        raise ValueError(f'Unknown algorithm: {algorithm}')
+    seed, diagnostic = algorithm_decision(algorithm, features, params)
+    source_histogram=algorithm=='tt2' and params.get('variant','source')=='source'
+    mask = tt2.pad_speech(seed, diagnostic['padding_frames']) if mode == 'enhanced' and source_histogram else seed
 
-    # Algorithm masks are candidates. Final endpoints require HIGH confirmation,
+    # Algorithm masks are candidates. Enhanced endpoints require HIGH confirmation,
     # LOW continuation, short-gap merging and duration filtering.
     candidate_regions=[(s,e) for s,e,state in mask_segments(mask,features['starts'],duration,features['ends']) if state]
-    source_histogram=algorithm=='tt2' and params.get('variant','source')=='source'
+    if mode == 'core':
+        final_regions = []
+        for start, end in candidate_regions:
+            if final_regions and start - final_regions[-1][1] < MIN_SILENCE_SECONDS - 1e-12:
+                final_regions[-1] = (final_regions[-1][0], end)
+            else:
+                final_regions.append((start, end))
+        mask = regions_to_mask(final_regions, features['starts'], features['ends'])
+        diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions,
+            low_ste_threshold=None, high_ste_threshold=None, endpoint_noise=None,
+            minimum_speech_ms=0., minimum_silence_ms=MIN_SILENCE_SECONDS*1000,
+            endpoint_mode=mode, geometry='union of active frame supports',
+            final_padding_ms=0., padding_stage='excluded from core FINAL',
+            endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding')
+        return dict(mask=mask, final_regions=final_regions, diagnostic=diagnostic,
+                    predicted_boundaries=[b for region in final_regions for b in region])
     if algorithm in ('tt1','tt3'):
-        base_threshold=params['threshold'];seed=mask
+        base_threshold=params['threshold']
     else:
         peak=max(features['energy'],default=0.)
         base_threshold=diagnostic['energy_threshold']/peak if source_histogram and peak>0 else diagnostic['energy_threshold'] if not source_histogram else 0.
-        seed=[int(e>diagnostic['energy_threshold'])
-              for e in features['energy']] if source_histogram else mask
     low,high=endpoint_thresholds(base_threshold,noise,histogram=algorithm in ('tt2','tt2-context'))
     final_regions=hysteresis_regions(features['ste_norm'],features['starts'],features['ends'],duration,
         low,high,MIN_SILENCE_SECONDS,MIN_SPEECH_SECONDS,seed_mask=seed)
     mask=regions_to_mask(final_regions,features['starts'],features['ends'])
     diagnostic.update(candidate_regions=candidate_regions,final_regions=final_regions,
+        endpoint_mode=mode,geometry='union of active frame supports',final_padding_ms=0.,
+        padding_stage='candidate diagnostics only' if source_histogram else 'none',
         low_ste_threshold=low,high_ste_threshold=high,endpoint_noise=noise,
         minimum_speech_ms=MIN_SPEECH_SECONDS*1000,minimum_silence_ms=MIN_SILENCE_SECONDS*1000,
         endpoint_policy='raw STE hysteresis; candidates/debug excluded; no fixed final padding')
     return dict(mask=mask, final_regions=final_regions, diagnostic=diagnostic,
                 predicted_boundaries=[b for region in final_regions for b in region])
 
 
 def predict_and_score(algorithm, record, params):
@@ -222,58 +261,74 @@ def predict_and_score(algorithm, record, params):
                   predicted_end_s=predicted[1] if predicted else None)
     # Imported historical JSON remains usable without relabeling its TEST W
     # calibration as TRAIN. Fresh fit_training_model outputs never have this key.
     legacy_test_tuned = algorithm == 'tt2' and 'W_selection_test' in params
     scores.update(metrics_schema_version=2, model_schema_version=params.get('schema_version', 1),
                   parameter_selection_set='test' if legacy_test_tuned else params.get('parameter_selection_set', 'train'),
                   evaluation_protocol='test_tuned_not_independent' if legacy_test_tuned else params.get('evaluation_protocol', 'train_selected_reused_test'),
                   historical_test_exposure=True if legacy_test_tuned else params.get('historical_test_exposure', True))
+    # Export the actual sampled timing and the locked mode policy beside metrics.
+    scores.update(endpoint_mode=params.get('endpoint_mode', 'enhanced'),
+                  boundary_convention=params.get('boundary_convention', diagnostic.get('geometry')),
+                  minimum_speech_ms=diagnostic.get('minimum_speech_ms'),
+                  minimum_silence_ms=diagnostic.get('minimum_silence_ms'),
+                  padding_stage=diagnostic.get('padding_stage'), final_padding_ms=diagnostic.get('final_padding_ms'),
+                  frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING,
+                  actual_frame_ms=record['features'].get('frame_ms'), actual_hop_ms=record['features'].get('hop_ms'),
+                  frame_samples=record['features'].get('frame_size'), hop_samples=record['features'].get('hop_size'))
     return dict(file=record["name"], algorithm=algorithm, mask=mask, metrics=scores,
                 final_regions=final_regions, ground_truth_regions=expected_regions,region_pairs=region_scores['region_pairs'],
                 predicted_boundaries=predicted_boundaries,
                 ground_truth_boundaries=expected_boundaries, diagnostic=diagnostic)
 
 
-def fit_training_model(algorithm, train_records):
+def fit_training_model(algorithm, train_records, *, endpoint_mode='enhanced'):
     """Fit and lock parameters and FINAL W from supplied prepared TRAIN only.
 
     Input: prepared records with explicit split=train; array records need no
     path and support future folds. Known TEST/external paths are rejected.
-    Output: (schema-v2 model, FINAL W sweep rows), empty rows for other methods.
+    Output: (schema-v3 model, FINAL W sweep rows), empty rows for other methods.
     No files are loaded here, including during the histogram calibration.
-    TT3 must fit speech-high for the current FINAL energy hysteresis.
+    Enhanced TT3 must fit speech-high for FINAL energy hysteresis; core
+    retains either native Gaussian decision direction.
     """
+    if endpoint_mode not in ('core', 'enhanced'):
+        raise ValueError(f'Unknown endpoint_mode: {endpoint_mode}')
     if not train_records:
         raise ValueError('fit_training_model requires TRAIN records')
     for record in train_records:
         if record.get('split') != 'train':
             raise ValueError('Training records require explicit TRAIN provenance (split=train)')
         if 'wav_path' in record and Path(record['wav_path']).resolve().parent != TRAIN_DIR.resolve():
             raise ValueError('Training record path must belong to TRAIN, never TEST/external')
     if algorithm == 'tt1':
         model = tt1.fit(train_records)
     elif algorithm == 'tt3':
         model = tt3.fit(train_records)
         # Do not lock a raw Gaussian model whose inequality contradicts HIGH.
-        if model.get('speech_direction', 'high') != 'high':
+        if endpoint_mode == 'enhanced' and model.get('speech_direction', 'high') != 'high':
             raise ValueError("FINAL endpoint detection requires TT3 speech_direction='high'; "
                              "TRAIN speech mean is below silence mean")
     elif algorithm in ('tt2', 'tt2-context'):
         model = tt2.fit(train_records, variant='context' if algorithm == 'tt2-context' else 'source')
     else:
         raise ValueError(f'Unknown algorithm: {algorithm}')
-    model.update(schema_version=2, metrics_schema_version=2,
+    model.update(schema_version=3, metrics_schema_version=2, endpoint_mode=endpoint_mode,
                  parameter_selection_set='train', evaluation_protocol='train_selected_reused_test',
                  historical_test_exposure=True, training_files=[record['name'] for record in train_records],
                  frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING,
                  minimum_internal_silence_ms=MIN_SILENCE_SECONDS*1000,
-                 minimum_speech_ms=MIN_SPEECH_SECONDS*1000,
-                 endpoint_noise=fit_noise_floor(train_records),
-                 endpoint_policy='hysteresis final regions; no fixed final padding',
+                 minimum_speech_ms=0. if endpoint_mode == 'core' else MIN_SPEECH_SECONDS*1000,
+                 minimum_silence_ms=MIN_SILENCE_SECONDS*1000,
+                 endpoint_noise=fit_noise_floor(train_records) if endpoint_mode == 'enhanced' else None,
+                 endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding' if endpoint_mode == 'core' else 'hysteresis final regions; no fixed final padding',
+                 feature_rule='Energy (mean squared sample amplitude)' if algorithm == 'tt2' else 'normalized STE',
+                 decision_rule='Energy > threshold' if algorithm == 'tt2' else 'STE <= threshold' if model.get('speech_direction') == 'low' else 'STE >= threshold',
+                 padding_stage='excluded from core FINAL' if endpoint_mode == 'core' else 'candidate diagnostics only' if algorithm == 'tt2' else 'none',
                  boundary_convention='union of active frame supports')
     sweep_rows = []
     if algorithm == 'tt2':
         # Preserve the core's candidate-stage proposal under explicit names.
         # Its F1 is not a score for the W selected below by FINAL-region MAE.
         model['candidate_frame_selected_W'] = model['W']
         model['candidate_frame_f1'] = model.pop('train_frame_f1')
         model['candidate_frame_selection_scores'] = [
@@ -288,16 +343,23 @@ def fit_training_model(algorithm, train_records):
         model.update(W=selection['selected_W'], finalW=selection['selected_W'],
                      tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE, W_selection_train=selection,
                      parameter_rule=selection['selection_rule'])
     elif algorithm == 'tt2-context':
         # Context W is declared by the report and has no candidate F1 fit.
         model.update(candidate_frame_selected_W=None, candidate_frame_f1=None,
                      candidate_frame_selection_scores=[], candidate_cleanup_records=None,
                      candidate_frame_selection_applicable=False, finalW=model['W'], tie_preference_W=None)
+    # Hash the complete locked model before attaching the digest to itself or
+    # its manifest. This includes numeric calibration and TRAIN provenance.
+    digest = hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False,
+                                       allow_nan=False).encode('utf-8')).hexdigest()
+    model['calibration_digest'] = digest
+    if algorithm == 'tt2':
+        model['W_selection_train']['calibration_digest'] = digest
     return model, sweep_rows
 
 
 def data_statistics(records, split):
     """Ước lượng SNR môi trường theo công suất speech/silence của LAB.
 
     Input: records chứa waveform/Fs/LAB, split là tên tập dữ liệu.
     Output: rows thời lượng/biên chuẩn/công suất và snr_proxy_db; SNR là
@@ -326,33 +388,37 @@ def data_statistics(records, split):
     return rows
 
 
 def summarize(metrics):
     """Tổng hợp metric từng thuật toán, phân biệt mean file và pooled RMSE.
 
     Input: metrics là rows endpoint/frame của từng file. Output: rows mean
     MAE/RMSE, pooled endpoint RMSE, F1 và số file có metric không xác định;
-    metric không xác định được loại khỏi mean và được đếm rõ.
+    primary mean chỉ xác định khi mọi file hợp lệ; mean subset được ghi riêng.
     """
     rows = []
-    for algorithm in dict.fromkeys(row["algorithm"] for row in metrics):
-        selected = [row for row in metrics if row["algorithm"] == algorithm]
-        valid = [row for row in selected if row["mae_ms"] is not None]
+    for algorithm, mode in dict.fromkeys((row["algorithm"], row.get("endpoint_mode", "enhanced")) for row in metrics):
+        selected = [row for row in metrics if row["algorithm"] == algorithm and row.get("endpoint_mode", "enhanced") == mode]
+        valid = [row for row in selected if row["mae_ms"] is not None
+                 and row.get("ground_truth_region_count") == row.get("predicted_region_count")]
         squared=sum(row.get('endpoint_squared_error_ms2',(row['rmse_ms']**2)*2) for row in valid)
         error_count=sum(row.get('endpoint_error_count',2) for row in valid)
         ordered=sorted(row['mae_ms'] for row in valid)
         median=(ordered[len(ordered)//2] if len(ordered)%2 else (ordered[len(ordered)//2-1]+ordered[len(ordered)//2])/2) if ordered else None
         count_correct=sum(row.get('ground_truth_region_count')==row.get('predicted_region_count') for row in selected)
-        rows.append(dict(algorithm=algorithm, metrics_schema_version=2,
+        rows.append(dict(algorithm=algorithm, endpoint_mode=mode, metrics_schema_version=2,
                          files=len(selected), evaluated_files=len(valid),
                          missing_speech_files=len(selected) - len(valid),
-                         mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,
-                         mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,
-                         pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,
+                         mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,
+                         valid_files_mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,
+                         mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,
+                         valid_files_mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,
+                         pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count and len(valid)==len(selected) else None,
+                         valid_files_pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,
                          median_file_mae_ms=median,min_file_mae_ms=min(ordered) if ordered else None,max_file_mae_ms=max(ordered) if ordered else None,
                          region_count_correct_files=count_correct,region_count_incorrect_files=len(selected)-count_correct,
                          top_mae_files='; '.join(f"{r['file']}:{r['mae_ms']:.2f}ms" for r in sorted(valid,key=lambda r:r['mae_ms'],reverse=True)[:3]),
                          parameter_selection_set=selected[0].get('parameter_selection_set','train'),
                          evaluation_protocol=selected[0].get('evaluation_protocol','train_selected_reused_test'),
                          historical_test_exposure=selected[0].get('historical_test_exposure', True),
                          mean_frame_f1=sum(row["frame_f1"] for row in selected) / len(selected)))
     return rows
@@ -438,145 +504,164 @@ def run_experiment(args):
     input_path = resolve_input_file(file_argument) if file_argument else None
     audio_train = load_audio_folder(TRAIN_DIR)
     train_common = prepare_records(audio_train)
     selected = ["tt1", "tt2", "tt3"] if args.algorithm == "all" else [args.algorithm]
     if args.compare_context and "tt2-context" not in selected:
         selected.append("tt2-context")
 
     # Lock every model, including FINAL W and noise, before TEST WAV/LAB I/O.
-    models, sweeps = {}, {}
-    for key in selected:
-        models[key], sweeps[key] = fit_training_model(key, train_common)
+    modes = ('core', 'enhanced') if getattr(args, 'compare_endpoint_modes', False) else (getattr(args, 'endpoint_mode', 'enhanced'),)
+    locked_models, locked_sweeps = {}, {}
+    for mode in modes:
+        locked_models[mode], locked_sweeps[mode] = {}, {}
+        for key in selected:
+            locked_models[mode][key], locked_sweeps[mode][key] = fit_training_model(key, train_common, endpoint_mode=mode)
 
     evaluate_all=getattr(args,'evaluate_all',False)
     audio_test = [load_audio_file(input_path)] if input_path else audio_train+load_audio_folder(TEST_DIR) if evaluate_all else load_audio_folder(TEST_DIR)
     evaluated_names = [record["name"] for record in audio_test]
     display_order = [name for name in FILE_ORDER if name in evaluated_names]
     display_order.extend(name for name in evaluated_names if name not in display_order)
     evaluation_split = 'all_dataset' if evaluate_all else "train" if input_path and input_path.parent == TRAIN_DIR.resolve() else "external" if input_path and input_path.parent != TEST_DIR.resolve() else "test"
     test_common = prepare_records(audio_test)
     records_by_algorithm = {key: test_common for key in selected}
-    tables = OUTPUT_DIR / "tables"
-    figures_root = OUTPUT_DIR / "figures"
-    tables.mkdir(parents=True, exist_ok=True)
-    figures_root.mkdir(parents=True, exist_ok=True)
-    run_name = args.algorithm + ("_with_context" if args.compare_context else "")
-    if evaluate_all:run_name+='_all_dataset'
-    run_folder = tables / run_name
-    if input_path:
-        # Một lần thử file không ghi đè metric tổng hợp của batch bốn test.
-        run_folder = run_folder / "single" / input_path.stem
-        print(f"Chạy WAV: {input_path} | tập {evaluation_split}; ngưỡng/noise/W đã chọn trên 4 WAV TRAIN.")
-
-    # Export the already locked TRAIN models and calibration audit.
-    for key in selected:
-        model = models[key]
-        if key=='tt2':
-            selection, sweep_rows = model['W_selection_train'], sweeps[key]
-            audit=tables/'tt2_w_selection'
-            write_csv(audit/'sweep.csv',sweep_rows)
-            write_csv(audit/'summary.csv',selection['summaries'])
-            write_csv(audit/'best_by_file.csv',[dict(filename=name,**values) for name,values in selection['best_by_file'].items()])
-            write_json(audit/'selection.json',selection)
-            print(f"TT2 W={model['W']:g}: selected on four TRAIN LABs; TEST scoring reuses historically exposed data; "
-                  f"mean final MAE={selection['selected_summary']['mean_MAE_ms']} ms")
-        write_json(OUTPUT_DIR / "models" / f"{key}.json", model)
-
-    # Lưu dữ liệu thống kê giúp kiểm tra lại mean/std, normalization và LAB.
-    training_frames = []
-    for record in train_common:
-        for center, value, label in zip(record["features"]["centers"], record["features"]["ste_norm"], record["labels"]):
-            training_frames.append(dict(file=record["name"], center_s=center, ste_norm=value,
-                                        label="unlabeled" if label is None else "speech" if label else "silence"))
-    write_csv(tables / "training_frames.csv", training_frames)
-    statistics_path = run_folder / "dataset_statistics.csv" if input_path else tables / "dataset_statistics.csv"
-    write_csv(statistics_path, data_statistics(audio_train, "train") + data_statistics(audio_test, evaluation_split))
-    if "tt3" in models:
-        values_by_class = {0: [], 1: []}
+    all_mode_rows = []
+    for mode in modes:
+        models, sweeps = locked_models[mode], locked_sweeps[mode]
+        output_root = endpoint_mode_root(mode, OUTPUT_DIR)
+        tables = output_root / "tables"
+        figures_root = output_root / "figures"
+        tables.mkdir(parents=True, exist_ok=True)
+        figures_root.mkdir(parents=True, exist_ok=True)
+        run_name = args.algorithm + ("_with_context" if args.compare_context else "")
+        if evaluate_all:run_name+='_all_dataset'
+        run_folder = tables / run_name
+        if input_path:
+            # Một lần thử file không ghi đè metric tổng hợp của batch bốn test.
+            run_folder = run_folder / "single" / input_path.stem
+            print(f"Chạy WAV: {input_path} | tập {evaluation_split}; ngưỡng/noise/W đã chọn trên 4 WAV TRAIN.")
+
+        # Export the already locked TRAIN models and calibration audit.
+        for key in selected:
+            model = models[key]
+            if key=='tt2':
+                selection, sweep_rows = model['W_selection_train'], sweeps[key]
+                audit=tables/'tt2_w_selection'
+                write_csv(audit/'sweep.csv',sweep_rows)
+                write_csv(audit/'summary.csv',selection['summaries'])
+                write_csv(audit/'best_by_file.csv',[dict(filename=name,**values) for name,values in selection['best_by_file'].items()])
+                write_json(audit/'selection.json',selection)
+                print(f"TT2 W={model['W']:g}: selected on four TRAIN LABs; TEST scoring reuses historically exposed data; "
+                      f"mean final MAE={selection['selected_summary']['mean_MAE_ms']} ms")
+            write_json(output_root / "models" / f"{key}.json", model)
+
+        # Lưu dữ liệu thống kê giúp kiểm tra lại mean/std, normalization và LAB.
+        training_frames = []
         for record in train_common:
-            for value, label in zip(record["features"]["ste_norm"], record["labels"]):
-                if label is not None:
-                    values_by_class[label].append(value)
-        training_figures = figures_root / "training"
-        training_figures.mkdir(exist_ok=True)
-        plot_gaussian_training(values_by_class, models["tt3"], training_figures / "gaussian_distributions.png")
-
-    metric_rows, threshold_rows, results_by_file = [], [], {}
-    demo_figures, noise_rows = [], []
-    for key in selected:
-        folder = figures_root / key
-        folder.mkdir(exist_ok=True)
-        for record in records_by_algorithm[key]:
-            result = predict_and_score(key, record, models[key])
-            metric_rows.append(dict(file=record["name"],split=record.get('split',evaluation_split),algorithm=key, **result["metrics"]))
-            threshold_rows.append(dict(file=record["name"], algorithm=key,
-                                       **{name: value for name, value in result["diagnostic"].items() if not isinstance(value, (dict, list))}))
-            results_by_file.setdefault(record["name"], {})[key] = (record, result)
-            write_json(OUTPUT_DIR / "diagnostics" / key / f"{record['name']}.json", result["diagnostic"])
-            segments = mask_segments(result["mask"], record["features"]["starts"], record["duration"], frame_ends=record["features"]["ends"])
-            write_csv(OUTPUT_DIR / "predictions" / key / f"{record['name']}.csv",
-                      [dict(start_s=start, end_s=end, label="speech" if state else "sil") for start, end, state in segments])
-            figure = make_file_figure(record["name"], [(record, result)], folder / f"{record['name']}.png")
-            # Batch giữ 4 figure, --file chỉ giữ 1; các bản xuất phụ đóng ngay.
-            if args.algorithm != "all" and key == args.algorithm and not args.no_show:
-                demo_figures.append(figure)
-            else:
-                plt.close(figure)
-
-            if args.snr_study:
-                noise_rows.append(dict(file=record["name"], algorithm=key, added_snr_db="clean", **result["metrics"]))
-                for level in NOISE_LEVELS_DB:
-                    file_seed = FILE_ORDER.index(record["name"]) if record["name"] in FILE_ORDER else zlib.crc32(record["name"].encode("utf-8"))
-                    base_noisy = noisy_copy(record, level, RANDOM_SEED + file_seed * 100 + level)
-                    noisy = prepare_records([base_noisy], key == "tt2")[0]
-                    noisy_result = predict_and_score(key, noisy, models[key])
-                    noise_rows.append(dict(file=record["name"], algorithm=key, added_snr_db=level, **noisy_result["metrics"]))
-
-    # all có một figure so sánh ba hàng/file; subset chỉ vẽ các WAV đã chọn.
-    if args.algorithm == "all":
-        comparison_folder = figures_root / "comparison"
-        comparison_folder.mkdir(exist_ok=True)
-        for name in display_order:
-            figure = make_file_figure(name, [results_by_file[name][key] for key in ("tt1", "tt2", "tt3")], comparison_folder / f"{name}.png")
-            if args.no_show:
-                plt.close(figure)
-            else:
-                demo_figures.append(figure)
-    else:
-        demo_figures.sort(key=lambda figure: display_order.index(figure._suptitle.get_text()))
-
-    # Lưu từng run độc lập; demo một thuật toán không ghi đè bảng tổng hợp all.
-    write_csv(run_folder / "test_metrics.csv", metric_rows)
-    write_csv(run_folder / "summary.csv", summarize(metric_rows))
-    write_csv(run_folder / "test_thresholds.csv", threshold_rows)
-    if args.snr_study:
-        write_csv(run_folder / "snr_study.csv", noise_rows)
-    if args.compare_context:
-        write_csv(tables / "context_benchmark_check.csv", context_benchmark(test_common))
-    write_json(run_folder / "run_config.json", dict(algorithm=args.algorithm, selected=selected,
-               input_file=str(input_path) if input_path else None, evaluated_files=evaluated_names,
-               evaluation_split=evaluation_split,
-               schema_version=2, metrics_schema_version=2,
-               parameter_selection_set='train', evaluation_protocol='train_selected_reused_test',
-               historical_test_exposure=True, training_files=[record['name'] for record in train_common],
-               parameter_selection={key:model['evaluation_protocol'] for key,model in models.items()},
-               frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING,
-               minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000,minimum_speech_ms=MIN_SPEECH_SECONDS*1000,
-               snr_study=args.snr_study, normalization="per_recording_max", lab_center_convention="sample_exact_half_open",
-               boundary_convention="final confirmed regions; union of active frame supports", primary_metric="ordered final-region START/END MAE; unmatched regions explicitly undefined",
-               noise_seed=RANDOM_SEED))
-    print(f"Đã xuất kết quả: {OUTPUT_DIR}")
-    for row in summarize(metric_rows):
-        mae = f"{row['mean_file_mae_ms']:.2f}" if row["mean_file_mae_ms"] is not None else "N/A"
-        rmse = f"{row['mean_file_rmse_ms']:.2f}" if row["mean_file_rmse_ms"] is not None else "N/A"
-        print(f"{row['algorithm']}: mean endpoint MAE={mae} ms; "
-              f"mean per-file RMSE={rmse} ms; frame F1={row['mean_frame_f1']:.3f}")
-        print(f"  median={row['median_file_mae_ms']}; min={row['min_file_mae_ms']}; max={row['max_file_mae_ms']} ms; "
-              f"region counts correct={row['region_count_correct_files']}/{row['files']}; wrong={row['region_count_incorrect_files']}")
-        print(f"  highest MAE: {row['top_mae_files']}")
-    if not args.no_show:
-        positions = show_figures(demo_figures, args.show_seconds)
-        write_json(run_folder / "demo_layout.json", positions)
-        if len(demo_figures) == 4:
-            print(f"Demo đã bố trí {len(positions)} cửa sổ tại bốn góc.")
+            for center, value, label in zip(record["features"]["centers"], record["features"]["ste_norm"], record["labels"]):
+                training_frames.append(dict(file=record["name"], center_s=center, ste_norm=value,
+                                            label="unlabeled" if label is None else "speech" if label else "silence"))
+        write_csv(tables / "training_frames.csv", training_frames)
+        statistics_path = run_folder / "dataset_statistics.csv" if input_path else tables / "dataset_statistics.csv"
+        write_csv(statistics_path, data_statistics(audio_train, "train") + data_statistics(audio_test, evaluation_split))
+        if "tt3" in models:
+            values_by_class = {0: [], 1: []}
+            for record in train_common:
+                for value, label in zip(record["features"]["ste_norm"], record["labels"]):
+                    if label is not None:
+                        values_by_class[label].append(value)
+            training_figures = figures_root / "training"
+            training_figures.mkdir(exist_ok=True)
+            plot_gaussian_training(values_by_class, models["tt3"], training_figures / "gaussian_distributions.png")
+
+        metric_rows, threshold_rows, results_by_file = [], [], {}
+        demo_figures, noise_rows = [], []
+        for key in selected:
+            folder = figures_root / key
+            folder.mkdir(exist_ok=True)
+            for record in records_by_algorithm[key]:
+                result = predict_and_score(key, record, models[key])
+                metric_rows.append(dict(file=record["name"],split=record.get('split',evaluation_split),algorithm=key, **result["metrics"]))
+                threshold_rows.append(dict(file=record["name"], algorithm=key,
+                                           **{name: value for name, value in result["diagnostic"].items() if not isinstance(value, (dict, list))}))
+                results_by_file.setdefault(record["name"], {})[key] = (record, result)
+                write_json(output_root / "diagnostics" / key / f"{record['name']}.json", result["diagnostic"])
+                segments = mask_segments(result["mask"], record["features"]["starts"], record["duration"], frame_ends=record["features"]["ends"])
+                write_csv(output_root / "predictions" / key / f"{record['name']}.csv",
+                          [dict(start_s=start, end_s=end, label="speech" if state else "sil") for start, end, state in segments])
+                figure = make_file_figure(record["name"], [(record, result)], folder / f"{record['name']}.png")
+                # Batch giữ 4 figure, --file chỉ giữ 1; các bản xuất phụ đóng ngay.
+                if args.algorithm != "all" and key == args.algorithm and not args.no_show:
+                    demo_figures.append(figure)
+                else:
+                    plt.close(figure)
+
+                if args.snr_study:
+                    noise_rows.append(dict(file=record["name"], algorithm=key, added_snr_db="clean", **result["metrics"]))
+                    for level in NOISE_LEVELS_DB:
+                        file_seed = FILE_ORDER.index(record["name"]) if record["name"] in FILE_ORDER else zlib.crc32(record["name"].encode("utf-8"))
+                        base_noisy = noisy_copy(record, level, RANDOM_SEED + file_seed * 100 + level)
+                        noisy = prepare_records([base_noisy], key == "tt2")[0]
+                        noisy_result = predict_and_score(key, noisy, models[key])
+                        noise_rows.append(dict(file=record["name"], algorithm=key, added_snr_db=level, **noisy_result["metrics"]))
+
+        # all có một figure so sánh ba hàng/file; subset chỉ vẽ các WAV đã chọn.
+        if args.algorithm == "all":
+            comparison_folder = figures_root / "comparison"
+            comparison_folder.mkdir(exist_ok=True)
+            for name in display_order:
+                figure = make_file_figure(name, [results_by_file[name][key] for key in ("tt1", "tt2", "tt3")], comparison_folder / f"{name}.png")
+                if args.no_show:
+                    plt.close(figure)
+                else:
+                    demo_figures.append(figure)
         else:
-            print(f"Đã hiển thị {len(demo_figures)} figure cho WAV đã chọn.")
+            demo_figures.sort(key=lambda figure: display_order.index(figure._suptitle.get_text()))
+
+        # Lưu từng run độc lập; demo một thuật toán không ghi đè bảng tổng hợp all.
+        all_mode_rows.extend(metric_rows)
+        write_csv(run_folder / "test_metrics.csv", metric_rows)
+        if evaluate_all and {"tt1", "tt2", "tt3"}.issubset(selected):
+            write_csv(tables / "all" / "test_metrics.csv", [row for row in metric_rows if row["split"]=="test"])
+            write_csv(tables / "all" / "summary.csv", summarize([row for row in metric_rows if row["split"]=="test"]))
+        write_csv(run_folder / "summary.csv", summarize(metric_rows))
+        write_csv(run_folder / "test_thresholds.csv", threshold_rows)
+        if args.snr_study:
+            write_csv(run_folder / "snr_study.csv", noise_rows)
+        if args.compare_context:
+            write_csv(tables / "context_benchmark_check.csv", context_benchmark(test_common))
+        write_json(run_folder / "run_config.json", dict(algorithm=args.algorithm, endpoint_mode=mode, selected=selected,
+                   input_file=str(input_path) if input_path else None, evaluated_files=evaluated_names,
+                   evaluation_split=evaluation_split,
+                   schema_version=2, metrics_schema_version=2,
+                   parameter_selection_set='train', evaluation_protocol='train_selected_reused_test',
+                   historical_test_exposure=True, training_files=[record['name'] for record in train_common],
+                   parameter_selection={key:model['evaluation_protocol'] for key,model in models.items()},
+                   frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING,
+                   minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000,minimum_speech_ms=0. if mode=="core" else MIN_SPEECH_SECONDS*1000,
+                   snr_study=args.snr_study, normalization="per_recording_max", lab_center_convention="sample_exact_half_open",
+                   boundary_convention="union of active frame supports", primary_metric="ordered final-region START/END MAE; unmatched regions explicitly undefined",
+                   noise_seed=RANDOM_SEED))
+        print(f"Đã xuất kết quả: {output_root}")
+        for row in summarize(metric_rows):
+            mae = f"{row['mean_file_mae_ms']:.2f}" if row["mean_file_mae_ms"] is not None else "N/A"
+            rmse = f"{row['mean_file_rmse_ms']:.2f}" if row["mean_file_rmse_ms"] is not None else "N/A"
+            print(f"{row['algorithm']} [{mode}]: mean FINAL-region endpoint MAE={mae} ms; "
+                  f"mean per-file RMSE={rmse} ms; frame F1={row['mean_frame_f1']:.3f}")
+            print(f"  median={row['median_file_mae_ms']}; min={row['min_file_mae_ms']}; max={row['max_file_mae_ms']} ms; "
+                  f"region counts correct={row['region_count_correct_files']}/{row['files']}; wrong={row['region_count_incorrect_files']}")
+            print(f"  highest MAE: {row['top_mae_files']}")
+        if not args.no_show:
+            positions = show_figures(demo_figures, args.show_seconds)
+            write_json(run_folder / "demo_layout.json", positions)
+            if len(demo_figures) == 4:
+                print(f"Demo đã bố trí {len(positions)} cửa sổ tại bốn góc.")
+            else:
+                print(f"Đã hiển thị {len(demo_figures)} figure cho WAV đã chọn.")
+
+    if len(modes) == 2:
+        comparison = endpoint_mode_root('comparison', OUTPUT_DIR) / 'tables'
+        write_csv(comparison / 'all_metrics.csv', all_mode_rows)
+        write_csv(comparison / 'all_summary.csv', summarize(all_mode_rows))
+        test_rows = [row for row in all_mode_rows if row['split']=='test']
+        write_csv(comparison / 'test_metrics.csv', test_rows)
+        write_csv(comparison / 'test_summary.csv', summarize(test_rows))
diff --git a/app/plotting.py b/app/plotting.py
index 5caa298..aa82607 100644
--- a/app/plotting.py
+++ b/app/plotting.py
@@ -19,45 +19,56 @@ def _plot_axis(axis, record, result):
     # Thưa mẫu chỉ để hiển thị nhanh; phép tính vẫn dùng toàn bộ samples.
     samples, fs = record["samples"], record["sample_rate"]
     stride = max(1, len(samples) // 12000)
     axis.plot([i / fs for i in range(0, len(samples), stride)], samples[::stride],
               color="#555555", linewidth=.55, alpha=.4)
     energy_axis = axis.twinx()
     energy_axis.plot(record["features"]["centers"], record["features"]["ste_norm"],
                      color="#dd8b12", linewidth=1.6, alpha=.95)
-    # These are the exact thresholds used by detection, not plot-only lines.
-    low=result['diagnostic']['low_ste_threshold']
-    high=result['diagnostic']['high_ste_threshold']
-    energy_axis.axhline(high,color='#8E44AD',linestyle='-.',linewidth=1.2)
-    energy_axis.axhline(low,color='#148F77',linestyle=':',linewidth=1.2)
+    diagnostic = result['diagnostic']
+    mode = diagnostic.get('endpoint_mode', 'enhanced')
+    threshold_handles = []
+    if mode == 'core':
+        native = diagnostic['native_threshold']
+        if diagnostic['native_threshold_units'] == 'mean squared sample amplitude':
+            peak = max(record['features']['energy'], default=0.)
+            native = native / peak if peak else 0.
+        energy_axis.axhline(native, color='#8E44AD', linestyle='-.', linewidth=1.2)
+        threshold_handles.append(Line2D([], [], color='#8E44AD', linestyle='-.', label=f'Native T ({diagnostic.get("native_threshold_units")}): {diagnostic["native_threshold"]:.5g}'))
+    else:
+        low, high = diagnostic['low_ste_threshold'], diagnostic['high_ste_threshold']
+        energy_axis.axhline(high,color='#8E44AD',linestyle='-.',linewidth=1.2)
+        energy_axis.axhline(low,color='#148F77',linestyle=':',linewidth=1.2)
+        threshold_handles.extend([Line2D([], [], color='#8E44AD',linestyle='-.',label=f'High STE: {high:.5g}'),
+                                  Line2D([], [], color='#148F77',linestyle=':',label=f'Low STE: {low:.5g}')])
     energy_axis.set_ylim(-.05, 1.1)
     energy_axis.set_ylabel("Normalized STE", color="#a2670a", fontsize=9)
     axis.set_ylabel("Amplitude", fontsize=9)
     axis.set_xlim(0, record["duration"])
     axis.grid(alpha=.18)
 
     # Candidate/debug points không được vẽ hoặc đưa vào metric chính.
     for boundary in result["ground_truth_boundaries"]:
         axis.axvline(boundary, color="#d62728", linewidth=1.45, alpha=.85)
     for boundary in result["predicted_boundaries"]:
         axis.axvline(boundary, color="#1766bd", linestyle="--", linewidth=1.35)
     mae = result["metrics"]["mae_ms"]
-    suffix = "Outer boundary MAE: N/A" if mae is None else f"Outer boundary MAE: {mae:.2f} ms"
-    axis.set_title(f"{record['name']} | {suffix} | {len(result['final_regions'])} speech region(s)", fontsize=10)
+    suffix = "FINAL-region endpoint MAE: N/A" if mae is None else f"FINAL-region endpoint MAE: {mae:.2f} ms"
+    axis.set_title(f"{record['name']} | {mode} | {suffix} | {len(result['final_regions'])} speech region(s)", fontsize=10)
     # Legend đủ nhãn kể cả không tìm được speech hoặc biên nội bộ.
     axis.legend(handles=[Line2D([], [], color="#555555", label="Waveform"),
                          Line2D([], [], color="#dd8b12", label="Normalized STE"),
-                         Line2D([], [], color='#8E44AD',linestyle='-.',label=f'High STE: {high:.5g}'),
-                         Line2D([], [], color='#148F77',linestyle=':',label=f'Low STE: {low:.5g}'),
+                         *threshold_handles,
                          Line2D([], [], color="#d62728", label="Ground truth"),
                          Line2D([], [], color="#1766bd", linestyle="--", label="Prediction")],
                 fontsize=8, ncol=3, loc="upper right")
 
 
+
 def make_file_figure(name, record_results, save_path):
     """Tạo và lưu một figure cho WAV với một hàng mỗi thuật toán.
 
     Đầu vào: name là tên WAV; record_results chứa cặp (record, result); save_path là đường dẫn PNG.
     Đầu ra: Figure Matplotlib để bố trí/hiển thị; ảnh PNG được ghi vào save_path.
     """
     # Mỗi cặp record/result được đặt lên một hàng độc lập.
     # Trục thời gian dùng chung để dễ so sánh biên giữa các thuật toán.
diff --git a/app/weight_selection.py b/app/weight_selection.py
index e838076..39d7a6f 100644
--- a/app/weight_selection.py
+++ b/app/weight_selection.py
@@ -3,25 +3,30 @@
 TRAIN calibration is reused for scoring historically exposed TEST recordings.
 All timing, feature extraction, histogram and hysteresis settings stay fixed.
 """
 import math
 from app.config import HISTOGRAM_W_TIE_PREFERENCE
 
 W_CANDIDATES=tuple(float(w) for w in range(1,51))
 ERROR_EPS_MS=1e-8
+POLICY_FIELDS=('endpoint_mode','boundary_convention','minimum_speech_ms',
+               'minimum_silence_ms','padding_stage')
 
 def select_final_weight(rows,tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE):
     """Input: one MAE/count row per (W,file). Output: shared W and audit tables.
 
     Prefer valid region counts, then minimize the worst per-file loss relative
     to that file's own optimum, then mean MAE. Ties use the declared preference;
     if unavailable, choose the smallest W. No candidate/debug boundary is scored.
     """
     if not rows:raise ValueError('W selection needs evaluation rows')
+    policy={key:rows[0][key] for key in POLICY_FIELDS if key in rows[0]}
+    if any({key:row[key] for key in POLICY_FIELDS if key in row} != policy for row in rows):
+        raise ValueError('Each candidate W must use the same endpoint policy')
     grouped={}
     for row in rows:
         w=row['W'];name=row['filename'];mae=row['final_region_mae_ms']
         if not math.isfinite(w) or w<0 or (mae is not None and (not math.isfinite(mae) or mae<0)):
             raise ValueError('Invalid W or endpoint MAE')
         files=grouped.setdefault(w,{})
         if name in files:raise ValueError('Duplicate (W,filename) in selection')
         files[name]=row
@@ -55,41 +60,55 @@ def select_final_weight(rows,tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE):
         better=False;tied=True
         for left,right in zip(objectives,best_objectives):
             if left==right or (math.isfinite(left) and math.isfinite(right) and abs(left-right)<=ERROR_EPS_MS):continue
             better=left<right;tied=False;break
         if tied:
             better=(candidate['W']!=tie_preference_W,candidate['W'])<(chosen['W']!=tie_preference_W,chosen['W'])
         if better:chosen=candidate;best_objectives=objectives
     shared=set.intersection(*(set(v['optimal_W']) for v in best_by_file.values()))
-    return dict(selected_W=chosen['W'],tie_preference_W=tie_preference_W,selected_summary=chosen,
+    return dict(**policy,selected_W=chosen['W'],tie_preference_W=tie_preference_W,selected_summary=chosen,
         summaries=summaries,best_by_file=best_by_file,shared_optimal_W=sorted(shared),
         candidate_W=sorted(grouped),selection_set='train',evaluation_protocol='train_final_calibration',
         selection_rule='valid regions; minimum worst per-file regret; mean MAE; declared W preference on ties; smallest W otherwise')
 
 def sweep_final_weights(records,model,predictor,candidates=W_CANDIDATES,
                         tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE):
     """Evaluate every W on all calibration files with the real endpoint pipeline.
 
     Input: annotated TRAIN records, fitted TRAIN/noise model, real predictor.
     Output: selection manifest and rows. Does not mutate records or model.
     """
     if not records:raise ValueError('W sweep needs annotated TRAIN recordings')
     if any(record.get('split')!='train' for record in records):
         raise ValueError('W sweep requires explicit TRAIN provenance (split=train)')
+    mode=model.get('endpoint_mode','enhanced')
+    if mode not in ('core','enhanced'):raise ValueError('Unknown endpoint_mode')
+    policy=dict(endpoint_mode=mode,
+        boundary_convention=model.get('boundary_convention','union of active frame supports'),
+        minimum_speech_ms=model.get('minimum_speech_ms',0. if mode=='core' else 100.),
+        minimum_silence_ms=model.get('minimum_silence_ms',model.get('minimum_internal_silence_ms',200.)),
+        padding_stage=model.get('padding_stage','excluded from core FINAL' if mode=='core' else 'candidate diagnostics only'))
     rows=[]
     for w in candidates:
         params=dict(model,W=float(w))
         for record in records:
             result=predictor('tt2',record,params);metrics=result['metrics'];diag=result['diagnostic']
-            rows.append(dict(filename=record['name'],W=float(w),
+            if diag.get('endpoint_mode','enhanced') != mode:
+                raise ValueError('Predictor endpoint_mode disagrees with calibration model')
+            if diag.get('geometry', policy['boundary_convention']) != policy['boundary_convention']:
+                raise ValueError('Predictor geometry disagrees with calibration boundary_convention')
+            for key in ('minimum_speech_ms','minimum_silence_ms','padding_stage'):
+                if key in diag and diag[key] != policy[key]:
+                    raise ValueError(f'Predictor {key} disagrees with calibration model')
+            rows.append(dict(**policy,filename=record['name'],W=float(w),
                 ground_truth_region_count=metrics['ground_truth_region_count'],predicted_region_count=metrics['predicted_region_count'],
                 final_region_mae_ms=metrics['mae_ms'],status=metrics['status'],
                 start_error_ms=metrics['start_error_ms'],end_error_ms=metrics['end_error_ms'],
                 energy_threshold=diag['energy_threshold'],
                 low_ste_threshold=diag['low_ste_threshold'],high_ste_threshold=diag['high_ste_threshold'],
                 raw_speech_frames=diag['raw_speech_frames'],candidate_region_count=len(diag['candidate_regions']),
                 final_regions=str(result['final_regions'])))
     result=select_final_weight(rows,tie_preference_W)
     result.update(evaluated_files=[record['name'] for record in records],
-                  endpoint_policy='fixed raw STE hysteresis; final START/END only; no padding endpoints',
+                  endpoint_policy=model.get('endpoint_policy','fixed raw STE hysteresis; final START/END only; no padding endpoints'),
                   note='W was calibrated using these TRAIN LABs; TEST has historical exposure and is reused for scoring, so no holdout independence is claimed.')
     return result,rows
diff --git a/core/decision_timing.py b/core/decision_timing.py
new file mode 100644
index 0000000..dbaf532
--- /dev/null
+++ b/core/decision_timing.py
@@ -0,0 +1,25 @@
+"""Experimental nearest-frame decision cells; production supports stay unchanged.
+
+Internal edges use actual center midpoints, including half samples. The outer
+cells extend to audio edges and include the unanalysed incomplete frame tail.
+Analysis windows are never changed by this timing convention.
+"""
+import math
+
+
+def decision_cells(features: dict, duration: float) -> tuple[list[float], list[float]]:
+    """Return one disjoint, positive cell per finite ordered in-audio center."""
+    if not math.isfinite(duration) or duration < 0:
+        raise ValueError('Duration must be finite and nonnegative')
+    centers = features['centers']
+    previous = -1.
+    for center in centers:
+        if not math.isfinite(center) or not 0 <= center < duration or center <= previous:
+            raise ValueError('Centers must be finite, strictly ordered and inside audio')
+        previous = center
+    if not centers:
+        return [], []
+    edges = [0.] + [(a+b)/2 for a,b in zip(centers,centers[1:])] + [duration]
+    if any(b <= a for a,b in zip(edges,edges[1:])):
+        raise ValueError('Decision cells must have positive duration')
+    return edges[:-1], edges[1:]
diff --git a/docs/superpowers/plans/2026-10-07-algorithm-baseline-and-endpoint-review.md b/docs/superpowers/plans/2026-10-07-algorithm-baseline-and-endpoint-review.md
index 13dd9ad..7017032 100644
--- a/docs/superpowers/plans/2026-10-07-algorithm-baseline-and-endpoint-review.md
+++ b/docs/superpowers/plans/2026-10-07-algorithm-baseline-and-endpoint-review.md
@@ -5,17 +5,19 @@
 **Goal:** Báo cáo riêng kết quả lõi của từng thuật toán và kết quả cải tiến HIGH/LOW, sửa tài liệu còn cũ, kiểm tra thời gian biên bằng bằng chứng TRAIN; không thay thuật toán để chạy theo MAE của BT1.
 
 **Architecture:** Giữ cấu trúc Python hiện có. Tạo hai chính sách endpoint có tên `core` và `enhanced`, khóa chính sách trong model trước TEST; chung feature extraction và metric, khác phần quyết định/hậu xử lý được công bố rõ. Giữ quy ước support hiện tại trong đợt tích hợp hai nhánh; khảo sát quy ước thời gian khác thành một bước nghiên cứu riêng, không tự đưa vào production.
 
 **Tech Stack:** Python chuẩn, các hàm tính toán tự cài; Matplotlib/IPython để trình bày, Jupyter để bàn giao notebook. Không thêm thư viện fit, VAD, histogram, thống kê hoặc DSP thay cho thuật toán tự viết.
 
 **Spec:** [Đề cập nhật nhóm 3–4](<H:/GIUAKI_XLTHS/Source/assignment/Hướng dẫn BT thi GK nhóm 3-4 SV_Phân đoạn tín hiệu thành tiếng nói và khoảng lặng_XLTHS_GK 2026.docx>), [phản biện mới](<C:/Users/Admin/Downloads/XAC_THUC_SO_SANH_VA_DE_XUAT_SUA_CODE (1).md>), [kế hoạch trước](H:/GIUAKI_XLTHS/reports/KE_HOACH_CAI_TIEN_ENDPOINT.md), các ràng buộc người dùng và phần thiết kế dưới đây. Phản biện là nguồn cần kiểm chứng; các khẳng định của tác giả không tự trở thành yêu cầu của thầy.
 
-**Trạng thái:** CHỜ NGƯỜI DÙNG DUYỆT. Ngày 07/10/2026. Lượt này chỉ đọc code, DOCX, artifacts và chạy probes đọc/số học nhỏ; chưa sửa code, chạy lại suite/kernel hay tái tạo artifacts. HEAD hiện là `d035dcb4d12e5f01abe7b33b6bd812a806193f1e`, nhưng working tree có các sửa Gaussian/notebook đã hoàn tất trước đó, chưa commit; đây mới là trạng thái phải giữ khi triển khai tiếp. Bằng chứng nghiệm thu trước là 133 tests, 24 trường hợp, không phải tests mới của lượt lập kế hoạch này.
+**Trạng thái thực thi 07/10/2026:** Người dùng đã duyệt và implementation Tasks1–5 đã thực hiện trên local `codex/endpoint-modes`; backup remote `codex/backup-before-endpoint-modes-20261007` tại `5ceb289c51079d53b977f5316bcc70971d119c47`. Task6 gate sau tích hợp/sửa writer+units:173testsPASS,24enhancednumeric exact,48core/enhanced cases,124protected hashes và3freshnotebooks/CODEZIP. Review độc lập cuối/visual và archive do root hoàn tất trước bàn giao; không push/merge implementation. Chi tiết: [báo cáo nghiệm thu](../../../reports/KET_QUA_NGHIEM_THU_2026_10_07.md).
+
+**Ghi chép lập kế hoạch lịch sử (trước duyệt, không phải trạng thái hiện tại):** CHỜ NGƯỜI DÙNG DUYỆT. Ngày 07/10/2026. Lượt này chỉ đọc code, DOCX, artifacts và chạy probes đọc/số học nhỏ; chưa sửa code, chạy lại suite/kernel hay tái tạo artifacts. HEAD hiện là `d035dcb4d12e5f01abe7b33b6bd812a806193f1e`, nhưng working tree có các sửa Gaussian/notebook đã hoàn tất trước đó, chưa commit; đây mới là trạng thái phải giữ khi triển khai tiếp. Bằng chứng nghiệm thu trước là 133 tests, 24 trường hợp, không phải tests mới của lượt lập kế hoạch này.
 
 ## A. Kết quả kiểm chứng tài liệu
 
 Ba subagent kiểm tra độc lập: giao thức/metrics/notebook; vai trò ngưỡng ba thuật toán; quy ước biên và 200/100 ms. Không subagent nào sửa file hoặc tái tạo kết quả.
 
 | Nhận xét trong file | Kết luận với code hiện tại | Bằng chứng |
 |---|---|---|
 | TT2 chọn W từ TEST | **Đã sửa trong đợt trước.** Nhận xét mô tả phiên bản cũ. | `app/pipeline.py:245–290` và `:445–451`; `app/weight_selection.py:75–77` yêu cầu TRAIN. Hai model/schema và notebook hiện ghi TRAIN. |
diff --git a/notebooks/README.md b/notebooks/README.md
index 624ef14..819f6f6 100644
--- a/notebooks/README.md
+++ b/notebooks/README.md
@@ -1,27 +1,43 @@
 # Mã nguồn nộp bài — Jupyter Notebook
 
+## Hai chế độ endpoint (07/10/2026)
+
+Mặc định `enhanced`: ngưỡng native tạo seed; noise TRAIN và HIGH/LOW xác nhận, giữ speech; nối gap support dưới 200 ms và lọc span dưới 100 ms. `core` giữ quyết định native và chỉ nối gap support dưới 200 ms, không lọc duration hoặc padding FINAL; LOW/HIGH là null. Gap ước lượng đúng 200 ms được giữ riêng. TT1 dùng STE ≥ T, TT2 dùng Energy > T, TT3 giữ hướng high/low của Gaussian native. Đây là hai chế độ endpoint của cùng ba thuật toán; enhanced là phần bổ sung của dự án.
+
+```powershell
+python main_tt1.py --endpoint-mode core
+python main.py --evaluate-all --compare-endpoint-modes
+```
+
+Mỗi mode fit và khóa model độc lập trên bốn TRAIN trước đọc TEST. Kết quả mới ở `outputs/endpoint_modes/core/` và `outputs/endpoint_modes/enhanced/`; bảng so sánh ở `outputs/endpoint_modes/comparison/tables/`. Model schema 3 giữ policy/digest, metric schema 2 tiếp tục `mae_ms`/`rmse_ms`. Thiếu/thừa vùng làm primary mean toàn bộ file undefined; `valid_files_*` là thống kê subset riêng. TEST có `historical_test_exposure=true`, không phải holdout độc lập. Không chọn mode tốt hơn riêng cho từng WAV.
+
+Notebook dùng `MODE="enhanced"` mặc định cho bốn TEST figure và một illustration; luôn fit/khóa `MODELS` cả hai mode trước TEST, xuất 16 dòng tám WAV/mode và bảng bốn TEST/mode. TT2 có 200 TRAIN sweep rows mỗi mode. Core plot native T; Energy TT2 được chuẩn hóa chỉ ở bước hiển thị. Source digest và model lock digests độc lập kiểm tra nguồn/outputs và model; Restart Kernel → Run All → Save vẫn chạy độc lập.
+
+PPTX/PDF và ZIP Python cũ giữ nguyên previous version. Các bảng, noise và ví dụ HIGH/LOW bên dưới mô tả enhanced; không phải công thức quyết định FINAL của core. Xem [báo cáo hai mode](../reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md).
+
+
 Theo yêu cầu bổ sung của thầy, mỗi sinh viên có một `.ipynb` riêng. Ba notebook chứa toàn bộ hàm tính toán cần thiết, chạy độc lập với các module `.py` của dự án:
 
 | Thành viên phụ trách | Notebook |
 |---|---|
 | TT1 — Binary Search | [THUAT_TOAN_1.ipynb](THUAT_TOAN_1.ipynb) |
 | TT2 — Histogram chỉ Energy | [THUAT_TOAN_2.ipynb](THUAT_TOAN_2.ipynb) |
 | TT3 — Thống kê Gaussian | [THUAT_TOAN_3.ipynb](THUAT_TOAN_3.ipynb) |
 
 ## Xem kết quả đã lưu
 
 Mở notebook bằng JupyterLab, VS Code hoặc trình xem notebook. Số liệu và ảnh kết quả được lưu trong chính notebook; không cần WAV/LAB để **xem** chúng. Giữ các outputs này khi nộp; không chọn “Clear All Outputs”.
 
 Notebook có các cell lần lượt: cấu hình → đọc WAV/LAB → chia khung/tính năng lượng thủ công → thuật toán riêng → High/Low và vùng nói cuối → học trên train → đánh giá → bảng và đồ thị. Bảng 4 test và bảng 8 file train + test được ghi rõ riêng.
 
-TT2 chỉ Energy, không F0/Centroid. Notebook fit mọi model/noise/W từ TRAIN trước TEST, chọn W1–50 trên TRAIN FINAL với `tie_preference_W=20`. TRAIN hiện tại hòa cả 50 W, chọn W20; candidate frame-F1 đề xuất W1 riêng (0.898698). Model schema 2 ghi `train_selected_reused_test`, `historical_test_exposure=true`; TEST được dùng lại sau lịch sử phát triển, không khẳng định độc lập. Model digest được khóa trước TEST và kiểm tra lại sau chấm. `--file` demo dùng model đã khóa. Metric chính `mae_ms`/`rmse_ms`, calibration `final_region_mae_ms`, diagnostic `tolerance_boundary_*` và `matched_boundary_mae_ms`.
+TT2 chỉ Energy, không F0/Centroid. Notebook fit mọi model/noise/W từ TRAIN trước TEST, chọn W1–50 trên TRAIN FINAL với `tie_preference_W=20`. Enhanced TRAIN hiện tại hòa cả 50 W với primary mean hợp lệ, chọn W20; core có count errors nên primary mean TRAIN undefined, valid-only được ghi riêng; candidate frame-F1 đề xuất W1 riêng (0.898698). Model schema 3 với metric schema 2 ghi `train_selected_reused_test`, `historical_test_exposure=true`; TEST được dùng lại sau lịch sử phát triển, không khẳng định độc lập. Model digest được khóa trước TEST và kiểm tra lại sau chấm. `--file` demo dùng model đã khóa. Metric chính `mae_ms`/`rmse_ms`, calibration `final_region_mae_ms`, diagnostic `tolerance_boundary_*` và `matched_boundary_mae_ms`.
 
-TT3 giải equal-density trong tọa độ dịch tâm/chia scale, với sigma floor `1e-9` và kiểm tra log-density. Gaussian thô `fit`/`predict` hỗ trợ hướng `low`; FINAL energy HIGH/LOW chỉ hỗ trợ `speech_direction='high'`, từ chối rõ ràng `low` hoặc hướng không hợp lệ lúc fit model FINAL và detect. Quy tắc 200 ms đo khoảng trống ước lượng giữa support khung hoạt động; 100 ms là heuristic lọc span support, không bảo đảm khoảng lặng vật lý hay độ dài voiced audio vì frame chồng lấn.
+TT3 giải equal-density trong tọa độ dịch tâm/chia scale, với sigma floor `1e-9` và kiểm tra log-density. Gaussian thô `fit`/`predict` hỗ trợ hướng `low`; Enhanced FINAL energy HIGH/LOW chỉ hỗ trợ `speech_direction='high'`, từ chối rõ ràng `low` hoặc hướng không hợp lệ lúc fit model FINAL và detect. Quy tắc 200 ms đo khoảng trống ước lượng giữa support khung hoạt động; 100 ms là heuristic lọc span support, không bảo đảm khoảng lặng vật lý hay độ dài voiced audio vì frame chồng lấn.
 
 ## Chạy lại trên máy này
 
 Từ thư mục gốc dự án:
 
 ```powershell
 .\.venv\Scripts\python.exe -m jupyterlab notebooks
 ```
diff --git a/outputs/README.md b/outputs/README.md
index 503d80b..be92cd5 100644
--- a/outputs/README.md
+++ b/outputs/README.md
@@ -1,15 +1,35 @@
-# Kết quả hiện hành
+# Kết quả hiện hành — nghiệm thu 07/10/2026
+
+## Hai chế độ endpoint (07/10/2026)
+
+Mặc định `enhanced`: ngưỡng native tạo seed; noise TRAIN và HIGH/LOW xác nhận, giữ speech; nối gap support dưới 200 ms và lọc span dưới 100 ms. `core` giữ quyết định native và chỉ nối gap support dưới 200 ms, không lọc duration hoặc padding FINAL; LOW/HIGH là null. Gap ước lượng đúng 200 ms được giữ riêng. TT1 dùng STE ≥ T, TT2 dùng Energy > T, TT3 giữ hướng high/low của Gaussian native. Đây là hai chế độ endpoint của cùng ba thuật toán; enhanced là phần bổ sung của dự án.
+
+```powershell
+python main_tt1.py --endpoint-mode core
+python main.py --evaluate-all --compare-endpoint-modes
+```
+
+Mỗi mode fit và khóa model độc lập trên bốn TRAIN trước đọc TEST. Kết quả mới ở `outputs/endpoint_modes/core/` và `outputs/endpoint_modes/enhanced/`; bảng so sánh ở `outputs/endpoint_modes/comparison/tables/`. Model schema 3 giữ policy/digest, metric schema 2 tiếp tục `mae_ms`/`rmse_ms`. Thiếu/thừa vùng làm primary mean toàn bộ file undefined; `valid_files_*` là thống kê subset riêng. TEST có `historical_test_exposure=true`, không phải holdout độc lập. Không chọn mode tốt hơn riêng cho từng WAV.
+
+Notebook dùng `MODE="enhanced"` mặc định cho bốn TEST figure và một illustration; luôn fit/khóa `MODELS` cả hai mode trước TEST, xuất 16 dòng tám WAV/mode và bảng bốn TEST/mode. TT2 có 200 TRAIN sweep rows mỗi mode. Core plot native T; Energy TT2 được chuẩn hóa chỉ ở bước hiển thị. Source digest và model lock digests độc lập kiểm tra nguồn/outputs và model; Restart Kernel → Run All → Save vẫn chạy độc lập.
+
+PPTX/PDF và ZIP Python cũ giữ nguyên previous version. Các bảng, noise và ví dụ HIGH/LOW bên dưới mô tả enhanced; không phải công thức quyết định FINAL của core. Xem [báo cáo hai mode](../reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md).
+
 
-- `models/`: model TT1/TT2/TT3; TT2 Energy-only, W = 20.
+- `models/`: ba model enhanced TT1/TT2/TT3 hiện tại, fit TRAIN và khóa trước TEST; TT2 Energy-only, W = 20. Chưa có model core riêng.
 - `tables/all/`: 4 test × 3 thuật toán.
 - `tables/all_all_dataset/`: 8 WAV × 3 thuật toán, gồm cả train nên không phải 8 test độc lập.
 - `tables/tt1/`, `tt2/`, `tt3/`: batch riêng.
-- `tables/tt2_w_selection/`: W nguyên 1–50 trên đủ 4 test, 200 trường hợp.
+- `tables/tt2_w_selection/`: W nguyên 1–50 trên đủ 4 TRAIN (`phone_F1`, `phone_M1`, `studio_F1`, `studio_M1`), 200 trường hợp; chấm FINAL, chọn W20 bằng tie preference 20 khi hòa.
 - `tables/training_frames.csv`, `dataset_statistics.csv`: dữ liệu thống kê.
 - `figures/`: 4 test, hình so sánh và phân phối Gaussian train.
 - `diagnostics/`: candidate/final regions, ngưỡng và fallback của từng WAV.
 - `predictions/`: các đoạn speech/sil được xuất cho từng WAV.
 
-MAE chính là `mae_ms`/`boundary_MAE_ms`. Cột phụ `boundary_mae_ms` chỉ ghép biên trong dung sai 100 ms; không dùng thay metric chính. Đọc [báo cáo kết quả](../reports/KET_QUA_HIEN_TAI.md) để phân biệt train/test, counts và bất thường.
+Metric schema 2 dùng MAE/RMSE chính `mae_ms` / `rmse_ms`. Thiếu/thừa vùng làm metric chính không xác định. `matched_boundary_mae_ms` chấm vùng ghép theo thứ tự; `tolerance_boundary_*` là diagnostic sự kiện trong dung sai 100 ms, không thay metric chính. Đọc [báo cáo kết quả](../reports/KET_QUA_HIEN_TAI.md) để phân biệt TRAIN/TEST, counts và bất thường.
+
+Model schema 3 với metric schema 2 ghi `parameter_selection_set=train`, `evaluation_protocol=train_selected_reused_test`, `historical_test_exposure=true`. TEST đã được xem trong phát triển và được dùng lại; không phải holdout mới độc lập. Model legacy hiệu chỉnh bằng TEST vẫn phải giữ provenance cũ.
+
+Nghiệm thu 07/10: **133/133 tests**, 24/24 trường hợp giữ nguyên và 0 regression; mean bốn TEST TT1/TT2/TT3 vẫn **20.00/13.75/12.50 ms**. Xem [bằng chứng nghiệm thu](tables/hotfix_oct06/verification.json). [Baseline khóa trước sửa tài liệu](tables/endpoint_modes_oct07/baseline.json) giữ ba model, 24 FINAL/masks/metrics/T/W/LOW/HIGH, đặc trưng, hashes và môi trường. Đợt khóa baseline không tái tạo bảng/model hoặc tuyên bố cải thiện số liệu; năm cờ END muộn vẫn còn.
 
 Chạy lại main cập nhật kết quả tương ứng. Các lượt `--file`, `--snr-study` hoặc `--compare-context` sinh thêm thư mục/bảng mới; bản dọn hiện tại chỉ giữ các batch chính.
diff --git a/reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md b/reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md
new file mode 100644
index 0000000..e186366
--- /dev/null
+++ b/reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md
@@ -0,0 +1,82 @@
+# Kết quả endpoint core và enhanced — 07/10/2026
+
+Cùng ba thuật toán và hai policy được fit TRAIN độc lập trước TEST. Không chọn mode theo từng bản ghi. TEST từng được xem trong lịch sử; protocol `train_selected_reused_test`, `historical_test_exposure=true`. Gaussian vẫn là xấp xỉ theo đề. TT1 cân bằng diện tích nhầm lẫn, TT3 giải equal-density; sigma đơn lẻ không suy ra T3 > T1.
+
+## Bốn TEST (12 kết quả mỗi mode)
+
+| Algorithm | Mode | Mean FINAL-region endpoint MAE ms | Valid-only mean ms | Counts correct | Max defined MAE ms |
+|---|---|---|---|---|---|
+| tt1 | core | undefined | 7.500000 | 3/4 | 12.500000 |
+| tt2 | core | undefined | 9.170446 | 3/4 | 17.505669 |
+| tt3 | core | 12.500000 | 12.500000 | 4/4 | 27.500000 |
+| tt1 | enhanced | 20.000000 | 20.000000 | 4/4 | 57.500000 |
+| tt2 | enhanced | 13.750000 | 13.750000 | 4/4 | 32.500000 |
+| tt3 | enhanced | 12.500000 | 12.500000 | 4/4 | 27.500000 |
+
+## Tám WAV TRAIN + TEST (24 kết quả mỗi mode)
+
+| Algorithm | Mode | Mean FINAL-region endpoint MAE ms | Valid-only mean ms | Counts correct | Max defined MAE ms |
+|---|---|---|---|---|---|
+| tt1 | core | undefined | 83.212666 | 7/8 | 297.500000 |
+| tt2 | core | undefined | 10.837113 | 6/8 | 27.505669 |
+| tt3 | core | 12.498583 | 12.498583 | 8/8 | 27.500000 |
+| tt1 | enhanced | 31.873583 | 31.873583 | 8/8 | 77.500000 |
+| tt2 | enhanced | 13.748583 | 13.748583 | 8/8 | 32.500000 |
+| tt3 | enhanced | 12.498583 | 12.498583 | 8/8 | 27.500000 |
+
+Primary MAE/RMSE cần đúng số vùng trên mọi file. Mean subset chỉ nằm ở valid-only; lỗi lớn vẫn được giữ. Counts sai của core TT1/TT2 không được thay bằng metric các vùng đã ghép. Core TT3 và enhanced TT3 cho cùng endpoints trên dataset này; đây không phải bảo đảm cho dữ liệu khác.
+
+## Từng WAV và từng mode
+
+| Split | WAV | Algorithm | Mode | GT / prediction regions | START s | END s | MAE ms | RMSE ms | Status |
+|---|---|---|---|---|---|---|---|---|---|
+| train | phone_F1 | tt1 | core | 1 / 1 | 0.53 | 3.235 | 242.49999999999994 | 342.9467888754755 | suspiciously high MAE |
+| train | phone_M1 | tt1 | core | 1 / 1 | 0.4 | 4.055 | 297.49999999999983 | 380.67374482619607 | suspiciously high MAE; boundary inside silence |
+| train | studio_F1 | tt1 | core | 1 / 1 | 0.66 | 2.164988662131519 | 17.494331065759596 | 17.67286044324514 | OK |
+| train | studio_M1 | tt1 | core | 1 / 1 | 0.87 | 2.0649886621315194 | 2.4943310657596918 | 3.5275168222458926 | OK |
+| test | phone_F2 | tt1 | core | 1 / 3 | 0.61 | 4.795 | undefined | undefined | extra predicted regions; boundary inside silence |
+| test | phone_M2 | tt1 | core | 1 / 1 | 0.52 | 2.535 | 12.500000000000068 | 12.747548783982039 | OK |
+| test | studio_F2 | tt1 | core | 1 / 1 | 0.76 | 2.3649886621315193 | 7.505668934240428 | 7.909282749784279 | OK |
+| test | studio_M2 | tt1 | core | 1 / 1 | 0.45 | 1.9349886621315193 | 2.4943310657596918 | 3.5275168222458926 | OK |
+| train | phone_F1 | tt2 | core | 1 / 2 | 0.54 | 2.745 | undefined | undefined | extra predicted regions |
+| train | phone_M1 | tt2 | core | 1 / 1 | 0.46 | 3.525 | 2.4999999999999467 | 3.5355339059326623 | OK |
+| train | studio_F1 | tt2 | core | 1 / 1 | 0.67 | 2.144988662131519 | 7.505668934240428 | 7.909282749784279 | OK |
+| train | studio_M1 | tt2 | core | 1 / 1 | 0.91 | 2.0449886621315194 | 27.505668934240333 | 30.21043085261847 | OK |
+| test | phone_F2 | tt2 | core | 1 / 2 | 1.05 | 4.015 | undefined | undefined | extra predicted regions |
+| test | phone_M2 | tt2 | core | 1 / 1 | 0.53 | 2.515 | 2.4999999999999467 | 3.5355339059326623 | OK |
+| test | studio_F2 | tt2 | core | 1 / 1 | 0.76 | 2.3449886621315192 | 17.505668934240436 | 19.046876672715992 | OK |
+| test | studio_M2 | tt2 | core | 1 / 1 | 0.46 | 1.9249886621315193 | 7.505668934240317 | 7.909282749784209 | OK |
+| train | phone_F1 | tt3 | core | 1 / 1 | 0.53 | 2.745 | 2.4999999999999467 | 3.5355339059326623 | OK |
+| train | phone_M1 | tt3 | core | 1 / 1 | 0.46 | 3.535 | 7.500000000000062 | 10.6066017177983 | OK |
+| train | studio_F1 | tt3 | core | 1 / 1 | 0.66 | 2.164988662131519 | 17.494331065759596 | 17.67286044324514 | OK |
+| train | studio_M1 | tt3 | core | 1 / 1 | 0.91 | 2.0649886621315194 | 22.49433106575971 | 28.503392340758833 | OK |
+| test | phone_F2 | tt3 | core | 1 / 1 | 1.01 | 4.085 | 27.499999999999968 | 32.59601202601319 | boundary inside silence |
+| test | phone_M2 | tt3 | core | 1 / 1 | 0.52 | 2.525 | 7.499999999999951 | 7.905694150420921 | OK |
+| test | studio_F2 | tt3 | core | 1 / 1 | 0.76 | 2.3649886621315193 | 7.505668934240428 | 7.909282749784279 | OK |
+| test | studio_M2 | tt3 | core | 1 / 1 | 0.46 | 1.9349886621315193 | 7.494331065759696 | 7.902112055091845 | OK |
+| train | phone_F1 | tt1 | enhanced | 1 / 1 | 0.53 | 2.865 | 57.50000000000011 | 81.31727983645311 | boundary inside silence |
+| train | phone_M1 | tt1 | enhanced | 1 / 1 | 0.45 | 3.665 | 77.50000000000001 | 102.77402395547234 | boundary inside silence |
+| train | studio_F1 | tt1 | enhanced | 1 / 1 | 0.66 | 2.164988662131519 | 17.494331065759596 | 17.67286044324514 | OK |
+| train | studio_M1 | tt1 | enhanced | 1 / 1 | 0.91 | 2.0649886621315194 | 22.49433106575971 | 28.503392340758833 | OK |
+| test | phone_F2 | tt1 | enhanced | 1 / 1 | 1.01 | 4.145 | 57.49999999999978 | 74.58216945088117 | boundary inside silence |
+| test | phone_M2 | tt1 | enhanced | 1 / 1 | 0.52 | 2.535 | 12.500000000000068 | 12.747548783982039 | OK |
+| test | studio_F2 | tt1 | enhanced | 1 / 1 | 0.76 | 2.3649886621315193 | 7.505668934240428 | 7.909282749784279 | OK |
+| test | studio_M2 | tt1 | enhanced | 1 / 1 | 0.45 | 1.9349886621315193 | 2.4943310657596918 | 3.5275168222458926 | OK |
+| train | phone_F1 | tt2 | enhanced | 1 / 1 | 0.53 | 2.745 | 2.4999999999999467 | 3.5355339059326623 | OK |
+| train | phone_M1 | tt2 | enhanced | 1 / 1 | 0.46 | 3.545 | 12.499999999999956 | 17.677669529663625 | OK |
+| train | studio_F1 | tt2 | enhanced | 1 / 1 | 0.66 | 2.164988662131519 | 17.494331065759596 | 17.67286044324514 | OK |
+| train | studio_M1 | tt2 | enhanced | 1 / 1 | 0.91 | 2.0649886621315194 | 22.49433106575971 | 28.503392340758833 | OK |
+| test | phone_F2 | tt2 | enhanced | 1 / 1 | 1.01 | 4.095 | 32.499999999999865 | 39.528470752104546 | boundary inside silence |
+| test | phone_M2 | tt2 | enhanced | 1 / 1 | 0.52 | 2.525 | 7.499999999999951 | 7.905694150420921 | OK |
+| test | studio_F2 | tt2 | enhanced | 1 / 1 | 0.76 | 2.3649886621315193 | 7.505668934240428 | 7.909282749784279 | OK |
+| test | studio_M2 | tt2 | enhanced | 1 / 1 | 0.46 | 1.9349886621315193 | 7.494331065759696 | 7.902112055091845 | OK |
+| train | phone_F1 | tt3 | enhanced | 1 / 1 | 0.53 | 2.745 | 2.4999999999999467 | 3.5355339059326623 | OK |
+| train | phone_M1 | tt3 | enhanced | 1 / 1 | 0.46 | 3.535 | 7.500000000000062 | 10.6066017177983 | OK |
+| train | studio_F1 | tt3 | enhanced | 1 / 1 | 0.66 | 2.164988662131519 | 17.494331065759596 | 17.67286044324514 | OK |
+| train | studio_M1 | tt3 | enhanced | 1 / 1 | 0.91 | 2.0649886621315194 | 22.49433106575971 | 28.503392340758833 | OK |
+| test | phone_F2 | tt3 | enhanced | 1 / 1 | 1.01 | 4.085 | 27.499999999999968 | 32.59601202601319 | boundary inside silence |
+| test | phone_M2 | tt3 | enhanced | 1 / 1 | 0.52 | 2.525 | 7.499999999999951 | 7.905694150420921 | OK |
+| test | studio_F2 | tt3 | enhanced | 1 / 1 | 0.76 | 2.3649886621315193 | 7.505668934240428 | 7.909282749784279 | OK |
+| test | studio_M2 | tt3 | enhanced | 1 / 1 | 0.46 | 1.9349886621315193 | 7.494331065759696 | 7.902112055091845 | OK |
+
+Các START/END scalar là envelope hỗ trợ đọc nhanh; khi nhiều vùng, diagnostic JSON chứa toàn bộ FINAL regions và primary metric chấm mọi cặp START/END theo thứ tự. Core LOW/HIGH null; native T nằm trong threshold diagnostics. Timing 25/10 ms dùng nearest samples/ties-to-even (44.1 kHz: 1102/441 samples); actual timing có trong metrics. Gap support <200 ms mới nối; exact200 ms giữ. Slides và ZIP Python cũ là previous version và được giữ nguyên.
diff --git a/reports/KET_QUA_HIEN_TAI.md b/reports/KET_QUA_HIEN_TAI.md
index b171bbe..685da98 100644
--- a/reports/KET_QUA_HIEN_TAI.md
+++ b/reports/KET_QUA_HIEN_TAI.md
@@ -1,19 +1,27 @@
 # Kết quả hiện tại — cập nhật 07/10/2026
 
+## Nghiệm thu core/enhanced ngày 07/10/2026
+
+[Báo cáo nghiệm thu tích hợp](KET_QUA_NGHIEM_THU_2026_10_07.md): fresh **173 tests PASS trong15.200s**, enhanced24/24numeric exact so baseline,48core/enhanced cases;6TRAIN models khóa trước TEST,3notebooks fresh/15PNG và CODE ZIP đúng3executednotebook bytes. **124protected hashes** trong148baseline unchanged; core TT1/TT2 mean TEST undefined do counts sai, không thay bằng valid-only mean. [Final verification](../outputs/tables/endpoint_modes_oct07/final_verification.json), [before/after](../outputs/tables/endpoint_modes_oct07/final_regression.csv), [mode comparison](../outputs/tables/endpoint_modes_oct07/final_core_enhanced.csv).
+
+Energy thực là STE/N (mean squared sample amplitude); production labels/models/notebooks đã sửa đúng. Timing research giữ study metadata lịch sử47cc00b/provenance; physical silence200/210ms còn có thể bị nối, LOW=T1 cófold+205ms nên chưa đổi default. Python3.10 chưa kiểm. Root đang hoàn tất review độc lập/visual và archive [verification_logs.zip](../outputs/tables/endpoint_modes_oct07/verification_logs.zip). Các nghiệm thu133/137 và số liệu bên dưới là lịch sử, không phải gate mới.
+
 ## Cập nhật sửa lỗi ngày 06/10, nghiệm thu ngày 07/10/2026
 
 [Báo cáo sửa lỗi chi tiết](KET_QUA_SUA_LOI_2026_10_06.md) ghi root cause, hàm đã sửa, TRAIN ablation, synthetic timing và nghiệm thu notebook. Solver TT3 đã dịch tâm/chia scale, kiểm tra log-density và sửa ca gần biên phụ thuộc thứ tự lớp; FINAL từ chối rõ hướng Gaussian `low`/không hợp lệ, chưa hỗ trợ hướng đó ở HIGH/LOW. Nghiệm thu lại ngày 07/10 đạt **133/133 tests trong 13.862 s**; ba notebook đã chạy bằng kernel mới, khớp 24/24 WAV, lưu 15 hình và ZIP CODE đã kiểm tra nguồn/bytes. Review độc lập cuối đã hoàn tất, không còn finding trọng yếu trong phạm vi sửa; bằng chứng tại [verification.json](../outputs/tables/hotfix_oct06/verification.json).
 
 [Before/after 24 trường hợp](../outputs/tables/hotfix_oct06/regression.csv) có **0 regression**: MAE/biên/số vùng đều không đổi, mean bốn TEST vẫn 20.00/13.75/12.50 ms. Năm cờ END muộn trong mục 4 vẫn còn. Có thêm 48 ca waveform tổng hợp và 48 dòng ablation chỉ TRAIN; giữ tham số production.
 
 Điều kiện 200 ms hiện đo **gap support ước lượng**, không bảo đảm giữ mọi silence vật lý ≥200 ms: silence thực 200/210 ms vẫn có thể bị gộp do frame chồng lấn. 100 ms lọc span support sau merge, không phải thời lượng voiced samples. Giới hạn này đã được kiểm tra/công bố, chưa sửa bằng estimator mới. Frame 25/hop 10 ms được giữ; Fs44,1k dùng 1102/441 samples, frame thực 24.988662 ms. Slide/PDF và ba ZIP Python cũ giữ nguyên theo yêu cầu, là previous version; notebook ZIP là gói CODE được làm mới. Các đoạn ngày 05/10 bên dưới là lịch sử, bao gồm trạng thái Git ở thời điểm đó.
 
 ## 1. Phiên bản đang dùng
+
+Baseline cho đợt đánh giá thuật toán/endpoint ngày 07/10 được khóa tại [baseline.json](../outputs/tables/endpoint_modes_oct07/baseline.json): **ba model enhanced hiện tại và 24 kết quả (8 WAV × 3 thuật toán)**, gồm FINAL regions, full masks, metrics/status, T/W/LOW/HIGH, record/features, SHA256 input/artifacts và versions môi trường. Đối chiếu trước sửa tài liệu khớp đủ 24 diagnostics/metric rows hiện hành và FINAL/MAE/status của nghiệm thu 07/10; mean TEST vẫn 20.00/13.75/12.50 ms. Đây là capture bằng model đã lưu, không fit lại hoặc tái tạo số liệu. Model core riêng chưa được tạo trong đợt khóa baseline.
 
 - TT1: Binary Search cân bằng diện tích nhầm lẫn trên normalized STE.
 - TT2: Histogram **chỉ Energy** theo yêu cầu mới của thầy; W = 20 chung, 64 bins, smoothing radius 2.
 - TT3: thống kê Gaussian population trên normalized STE, ngưỡng giao hai mật độ.
 - Chung: frame 25 ms, hop 10 ms; HIGH/LOW hysteresis; nối silence dưới 200 ms; loại speech dưới 100 ms. Không tính F0.
 
 Tất cả endpoint chính lấy từ FINAL speech regions. Candidate/debug và padding 250 ms của TT2 không được dùng làm biên cuối. Dataset gốc có một vùng nói trong mỗi WAV; code hỗ trợ nhiều vùng khi có khoảng lặng đủ dài.
 
@@ -94,17 +102,19 @@ Nhiều vùng được ghép theo thời gian. Thiếu/thừa vùng làm MAE ch
 - [200 trường hợp W](../outputs/tables/tt2_w_selection/sweep.csv)
 - [Model TT2](../outputs/models/tt2.json)
 - [Giải thích TT1](TT1_BINARY_SEARCH_GIAI_THICH.md)
 - [Giải thích TT2](TT2_HISTOGRAM_GIAI_THICH.md)
 - [Giải thích TT3](TT3_GAUSSIAN_GIAI_THICH.md)
 
 Các bảng là kết quả pipeline hiện hành đã tính sau chuyển TT2 Energy-only. Việc dọn thư mục, tách tài liệu và đổi ngôn ngữ slide không thay đổi code thuật toán.
 
-## 8. Stage1: thay đổi và bằng chứng hồi quy
+## 8. Lịch sử 05/10/2026 — Stage1 và bằng chứng hồi quy
+
+Mục này giữ nguyên bằng chứng Stage1/Stage4 ngày 05/10; số 98 tests và branch/trạng thái push dưới đây chỉ áp dụng thời điểm đó. Nghiệm thu hiện hành 07/10 là 133 tests trong mục cập nhật đầu báo cáo.
 
 Stage1 tách detector khỏi chấm LAB, fit toàn bộ TRAIN trước TEST, hiệu chỉnh W trên TRAIN FINAL, khóa mô hình khi đánh giá và chuyển sang schema 2. Các main Python hiện hành đã đồng bộ.
 
 [Bảng before/after](../outputs/tables/all_all_dataset/regression_before_after.csv) lưu đối chiếu 24 file/thuật toán. Lượt tái tạo Python do tác vụ tích hợp chạy xác nhận FINAL regions, LOW/HIGH, MAE/RMSE, frame F1, số vùng và status không đổi so với baseline. Mean TEST vẫn 20.00 / 13.75 / 12.50 ms; năm trường hợp END muộn trong mục 4 vẫn còn. Thay đổi giao thức không tạo tuyên bố cải thiện độ chính xác.
 
 Đã hoàn tất Stage1 và Stage4 bắt buộc ngày 05/10/2026 tại thư mục chính `H:/GIUAKI_XLTHS`. Bộ test cuối khi tiếp tục công việc đạt **98/98 trong 21.788 s**. Ba notebook đã chạy bằng **ba kernel mới**, mỗi notebook khớp đầy đủ model/metric/FINAL/ngưỡng với Python ở 8/8 WAV, tổng **24/24**; TT2 kiểm tra 200 dòng TRAIN và digest model đã khóa. Auditor xác nhận saved outputs hợp lệ.
 
 Các lệnh nghiệm thu đã chạy bằng Python trong `.venv/Scripts/python.exe`: `-m unittest discover -s tests -v`; `tools/build_notebooks.py`; `tools/run_notebooks.py`; `tools/run_notebooks.py --validate-only`. Các lệnh trên đều hoàn tất thành công; đối chiếu hồi quy, hash input và manifest ZIP được kiểm tra riêng trong tác vụ tích hợp.
diff --git a/reports/KET_QUA_NGHIEM_THU_2026_10_07.md b/reports/KET_QUA_NGHIEM_THU_2026_10_07.md
new file mode 100644
index 0000000..cc1d5db
--- /dev/null
+++ b/reports/KET_QUA_NGHIEM_THU_2026_10_07.md
@@ -0,0 +1,100 @@
+# Nghiệm thu endpoint core/enhanced — 07/10/2026
+
+Gate tích hợp sau sửa writer/units đã PASS; bàn giao cuối chờ root hoàn tất review độc lập và archive. Không push/merge implementation.
+
+## Phạm vi và các hàm đã thay đổi
+
+Ba thuật toán giữ nguyên: TT1 Binary Search cân bằng diện tích nhầm lẫn trên normalized STE; TT2 Histogram chỉ Energy; TT3 Gaussian equal-density xấp xỉ theo đề. Không thêm F0/Centroid/ZCR hay thuật toán thứ tư.
+
+`app.pipeline.algorithm_decision` tách quyết định native; `detect_regions` chọn policy khóa trong model: core quyết định native, merge internal support gap <200 ms, không lọc minimum speech/padding FINAL; enhanced giữ noise/HIGH–LOW hysteresis và 100 ms span filter. `fit_training_model` fit riêng từng mode trên TRAIN, chọn FINAL W theo mode và khóa schema3/calibration digest trước TEST. `app.weight_selection.sweep_final_weights`/`select_final_weight` giữ primary undefined nếu count sai; `summarize` nhóm theo algorithm+mode. `run_experiment`, CLI/config/output routing, plotting và notebook builder/runner xử lý cả hai mode và audit provenance. `core.decision_timing.decision_cells` cùng `tools.check_endpoint_robustness` chỉ phục vụ nghiên cứu opt-in, chưa đổi timing/LOW production.
+
+Đối chiếu Task3 `47cc00b`: 7 module tính toán có AST không đổi (TT2 chỉ sửa module docstring), 3 API `algorithm_decision`/`detect_regions`/`fit_training_model` có mọi AST node không đổi ngoài đúng hai string metadata: `sum of squared samples` → `mean squared sample amplitude`, và `Energy (sum of squared samples)` → `Energy (mean squared sample amplitude)`. Occurrence mỗi replacement phải đúng1; không dùng generic ignore AST. Task5 nâng phần consumer/metadata, không đổi native arithmetic. Initial byte gate TT2 fail do docstring đã được duyệt; diff thật được kiểm tra, gate sửa thành AST bỏ module docstring. Log fail được giữ, không che lỗi.
+
+## Gate thực thi và môi trường
+
+Fresh suite sau second STABLE: **173 tests PASS**, 15.200 s unittest, 16.794 s wall, exit0. Baseline133 và Task1 gate137 là số lịch sử; số mới lấy từ output thật. Acceptance numeric/audit: 1.219 s.
+
+Môi trường: Python **3.14.7**, Windows11; numpy 2.5.2, matplotlib 3.11.1, nbformat 5.11.1, nbclient 0.11.0. Python3.10 **chưa kiểm** vì không có môi trường3.10; không suy diễn từ3.14.
+
+Commands: `.venv/Scripts/python.exe -m unittest discover -s tests -v`; `.venv/Scripts/python.exe .superpowers/sdd/2026-10-07-algorithm-baseline-and-endpoint-review/task6-acceptance.py`. Sau cleanup, scratch script và full raw command logs nằm trong [verification_logs.zip](../outputs/tables/endpoint_modes_oct07/verification_logs.zip); archive entry names giữ nguyên đường dẫn gốc. Root lưu review/rulings trước cleanup.
+
+## Enhanced trước/sau baseline
+
+**24/24 exact, 0 numeric regression**: full masks, FINAL regions, predicted/GT boundaries, region pairs, mọi metric cũ trừ intentional `model_schema_version` 2→3, status và mọi diagnostic cũ. T/W/noise/candidate W/F1 giữ nguyên. Bốn TEST enhanced mean MAE TT1/TT2/TT3 vẫn20.00/13.75/12.50 ms. Metadata schema/provenance mới không được dùng làm cớ để đổi số.
+
+Chi tiết before/after đầy đủ: [final_regression.csv](../outputs/tables/endpoint_modes_oct07/final_regression.csv); [baseline.json](../outputs/tables/endpoint_modes_oct07/baseline.json); [final_verification.json](../outputs/tables/endpoint_modes_oct07/final_verification.json).
+
+## Core/enhanced: toàn bộ bốn TEST và tám WAV
+
+Primary mean chỉ defined khi mọi file đúng count/matching. Median/min/max dưới đây là trên file có primary defined, n được báo rõ; không thay primary mean bằng valid-only mean. RMSE trong evidence là mean per-file RMSE, khác pooled boundary RMSE.
+
+| Scope | Mode | Algorithm | Defined/total | Primary mean MAE ms | Valid-only mean | Median defined | Min defined | Max defined | Extra regions | Worst defined file |
+|---|---|---|---:|---:|---:|---:|---:|---:|---:|---|
+| all | core | tt1 | 7/8 | undefined | 83.212666 | 12.500000 | 2.494331 | 297.500000 | 2 | train/phone_M1 |
+| test | core | tt1 | 3/4 | undefined | 7.500000 | 7.505669 | 2.494331 | 12.500000 | 2 | test/phone_M2 |
+| all | core | tt2 | 6/8 | undefined | 10.837113 | 7.505669 | 2.500000 | 27.505669 | 2 | train/studio_M1 |
+| test | core | tt2 | 3/4 | undefined | 9.170446 | 7.505669 | 2.500000 | 17.505669 | 1 | test/studio_F2 |
+| all | core | tt3 | 8/8 | 12.498583 | 12.498583 | 7.502834 | 2.500000 | 27.500000 | 0 | test/phone_F2 |
+| test | core | tt3 | 4/4 | 12.500000 | 12.500000 | 7.502834 | 7.494331 | 27.500000 | 0 | test/phone_F2 |
+| all | enhanced | tt1 | 8/8 | 31.873583 | 31.873583 | 19.994331 | 2.494331 | 77.500000 | 0 | train/phone_M1 |
+| test | enhanced | tt1 | 4/4 | 20.000000 | 20.000000 | 10.002834 | 2.494331 | 57.500000 | 0 | test/phone_F2 |
+| all | enhanced | tt2 | 8/8 | 13.748583 | 13.748583 | 10.002834 | 2.500000 | 32.500000 | 0 | test/phone_F2 |
+| test | enhanced | tt2 | 4/4 | 13.750000 | 13.750000 | 7.502834 | 7.494331 | 32.500000 | 0 | test/phone_F2 |
+| all | enhanced | tt3 | 8/8 | 12.498583 | 12.498583 | 7.502834 | 2.500000 | 27.500000 | 0 | test/phone_F2 |
+| test | enhanced | tt3 | 4/4 | 12.500000 | 12.500000 | 7.502834 | 7.494331 | 27.500000 | 0 | test/phone_F2 |
+
+Core count failures: TT1 test/phone_F2 GT1/pred3 (extra2), TT2 train/phone_F1 và test/phone_F2 GT1/pred2 (extra1 mỗi file); MAE/RMSE đều undefined. Không bỏ lỗi lớn: core TT1 phone_M1=297.5 ms, phone_F1=242.5 ms. Core TT3/endpoints trùng enhanced TT3 trên dataset này, không cam kết với dữ liệu khác.
+
+Toàn48 kết quả/allregions/status/counts: [final_core_enhanced.csv](../outputs/tables/endpoint_modes_oct07/final_core_enhanced.csv); thống kê: [final_summary.csv](../outputs/tables/endpoint_modes_oct07/final_summary.csv). [Báo cáo Task5](KET_QUA_ENDPOINT_MODES_2026_10_07.md) giữ bảng48file/mode chi tiết.
+
+Các file core xấu hơn enhanced (mode comparison, không phải regression enhanced):
+
+| WAV | Algorithm | Enhanced MAE ms | Core MAE ms | Lý do |
+|---|---|---:|---:|---|
+| train/phone_F1 | tt1 | 57.500000 | 242.500000 | suspiciously high MAE |
+| train/phone_M1 | tt1 | 77.500000 | 297.500000 | suspiciously high MAE; boundary inside silence |
+| test/phone_F2 | tt1 | 57.500000 | undefined | extra predicted regions; boundary inside silence |
+| train/phone_F1 | tt2 | 2.500000 | undefined | extra predicted regions |
+| train/studio_M1 | tt2 | 22.494331 | 27.505669 | OK |
+| test/phone_F2 | tt2 | 32.500000 | undefined | extra predicted regions |
+| test/studio_F2 | tt2 | 7.505669 | 17.505669 | OK |
+| test/studio_M2 | tt2 | 7.494331 | 7.505669 | OK |
+
+## Khóa model, notebook và bảo toàn
+
+Fit cả6 model riêng core/enhanced trước lần load TEST đầu tiên; fresh calibration exact với6 saved models, tự recompute calibration digest (loại digest self-reference), model không đổi sau inference48cases. TRAIN_files đúng4; `parameter_selection_set=train`, `evaluation_protocol=train_selected_reused_test`, `historical_test_exposure=true`. TEST đã được xem nhiều lượt trước; đổi protocol không tạo holdout độc lập. Legacy TEST-calibrated provenance được giữ trong canonical old models.
+
+Baseline148 SHA256; **124 protected files exact** gồm Source/data/slides/3ZIP Python cũ/toàn canonical outputs models/tables/diagnostics/predictions. Changed paths hợp lệ (source/docs/notebooks/CODEZIP) có before/after digests trong JSON. Không sửa slides/PDF/PPTX/data/LAB hay legacy canonical outputs.
+
+Ba notebook chạy kernel fresh độc lập, code sources không import project runtime; ordered source digest khớp saved execution evidence. External audit kiểm core+enhanced model khóa, results/provenance/diagnostics và TT2 hai TRAIN sweeps200rows; mỗi notebook5PNG (4TEST enhanced+1illustration), tổng15PNG. CODE ZIP có đúng3executedipynb, từng entry byteexact với notebook hiện tại, không WAV/LAB/audio/widget payload. Root phụ trách visual15PNG và review độc lập.
+
+## Timing research, mọi fold xấu đi và giới hạn vật lý
+
+4TRAIN folds:6commontrials×3algorithms +1TT1 LOW=T1 trial =76heldout rows. TT2 mỗi branch W1..50 trên3fitfiles:3600calibration rows,24heldout TT2 scores. 19synthetic branch configs resolve1216waveform row SHA; cả76heldout SHA resolve vềfull locked models. Study được fit bởi source47cc00b trước sửa units label; manifest/native/synthetic models và CSV diagnostics lịch sử có thể còn ghi sum, nhưng phép tính thực là Energy=STE/N (mean squared sample amplitude). Giữ exact study bytes/provenance, không viết lại evidence thành dữ liệu mới; production6models/notebooks/plots hiện đã sửa label đúng. P3 provenance thiếu19branch manifest đã được sửa bằng deterministic reconstruction từ6native locked models+trials, không refit/re-score;7CSV numerical bytes giữ nguyên. Full model hashes và source-native links được kiểm fresh.
+
+Không đẩy cells/LOW vào default. Estimated support gap exact200ms giữ, <200ms mới nối; 100ms enhanced filter đo span sau merge. Frame25/hop10 nearest samples/ties-to-even:16k400/160samples;44.1k1102/441samples, actualframe24.988662ms. Edges đầu/cuối không ép200ms; cells có thể extend nearest decision ra0/duration và incomplete tail.
+
+Physical GT không được đổi. Support oracle gộp cả24ca silence vật lý200/210ms (MAE undefined); cells oracle vẫn gộp23/24, chỉ1ca210ms giữ2vùng. Tất cả19locked branches gộp cả24ca200/210ms/branch. Có8shortbursts75/95/100/105ms và8edge/weak-tail cases trong characterization. Quy tắc200ms đúng với estimated support, không bảo đảm mọi physical silence≥200ms vì cửa sổ25ms overlap speech. Cần estimator mới có bằng chứng riêng nếu muốn sửa giới hạn vật lý.
+
+LOW=T1 TT1 phone_M1 fold xấu thêm **+205ms**, fullmean54.997→106.247ms; không thay noise/hysteresis LOW production. TT1 enhanced ở model hiện tại vẫn chịu noise policy, sửa đợt này là báo thêm faithful core. Các timing trials không tự làm mọi MAE tốt hơn.
+
+| Trial | Algorithm | Held-out TRAIN WAV | Delta MAE ms |
+|---|---|---|---:|
+| core_cells_0 | tt3 | phone_F1 | +7.500000 |
+| enhanced_cells_100 | tt2 | phone_F1 | +7.500000 |
+| enhanced_cells_100 | tt3 | phone_F1 | +7.500000 |
+| enhanced_tt1_t1_support_100 | tt1 | phone_M1 | +205.000000 |
+| core_cells_0 | tt1 | studio_M1 | +2.505669 |
+| core_cells_0 | tt2 | studio_M1 | +7.494331 |
+| core_cells_0 | tt3 | studio_M1 | +7.494331 |
+| enhanced_cells_100 | tt1 | studio_M1 | +2.505669 |
+| enhanced_cells_100 | tt2 | studio_M1 | +2.505669 |
+| enhanced_cells_100 | tt3 | studio_M1 | +7.494331 |
+
+Tổng10MAE fold regressions,52alternative comparisons; count regression không xảy ra. Undefined core means được giữ. Bằng chứng: [fold_comparisons.csv](../outputs/tables/endpoint_modes_oct07/timing_research/fold_comparisons.csv), [heldout_summary.csv](../outputs/tables/endpoint_modes_oct07/timing_research/heldout_summary.csv), [manifest.json](../outputs/tables/endpoint_modes_oct07/timing_research/manifest.json), [physical waveforms](../outputs/tables/endpoint_modes_oct07/timing_research/locked_model_waveforms.csv).
+
+## Coordination, review và archive
+
+Ruling cho Task4/5 chạy song song vì research không chặn integration, native/model interfaces đã ổn định và file ownership tách rõ. Task4 sở hữu decision_timing/check_endpoint_robustness/research/focusedtests; Task5 sở hữu CLI/config/run_experiment/summary/plotting/notebooktools/docs/geometry audit guard. Cost nếu interface drift: focused integration fixes và rerun complete regression. Gate fullsuite/regression chỉ chạy sau root STABLE; không stage/commit cùng lúc. Không production timing/default change được phép. Reviewer tìm P2: `main_tt1 --evaluate-all` có thể ghi đè shared `tables/all` bằng subset. Writer nay chỉ ghi shared benchmark khi selected chứa đủ3algorithms; demo1algorithm giữ run riêng, regression test kiểm cả3fixed-entrypoints và shared bytes. Root còn sửa label units từ sum thành mean-square đúng với Energy=STE/N; số học không đổi,6models/digests/plots và3freshkernel notebooks+ZIP đã regenerate. Gate171tests trướcfix được giữ riêng; saufix freshsuite173PASS và acceptance48casesPASS. Đây là rerun có lý do source mới, không lặp suite không cần thiết.
+
+Root lưu final independent review và artifact visual acceptance ở mục bàn giao dưới đây trước cleanup. RED/GREEN các Task1–5, reviewer packages/reports và intermediate taskN logs được bảo toàn exact bytes/digests trong [verification_logs.zip](../outputs/tables/endpoint_modes_oct07/verification_logs.zip). Standalone retained: baseline.json/final_verification.json/final_regression.csv/final_core_enhanced.csv/final_summary.csv/timing_research CSV+JSON và báo cáo này. Không xóa protected hoặc unowned artifacts.
diff --git a/reports/TT1_BINARY_SEARCH_GIAI_THICH.md b/reports/TT1_BINARY_SEARCH_GIAI_THICH.md
index bedfe03..c3f5a10 100644
--- a/reports/TT1_BINARY_SEARCH_GIAI_THICH.md
+++ b/reports/TT1_BINARY_SEARCH_GIAI_THICH.md
@@ -1,10 +1,26 @@
 # TT1 — Tìm ngưỡng bằng Binary Search: giải thích thuật toán và code
 
+## Hai chế độ endpoint (07/10/2026)
+
+Mặc định `enhanced`: ngưỡng native tạo seed; noise TRAIN và HIGH/LOW xác nhận, giữ speech; nối gap support dưới 200 ms và lọc span dưới 100 ms. `core` giữ quyết định native và chỉ nối gap support dưới 200 ms, không lọc duration hoặc padding FINAL; LOW/HIGH là null. Gap ước lượng đúng 200 ms được giữ riêng. TT1 dùng STE ≥ T, TT2 dùng Energy > T, TT3 giữ hướng high/low của Gaussian native. Đây là hai chế độ endpoint của cùng ba thuật toán; enhanced là phần bổ sung của dự án.
+
+```powershell
+python main_tt1.py --endpoint-mode core
+python main.py --evaluate-all --compare-endpoint-modes
+```
+
+Mỗi mode fit và khóa model độc lập trên bốn TRAIN trước đọc TEST. Kết quả mới ở `outputs/endpoint_modes/core/` và `outputs/endpoint_modes/enhanced/`; bảng so sánh ở `outputs/endpoint_modes/comparison/tables/`. Model schema 3 giữ policy/digest, metric schema 2 tiếp tục `mae_ms`/`rmse_ms`. Thiếu/thừa vùng làm primary mean toàn bộ file undefined; `valid_files_*` là thống kê subset riêng. TEST có `historical_test_exposure=true`, không phải holdout độc lập. Không chọn mode tốt hơn riêng cho từng WAV.
+
+Notebook dùng `MODE="enhanced"` mặc định cho bốn TEST figure và một illustration; luôn fit/khóa `MODELS` cả hai mode trước TEST, xuất 16 dòng tám WAV/mode và bảng bốn TEST/mode. TT2 có 200 TRAIN sweep rows mỗi mode. Core plot native T; Energy TT2 được chuẩn hóa chỉ ở bước hiển thị. Source digest và model lock digests độc lập kiểm tra nguồn/outputs và model; Restart Kernel → Run All → Save vẫn chạy độc lập.
+
+PPTX/PDF và ZIP Python cũ giữ nguyên previous version. Các bảng, noise và ví dụ HIGH/LOW bên dưới mô tả enhanced; không phải công thức quyết định FINAL của core. Xem [báo cáo hai mode](KET_QUA_ENDPOINT_MODES_2026_10_07.md).
+
+
 Cập nhật theo code hiện tại ngày 05/10/2026. Tài liệu này giải thích riêng TT1 để thành viên phụ trách có thể đọc, chạy và thuyết trình độc lập.
 
 ## Giao thức Stage1 và schema 2
 
 Mọi model, W và `endpoint_noise` được fit từ bốn TRAIN trước khi đọc TEST. Ba thuật toán dùng `schema_version=2`, `parameter_selection_set=train`, `evaluation_protocol=train_selected_reused_test`, `historical_test_exposure=true`. TEST đã được xem trong phát triển trước đây và được dùng lại để chấm; không gọi đây là holdout mới hoặc độc lập. Chạy một file (`--file`) vẫn fit TRAIN trước, không hiệu chỉnh bằng TEST.
 
 Hàm công khai [detect_regions()](../app/pipeline.py#L132) nhận `(algorithm, features, duration, params)`, không nhận LAB, nhãn hay filename; `endpoint_noise` phải được fit sẵn. [predict_and_score()](../app/pipeline.py#L174) gọi detector rồi chấm với LAB. CLI xuất metric vẫn yêu cầu WAV/LAB cùng tên.
 
@@ -142,17 +158,17 @@ Dừng khi **cả hai số đếm không thay đổi sau một lần cập nhậ
 | Overlap low | 0.0000542396991 |
 | Overlap high | 0.0113686891974 |
 | Quan sát silence trong overlap | 253 |
 | Quan sát speech trong overlap | 178 |
 | Số vòng | 11 |
 | T1 | **0.0010293375196** |
 | A(T1) còn dư | khoảng 0.0000002448924 |
 
-Các giá trị lấy từ [model TT1](../outputs/models/tt1.json), không phải hằng ngưỡng gán sẵn trong code. Chạy lại trên cùng dữ liệu sẽ học lại mô hình.
+Các giá trị lấy từ [model TT1](../outputs/endpoint_modes/enhanced/models/tt1.json), không phải hằng ngưỡng gán sẵn trong code. Chạy lại trên cùng dữ liệu sẽ học lại mô hình.
 
 [predict()](../algorithms/tt1_hodgkinson.py#L131) tạo nhãn ứng viên `1 if z >= T1 else 0`. Nó không đọc LAB.
 
 ## 5. Từ ứng viên đến vùng nói cuối cùng
 
 Phần này nằm ngoài lõi Binary Search. Nó được dùng chung để tránh nhiễu làm xuất hiện nhiều endpoint và hỗ trợ nhiều phát ngôn trong một WAV.
 
 ### 5.1. Học nền nhiễu từ train
@@ -254,18 +270,18 @@ Mở terminal tại thư mục gốc của dự án:
 python main_tt1.py
 python main_tt1.py --file phone_F2.wav
 python main_tt1.py --no-show
 python main_tt1.py --evaluate-all
 ```
 
 Mặc định chạy bốn test. `--file` chọn một WAV có LAB cùng tên. `--no-show` chỉ xuất file; `--evaluate-all` chấm cả tám WAV train/test và tự tắt cửa sổ.
 
-- [Model học được](../outputs/models/tt1.json): ngưỡng, overlap, số vòng, noise.
-- [Bảng bốn test](../outputs/tables/tt1/test_metrics.csv): MAE, RMSE, số vùng và status.
-- [Ảnh phone_F2](../outputs/figures/tt1/phone_F2.png): waveform, STE, High/Low, GT và final prediction.
-- [Diagnostic phone_F2](../outputs/diagnostics/tt1/phone_F2.json): candidate và final được lưu riêng.
+- [Model học được](../outputs/endpoint_modes/enhanced/models/tt1.json): ngưỡng, overlap, số vòng, noise.
+- [Bảng bốn test](../outputs/endpoint_modes/enhanced/tables/tt1/test_metrics.csv): MAE, RMSE, số vùng và status.
+- [Ảnh phone_F2](../outputs/endpoint_modes/enhanced/figures/tt1/phone_F2.png): waveform, STE, High/Low, GT và final prediction.
+- [Diagnostic phone_F2](../outputs/endpoint_modes/enhanced/diagnostics/tt1/phone_F2.json): candidate và final được lưu riêng.
 
 ## 9. Cách giải thích ngắn khi thuyết trình
 
 “Em học một ngưỡng normalized STE từ các khung train có nhãn. Binary Search thu hẹp miền chồng lấn theo dấu của hiệu diện tích nhầm lẫn, dừng khi hai số đếm không đổi. Khi chạy test, ngưỡng tạo ứng viên; High/Low xác nhận và duy trì tiếng nói, nối gap dưới 200 ms, loại vùng dưới 100 ms. Biên cuối lấy theo support khung và MAE chỉ tính trên các vùng đã xác nhận.”
 
 Giới hạn cần hiểu: nguồn dùng MA còn project dùng STE; điều kiện dừng không giải diện tích chính xác; chuẩn hóa theo đỉnh mỗi WAV và noise train có thể hạn chế khả năng áp dụng sang môi trường nhiễu khác. Với bộ hiện tại, noise floor quyết định nhiều phần của biên cuối TT1.
diff --git a/reports/TT2_HISTOGRAM_GIAI_THICH.md b/reports/TT2_HISTOGRAM_GIAI_THICH.md
index 541f4ac..e17c4aa 100644
--- a/reports/TT2_HISTOGRAM_GIAI_THICH.md
+++ b/reports/TT2_HISTOGRAM_GIAI_THICH.md
@@ -1,10 +1,26 @@
 # TT2 — Histogram chỉ dùng Energy: giải thích thuật toán và code
 
+## Hai chế độ endpoint (07/10/2026)
+
+Mặc định `enhanced`: ngưỡng native tạo seed; noise TRAIN và HIGH/LOW xác nhận, giữ speech; nối gap support dưới 200 ms và lọc span dưới 100 ms. `core` giữ quyết định native và chỉ nối gap support dưới 200 ms, không lọc duration hoặc padding FINAL; LOW/HIGH là null. Gap ước lượng đúng 200 ms được giữ riêng. TT1 dùng STE ≥ T, TT2 dùng Energy > T, TT3 giữ hướng high/low của Gaussian native. Đây là hai chế độ endpoint của cùng ba thuật toán; enhanced là phần bổ sung của dự án.
+
+```powershell
+python main_tt1.py --endpoint-mode core
+python main.py --evaluate-all --compare-endpoint-modes
+```
+
+Mỗi mode fit và khóa model độc lập trên bốn TRAIN trước đọc TEST. Kết quả mới ở `outputs/endpoint_modes/core/` và `outputs/endpoint_modes/enhanced/`; bảng so sánh ở `outputs/endpoint_modes/comparison/tables/`. Model schema 3 giữ policy/digest, metric schema 2 tiếp tục `mae_ms`/`rmse_ms`. Thiếu/thừa vùng làm primary mean toàn bộ file undefined; `valid_files_*` là thống kê subset riêng. TEST có `historical_test_exposure=true`, không phải holdout độc lập. Không chọn mode tốt hơn riêng cho từng WAV.
+
+Notebook dùng `MODE="enhanced"` mặc định cho bốn TEST figure và một illustration; luôn fit/khóa `MODELS` cả hai mode trước TEST, xuất 16 dòng tám WAV/mode và bảng bốn TEST/mode. TT2 có 200 TRAIN sweep rows mỗi mode. Core plot native T; Energy TT2 được chuẩn hóa chỉ ở bước hiển thị. Source digest và model lock digests độc lập kiểm tra nguồn/outputs và model; Restart Kernel → Run All → Save vẫn chạy độc lập.
+
+PPTX/PDF và ZIP Python cũ giữ nguyên previous version. Các bảng, noise và ví dụ HIGH/LOW bên dưới mô tả enhanced; không phải công thức quyết định FINAL của core. Xem [báo cáo hai mode](KET_QUA_ENDPOINT_MODES_2026_10_07.md).
+
+
 Cập nhật theo code hiện tại ngày 05/10/2026. TT2 đã bỏ Spectral Centroid theo yêu cầu của thầy. Ba main hiện không tính FFT/Centroid trong đường chạy thực nghiệm.
 
 ## Giao thức Stage1 và schema 2
 
 Mọi model, W và `endpoint_noise` được fit từ bốn TRAIN trước khi đọc TEST. Ba thuật toán dùng `schema_version=2`, `parameter_selection_set=train`, `evaluation_protocol=train_selected_reused_test`, `historical_test_exposure=true`. TEST đã được xem trong phát triển trước đây và được dùng lại để chấm; không gọi đây là holdout mới hoặc độc lập. Chạy một file (`--file`) vẫn fit TRAIN trước, không hiệu chỉnh bằng TEST.
 
 Hàm công khai [detect_regions()](../app/pipeline.py#L132) nhận `(algorithm, features, duration, params)`, không nhận LAB, nhãn hay filename; `endpoint_noise` phải được fit sẵn. [predict_and_score()](../app/pipeline.py#L174) gọi detector rồi chấm với LAB. CLI xuất metric vẫn yêu cầu WAV/LAB cùng tên.
 
@@ -197,17 +213,17 @@ Pipeline fit TRAIN trước TEST; thử mọi W nguyên **1–50** trên `phone_
 
 1. Ít file có số vùng sai hoặc MAE không xác định nhất.
 2. Nhỏ nhất mức thiệt hại tệ nhất so với W tốt nhất riêng của từng file.
 3. Nhỏ nhất MAE trung bình các file hợp lệ.
 4. Nếu vẫn hòa, giữ W đang ưu tiên từ cấu hình; nếu không có thì chọn W nhỏ nhất.
 
 “Thiệt hại” ở đây là `MAE(file,W) - min_W MAE(file,W)`, không phải một công thức ngưỡng mới.
 
-TT2 đề xuất candidate **W1** bằng TRAIN frame F1 (0.898698, không phải F1 của FINAL W20). Sau đó [fit_training_model()](../app/pipeline.py#L229) khảo sát W nguyên **1–50** trên FINAL regions của `phone_F1`, `phone_M1`, `studio_F1`, `studio_M1`: 200 dòng TRAIN. Kết quả lưu hiện tại: cả 50 W đồng tối ưu; mean FINAL MAE TRAIN **13.747165532879801 ms**. Chọn **W20** bằng `tie_preference_W=20` cố định. Đây là kết quả của TRAIN hiện tại, không phải giả định mọi dataset đều hòa. Manifest `W_selection_train` ghi `selection_set=train`, `evaluation_protocol=train_final_calibration` và tên TRAIN đã chấm.
+Trong enhanced, TT2 đề xuất candidate **W1** bằng TRAIN frame F1 (0.898698, không phải F1 của FINAL W20). Sau đó [fit_training_model()](../app/pipeline.py#L229) khảo sát W nguyên **1–50** trên FINAL regions của `phone_F1`, `phone_M1`, `studio_F1`, `studio_M1`: 200 dòng TRAIN. Kết quả enhanced lưu hiện tại: cả 50 W đồng tối ưu; mean FINAL MAE TRAIN **13.747165532879801 ms**. Chọn **W20** bằng `tie_preference_W=20` cố định. Đây là kết quả của TRAIN hiện tại, không phải giả định mọi dataset đều hòa. Manifest `W_selection_train` ghi `selection_set=train`, `evaluation_protocol=train_final_calibration` và tên TRAIN đã chấm.
 
 `candidate_frame_selected_W`, `candidate_frame_f1`, `candidate_frame_selection_scores`, `candidate_cleanup_records` chỉ mô tả bước candidate. `W`/`finalW` và manifest TRAIN mô tả lựa chọn FINAL; không gán candidate F1 cho W20. Không có W riêng theo filename. W20 không phải tối ưu duy nhất; chưa khảo sát số thực ngoài miền W nguyên 1–50.
 
 ## 6. Padding ứng viên và High/Low tạo biên cuối
 
 ### 6.1. Padding không phải endpoint cuối
 
 [pad_speech()](../algorithms/tt2_histogram.py#L112) mở rộng mask ứng viên 25 hop ở mỗi phía, tức 250 ms. Nó đọc mask gốc để padding không tự lan tiếp.
@@ -315,19 +331,19 @@ Tại thư mục gốc của dự án:
 python main_tt2.py
 python main_tt2.py --file phone_F2.wav
 python main_tt2.py --no-show
 python main_tt2.py --evaluate-all
 ```
 
 Mặc định bốn test; `--file` chọn một WAV có LAB cùng tên; `--evaluate-all` chấm tám WAV và không mở cửa sổ. Chế độ một file fit bốn TRAIN trước khi đọc file đã chọn; không nạp bốn TEST để calibration.
 
-- [Model TT2](../outputs/models/tt2.json): W train, W cuối, cấu hình histogram, noise.
-- [Bảng metric](../outputs/tables/tt2/test_metrics.csv).
-- [Khảo sát W](../outputs/tables/tt2_w_selection/sweep.csv): 200 lần chấm final regions.
-- [Diagnostic phone_F2](../outputs/diagnostics/tt2/phone_F2.json): M1/M2, TE, High/Low, candidate/final.
-- [Ảnh phone_F2](../outputs/figures/tt2/phone_F2.png).
+- [Model TT2](../outputs/endpoint_modes/enhanced/models/tt2.json): W train, W cuối, cấu hình histogram, noise.
+- [Bảng metric](../outputs/endpoint_modes/enhanced/tables/tt2/test_metrics.csv).
+- [Khảo sát W](../outputs/endpoint_modes/enhanced/tables/tt2_w_selection/sweep.csv): 200 lần chấm final regions.
+- [Diagnostic phone_F2](../outputs/endpoint_modes/enhanced/diagnostics/tt2/phone_F2.json): M1/M2, TE, High/Low, candidate/final.
+- [Ảnh phone_F2](../outputs/endpoint_modes/enhanced/figures/tt2/phone_F2.png).
 
 ## 10. Cách giải thích ngắn và giới hạn
 
 “Em tính Energy từng khung 25 ms, tạo histogram 64 bin, làm trơn số đếm bằng tối đa 5 bin và lấy hai đỉnh đầu theo chiều năng lượng tăng. Ngưỡng là `(20*M1+M2)/21`. Bản này chỉ dùng Energy theo yêu cầu thầy. Sau khi tạo ứng viên, em dùng High/Low STE và điều kiện 200/100 ms để tạo final regions; chỉ các biên cuối mới được chấm MAE.”
 
 Energy-only nhẹ và dễ giải thích hơn, nhưng không có đặc trưng phổ để loại một số loại nhiễu. Histogram một đỉnh phải dùng fallback; hai đỉnh đầu có thể không đại diện đúng hai lớp. W20 không duy nhất trong khảo sát hiện tại. High/Low là phần cải tiến chung, còn 100 ms là tham số bổ sung; TEST có historical exposure và được dùng lại để đánh giá, nên cần trình bày giới hạn này.
diff --git a/reports/TT3_GAUSSIAN_GIAI_THICH.md b/reports/TT3_GAUSSIAN_GIAI_THICH.md
index 85331dd..86ab433 100644
--- a/reports/TT3_GAUSSIAN_GIAI_THICH.md
+++ b/reports/TT3_GAUSSIAN_GIAI_THICH.md
@@ -1,10 +1,26 @@
 # TT3 — Thống kê phân phối chuẩn Gaussian: giải thích thuật toán và code
 
+## Hai chế độ endpoint (07/10/2026)
+
+Mặc định `enhanced`: ngưỡng native tạo seed; noise TRAIN và HIGH/LOW xác nhận, giữ speech; nối gap support dưới 200 ms và lọc span dưới 100 ms. `core` giữ quyết định native và chỉ nối gap support dưới 200 ms, không lọc duration hoặc padding FINAL; LOW/HIGH là null. Gap ước lượng đúng 200 ms được giữ riêng. TT1 dùng STE ≥ T, TT2 dùng Energy > T, TT3 giữ hướng high/low của Gaussian native. Đây là hai chế độ endpoint của cùng ba thuật toán; enhanced là phần bổ sung của dự án.
+
+```powershell
+python main_tt1.py --endpoint-mode core
+python main.py --evaluate-all --compare-endpoint-modes
+```
+
+Mỗi mode fit và khóa model độc lập trên bốn TRAIN trước đọc TEST. Kết quả mới ở `outputs/endpoint_modes/core/` và `outputs/endpoint_modes/enhanced/`; bảng so sánh ở `outputs/endpoint_modes/comparison/tables/`. Model schema 3 giữ policy/digest, metric schema 2 tiếp tục `mae_ms`/`rmse_ms`. Thiếu/thừa vùng làm primary mean toàn bộ file undefined; `valid_files_*` là thống kê subset riêng. TEST có `historical_test_exposure=true`, không phải holdout độc lập. Không chọn mode tốt hơn riêng cho từng WAV.
+
+Notebook dùng `MODE="enhanced"` mặc định cho bốn TEST figure và một illustration; luôn fit/khóa `MODELS` cả hai mode trước TEST, xuất 16 dòng tám WAV/mode và bảng bốn TEST/mode. TT2 có 200 TRAIN sweep rows mỗi mode. Core plot native T; Energy TT2 được chuẩn hóa chỉ ở bước hiển thị. Source digest và model lock digests độc lập kiểm tra nguồn/outputs và model; Restart Kernel → Run All → Save vẫn chạy độc lập.
+
+PPTX/PDF và ZIP Python cũ giữ nguyên previous version. Các bảng, noise và ví dụ HIGH/LOW bên dưới mô tả enhanced; không phải công thức quyết định FINAL của core. Xem [báo cáo hai mode](KET_QUA_ENDPOINT_MODES_2026_10_07.md).
+
+
 Cập nhật theo code hiện tại ngày 06/10/2026. Tài liệu này mô tả TT3 đang chạy: thống kê trên normalized STE tuyến tính, tìm giao điểm hai mật độ Gaussian bằng phép tính đã center/scale, sau đó lấy biên bằng xử lý chung.
 
 ## Giao thức Stage1 và schema 2
 
 Mọi model, W và `endpoint_noise` được fit từ bốn TRAIN trước khi đọc TEST. Ba thuật toán dùng `schema_version=2`, `parameter_selection_set=train`, `evaluation_protocol=train_selected_reused_test`, `historical_test_exposure=true`. TEST đã được xem trong phát triển trước đây và được dùng lại để chấm; không gọi đây là holdout mới hoặc độc lập. Chạy một file (`--file`) vẫn fit TRAIN trước, không hiệu chỉnh bằng TEST.
 
 Hàm công khai [detect_regions()](../app/pipeline.py#L132) nhận `(algorithm, features, duration, params)`, không nhận LAB, nhãn hay filename; `endpoint_noise` phải được fit sẵn. [predict_and_score()](../app/pipeline.py#L174) gọi detector rồi chấm với LAB. CLI xuất metric vẫn yêu cầu WAV/LAB cùng tên.
 
@@ -198,28 +214,28 @@ T_a=0.0028777336852,\qquad T_b=-0.0021071776746
 \]
 
 Ta nằm giữa mean silence và mean speech, Tb không nằm trong miền đó, nên:
 
 \[
 \boxed{T3=0.0028777336852}
 \]
 
-[Model TT3](../outputs/models/tt3.json) lưu ngưỡng và hai nghiệm này. Không có sigma nào bị floor trên dữ liệu hiện tại.
+[Model TT3](../outputs/endpoint_modes/enhanced/models/tt3.json) lưu ngưỡng và hai nghiệm này. Không có sigma nào bị floor trên dữ liệu hiện tại.
 
 ## 6. Tạo nhãn ứng viên
 
 [predict()](../algorithms/tt3_gaussian.py#L109) xem hướng của hai mean:
 
 - Mean speech ≥ mean silence → speech nếu `z >= T3`.
 - Mean speech < mean silence → nhánh lõi dùng `z <= T3`.
 
 Dataset hiện tại dùng hướng **high**. Ví dụ z=0.001 → silence ứng viên, z=0.01 → speech ứng viên.
 
-Nhánh lõi hỗ trợ mean đảo hướng, nhưng **FINAL hysteresis chỉ hỗ trợ speech có năng lượng cao**. `fit_training_model()` từ chối TRAIN cho hướng `low`; `detect_regions()` cũng từ chối model nhập vào có hướng `low` hoặc không hợp lệ bằng `ValueError` rõ ràng. Model cũ thiếu trường direction được hiểu là `high` để giữ tương thích. Không còn tình trạng âm thầm trả zero speech do candidate `z<=T` mâu thuẫn với HIGH `z>T`.
+Gaussian native và core FINAL hỗ trợ mean đảo hướng. **Enhanced FINAL hysteresis chỉ hỗ trợ speech có năng lượng cao**. Chỉ khi `endpoint_mode="enhanced"`, `fit_training_model()` từ chối TRAIN hướng `low` và `detect_regions()` từ chối model hướng `low` hoặc không hợp lệ bằng `ValueError`; core giữ hướng high/low native. Model cũ thiếu trường direction được hiểu là `high` để giữ tương thích. Không còn tình trạng âm thầm trả zero speech do candidate `z<=T` mâu thuẫn với HIGH `z>T`.
 
 Đây là giới hạn được công bố của pipeline FINAL, không phải hỗ trợ hoàn chỉnh việc phát hiện speech năng lượng thấp hơn noise. Các hàm lõi `fit()/predict()` vẫn có thể dùng riêng cho thí nghiệm hướng đảo.
 
 Một ngưỡng không tự tạo final region: các khung có thể dao động quanh T3 và tạo nhiều đoạn nhỏ. Bước xử lý chung dưới đây làm nhiệm vụ đó.
 
 ## 7. Noise floor, High/Low và vùng nói cuối
 
 Đây là phần cải tiến dùng chung, tách khỏi việc tính ngưỡng Gaussian.
@@ -336,19 +352,19 @@ Tại thư mục gốc của dự án:
 python main_tt3.py
 python main_tt3.py --file phone_F2.wav
 python main_tt3.py --no-show
 python main_tt3.py --evaluate-all
 ```
 
 Mặc định chạy bốn test; `--file` chọn một WAV có LAB cùng tên; `--no-show` chỉ xuất file; `--evaluate-all` chấm cả tám WAV và không mở cửa sổ.
 
-- [Model TT3](../outputs/models/tt3.json): mean/std, nghiệm, sigma floor, T3, noise.
-- [Bảng metric TT3](../outputs/tables/tt3/test_metrics.csv).
-- [Ảnh phân phối train](../outputs/figures/training/gaussian_distributions.png): minh họa mật độ từ tham số đã học, không chứng minh phân phối thực đúng Gaussian.
-- [Diagnostic phone_F2](../outputs/diagnostics/tt3/phone_F2.json).
-- [Ảnh kết quả phone_F2](../outputs/figures/tt3/phone_F2.png).
+- [Model TT3](../outputs/endpoint_modes/enhanced/models/tt3.json): mean/std, nghiệm, sigma floor, T3, noise.
+- [Bảng metric TT3](../outputs/endpoint_modes/enhanced/tables/tt3/test_metrics.csv).
+- [Ảnh phân phối train](../outputs/endpoint_modes/enhanced/figures/training/gaussian_distributions.png): minh họa mật độ từ tham số đã học, không chứng minh phân phối thực đúng Gaussian.
+- [Diagnostic phone_F2](../outputs/endpoint_modes/enhanced/diagnostics/tt3/phone_F2.json).
+- [Ảnh kết quả phone_F2](../outputs/endpoint_modes/enhanced/figures/tt3/phone_F2.png).
 
 ## 11. Cách giải thích ngắn và giới hạn
 
 “Em gom normalized STE của silence và speech trên train, tự tính mean và population standard deviation. Em giả định hai lớp có mật độ Gaussian, giải phương trình hai mật độ bằng nhau và chọn nghiệm giữa hai mean. Ngưỡng tạo ứng viên; High/Low cùng điều kiện thời lượng tạo final speech regions. MAE chỉ chấm START/END của các vùng cuối.”
 
 Giới hạn cần nêu: dữ liệu STE không được kiểm định Gaussian; normalized STE bị giới hạn [0,1] còn Gaussian trải trên toàn trục thực. Code dùng equal density không xét class priors. Một ngưỡng cố định học từ train có thể nhạy khi noise hoặc cách thu thay đổi. Hysteresis là phần bổ sung chung nên kết quả cuối không thể quy hoàn toàn cho một ngưỡng T3.
diff --git a/submission/README.md b/submission/README.md
index 7bb1552..879ad3b 100644
--- a/submission/README.md
+++ b/submission/README.md
@@ -1,9 +1,21 @@
-# Gói CODE chính và artifacts trước Stage1
+# Gói CODE chính — nghiệm thu 07/10/2026
+
+[JUPYTER_NOTEBOOKS_CODE_ONLY.zip](JUPYTER_NOTEBOOKS_CODE_ONLY.zip) là gói CODE hiện hành đã được kiểm tra nguồn/bytes ngày **07/10/2026**: đúng ba notebook đã thực thi, byte trùng file ngoài ZIP, không WAV/LAB/audio/module Python/slide. Ba notebook khớp model/metric/FINAL/ngưỡng với Python ở **24/24** trường hợp trên tám WAV, lưu tổng 15 PNG. Xem [hướng dẫn notebook](../notebooks/README.md) và [bằng chứng nghiệm thu](../outputs/tables/hotfix_oct06/verification.json).
+
+Nghiệm thu hiện hành đạt **133/133 tests trong 13.862 s**, 0 regression trên 24 trường hợp; mean bốn TEST TT1/TT2/TT3 vẫn **20.00/13.75/12.50 ms**. Đợt sửa tài liệu và [khóa baseline](../outputs/tables/endpoint_modes_oct07/baseline.json) giữ số liệu này, không tái tạo notebook/ZIP. Năm trường hợp END muộn vẫn còn; không có tuyên bố cải thiện MAE.
+
+Ba model enhanced dùng giao thức TRAIN/schema 2: model/noise/W fit TRAIN trước TEST, TT2 W1–50 chấm FINAL trên bốn TRAIN (200 dòng), chọn W20 bằng tie preference 20 khi hòa. Candidate W1/F1 ≈ 0.898698 là diagnostic riêng. Metric chính là `mae_ms` / `rmse_ms`; thiếu/thừa vùng làm primary undefined. TEST đã được xem trong phát triển: `train_selected_reused_test`, `historical_test_exposure=true`; đổi protocol không tạo holdout độc lập.
+
+`THUAT_TOAN_1.zip`, `THUAT_TOAN_2.zip`, `THUAT_TOAN_3.zip` và PPTX/PDF là **previous version (trước Stage1)**, cả chín binary giữ nguyên byte, chưa đồng bộ giao thức TRAIN/schema 2. Runtime đã chạy là Python 3.14; Python 3.10 chỉ kiểm tra cú pháp. CLI chấm cần WAV/LAB cùng tên. STT nhóm/họ tên/MSSV còn placeholder. Các trạng thái branch/push ngày 05/10 dưới đây là lịch sử, không mô tả trạng thái Git hiện tại.
+
+## Lịch sử 05/10/2026
+
+Các số test, thời gian chạy và trạng thái tích hợp trong mục này là bằng chứng lịch sử Stage1/Stage4.
 
 [JUPYTER_NOTEBOOKS_CODE_ONLY.zip](JUPYTER_NOTEBOOKS_CODE_ONLY.zip) là gói CODE chính đã tái tạo và kiểm tra ngày **05/10/2026**: đúng ba notebook đã chạy, byte trùng file ngoài ZIP, không WAV/LAB/audio/module Python/slide. Xem [hướng dẫn notebook](../notebooks/README.md).
 
 Ba notebook chạy bằng ba kernel mới tại thư mục chính, khớp đầy đủ model/metric/FINAL/ngưỡng với Python ở **24/24** trường hợp trên tám WAV. TT2 có 200 dòng TRAIN, kiểm tra digest khóa model; saved outputs hợp lệ, tổng 15 PNG đã được xem trực quan. Trước đó ba notebook cũng chạy độc lập, mỗi thư mục chỉ có notebook riêng và data. Runtime thực tế **Python 3.14**; Python 3.10 mới được kiểm tra cú pháp, chưa chạy runtime.
 
 Bộ test cuối **98/98 đạt trong 22.091 s**; 24/24 trường hợp giữ nguyên so với `111ab37`, 0 regression, mean TEST 20.00/13.75/12.50 ms. SHA256 của 28 file data/Source không đổi. Xem [bảng hồi quy](../outputs/tables/all_all_dataset/regression_before_after.csv) và [kết quả hiện tại](../reports/KET_QUA_HIEN_TAI.md).
 
 `THUAT_TOAN_1.zip`, `THUAT_TOAN_2.zip`, `THUAT_TOAN_3.zip` và PPTX/PDF hiện có là **previous version (trước Stage1)**, cả chín binary giữ nguyên byte, chưa đồng bộ giao thức TRAIN/schema 2; không dùng chúng như gói nộp hiện hành. Các main Python trong dự án đã đồng bộ Stage1.
diff --git a/tests/test_decision_timing.py b/tests/test_decision_timing.py
new file mode 100644
index 0000000..b6da1da
--- /dev/null
+++ b/tests/test_decision_timing.py
@@ -0,0 +1,71 @@
+"""Independent midpoint and duration-rule oracles for diagnostic decision cells."""
+import importlib
+import unittest
+
+class DecisionTimingTests(unittest.TestCase):
+    def helper(self):
+        self.assertIsNotNone(importlib.util.find_spec('core.decision_timing'), 'Decision-cell helper is required')
+        return importlib.import_module('core.decision_timing').decision_cells
+
+    def test_midpoints_cover_audio_and_extend_unanalysed_tail(self):
+        cells = self.helper()
+        for fs, centers, middle in ((16000, [.0125,.0225,.0325], [.0175,.0275]),
+                                    (44100, [551/44100,992/44100,1433/44100], [771.5/44100,1212.5/44100])):
+            with self.subTest(fs=fs):
+                starts, ends = cells(dict(centers=centers), .049)
+                self.assertEqual(starts, [0.,*middle])
+                self.assertEqual(ends, [*middle,.049])
+                self.assertAlmostEqual(sum(e-s for s,e in zip(starts,ends)), .049)
+
+    def test_empty_one_frame_and_invalid_centers(self):
+        cells = self.helper()
+        self.assertEqual(cells(dict(centers=[]), 0.), ([],[]))
+        self.assertEqual(cells(dict(centers=[.0125]), .03), ([0.],[.03]))
+        for centers,duration in (([.02,.01],.1),([.01,.01],.1),([float('nan')],.1),([-.01],.1),([.2],.1),([.01],0.),([],float('inf'))):
+            with self.subTest(centers=centers), self.assertRaises(ValueError):
+                cells(dict(centers=centers),duration)
+
+    def test_cell_gap_190_merges_exact_200_and_210_survive(self):
+        from core.endpoints import hysteresis_regions, regions_to_mask
+        cells = self.helper()
+        for fs in (16000,44100):
+            offset = round(fs*.025)/(2*fs)-.0125
+            for gap,count in ((.19,1),(.2,2),(.21,2)):
+                # Literal midpoints yield [.1,.2] and [.2+gap,.3+gap].
+                centers = [x+offset for x in [.05,.15,.25,.15+2*gap,.45+2*gap]]
+                starts,ends = cells(dict(centers=centers), 1.)
+                values=[0.,.8,0.,.8,0.]
+                result=hysteresis_regions(values,starts,ends,1.,.1,.5,.2,0.)
+                expected=[(.1+offset,.3+2*gap+offset)] if count==1 else [(.1+offset,.2+offset),(.2+gap+offset,.3+2*gap+offset)]
+                self.assertEqual(len(result),count)
+                for pair,want in zip(result,expected):
+                    for x,y in zip(pair,want):self.assertAlmostEqual(x,y)
+                self.assertEqual(regions_to_mask(result,starts,ends),[0,1,1,1,0] if count==1 else [0,1,0,1,0])
+
+
+
+
+class EstimatedCellSpanTests(unittest.TestCase):
+    def test_estimated_95_removed_exact_100_and_105_retained(self):
+        from core.decision_timing import decision_cells
+        from core.endpoints import hysteresis_regions
+        for span,expected in ((.095,[]),(.100,[(.1,.2)]),(.105,[(.1,.205)])):
+            centers=[.05,.15,.05+2*span,.35+2*span]
+            starts,ends=decision_cells(dict(centers=centers),.8)
+            result=hysteresis_regions([0.,.8,0.,0.],starts,ends,.8,.1,.5,.2,.1)
+            self.assertEqual(len(result),len(expected))
+            for pair,want in zip(result,expected):
+                for a,b in zip(pair,want):self.assertAlmostEqual(a,b)
+
+    def test_speech_at_edges_uses_0_duration_and_last_cell_tail(self):
+        from core.decision_timing import decision_cells
+        from core.endpoints import hysteresis_regions,regions_to_mask
+        for centers in ([.0125,.0225,.0325],[551/44100,992/44100,1433/44100]):
+            starts,ends=decision_cells(dict(centers=centers),.049)
+            for values,want_mask in (([.8,0.,0.],[1,0,0]),([0.,0.,.8],[0,0,1])):
+                result=hysteresis_regions(values,starts,ends,.049,.1,.5,.2,0.)
+                self.assertEqual(regions_to_mask(result,starts,ends),want_mask)
+                if values[0]:self.assertEqual(result[0][0],0.)
+                else:self.assertEqual(result[0][1],.049)
+
+if __name__=='__main__':unittest.main()
diff --git a/tests/test_endpoint_mode_integration.py b/tests/test_endpoint_mode_integration.py
new file mode 100644
index 0000000..7b52707
--- /dev/null
+++ b/tests/test_endpoint_mode_integration.py
@@ -0,0 +1,140 @@
+import unittest
+from app.cli import parse_args
+from app.pipeline import summarize
+from tools import build_notebooks as builder
+
+class EndpointModeIntegrationTests(unittest.TestCase):
+    def test_cli_modes(self):
+        self.assertEqual(parse_args([]).endpoint_mode, 'enhanced')
+        self.assertTrue(parse_args(['--compare-endpoint-modes']).compare_endpoint_modes)
+        self.assertEqual(parse_args(['--endpoint-mode','core']).endpoint_mode, 'core')
+
+    def test_summary_groups_modes_and_keeps_primary_undefined(self):
+        common=dict(algorithm='tt1',file='a',frame_f1=1.,ground_truth_region_count=1,predicted_region_count=1,mae_ms=2.,rmse_ms=2.)
+        rows=[dict(common,endpoint_mode='enhanced'),dict(common,endpoint_mode='core'),dict(common,file='b',endpoint_mode='core',predicted_region_count=2,mae_ms=None,rmse_ms=None)]
+        summary=summarize(rows)
+        self.assertEqual(len(summary),2)
+        core=next(row for row in summary if row['endpoint_mode']=='core')
+        self.assertIsNone(core['mean_file_mae_ms'])
+        self.assertEqual(core['valid_files_mean_file_mae_ms'],2.)
+        malformed=summarize([dict(common,endpoint_mode='core',predicted_region_count=2)])[0]
+        self.assertIsNone(malformed['mean_file_mae_ms'])
+
+    def test_notebook_locks_both_modes(self):
+        self.assertIn('MODELS',builder.FIT_MODEL)
+        self.assertIn('MODEL_LOCK_DIGESTS',builder.LOCK_MODEL)
+        self.assertIn('ALL_RESULTS_BY_MODE',builder.EVALUATION)
+
+    def test_schema_three_requires_self_excluded_calibration_digest(self):
+        from tools import run_notebooks as runner
+        model=dict(schema_version=3, metrics_schema_version=2, parameter_selection_set='train',
+                   evaluation_protocol='train_selected_reused_test', historical_test_exposure=True,
+                   training_files=list(runner.TRAIN_NAMES), endpoint_mode='core',minimum_speech_ms=0.,
+                   minimum_silence_ms=200.,endpoint_noise=None,boundary_convention='union of active frame supports',
+                   padding_stage='excluded from core FINAL')
+        with self.assertRaisesRegex(ValueError,'calibration digest'):
+            runner.audit_model_protocol(model,runner.model_digest(model))
+
+    def test_weight_sweep_checks_declared_geometry(self):
+        from app.weight_selection import sweep_final_weights
+        model=dict(endpoint_mode='core',boundary_convention='union of active frame supports')
+        def predictor(*args):
+            return dict(metrics=dict(ground_truth_region_count=1,predicted_region_count=1,mae_ms=0.,status='ok',start_error_ms=0.,end_error_ms=0.), diagnostic=dict(endpoint_mode='core',geometry='frame centers',energy_threshold=1.,low_ste_threshold=None,high_ste_threshold=None,raw_speech_frames=1,candidate_regions=[]),final_regions=[])
+        with self.assertRaisesRegex(ValueError,'geometry|boundary_convention'):
+            sweep_final_weights([dict(name='a',split='train')],model,predictor,candidates=(1.,))
+
+    def test_core_plot_uses_native_threshold_with_nullable_low_high(self):
+        import matplotlib.pyplot as plt
+        from app.plotting import _plot_axis
+        record=dict(name='a',samples=[0.,1.,0.],sample_rate=100,duration=.03,
+                    features=dict(centers=[.01,.02],ste_norm=[.5,1.],energy=[2.,4.]))
+        result=dict(diagnostic=dict(endpoint_mode='core',native_threshold=2.,native_threshold_units='mean squared sample amplitude',
+                                    low_ste_threshold=None,high_ste_threshold=None),ground_truth_boundaries=[],predicted_boundaries=[],
+                    metrics=dict(mae_ms=None),final_regions=[])
+        fig,axis=plt.subplots()
+        try:
+            _plot_axis(axis,record,result)
+            labels=[item.get_text() for item in axis.get_legend().get_texts()]
+            self.assertTrue(any('Native T' in label for label in labels))
+            self.assertFalse(any('High STE' in label or 'Low STE' in label for label in labels))
+            self.assertIn('core',axis.get_title())
+            self.assertEqual(list(fig.axes[1].lines[-1].get_ydata()),[.5,.5])
+            self.assertIn('FINAL-region endpoint MAE',axis.get_title())
+        finally:plt.close(fig)
+
+    def test_cli_locks_every_algorithm_in_both_modes_before_test_read(self):
+        import tempfile
+        from pathlib import Path
+        from unittest.mock import patch
+        from app import pipeline
+        from tests.test_notebook_protocol import tiny_dataset
+        with tempfile.TemporaryDirectory() as temporary:
+            root=Path(temporary); tiny_dataset(root)
+            events=[]
+            real_fit,real_load=pipeline.fit_training_model,pipeline.load_audio_folder
+            def fit(algorithm,records,**kwargs):
+                result=real_fit(algorithm,records,**kwargs)
+                events.append(('fit',algorithm,kwargs['endpoint_mode']))
+                return result
+            def load(folder):
+                if folder==root/'test':
+                    self.assertEqual(set(events),{('fit',algorithm,mode) for algorithm in ('tt1','tt2','tt3') for mode in ('core','enhanced')})
+                return real_load(folder)
+            with patch.multiple(pipeline,TRAIN_DIR=root/'train',TEST_DIR=root/'test',OUTPUT_DIR=root/'outputs'), \
+                 patch.object(pipeline,'fit_training_model',side_effect=fit),patch.object(pipeline,'load_audio_folder',side_effect=load), \
+                 patch.object(pipeline,'make_file_figure',return_value=None),patch.object(pipeline,'plot_gaussian_training'):
+                pipeline.run_experiment(parse_args(['--evaluate-all','--compare-endpoint-modes']))
+            self.assertTrue((root/'outputs/endpoint_modes/comparison/tables/all_metrics.csv').is_file())
+            self.assertFalse((root/'outputs/models').exists())
+
+    def test_default_main_dispatches_once_and_demo_retains_four_test_figures(self):
+        import contextlib,io,tempfile
+        from pathlib import Path
+        from unittest.mock import patch
+        from app import cli,pipeline
+        from tests.test_notebook_protocol import tiny_dataset
+        with patch('matplotlib.use'),patch.object(pipeline,'run_experiment') as run:
+            cli.main([])
+            run.assert_called_once()
+            self.assertEqual(run.call_args.args[0].endpoint_mode,'enhanced')
+        with tempfile.TemporaryDirectory() as temporary:
+            root=Path(temporary);tiny_dataset(root)
+            with patch.multiple(pipeline,TRAIN_DIR=root/'train',TEST_DIR=root/'test',OUTPUT_DIR=root/'outputs'), \
+                 patch.object(pipeline,'make_file_figure',return_value=None),patch.object(pipeline,'plot_gaussian_training'), \
+                 patch.object(pipeline,'show_figures',return_value=[]) as show,contextlib.redirect_stdout(io.StringIO()):
+                pipeline.run_experiment(parse_args([]))
+            show.assert_called_once()
+            self.assertEqual(len(show.call_args.args[0]),4)
+
+    def test_fixed_algorithm_all_dataset_preserves_shared_all_benchmarks(self):
+        import contextlib,csv,io,tempfile
+        from pathlib import Path
+        from unittest.mock import patch
+        from app import pipeline
+        from tests.test_notebook_protocol import tiny_dataset
+        with tempfile.TemporaryDirectory() as temporary:
+            root=Path(temporary);tiny_dataset(root)
+            with patch.multiple(pipeline,TRAIN_DIR=root/'train',TEST_DIR=root/'test',OUTPUT_DIR=root/'outputs'), \
+                 patch.object(pipeline,'make_file_figure',return_value=None),patch.object(pipeline,'plot_gaussian_training'), \
+                 contextlib.redirect_stdout(io.StringIO()):
+                pipeline.run_experiment(parse_args(['--evaluate-all','--compare-endpoint-modes']))
+                sentinels={}
+                for mode in ('core','enhanced'):
+                    target=root/'outputs/endpoint_modes'/mode/'tables/all'
+                    for name in ('test_metrics.csv','summary.csv'):
+                        path=target/name;sentinels[path]=path.read_bytes()
+                for algorithm in ('tt1','tt2','tt3'):
+                    pipeline.run_experiment(parse_args(['--evaluate-all','--compare-endpoint-modes'],fixed_algorithm=algorithm))
+                    for path,original in sentinels.items():
+                        self.assertEqual(path.read_bytes(),original, f'{algorithm} must preserve {path.name} shared benchmark')
+                    for mode in ('core','enhanced'):
+                        path=root/'outputs/endpoint_modes'/mode/'tables'/f'{algorithm}_all_dataset'/'test_metrics.csv'
+                        with path.open(encoding='utf-8-sig') as handle:rows=list(csv.DictReader(handle))
+                        self.assertEqual(len(rows),8)
+                        self.assertEqual({row['algorithm'] for row in rows},{algorithm})
+
+    def test_histogram_metadata_names_mean_squared_energy(self):
+        from app import pipeline
+        features=dict(ste_norm=[0.,.5,1.],energy=[0.,2.,4.],starts=[0.,.01,.02],ends=[.025,.035,.045])
+        _,diagnostic=pipeline.algorithm_decision('tt2',features,dict(bins=1,smooth_radius=0,W=5.,padding_frames=25))
+        self.assertEqual(diagnostic['native_threshold_units'],'mean squared sample amplitude')
diff --git a/tests/test_endpoint_modes.py b/tests/test_endpoint_modes.py
new file mode 100644
index 0000000..00f4079
--- /dev/null
+++ b/tests/test_endpoint_modes.py
@@ -0,0 +1,113 @@
+"""Native inequalities and policy behavior, with hand-derived support fixtures."""
+import copy
+import unittest
+
+from app import pipeline
+from core.features import compute_features
+
+
+NOISE = dict(noise_q95=.01, noise_upper=.03, high_multiplier=1.5)
+
+
+def features(values, starts=None, ends=None):
+    starts = starts if starts is not None else [i*.01 for i in range(len(values))]
+    ends = ends if ends is not None else [s+.025 for s in starts]
+    return dict(ste_norm=list(values), energy=[v*100 for v in values], starts=starts, ends=ends)
+
+
+class EndpointModesTests(unittest.TestCase):
+    def decision(self, algorithm, f, params):
+        self.assertTrue(callable(getattr(pipeline, 'algorithm_decision', None)),
+                        'Native classifier API must exist without endpoint policy dependencies')
+        return pipeline.algorithm_decision(algorithm, f, params)
+
+    def test_native_tt1_and_tt3_include_equality_and_support_low_direction(self):
+        # Changing >= / <= to strict comparisons loses the equality frame.
+        for a, direction, want in (('tt1','high',[0,1,1]), ('tt3','high',[0,1,1]),
+                                   ('tt3','low',[1,1,0])):
+            with self.subTest(algorithm=a, direction=direction):
+                mask, d = self.decision(a, dict(ste_norm=[.2,.5,.8]),
+                                        dict(threshold=.5,speech_direction=direction))
+                self.assertEqual(mask, want)
+                self.assertEqual(d['native_threshold'], .5)
+                self.assertEqual(d['native_threshold_units'], 'normalized STE')
+
+    def test_tt2_native_energy_is_strict_and_excludes_candidate_padding(self):
+        mask, d = self.decision('tt2', dict(energy=[0.,2.,4.]),
+                               dict(bins=1,smooth_radius=0,W=5.,padding_frames=25))
+        self.assertEqual(mask, [0,0,1])  # one peak -> midpoint 2, equality is silence
+        self.assertEqual(d['native_threshold'], 2.)
+        self.assertEqual(d['native_threshold_units'], 'mean squared sample amplitude')
+
+    def test_context_native_decision_uses_normalized_ste(self):
+        mask, d = self.decision('tt2-context', dict(ste_norm=[0.,.5,1.]),
+                               dict(variant='context',bins=1,smooth_radius=0,W=5.))
+        self.assertEqual(mask, [0,0,1])
+        self.assertEqual(d['native_threshold_units'], 'normalized STE')
+
+    def test_core_support_gap_threshold_keeps_exact_200ms(self):
+        # Wrong gap comparator or using frame count would merge the 200ms case.
+        for gap, want in ((.19,[(.1,.605)]),(.2,[(.1,.325),(.525,.615)]),
+                          (.21,[(.1,.325),(.535,.625)]),(.25,[(.1,.325),(.575,.665)])):
+            with self.subTest(gap=gap):
+                right=.325+gap
+                f=features([0,1,0,1,0], [0,.1,.35,right,.8], [.025,.325,.375,right+.09,.825])
+                before=copy.deepcopy(f)
+                r=pipeline.detect_regions('tt1',f,.825,dict(threshold=.5,endpoint_mode='core'))
+                self.assertEqual(len(r['final_regions']),len(want))
+                for actual,expected in zip(r['final_regions'],want):
+                    for x,y in zip(actual,expected): self.assertAlmostEqual(x,y)
+                self.assertEqual(f,before)
+
+    def test_core_retains_80ms_support_without_noise_and_labels_metadata(self):
+        f=features([0,1,0],[0,.1,.3],[.025,.18,.325])
+        params=dict(threshold=.5,endpoint_mode='core')
+        before=copy.deepcopy(params)
+        r=pipeline.detect_regions('tt1',f,.325,params)
+        self.assertEqual(r['final_regions'],[(.1,.18)])
+        self.assertEqual(r['predicted_boundaries'],[.1,.18])
+        for key in ('low_ste_threshold','high_ste_threshold','endpoint_noise'):
+            self.assertIsNone(r['diagnostic'][key])
+        self.assertEqual(r['diagnostic']['endpoint_mode'],'core')
+        self.assertEqual(r['diagnostic']['minimum_speech_ms'],0.)
+        self.assertEqual(r['diagnostic']['final_padding_ms'],0.)
+        self.assertEqual(params,before)
+        enhanced=pipeline.detect_regions('tt1',f,.325,dict(params,endpoint_mode='enhanced',endpoint_noise=NOISE))
+        self.assertEqual(enhanced['final_regions'],[])
+
+    def test_core_low_gaussian_keeps_native_inequality(self):
+        r=pipeline.detect_regions('tt3', features([.8,.5,.2,.8]), .055,
+                                  dict(threshold=.5,speech_direction='low',endpoint_mode='core'))
+        self.assertEqual(r['final_regions'],[(.01,.045)])
+
+    def test_unknown_mode_and_gaussian_direction_are_rejected(self):
+        f=features([0.,1.])
+        with self.assertRaisesRegex(ValueError,'endpoint_mode'):
+            pipeline.detect_regions('tt1',f,.035,dict(threshold=.5,endpoint_mode='typo',endpoint_noise=NOISE))
+        for mode,direction in (('core','unknown'),('enhanced','unknown'),('enhanced','low')):
+            with self.subTest(mode=mode,direction=direction), self.assertRaisesRegex(ValueError,'direction'):
+                pipeline.detect_regions('tt3',f,.035,dict(threshold=.5,endpoint_mode=mode,
+                    speech_direction=direction,endpoint_noise=NOISE))
+
+    def test_legacy_mode_resolves_enhanced_and_noise_remains_required(self):
+        f=features([0.]*10+[1.]*20+[0.]*30)
+        p=dict(threshold=.5,endpoint_noise=NOISE)
+        self.assertEqual(pipeline.detect_regions('tt1',f,.615,p),
+                         pipeline.detect_regions('tt1',f,.615,dict(p,endpoint_mode='enhanced')))
+        with self.assertRaisesRegex(ValueError,'endpoint_noise'):
+            pipeline.detect_regions('tt1',f,.615,dict(threshold=.5))
+
+    def test_valid_train_models_do_not_detect_zero_waveform_or_empty_features(self):
+        train=[dict(features=dict(ste_norm=[.001,.002,.7,.9],energy=[.1,.2,70.,90.]), labels=[0,0,1,1])]
+        models={'tt1':pipeline.tt1.fit(train), 'tt3':pipeline.tt3.fit(train),
+                'tt2':dict(bins=64,smooth_radius=2,W=20.,padding_frames=25)}
+        for fs in (16000,44100):
+            f=compute_features([0.]*round(fs*.8),fs)
+            for a,p in models.items():
+                with self.subTest(fs=fs,algorithm=a):
+                    self.assertEqual(pipeline.detect_regions(a,f,.8,dict(p,endpoint_mode='core'))['final_regions'],[])
+                    self.assertEqual(pipeline.detect_regions(a,features([]),0.,dict(p,endpoint_mode='core'))['final_regions'],[])
+
+
+if __name__ == '__main__':
+    unittest.main()
diff --git a/tests/test_endpoint_robustness.py b/tests/test_endpoint_robustness.py
index 367b686..6fac93c 100644
--- a/tests/test_endpoint_robustness.py
+++ b/tests/test_endpoint_robustness.py
@@ -248,10 +248,104 @@ class DiagnosticToolTests(unittest.TestCase):
         self.assertEqual(len(payload['ablation']), 48)
         writer.assert_called_once()
         self.assertEqual(payload['manifest']['parameter_selection_set'], 'train')
         self.assertTrue(payload['manifest']['historical_test_exposure'])
         self.assertEqual(payload['manifest']['training_files'], [r['name'] for r in records])
         self.assertEqual(models['tt2']['W'], 20.)
 
 
+
+
+class TimingResearchTests(unittest.TestCase):
+    def setUp(self):
+        self.tool=importlib.import_module('tools.check_endpoint_robustness')
+
+    def test_cells_branch_scores_cell_membership_and_audio_edges(self):
+        self.assertTrue(hasattr(self.tool,'timing_predictor'), 'Shared research predictor required')
+        f=dict(centers=[.0125,.0225,.0325],starts=[0.,.01,.02],ends=[.025,.035,.045],ste_norm=[1.,0.,1.])
+        record=dict(name='edge',split='train',features=f,duration=.05,labels=[1,1,1],intervals=[(0.,.05,'v')])
+        params=dict(endpoint_mode='core',threshold=.5,geometry='cells',minimum_speech_ms=0.)
+        result=self.tool.timing_predictor('tt1',record,params)
+        self.assertEqual(result['final_regions'],[(0.,.05)])
+        self.assertEqual(result['mask'],[1,1,1])
+        self.assertEqual(result['metrics']['mae_ms'],0.)
+
+    def test_trial_matrix_is_bounded_one_factor_and_rejects_nontrain(self):
+        self.assertTrue(hasattr(self.tool,'TIMING_TRIALS'), 'Declared matrix required')
+        trials=self.tool.TIMING_TRIALS
+        self.assertEqual(len(trials),7)
+        self.assertEqual(sum(len(t['algorithms']) for t in trials)*4,76)
+        self.assertNotIn(('cells',0.,'enhanced'),{(t['geometry'],t['minimum_speech_ms'],t['endpoint_mode']) for t in trials})
+        with self.assertRaisesRegex(ValueError,'TRAIN'):
+            self.tool.timing_training_study([dict(split='test')])
+
+    def test_t1_zero_is_explicitly_unsupported_without_floor(self):
+        self.assertTrue(hasattr(self.tool,'timing_predictor'))
+        f=dict(centers=[.0125],starts=[0.],ends=[.025],ste_norm=[1.])
+        record=dict(name='zero',split='train',features=f,duration=.03,labels=[1],intervals=[(0.,.03,'v')])
+        params=dict(endpoint_mode='enhanced',threshold=0.,geometry='support',minimum_speech_ms=100.,low_rule='T1',
+                    endpoint_noise=dict(noise_upper=.03))
+        with self.assertRaisesRegex(ValueError,'unsupported LOW=T1'):
+            self.tool.timing_predictor('tt1',record,params)
+
+class TimingFoldIntegrationTests(unittest.TestCase):
+    def test_real_train_folds_budget_locked_geometry_and_full_undefined_scores(self):
+        tool=importlib.import_module('tools.check_endpoint_robustness')
+        records=prepare_records(load_audio_folder(TRAIN_DIR))
+        before=copy.deepcopy(records)
+        with redirect_stdout(io.StringIO()):payload=tool.timing_training_study(records)
+        self.assertEqual(records,before)
+        self.assertEqual(len(payload['heldout']),76)
+        self.assertEqual(len(payload['sweep']),3600)
+        self.assertEqual(len(payload['models']),76)
+        for entry in payload['models']:
+            self.assertEqual(len(entry['fit_files']),3)
+            self.assertNotIn(entry['heldout_file'],entry['fit_files'])
+            model=entry['model']
+            self.assertEqual(model['historical_test_exposure'],True)
+            self.assertEqual(model['boundary_convention'],'nearest-frame centered decision cells' if model['geometry']=='cells' else 'union of active frame supports')
+            if entry['algorithm']=='tt2':
+                chosen=model['W_selection_train']
+                self.assertEqual(chosen['candidate_W'],[float(i) for i in range(1,51)])
+                self.assertEqual(chosen['minimum_speech_ms'],model['minimum_speech_ms'])
+                self.assertEqual(chosen['boundary_convention'],model['boundary_convention'])
+                self.assertEqual(model['W'],model['finalW'])
+        for summary in payload['summary']:
+            if summary['invalid_count']:
+                self.assertIsNone(summary['mean_mae_ms'])
+                self.assertIsNone(summary['mean_file_rmse_ms'])
+        self.assertEqual(len(payload['comparisons']),52)
+
+
+
+class SyntheticBranchProvenanceTests(unittest.TestCase):
+    def test_row_hashes_resolve_to_deduplicated_actual_configs_with_native_sources(self):
+        import hashlib
+        tool=importlib.import_module('tools.check_endpoint_robustness')
+        self.assertTrue(hasattr(tool,'synthetic_branch_configs'),'Actual synthetic branch configs must be persisted')
+        digest=lambda value:hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False).encode('utf-8')).hexdigest()
+        native=[]
+        for mode in ('core','enhanced'):
+            for algorithm in ('tt1','tt2','tt3'):
+                model=dict(threshold={'tt1':.2,'tt2':.3,'tt3':.4}[algorithm],endpoint_mode=mode,calibration_digest='native-only',W_selection_train=dict(selected_W=20.))
+                if algorithm=='tt2':model['variant']='source'
+                native.append(dict(mode=mode,algorithm=algorithm,model=model,model_sha256=digest(model)))
+        before=copy.deepcopy(native)
+        configs=tool.synthetic_branch_configs(native)
+        self.assertEqual(native,before)
+        self.assertEqual(len(configs),19)
+        expected=dict(threshold=.2,endpoint_mode='enhanced',trial_id='enhanced_cells_100',geometry='cells',
+            minimum_speech_ms=100.,low_rule='native',boundary_convention='nearest-frame centered decision cells',
+            minimum_silence_ms=200.,endpoint_policy='diagnostic native/hysteresis branch; merge estimated gaps below 200 ms',padding_stage='none')
+        entry=configs[digest(expected)]
+        self.assertEqual(entry['model'],expected)
+        self.assertEqual(entry['algorithm'],'tt1')
+        self.assertEqual(entry['trial_id'],'enhanced_cells_100')
+        source=next(r for r in native if r['mode']=='enhanced' and r['algorithm']=='tt1')
+        self.assertEqual(entry['source_native_model_sha256'],source['model_sha256'])
+        for key,entry in configs.items():
+            self.assertEqual(key,digest(entry['model']))
+            self.assertEqual(entry['model_sha256'],key)
+            self.assertIn(entry['source_native_model_sha256'],[r['model_sha256'] for r in native])
+
 if __name__ == '__main__':
     unittest.main()
diff --git a/tests/test_framing.py b/tests/test_framing.py
index ec2b392..a435b2f 100644
--- a/tests/test_framing.py
+++ b/tests/test_framing.py
@@ -210,20 +210,20 @@ class PipelineMetadataTests(unittest.TestCase):
                         handle.setframerate(1000)
                         handle.writeframes(struct.pack("<100h", *samples))
                     (destination / f"{name}.lab").write_text("0 .03 sil\n.03 .07 v\n.07 .1 sil\n", encoding="utf-8")
             args = SimpleNamespace(algorithm="all", compare_context=True, snr_study=False,
                                    file=None, no_show=True, show_seconds=0)
             with patch.multiple("app.pipeline", TRAIN_DIR=train, TEST_DIR=test, OUTPUT_DIR=output), contextlib.redirect_stdout(io.StringIO()):
                 run_experiment(args)
             for name in ("tt1", "tt2", "tt3", "tt2-context"):
-                model = json.loads((output / "models" / f"{name}.json").read_text(encoding="utf-8"))
+                model = json.loads((output / "endpoint_modes" / "enhanced" / "models" / f"{name}.json").read_text(encoding="utf-8"))
                 self.assertEqual((model["frame_ms"], model["hop_ms"]), (25.0, 10.0))
                 self.assertIn("ties_to_even", model.get("sample_rounding", ""))
                 if name == 'tt2':
                     self.assertEqual(model['W'], 20., 'Equal final scores must retain the previously selected W=20')
-            config = json.loads((output / "tables" / "all_with_context" / "run_config.json").read_text(encoding="utf-8"))
+            config = json.loads((output / "endpoint_modes" / "enhanced" / "tables" / "all_with_context" / "run_config.json").read_text(encoding="utf-8"))
             self.assertEqual((config.get("frame_ms"), config.get("hop_ms")), (25.0, 10.0))
             self.assertIn("ties_to_even", config.get("sample_rounding", ""))
 
 
 if __name__ == "__main__":
     unittest.main()
diff --git a/tests/test_notebook_protocol.py b/tests/test_notebook_protocol.py
index 765dcfc..c3a02ab 100644
--- a/tests/test_notebook_protocol.py
+++ b/tests/test_notebook_protocol.py
@@ -32,16 +32,39 @@ def tiny_dataset(root):
                       for i in range(1000)]
             with wave.open(str(path), "wb") as handle:
                 handle.setparams((1, 2, 1000, 0, "NONE", "not compressed"))
                 handle.writeframes(b"".join(value.to_bytes(2, "little", signed=True) for value in values))
             path.with_suffix(".lab").write_text("0 0.2 sil\n0.2 0.65 v\n0.65 1 sil\n")
 
 
 class NotebookGenerationTests(unittest.TestCase):
+    def test_extracted_decision_helper_and_core_policy_execute_without_project_imports(self):
+        # Missing extraction or algorithm namespace mapping breaks real calls.
+        for algorithm in ('tt1', 'tt2', 'tt3'):
+            with self.subTest(algorithm=algorithm):
+                namespace = {}
+                exec(builder.CONFIG.format(algorithm=algorithm), namespace)
+                # Function defaults reference this constant in the TT2 setup cell.
+                namespace['W_CANDIDATES'] = (1., 3., 5., 10., 20.)
+                for cell in self.generated(algorithm)['cells']:
+                    if cell['cell_type'] != 'code':
+                        continue
+                    tree = ast.parse(''.join(cell['source']))
+                    tree.body = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.Import, ast.ImportFrom))]
+                    exec(compile(tree, '<extracted-definitions>', 'exec'), namespace)
+                f = dict(ste_norm=[0.,.5,1.], energy=[0.,2.,4.],
+                         starts=[0.,.01,.02], ends=[.025,.035,.045])
+                p = dict(threshold=.5,speech_direction='high',endpoint_mode='core',
+                         bins=1,smooth_radius=0,W=5.,padding_frames=25)
+                raw, _ = namespace['algorithm_decision'](algorithm,f,p)
+                self.assertEqual(raw, [0,0,1] if algorithm=='tt2' else [0,1,1])
+                r = namespace['detect_regions'](algorithm,f,.045,p)
+                self.assertEqual(r['final_regions'], [(.02,.045)] if algorithm=='tt2' else [(.01,.045)])
+
     def generated(self, algorithm):
         try:
             return builder.build_notebook(algorithm)
         except (ValueError, StopIteration) as error:
             self.fail(f"Generator must adapt current public core interfaces: {error}")
 
     def test_stage_comments_preserve_nested_numeric_ast_and_multiline_docstrings(self):
         inject = getattr(builder, 'add_stage_comments', None)
@@ -141,30 +164,34 @@ def second(value):
                             namespace["DATA_DIR"] = dataset
                             real_loader = namespace["load_dataset_folder"]
                             def guarded_loader(data_root, split):
                                 if split == "test":
                                     self.assertIn("MODEL_LOCK_DIGEST", namespace,
                                                   "TEST reads must follow TRAIN calibration and lock")
                                     self.assertEqual(namespace["MODEL_LOCK_DIGEST"],
                                                      namespace["model_digest"](namespace["MODEL"]))
+                                    self.assertEqual(set(namespace['MODELS']), {'core','enhanced'})
+                                    for mode, model in namespace['MODELS'].items():
+                                        self.assertEqual(namespace['MODEL_LOCK_DIGESTS'][mode], namespace['model_digest'](model))
                                     checked.append(split)
                                 return real_loader(data_root, split)
                             namespace["load_dataset_folder"] = guarded_loader
                         with contextlib.redirect_stdout(io.StringIO()), patch("matplotlib.pyplot.show"), \
                                 patch("IPython.display.display"):
                             exec(compile(source, "<generated-notebook>", "exec"), namespace)
                     self.assertEqual(checked, ["test"])
                     model = namespace["MODEL"]
-                    self.assertEqual(model["schema_version"], 2)
+                    self.assertEqual(model["schema_version"], 3)
                     self.assertEqual(model["parameter_selection_set"], "train")
                     self.assertEqual(model["evaluation_protocol"], "train_selected_reused_test")
                     self.assertIs(model["historical_test_exposure"], True)
                     self.assertEqual(namespace["MODEL_LOCK_DIGEST"], namespace["model_digest"](model))
                     self.assertEqual(len(namespace["DATASET_MANIFEST"]), 8)
+                    self.assertEqual(len(namespace["ALL_METRIC_ROWS"]), 16)
                     for row in namespace["ALL_METRIC_ROWS"]:
                         self.assertEqual(len(row), len({key.casefold() for key in row}))
                         self.assertNotIn("boundary_MAE_ms", row)
                         self.assertIn("tolerance_boundary_mae_ms", row)
                     if algorithm == "tt2":
                         self.assertEqual(len(namespace["TT2W_SWEEP_ROWS"]), 200)
                         self.assertEqual(model["W_selection_train"]["selection_set"], "train")
                         self.assertEqual(model["candidate_cleanup_records"]["full_pipeline_records"], 4)
@@ -178,30 +205,32 @@ def second(value):
                             patch("IPython.display.display"):
                         namespace["demo_one_file"](str(dataset / "test/phone_F2.wav"))
                     self.assertEqual(original, json.dumps(model, sort_keys=True))
                     self.audit_with_core_benchmark(namespace, root)
 
     def audit_with_core_benchmark(self, namespace, root):
         """Use tiny real core runs to catch generated metadata/scorer drift."""
         algorithm = namespace['ALGORITHM']
-        with patch.multiple(pipeline, TRAIN_DIR=root / 'data/train', TEST_DIR=root / 'data/test'):
-            train = pipeline.prepare_records(pipeline.load_audio_folder(root / 'data/train'))
-            test = pipeline.prepare_records(pipeline.load_audio_folder(root / 'data/test'))
-            model, rows = pipeline.fit_training_model(algorithm, train)
-        results = [pipeline.predict_and_score(algorithm, record, model) for record in train + test]
-        metric_rows = [dict(file=result['file'], algorithm=algorithm, **result['metrics']) for result in results]
-        pipeline.write_csv(root / 'outputs/tables/all_all_dataset/test_metrics.csv', metric_rows)
-        pipeline.write_csv(root / 'outputs/tables/all/summary.csv', pipeline.summarize(metric_rows[4:]))
-        pipeline.write_json(root / f'outputs/models/{algorithm}.json', model)
-        for result in results:
-            pipeline.write_json(root / f'outputs/diagnostics/{algorithm}/{result["file"]}.json', result['diagnostic'])
-        if algorithm == 'tt2':
-            pipeline.write_csv(root / 'outputs/tables/tt2_w_selection/sweep.csv', rows)
-            pipeline.write_json(root / 'outputs/tables/tt2_w_selection/selection.json', model['W_selection_train'])
+        for mode in ('core', 'enhanced'):
+            with patch.multiple(pipeline, TRAIN_DIR=root / 'data/train', TEST_DIR=root / 'data/test'):
+                train = pipeline.prepare_records(pipeline.load_audio_folder(root / 'data/train'))
+                model, rows = pipeline.fit_training_model(algorithm, train, endpoint_mode=mode)
+                test = pipeline.prepare_records(pipeline.load_audio_folder(root / 'data/test'))
+            results = [pipeline.predict_and_score(algorithm, record, model) for record in train + test]
+            metric_rows = [dict(file=result['file'],algorithm=algorithm,**result['metrics']) for result in results]
+            target = runner.endpoint_mode_root(mode, root / 'outputs')
+            pipeline.write_csv(target / 'tables/all_all_dataset/test_metrics.csv', metric_rows)
+            pipeline.write_csv(target / 'tables/all/summary.csv', pipeline.summarize(metric_rows[4:]))
+            pipeline.write_json(target / f'models/{algorithm}.json', model)
+            for result in results:
+                pipeline.write_json(target / f'diagnostics/{algorithm}/{result["file"]}.json', result['diagnostic'])
+            if algorithm == 'tt2':
+                pipeline.write_csv(target / 'tables/tt2_w_selection/sweep.csv', rows)
+                pipeline.write_json(target / 'tables/tt2_w_selection/selection.json', model['W_selection_train'])
         stream = io.StringIO()
         with contextlib.redirect_stdout(stream):
             exec(runner.AUDIT_CELL, namespace)
         evidence = json.loads(stream.getvalue().split(runner.AUDIT_PREFIX, 1)[1])
         with patch.object(runner, 'ROOT', root):
             self.assertIsInstance(runner.audit_results(evidence), float)
             damaged = copy.deepcopy(evidence)
             damaged['all_results'][0]['metrics']['mae_ms'] += 5
@@ -224,16 +253,36 @@ def executed_plot_notebook():
             execution_count=index, outputs=[copy.deepcopy(output)]))
     source_digest = hashlib.sha256(json.dumps([cell.source for cell in cells],
                                              ensure_ascii=False, separators=(',', ':')).encode('utf-8')).hexdigest()
     return nbformat.v4.new_notebook(cells=cells, metadata={
         'endpoint_execution': {'fixture': True, 'code_source_sha256': source_digest}})
 
 
 class NotebookAuditTests(unittest.TestCase):
+    def test_schema_three_audit_validates_mode_and_keeps_schema_two_compatible(self):
+        model = dict(schema_version=3, metrics_schema_version=2, parameter_selection_set='train',
+                     evaluation_protocol='train_selected_reused_test', historical_test_exposure=True,
+                     training_files=list(runner.TRAIN_NAMES), endpoint_mode='core',
+                     minimum_speech_ms=0., minimum_silence_ms=200., endpoint_noise=None,
+                     boundary_convention='union of active frame supports', padding_stage='excluded from core FINAL')
+        model["calibration_digest"] = hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False, allow_nan=False).encode("utf-8")).hexdigest()
+        runner.audit_model_protocol(model, runner.model_digest(model))
+        selected = dict(model, W=20., finalW=20., W_selection_train=dict(
+            endpoint_mode='enhanced', minimum_speech_ms=100., minimum_silence_ms=200.,
+            boundary_convention='union of active frame supports', padding_stage='candidate diagnostics only',
+            selected_W=20.))
+        with self.assertRaisesRegex(ValueError,'policy'):
+            runner.audit_model_protocol(selected, runner.model_digest(selected))
+        for changes in ({'endpoint_mode':'unknown'}, {'minimum_speech_ms':100.},
+                        {'endpoint_noise':{'noise_q95':.1}}, {'padding_stage':'candidate diagnostics only'}):
+            damaged = dict(model, **changes)
+            with self.subTest(changes=changes), self.assertRaisesRegex(ValueError,'policy|mode'):
+                runner.audit_model_protocol(damaged, runner.model_digest(damaged))
+
     def test_source_bound_audit_rejects_changed_code_even_when_only_a_comment_changes(self):
         notebook = executed_plot_notebook()
         notebook.cells[0].source += '\n# Added after execution.'
         with patch.object(runner, 'audit_results', return_value=10.):
             with self.assertRaisesRegex(ValueError, 'source.*rerun|rerun.*source'):
                 runner.audit_notebook(notebook, 'changed.ipynb')
 
     def test_source_bound_audit_requires_digest_and_accepts_unchanged_source(self):
diff --git a/tests/test_training_protocol.py b/tests/test_training_protocol.py
index 3088f48..0bb420a 100644
--- a/tests/test_training_protocol.py
+++ b/tests/test_training_protocol.py
@@ -21,16 +21,67 @@ def synthetic_record():
     starts = [i * .01 for i in range(80)]
     ends = [start + .025 for start in starts]
     intervals = [(0., .1, 'sil'), (.1, .515, 'v'), (.515, .82, 'sil')]
     return dict(name='array_fold', split='train', duration=.82, intervals=intervals,
                 features=dict(energy=values, ste_norm=values, starts=starts, ends=ends),
                 labels=frame_labels([(s + e) / 2 for s, e in zip(starts, ends)], intervals))
 
 
+class CurrentArtifactDocumentationTests(unittest.TestCase):
+    """Prevent current artifact labels from drifting to legacy TEST/schema 1."""
+    root = Path(__file__).resolve().parents[1]
+
+    def test_current_w_sweep_contains_train_names_and_unique_headers(self):
+        with (self.root / 'outputs/tables/tt2_w_selection/sweep.csv').open(
+                encoding='utf-8-sig', newline='') as handle:
+            reader = csv.DictReader(handle)
+            fields = reader.fieldnames
+            rows = list(reader)
+        self.assertEqual(len(rows), 200)
+        self.assertEqual({row['filename'] for row in rows},
+                         {'phone_F1', 'phone_M1', 'studio_F1', 'studio_M1'})
+        self.assertEqual(len(fields), len({key.casefold() for key in fields}))
+        self.assertIn('final_region_mae_ms', fields)
+
+    def test_current_metric_exports_have_schema_two_unique_headers(self):
+        for folder in ('all', 'all_all_dataset', 'tt1', 'tt2', 'tt3'):
+            with self.subTest(folder=folder):
+                with (self.root / 'outputs/tables' / folder / 'test_metrics.csv').open(
+                        encoding='utf-8-sig', newline='') as handle:
+                    reader = csv.DictReader(handle)
+                    fields = reader.fieldnames
+                    rows = list(reader)
+                self.assertEqual(len(fields), len({key.casefold() for key in fields}))
+                self.assertTrue({'mae_ms', 'rmse_ms', 'tolerance_boundary_mae_ms'} <= set(fields))
+                self.assertNotIn('boundary_MAE_ms', fields)
+                self.assertTrue(all(row['metrics_schema_version'] == '2' for row in rows))
+
+    def test_outputs_readme_labels_current_sweep_as_train_and_schema_two(self):
+        text = (self.root / 'outputs/README.md').read_text(encoding='utf-8')
+        sweep_line = next(line for line in text.splitlines() if '`tables/tt2_w_selection/`' in line)
+        self.assertIn('TRAIN', sweep_line)
+        self.assertNotIn('test', sweep_line.casefold())
+        self.assertIn('`mae_ms` / `rmse_ms`', text)
+        self.assertNotIn('`boundary_MAE_ms`', text)
+        self.assertNotIn('`boundary_mae_ms`', text)
+        self.assertIn('historical_test_exposure=true', text)
+
+    def test_submission_readme_separates_current_acceptance_from_oct05_history(self):
+        text = (self.root / 'submission/README.md').read_text(encoding='utf-8')
+        self.assertIn('## Lịch sử 05/10/2026', text)
+        current, history = text.split('## Lịch sử 05/10/2026', 1)
+        self.assertIn('07/10/2026', current)
+        self.assertIn('133/133', current)
+        self.assertNotIn('98/98', current)
+        self.assertIn('98/98', history)
+        self.assertIn('historical_test_exposure=true', current)
+        self.assertIn('schema 2', current)
+
+
 class DetectionContractTests(unittest.TestCase):
     def test_lab_free_detection_and_changed_lab_only_change_scoring(self):
         self.assertTrue(callable(getattr(pipeline, 'detect_regions', None)),
                         'A detector accepting features/duration/model without LAB is required')
         record = synthetic_record()
         params = dict(threshold=.1, endpoint_noise=dict(noise_q95=.02, noise_upper=.15))
         detected = pipeline.detect_regions('tt1', record['features'], record['duration'], params)
         scored = pipeline.predict_and_score('tt1', record, params)
@@ -56,17 +107,17 @@ class DetectionContractTests(unittest.TestCase):
         params = dict(threshold=.1, endpoint_noise=dict(noise_q95=.02, noise_upper=.15))
         metrics = pipeline.predict_and_score('tt1', record, params)['metrics']
         self.assertEqual(metrics.get('metrics_schema_version'), 2)
         self.assertIn('mae_ms', metrics)
         self.assertIn('rmse_ms', metrics)
         self.assertIn('matched_boundary_mae_ms', metrics)
         self.assertIn('tolerance_boundary_mae_ms', metrics)
         self.assertNotIn('boundary_MAE_ms', metrics)
-        self.assertFalse(any(key.startswith('boundary_') and not key.startswith('boundary_inside_')
+        self.assertFalse(any(key.startswith('boundary_') and key != 'boundary_convention' and not key.startswith('boundary_inside_')
                              for key in metrics))
         with tempfile.TemporaryDirectory() as folder:
             path = Path(folder) / 'metrics.csv'
             pipeline.write_csv(path, [metrics])
             with path.open(encoding='utf-8-sig', newline='') as handle:
                 fields = next(csv.reader(handle))
             self.assertEqual(len(fields), len(set(key.casefold() for key in fields)))
 
@@ -94,16 +145,53 @@ class DetectionContractTests(unittest.TestCase):
         scores = pipeline.predict_and_score('tt1', record, params)['metrics']
         summary = pipeline.summarize([dict(file='fixture', algorithm='tt1', **scores)])[0]
         self.assertEqual(summary.get('metrics_schema_version'), 2)
         self.assertEqual(summary.get('evaluation_protocol'), 'train_selected_reused_test')
         self.assertTrue(summary.get('historical_test_exposure'))
 
 
 class TrainingProtocolTests(unittest.TestCase):
+    def test_core_fit_skips_noise_calibration(self):
+        for algorithm in ('tt1', 'tt3'):
+            with self.subTest(algorithm=algorithm), patch.object(
+                    pipeline, 'fit_noise_floor', side_effect=AssertionError('core noise fit')):
+                model, rows = pipeline.fit_training_model(algorithm, [synthetic_record()], endpoint_mode='core')
+            self.assertIsNone(model['endpoint_noise'])
+            self.assertEqual(model['minimum_speech_ms'], 0)
+            self.assertEqual(model['endpoint_mode'], 'core')
+            self.assertEqual(rows, [])
+
+    def test_core_accepts_speech_low_gaussian_but_enhanced_rejects_it(self):
+        record = synthetic_record()
+        record['features']['ste_norm'] = [1. - value for value in record['features']['ste_norm']]
+        model, _ = pipeline.fit_training_model('tt3', [record], endpoint_mode='core')
+        self.assertEqual(model['speech_direction'], 'low')
+        result = pipeline.predict_and_score('tt3', record, model)
+        self.assertEqual(result['final_regions'], [(.1, .515)])
+        with self.assertRaisesRegex(ValueError, 'speech_direction'):
+            pipeline.fit_training_model('tt3', [record], endpoint_mode='enhanced')
+
+    def test_both_policies_sweep_final_train_regions_and_export_null_thresholds(self):
+        for mode in ('core', 'enhanced'):
+            with self.subTest(mode=mode):
+                model, rows = pipeline.fit_training_model('tt2', self.training, endpoint_mode=mode)
+                selection = model['W_selection_train']
+                self.assertEqual(len(rows), 200)
+                self.assertEqual(selection['endpoint_mode'], mode)
+                self.assertEqual(model['W'], selection['selected_W'])
+                self.assertEqual(len(model['calibration_digest']), 64)
+                self.assertTrue(all(row['endpoint_mode'] == mode for row in rows))
+                if mode == 'core':
+                    self.assertTrue(all(row['low_ste_threshold'] is None and
+                                        row['high_ste_threshold'] is None for row in rows))
+                    with tempfile.TemporaryDirectory() as folder:
+                        pipeline.write_csv(Path(folder) / 'sweep.csv', rows)
+                        pipeline.write_json(Path(folder) / 'selection.json', selection)
+
     @classmethod
     def setUpClass(cls):
         cls.training = pipeline.prepare_records(pipeline.load_audio_folder(TRAIN_DIR))
 
     def require_fit(self):
         self.assertTrue(callable(getattr(pipeline, 'fit_training_model', None)),
                         'Models must be calibrated and locked from TRAIN before TEST reads')
 
@@ -131,17 +219,17 @@ class TrainingProtocolTests(unittest.TestCase):
         self.assertEqual(model['W'], selection['selected_W'])
         self.assertEqual(model['finalW'], model['W'])
         self.assertEqual(model['candidate_frame_selected_W'], proposal['W'])
         self.assertEqual(model['candidate_frame_f1'], proposal['train_frame_f1'])
         self.assertEqual(model['candidate_cleanup_records']['full_pipeline_records'], 4)
         self.assertNotIn('train_frame_f1', model)
         self.assertNotIn('selection_scores', model)
         self.assertNotIn('W_selection_test', model)
-        self.assertEqual(model['schema_version'], 2)
+        self.assertEqual(model['schema_version'], 3)
         self.assertEqual(model['metrics_schema_version'], 2)
         self.assertEqual(model['parameter_selection_set'], 'train')
         self.assertEqual(model['evaluation_protocol'], 'train_selected_reused_test')
         self.assertTrue(model['historical_test_exposure'])
         self.assertTrue(all('final_region_mae_ms' in row and 'boundary_MAE_ms' not in row for row in rows))
         self.assertEqual(before, json.dumps(self.training, sort_keys=True))
 
     def test_fit_rejects_test_external_and_spoofed_test_path_but_accepts_array_fold(self):
@@ -153,36 +241,41 @@ class TrainingProtocolTests(unittest.TestCase):
         with self.assertRaisesRegex(ValueError, 'TRAIN|train'):
             pipeline.fit_training_model('tt1', [dict(synthetic_record(), wav_path=str(TEST_DIR / 'phone_F2.wav'))])
         model, rows = pipeline.fit_training_model('tt1', [synthetic_record()])
         self.assertEqual(rows, [])
         self.assertEqual(model['training_files'], ['array_fold'])
 
     def test_changed_test_lab_does_not_affect_model_noise_or_weight(self):
         self.require_fit()
-        model, _ = pipeline.fit_training_model('tt2', self.training)
         record = pipeline.prepare_records(pipeline.load_audio_folder(TEST_DIR))[0]
-        before = json.dumps(model, sort_keys=True)
-        first = pipeline.predict_and_score('tt2', record, model)
         modified = dict(record, intervals=[(0., record['duration'], 'sil')], labels=[0] * len(record['labels']))
-        second = pipeline.predict_and_score('tt2', modified, model)
-        self.assertEqual(first['final_regions'], second['final_regions'])
-        self.assertNotEqual(first['metrics']['mae_ms'], second['metrics']['mae_ms'])
-        self.assertEqual(before, json.dumps(model, sort_keys=True))
+        for mode in ('core', 'enhanced'):
+            with self.subTest(mode=mode):
+                model, _ = pipeline.fit_training_model('tt2', self.training, endpoint_mode=mode)
+                before = json.dumps(model, sort_keys=True)
+                first = pipeline.predict_and_score('tt2', record, model)
+                second = pipeline.predict_and_score('tt2', modified, model)
+                self.assertEqual(first['final_regions'], second['final_regions'])
+                self.assertEqual(first['mask'], second['mask'])
+                self.assertEqual(first['diagnostic'], second['diagnostic'])
+                self.assertNotEqual(first['metrics']['ground_truth_region_count'],
+                                    second['metrics']['ground_truth_region_count'])
+                self.assertEqual(before, json.dumps(model, sort_keys=True))
 
     def test_single_file_fits_before_target_read_and_never_reloads_all_test(self):
         # Keep the real fits/scorers; suppress only artifacts and graphics.
         args = parse_args(['--algorithm', 'all', '--file', 'phone_F2.wav', '--no-show'])
         real_loader = pipeline.load_audio_file
         real_folder = pipeline.load_audio_folder
         lock = []
         self.require_fit()
         real_fit = pipeline.fit_training_model
-        def fit(algorithm, records):
-            value = real_fit(algorithm, records)
+        def fit(algorithm, records, **kwargs):
+            value = real_fit(algorithm, records, **kwargs)
             lock.append(algorithm)
             return value
         def load_file(path):
             if Path(path).parent == TEST_DIR:
                 self.assertEqual(set(lock), {'tt1', 'tt2', 'tt3'}, 'All models fit before TEST WAV/LAB read')
             return real_loader(path)
         def load_folder(folder):
             self.assertNotEqual(Path(folder), TEST_DIR, 'A single-file demo must not reload 4 TEST records')
@@ -191,22 +284,22 @@ class TrainingProtocolTests(unittest.TestCase):
                 patch.object(pipeline, 'OUTPUT_DIR', Path(folder)), \
                 patch.object(pipeline, 'load_audio_file', side_effect=load_file), \
                 patch.object(pipeline, 'load_audio_folder', side_effect=load_folder), \
                 patch.object(pipeline, 'fit_training_model', side_effect=fit), \
                 patch.object(pipeline, 'make_file_figure', return_value=None), \
                 patch.object(pipeline, 'plot_gaussian_training'), \
                 patch.object(pipeline, 'plt'), contextlib.redirect_stdout(io.StringIO()):
             pipeline.run_experiment(args)
-            config = json.loads((Path(folder) / 'tables/all/single/phone_F2/run_config.json').read_text())
+            config = json.loads((Path(folder) / 'endpoint_modes/enhanced/tables/all/single/phone_F2/run_config.json').read_text())
             self.assertEqual(config['metrics_schema_version'], 2)
             self.assertEqual(config['parameter_selection_set'], 'train')
             self.assertEqual(config['evaluation_protocol'], 'train_selected_reused_test')
             self.assertTrue(config['historical_test_exposure'])
             self.assertEqual(config['evaluated_files'], ['phone_F2'])
-            with (Path(folder) / 'tables/all/single/phone_F2/test_metrics.csv').open(encoding='utf-8-sig', newline='') as handle:
+            with (Path(folder) / 'endpoint_modes/enhanced/tables/all/single/phone_F2/test_metrics.csv').open(encoding='utf-8-sig', newline='') as handle:
                 fields = next(csv.reader(handle))
             self.assertNotIn('boundary_MAE_ms', fields)
             self.assertEqual(len(fields), len(set(key.casefold() for key in fields)))
 
 
 if __name__ == '__main__':
     unittest.main()
diff --git a/tests/test_weight_selection.py b/tests/test_weight_selection.py
index bb8439d..b23e3fd 100644
--- a/tests/test_weight_selection.py
+++ b/tests/test_weight_selection.py
@@ -3,16 +3,28 @@ import unittest
 from app import pipeline
 from app.config import TRAIN_DIR
 
 def row(weight,name,error,gt=1,pred=1):
     return dict(W=weight,filename=name,final_region_mae_ms=error,
                 ground_truth_region_count=gt,predicted_region_count=pred)
 
 class FinalWeightSelectionTests(unittest.TestCase):
+    def test_mixed_endpoint_policies_cannot_select_one_shared_weight(self):
+        rows=[dict(row(1,'a',1),endpoint_mode='core'),
+              dict(row(20,'a',0),endpoint_mode='enhanced')]
+        with self.assertRaisesRegex(ValueError,'policy'):
+            self.select(rows)
+
+    def test_primary_mean_is_undefined_with_one_invalid_count(self):
+        result=self.select([row(1,'a',None,pred=2),row(1,'b',10)])
+        self.assertIsNone(result['selected_summary']['mean_MAE_ms'])
+        self.assertEqual(result['selected_summary']['invalid_files'],1)
+        self.assertEqual(result['selected_summary']['valid_files_mean_MAE_ms'],10)
+
     def select(self,rows,tie_preference=20):
         return pipeline.select_final_weight(rows,tie_preference)
 
     def test_all_four_optimal_uses_declared_tie_preference(self):
         rows=[row(w,n,e) for w in (1,5,20) for n,e in [('a',32.5),('b',7.5),('c',7.5),('d',7.5)]]
         result=self.select(rows)
         self.assertEqual(result['selected_W'],20)
         self.assertEqual(result['shared_optimal_W'],[1,5,20])
diff --git a/tools/README.md b/tools/README.md
index 35735df..aaab37a 100644
--- a/tools/README.md
+++ b/tools/README.md
@@ -1,10 +1,26 @@
 # Công cụ tạo lại artifacts
 
+## Hai chế độ endpoint (07/10/2026)
+
+Mặc định `enhanced`: ngưỡng native tạo seed; noise TRAIN và HIGH/LOW xác nhận, giữ speech; nối gap support dưới 200 ms và lọc span dưới 100 ms. `core` giữ quyết định native và chỉ nối gap support dưới 200 ms, không lọc duration hoặc padding FINAL; LOW/HIGH là null. Gap ước lượng đúng 200 ms được giữ riêng. TT1 dùng STE ≥ T, TT2 dùng Energy > T, TT3 giữ hướng high/low của Gaussian native. Đây là hai chế độ endpoint của cùng ba thuật toán; enhanced là phần bổ sung của dự án.
+
+```powershell
+python main_tt1.py --endpoint-mode core
+python main.py --evaluate-all --compare-endpoint-modes
+```
+
+Mỗi mode fit và khóa model độc lập trên bốn TRAIN trước đọc TEST. Kết quả mới ở `outputs/endpoint_modes/core/` và `outputs/endpoint_modes/enhanced/`; bảng so sánh ở `outputs/endpoint_modes/comparison/tables/`. Model schema 3 giữ policy/digest, metric schema 2 tiếp tục `mae_ms`/`rmse_ms`. Thiếu/thừa vùng làm primary mean toàn bộ file undefined; `valid_files_*` là thống kê subset riêng. TEST có `historical_test_exposure=true`, không phải holdout độc lập. Không chọn mode tốt hơn riêng cho từng WAV.
+
+Notebook dùng `MODE="enhanced"` mặc định cho bốn TEST figure và một illustration; luôn fit/khóa `MODELS` cả hai mode trước TEST, xuất 16 dòng tám WAV/mode và bảng bốn TEST/mode. TT2 có 200 TRAIN sweep rows mỗi mode. Core plot native T; Energy TT2 được chuẩn hóa chỉ ở bước hiển thị. Source digest và model lock digests độc lập kiểm tra nguồn/outputs và model; Restart Kernel → Run All → Save vẫn chạy độc lập.
+
+PPTX/PDF và ZIP Python cũ giữ nguyên previous version. Các bảng, noise và ví dụ HIGH/LOW bên dưới mô tả enhanced; không phải công thức quyết định FINAL của core. Xem [báo cáo hai mode](../reports/KET_QUA_ENDPOINT_MODES_2026_10_07.md).
+
+
 Các main chạy bài tập không phụ thuộc thư mục này. Công cụ này giúp cập nhật slide và ZIP sau khi có kết quả mới hoặc bổ sung họ tên/MSSV.
 
 ## Mã nguồn Jupyter Notebook
 
 Các lệnh dưới đây dành cho người bảo trì dự án làm mới evidence và gói CODE ZIP đã audit. Notebook độc lập vẫn chạy bằng **Restart Kernel and Run All**, rồi **Save**, không cần module dự án hay builder/runner; yêu cầu runner chỉ thuộc audit/đóng gói của dự án.
 
 ```powershell
 .\.venv\Scripts\python.exe tools/build_notebooks.py
diff --git a/tools/build_notebooks.py b/tools/build_notebooks.py
index 99699c5..6dd7de4 100644
--- a/tools/build_notebooks.py
+++ b/tools/build_notebooks.py
@@ -101,49 +101,49 @@ TT2_STAGE_COMMENTS = {
         ('@return', 'Return proposal diagnostics; downstream TRAIN FINAL-region calibration selects the reusable W.')],
 }
 
 
 def pipeline_stage_comments(algorithm: str) -> dict:
     decisions = {
         'tt1': 'TT1 compares normalized STE with the TRAIN binary-search threshold.',
         'tt2': 'TT2 estimates raw energy threshold per file; padded masks remain candidate diagnostics.',
-        'tt3': 'TT3 raw classification supports both directions; FINAL rejects explicit low/unknown models.'}
+        'tt3': 'TT3 raw classification supports both directions; enhanced FINAL rejects low/unknown models; core retains native high/low direction.'}
     comments = {
         'detect_regions': [
             ('@input', 'Input: frame features/supports, duration and fitted model; Output: FINAL regions, mask and diagnostics.'),
-            ('noise', decisions[algorithm] + ' Require TRAIN noise before inference.'),
+            ('noise', decisions[algorithm] + ' Enhanced requires TRAIN noise; core uses native decisions.'),
             ('candidate_regions', 'Retain candidate supports for inspection; only FINAL regions produce endpoint scores.'),
             ('base_threshold', 'Use the TRAIN normalized STE threshold and raw classifier seed.'
              if algorithm != 'tt2' else 'Normalize TT2 raw energy threshold and seed from unpadded raw energy decisions.'),
             ('low', 'Derive LOW/HIGH from the threshold and TRAIN silence noise statistics.'),
-            ('final_regions', 'Confirm with HIGH and continue above LOW; merge estimated support gaps below 200 ms.'),
-            ('@return', 'The 100 ms support-span filter is a heuristic; support bounds do not guarantee physical silence.')],
+            ('high', 'Confirm with HIGH and continue above LOW; merge estimated support gaps below 200 ms.'),
+            ('mode', 'The enhanced 100 ms support-span filter is a heuristic; core keeps native speech supports.')],
         'predict_and_score': [
             ('detected', 'Detect without LAB first; consult reference regions only after FINAL detection returns.'),
             ('region_scores', 'Score complete FINAL regions in time order; missing/extra regions leave primary MAE undefined.'),
             ('flags', 'Report missing/extra regions and large errors instead of hiding them in matched-only metrics.'),
             ('boundary', 'Inspect endpoint positions against audio bounds and reference silence for diagnostics.'),
             ('frames', 'Compute frame and tolerance-based event diagnostics separately from complete-region MAE.'),
             ('legacy_test_tuned', 'Retain provenance for imported historical models; fresh fits record TRAIN selection.'),
             ('@return', 'Output: FINAL detection, reference regions, scores, status and original detector diagnostics.')],
         'fit_training_model': [
             ('@input', 'Validate supplied TRAIN provenance before fitting; TEST reads occur after model locking.'),
             ('model', {'tt1': 'Fit the normalized STE binary-search threshold from labeled TRAIN frames.',
                        'tt2': 'Fit the candidate-frame histogram W proposal from TRAIN only.',
-                       'tt3': 'Fit robust centered/scaled Gaussian crossings; reject a non-high model before FINAL reuse.'}[algorithm])],
+                       'tt3': 'Fit robust centered/scaled Gaussian crossings; enhanced rejects non-high models; core preserves native direction.'}[algorithm])],
     }
     if algorithm == 'tt2':
         comments['fit_training_model'].extend([
-            ('candidate_frame_selected_W', 'Preserve candidate F1 diagnostics beside schema-v2 TRAIN noise and provenance.'),
+            ('candidate_frame_selected_W', 'Preserve candidate F1 diagnostics beside schema-v3 mode policy, enhanced TRAIN noise and provenance.'),
             ('selection', 'Calibrate shared W on TRAIN FINAL regions; candidate F1 remains a separate diagnostic.'),
             ('@return', 'Return the TRAIN-selected reusable model and all 200 W/file calibration rows.')])
     else:
         comments['fit_training_model'].append(
-            ('sweep_rows', 'Output: schema-v2 model with TRAIN silence noise and provenance; no W sweep for this method.'))
+            ('sweep_rows', 'Output: schema-v3 model with mode policy and TRAIN provenance; no W sweep for this method.'))
     return comments
 
 
 def make_cell(kind: str, source: str, index: int) -> dict:
     result = dict(cell_type=kind, id=f"cell-{index:03d}", metadata={},
                   source=clean_code(source).splitlines(keepends=True))
     if kind == "code":
         result.update(execution_count=None, outputs=[])
@@ -201,17 +201,17 @@ def algorithm_code(algorithm: str) -> tuple[str, str]:
                 if node.name == "fit" else "Predict the source energy histogram candidate mask."))
     prediction = ast.unparse(ast.fix_missing_locations(tree))
     prediction = add_stage_comments(prediction, TT2_STAGE_COMMENTS)
     return helpers, prediction
 
 
 def standalone_pipeline(algorithm: str) -> str:
     """Adapt public production functions by AST, retaining their numeric logic."""
-    tree = ast.parse(functions("app/pipeline.py", "detect_regions", "predict_and_score", "fit_training_model"))
+    tree = ast.parse(functions("app/pipeline.py", "algorithm_decision", "detect_regions", "predict_and_score", "fit_training_model"))
     class LocalAlgorithm(ast.NodeTransformer):
         def visit_Compare(self, node):
             # The public guard fixes algorithm, so omit other dispatch branches
             # without rewriting any detector or calibration formula.
             if (isinstance(node.left, ast.Name) and node.left.id == "algorithm"
                     and len(node.ops) == 1):
                 right = ast.literal_eval(node.comparators[0])
                 operation = node.ops[0]
@@ -231,17 +231,17 @@ def standalone_pipeline(algorithm: str) -> str:
         def visit_IfExp(self, node):
             node = self.generic_visit(node)
             if isinstance(node.test, ast.Constant) and isinstance(node.test.value, bool):
                 return node.body if node.test.value else node.orelse
             return node
 
         def visit_Attribute(self, node):
             if (isinstance(node.value, ast.Name) and node.value.id in ("tt1", "tt2", "tt3")
-                    and node.attr in ("fit", "predict")):
+                    and node.attr in ("fit", "predict", "pad_speech")):
                 return ast.copy_location(ast.Name(node.attr, ast.Load()), node)
             return self.generic_visit(node)
 
         def visit_Name(self, node):
             if node.id == "TRAIN_DIR":
                 return ast.copy_location(ast.parse("(DATA_ROOT / 'train')", mode="eval").body, node)
             return node
 
@@ -262,16 +262,17 @@ import hashlib
 import json
 import html
 from pathlib import Path
 
 import matplotlib.pyplot as plt
 from IPython.display import HTML, display
 
 ALGORITHM = {algorithm!r}
+MODE = "enhanced"  # selected mode for the four plots and illustration
 FRAME_MS = 25.0
 HOP_MS = 10.0
 SAMPLE_ROUNDING = "nearest_integer_samples_python_round_ties_to_even"
 MIN_SILENCE_SECONDS = 0.200
 MIN_SPEECH_SECONDS = 0.100
 BOUNDARY_TOLERANCE_SECONDS = 0.100
 HISTOGRAM_W_TIE_PREFERENCE = 20.0
 PADDING_MS = 250.0
@@ -375,17 +376,21 @@ DATASET_MANIFEST = [dict(file=r["name"], split=r["split"],
 display_table(DATASET_MANIFEST,
               [("file", "WAV/LAB stem"), ("split", "Split"),
                ("sample_rate_hz", "Fs (Hz)"), ("duration_s", "Duration (s)")],
               "Eight WAV/LAB pairs loaded from the separate dataset")
 '''
 
 
 FIT_MODEL = '''
-MODEL, TT2W_SWEEP_ROWS = fit_training_model(ALGORITHM, TRAIN_RECORDS)
+MODELS, TT2W_SWEEPS = {}, {}
+for endpoint_mode in ("core", "enhanced"):
+    MODELS[endpoint_mode], TT2W_SWEEPS[endpoint_mode] = fit_training_model(
+        ALGORITHM, TRAIN_RECORDS, endpoint_mode=endpoint_mode)
+MODEL, TT2W_SWEEP_ROWS = MODELS[MODE], TT2W_SWEEPS[MODE]
 '''
 
 
 CALIBRATE_W = '''
 # fit_training_model has selected FINAL W from supplied TRAIN records only.
 W_SELECTION = MODEL["W_selection_train"]
 display_table(MODEL["candidate_frame_selection_scores"],
               [("W", "TRAIN candidate W"), ("candidate_frame_f1", "Candidate frame F1"),
@@ -405,65 +410,81 @@ display_table(TT2W_SWEEP_ROWS,
 '''
 
 
 LOCK_MODEL = '''
 def model_digest(model):
     return hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False,
                                      allow_nan=False, separators=(",", ":")).encode("utf-8")).hexdigest()
 
-MODEL_LOCK_DIGEST = model_digest(MODEL)
+MODEL_LOCK_DIGESTS = {mode: model_digest(model) for mode, model in MODELS.items()}
+MODEL_LOCK_DIGEST = MODEL_LOCK_DIGESTS[MODE]
 
 def assert_model_locked():
-    if model_digest(MODEL) != MODEL_LOCK_DIGEST:
-        raise ValueError("Frozen TRAIN model digest changed after calibration")
+    for mode, model in MODELS.items():
+        if model.get("endpoint_mode") != mode or model_digest(model) != MODEL_LOCK_DIGESTS[mode]:
+            raise ValueError("Frozen TRAIN model digest or mode changed after calibration")
+    if MODEL is not MODELS[MODE] or model_digest(MODEL) != MODEL_LOCK_DIGEST:
+        raise ValueError("Selected model alias changed after calibration")
 
 print("MODEL locked before TEST reads:", MODEL_LOCK_DIGEST)
 '''
 
 
 MODEL_DISPLAY = '''
 parameter_names = {parameter_names!r}
 parameter_rows = [dict(parameter=key, value=MODEL.get(key)) for key in parameter_names]
 parameter_rows.extend(dict(parameter=key, value=value)
-                      for key, value in MODEL["endpoint_noise"].items())
+                      for key, value in (MODEL["endpoint_noise"] or {{}}).items())
 display_table(parameter_rows, [("parameter", "Parameter"), ("value", "Freshly computed value")],
               "Training parameters and train-only noise calibration")
 '''
 
 
 EVALUATION = '''
-TEST_RESULTS = [predict_and_score(ALGORITHM, record, MODEL) for record in TEST_RECORDS]
+TEST_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in TEST_RECORDS]
+                        for mode, model in MODELS.items()}
 assert_model_locked()
-ALL_RESULTS = [predict_and_score(ALGORITHM, record, MODEL) for record in ALL_RECORDS]
+ALL_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in ALL_RECORDS]
+                       for mode, model in MODELS.items()}
 assert_model_locked()
+TEST_RESULTS, ALL_RESULTS = TEST_RESULTS_BY_MODE[MODE], ALL_RESULTS_BY_MODE[MODE]
 
 def metric_rows(records, results):
     return [dict(file=record["name"], split=record["split"], algorithm=ALGORITHM,
                  **result["metrics"])
             for record, result in zip(records, results)]
 
-TEST_METRIC_ROWS = metric_rows(TEST_RECORDS, TEST_RESULTS)
-ALL_METRIC_ROWS = metric_rows(ALL_RECORDS, ALL_RESULTS)
-TEST_SUMMARY = summarize(TEST_METRIC_ROWS)
+TEST_METRICS_BY_MODE = {mode: metric_rows(TEST_RECORDS, results) for mode, results in TEST_RESULTS_BY_MODE.items()}
+ALL_METRICS_BY_MODE = {mode: metric_rows(ALL_RECORDS, results) for mode, results in ALL_RESULTS_BY_MODE.items()}
+TEST_SUMMARIES_BY_MODE = {mode: summarize(rows) for mode, rows in TEST_METRICS_BY_MODE.items()}
+TEST_METRIC_ROWS = [row for rows in TEST_METRICS_BY_MODE.values() for row in rows]
+ALL_METRIC_ROWS = [row for rows in ALL_METRICS_BY_MODE.values() for row in rows]
+TEST_SUMMARY = TEST_SUMMARIES_BY_MODE[MODE]
 METRIC_COLUMNS = [
-    ("file", "File"), ("split", "Split"),
+    ("file", "File"), ("split", "Split"), ("endpoint_mode", "Mode"),
     ("ground_truth_region_count", "GT regions"), ("predicted_region_count", "Pred regions"),
     ("mae_ms", "Final MAE (ms)"), ("rmse_ms", "RMSE (ms)"), ("status", "Status"),
     ("start_error_ms", "Signed START error (ms)"), ("end_error_ms", "Signed END error (ms)"),
     ("gt_start_s", "GT START (s)"), ("gt_end_s", "GT END (s)"),
     ("predicted_start_s", "Pred START (s)"), ("predicted_end_s", "Pred END (s)")
 ]
-display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings: final confirmed boundaries")
+display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings in each mode: FINAL-region endpoints")
+THRESHOLD_ROWS = [dict(file=result["file"], endpoint_mode=mode,
+                      **{key:result["diagnostic"].get(key) for key in
+                         ("native_threshold", "native_threshold_units", "low_ste_threshold", "high_ste_threshold",
+                          "geometry", "minimum_speech_ms", "padding_stage")})
+                  for mode, results in ALL_RESULTS_BY_MODE.items() for result in results]
+display_table(THRESHOLD_ROWS, [(key,key) for key in THRESHOLD_ROWS[0]], "Both-mode threshold and geometry diagnostics")
 '''
 
 
 SUMMARY_DISPLAY = '''
-display_table(TEST_SUMMARY,
-              [("algorithm", "Algorithm"), ("files", "Files"),
+display_table([row for rows in TEST_SUMMARIES_BY_MODE.values() for row in rows],
+              [("algorithm", "Algorithm"), ("endpoint_mode", "Mode"), ("files", "Files"),
                ("evaluated_files", "Defined MAE files"), ("mean_file_mae_ms", "Mean MAE (ms)"),
                ("median_file_mae_ms", "Median (ms)"), ("min_file_mae_ms", "Min (ms)"),
                ("max_file_mae_ms", "Max (ms)"), ("mean_file_rmse_ms", "Mean file RMSE (ms)"),
                ("pooled_endpoint_rmse_ms", "Pooled endpoint RMSE (ms)"),
                ("region_count_correct_files", "Correct counts"),
                ("region_count_incorrect_files", "Incorrect counts"),
                ("mean_frame_f1", "Mean frame F1"), ("top_mae_files", "Highest MAE files"),
                ("evaluation_protocol", "Protocol")],
@@ -480,37 +501,42 @@ def plot_record(record, result):
     mae_text = f"{mae:.2f} ms" if mae is not None else "N/A"
     figure, axes = plt.subplots(2, 1, figsize=(12.5, 5.5), sharex=True,
                                gridspec_kw={"height_ratios": [1, 1.25]})
     time = [index / record["sample_rate"] for index in range(len(record["samples"]))]
     axes[0].plot(time, record["samples"], color="#444444", linewidth=0.6)
     axes[0].set_ylabel("PCM amplitude")
     axes[1].plot(features["centers"], features["ste_norm"], color="#263238",
                  linewidth=1, label="Normalized STE")
-    axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060",
-                   linestyle="--", linewidth=1.2, label="LOW")
-    axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700",
-                   linestyle=":", linewidth=1.4, label="HIGH")
+    if diagnostic["endpoint_mode"] == "core":
+        native = diagnostic["native_threshold"]
+        if diagnostic["native_threshold_units"] == "mean squared sample amplitude":
+            peak = max(features["energy"], default=0.)
+            native = native / peak if peak else 0.
+        axes[1].axhline(native, color="#9b6700", linestyle=":", label="Native T (display normalized)")
+    else:
+        axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060", linestyle="--", label="LOW")
+        axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700", linestyle=":", label="HIGH")
     for axis in axes:
         for index, (start, end) in enumerate(result["ground_truth_regions"]):
             axis.axvspan(start, end, color="red", alpha=0.05)
             axis.axvline(start, color="red", linestyle="--", linewidth=1.25,
                         label="GT boundary" if index == 0 else None)
             axis.axvline(end, color="red", linestyle="--", linewidth=1.25)
         for index, (start, end) in enumerate(result["final_regions"]):
             axis.axvspan(start, end, color="#1769d2", alpha=0.11)
             axis.axvline(start, color="#1769d2", linewidth=1.4,
                         label="FINAL predicted boundary" if index == 0 else None)
             axis.axvline(end, color="#1769d2", linewidth=1.4)
         axis.grid(alpha=0.16)
         axis.set_xlim(0, record["duration"])
     axes[1].set_ylabel("Normalized STE")
     axes[1].set_xlabel("Time (s)")
     axes[1].legend(loc="upper right", fontsize=8, ncol=3)
-    figure.suptitle(f"{record['name']}.wav | Outer boundary MAE: {mae_text} | "
+    figure.suptitle(f"{record['name']}.wav | {MODE} | FINAL-region endpoint MAE: {mae_text} | "
                    f"{len(result['final_regions'])} speech regions")
     figure.tight_layout()
     plt.show()
     plt.close(figure)
 
 
 TEST_RECORDS_BY_FILE = {record["name"]: record for record in TEST_RECORDS}
 TEST_RESULTS_BY_FILE = {result["file"]: result for result in TEST_RESULTS}
@@ -692,88 +718,88 @@ def demo_one_file(filename="phone_F2"):
 
 def build_notebook(algorithm: str) -> dict:
     titles = {"tt1": "TT1 — Equal-confusion-area binary search",
               "tt2": "TT2 — Energy histogram threshold",
               "tt3": "TT3 — Gaussian energy distributions"}
     explanations = {
         "tt1": "Learn the normalized STE threshold from labeled TRAIN silence/speech by the source binary-search rule.",
         "tt2": "Estimate each recording's energy threshold from the first two histogram peaks. Show the TRAIN candidate-frame F1 proposal separately from global FINAL W calibration on the four TRAIN recordings.",
-        "tt3": "Fit population mean and standard deviation to labeled TRAIN normalized STE. Solve equal Gaussian densities in centered/scaled coordinates with an explicit 1e-9 sigma floor, stable quadratic roots and a log-density check; use the declared midpoint fallback if no valid crossing lies between the means. Raw fit/predict supports speech_direction='low', while the current FINAL HIGH/LOW energy hysteresis requires speech_direction='high' and explicitly rejects low or unknown directions during fitting and inference.",
+        "tt3": "Fit population mean and standard deviation to labeled TRAIN normalized STE. Solve equal Gaussian densities in centered/scaled coordinates with an explicit 1e-9 sigma floor, stable quadratic roots and a log-density check; use the declared midpoint fallback if no valid crossing lies between the means. Raw fit/predict supports speech_direction='low', core FINAL preserves that native direction; enhanced FINAL HIGH/LOW energy hysteresis requires speech_direction='high' and explicitly rejects low or unknown directions during fitting and inference.",
     }
     sections: list[tuple[str, str]] = []
     def md(source: str) -> None:
         sections.append(("markdown", source))
     def code(source: str) -> None:
         sections.append(("code", source))
 
     md(f"""# {titles[algorithm]}
 
 {explanations[algorithm]}
 
 This notebook contains all computation for one student's algorithm. Run the cells in order with Python 3, matplotlib and IPython. WAV/LAB input is supplied separately in `data/train/` and `data/test/`; edit `DATA_DIR` if needed. The notebook discovers these folders from its working directory and ancestors.
 
-The signal is framed with full 25 ms windows and 10 ms hops, using Python's nearest-sample rounding with ties to even. Energy is STE divided by frame size. Final regions require HIGH confirmation and continue above LOW. The 200 ms rule measures estimated gaps between active frame supports, and the 100 ms minimum is a support-span heuristic. Overlapping frames can bridge physical silence or retain brief impulses; these settings do not guarantee 200 ms of physical silence or 100 ms of voiced audio. Training and test results are labeled separately. Every number and plot below is recomputed from input WAV/LAB; no saved model or result is loaded.
+The signal is framed with full 25 ms windows and 10 ms hops, using Python's nearest-sample rounding with ties to even. Energy is STE divided by frame size. Default MODE=enhanced requires HIGH confirmation and continuation above LOW. Core uses native decisions without HIGH/LOW, final padding or duration filtering. The 200 ms rule measures estimated gaps between active frame supports; exact 200 ms is preserved. Enhanced alone uses the 100 ms support-span heuristic. Overlapping frames can bridge physical silence or retain brief impulses; these settings do not guarantee 200 ms of physical silence or 100 ms of voiced audio. Training and test results are labeled separately. Every number and plot below is recomputed from input WAV/LAB; no saved model or result is loaded.
 
 For standalone use, choose **Restart Kernel and Run All** and save the executed notebook so tables and plots stay visible; this notebook needs no project modules or generator/runner scripts to execute. Submit this `.ipynb` without bundling WAV or other signal files.
 
 Project maintainers refresh this repository's audited CODE ZIP by rebuilding with `tools/build_notebooks.py`, executing with `tools/run_notebooks.py` in fresh kernels, then checking saved evidence with `--validate-only`. That runner hashes ordered code-cell sources after removing its temporary audit cell. A code edit, including a comment, requires fresh runner execution before the repository's source-bound audit/packaging accepts it; this audit requirement is separate from standalone notebook execution.
 """)
     md("## Imports and fixed configuration\n\nOnly the standard library, matplotlib and IPython are used. Timing and endpoint rules are fixed.")
     code(CONFIG.format(algorithm=algorithm))
     md("## WAV and LAB input\n\nPCM decoding and interval validation are manual. `sil=0`; `v` and `uv` are speech. Optional Praat metadata lines are ignored after format validation.")
     code(functions("core/io_utils.py", "read_wav", "read_lab"))
     code(DATA_HELPERS)
     md("## Manual frame features\n\nEach full frame computes STE and mean absolute amplitude by sample loops. Normalization divides by the recording's maximum; an all-zero recording stays zero. The short tail is discarded.")
     code(manual_features())
     md("## LAB alignment and scoring\n\nLAB labels use the frame center and half-open intervals. Region MAE/RMSE score START and END of complete matched final regions. A missing or extra region leaves the primary MAE undefined; frame and tolerance-based boundary scores are additional diagnostics.\n\nFor multiple speech regions, \"outer\" refers to each final region's START/END; the metric does not collapse regions into a single global envelope.")
     code(functions("core/metrics.py", "frame_labels", "frame_metrics", "ground_truth_regions", "region_endpoint_metrics", "boundary_metrics"))
-    md("## Final endpoint confirmation\n\nThe noise floor is estimated from TRAIN silence only. HIGH confirms speech; LOW retains weak speech. The 200 ms estimated support-gap rule and 100 ms support-span filter are heuristics, without a guarantee about physical silence or voiced duration. Silence waiting time and TT2 candidate padding do not extend final boundaries.")
+    md("## Final endpoint confirmation\n\nIn enhanced mode the noise floor is estimated from TRAIN silence only. Core uses native decisions and merges internal support gaps below 200 ms. Enhanced HIGH confirms speech; LOW retains weak speech. The 200 ms estimated support-gap rule and 100 ms support-span filter are heuristics, without a guarantee about physical silence or voiced duration. Silence waiting time and TT2 candidate padding do not extend final boundaries.")
     code(functions("core/endpoints.py", "fit_noise_floor", "endpoint_thresholds", "hysteresis_regions", "regions_to_mask"))
     post_names = ("_validate", "mask_segments", "fill_short_internal_silences") if algorithm == "tt2" else ("_validate", "mask_segments")
     code(functions("core/postprocess.py", *post_names))
     md(f"## {titles[algorithm]} implementation\n\n{explanations[algorithm]}")
     helpers, fit_predict = algorithm_code(algorithm)
     code(helpers)
     code(fit_predict)
     md("## End-to-end detection and summary\n\nDetection uses features and the fitted model. Target LAB is consulted only after final regions have been computed, for scores and plot references.")
     prepared = source_function("app/pipeline.py", "prepare_records")
     prepared = prepared.replace("def prepare_records(audio_records, source_histogram=False):", "def prepare_records(audio_records):")
     prepared = prepared.replace("    Input: audio_records chứa waveform/Fs/LAB. source_histogram giữ tương\n    thích các điểm gọi cũ; mọi thuật toán hiện chỉ cần đặc trưng năng lượng.\n",
                                 "    Input: audio_records chứa waveform/Fs/LAB; dùng đặc trưng năng lượng.\n")
     code(prepared + "\n\n\n" + standalone_pipeline(algorithm))
     code(source_function("app/pipeline.py", "summarize"))
     if algorithm == "tt2":
         md("## Global W calibration rule\n\nEvaluate integer W=1…50 on the four TRAIN LABs using the actual FINAL endpoint pipeline. Prefer valid region counts, minimize worst per-file regret, then mean MAE; tied values prefer W=20. Historical TEST sweeps are prior development evidence only; they are not rerun for calibration.")
-        code('W_CANDIDATES = tuple(float(w) for w in range(1, 51))\nERROR_EPS_MS = 1e-8\n\n' + functions("app/weight_selection.py", "select_final_weight", "sweep_final_weights"))
+        code('W_CANDIDATES = tuple(float(w) for w in range(1, 51))\nERROR_EPS_MS = 1e-8\nPOLICY_FIELDS = ("endpoint_mode", "boundary_convention", "minimum_speech_ms", "minimum_silence_ms", "padding_stage")\n\n' + functions("app/weight_selection.py", "select_final_weight", "sweep_final_weights"))
     md("## Load four TRAIN input pairs\n\nTRAIN is read first. TEST WAV/LAB reads follow calibration and model locking.")
     code(LOAD_DATA)
-    md("## Fit fresh TRAIN parameters\n\nAll core model parameters and noise statistics are computed using the four TRAIN recordings.")
+    md("## Fit fresh TRAIN parameters\n\nBoth mode models are fit independently on the four TRAIN recordings; noise is calibrated only for enhanced.")
     code(FIT_MODEL)
     if algorithm == "tt2":
         md("### TRAIN FINAL W calibration\n\nShow all 50 candidates and 200 TRAIN rows. The original candidate-frame F1 proposal remains a separate diagnostic. The selected FINAL W is shared by all files.")
-        code(CALIBRATE_W)
+        code("for mode in ('core', 'enhanced'):\n    MODEL, TT2W_SWEEP_ROWS = MODELS[mode], TT2W_SWEEPS[mode]\n" + textwrap.indent(clean_code(CALIBRATE_W), "    ") + "\nMODEL, TT2W_SWEEP_ROWS = MODELS[MODE], TT2W_SWEEPS[MODE]")
     parameters = {
         "tt1": ["threshold", "silence_count", "speech_count", "overlap_low", "overlap_high", "iterations", "stop_reason", "area_residual", "overlap_silence_count", "overlap_speech_count"],
         "tt2": ["candidate_frame_selected_W", "candidate_frame_f1", "candidate_cleanup_records", "W", "finalW", "tie_preference_W", "bins", "smooth_radius", "padding_ms", "padding_frames"],
         "tt3": ["muSil", "stdSil", "muSp", "stdSp", "silence_count", "speech_count", "threshold", "threshold_rule", "speech_direction", "sigma_floor", "sigma_was_floored"],
     }
     code(MODEL_DISPLAY.format(parameter_names=parameters[algorithm]))
-    md("## Lock TRAIN model, then load TEST\n\nThe model digest is captured before TEST input reads and checked after scoring. Schema 2 uses `parameter_selection_set=train`, `evaluation_protocol=train_selected_reused_test`, and `historical_test_exposure=true`: these TEST recordings were seen during earlier development. The eight-file manifest retains WAV/LAB hashes and split provenance.")
+    md("## Lock TRAIN model, then load TEST\n\nBoth mode model digests are captured before TEST input reads and checked after scoring. Schema 3 model policy with schema 2 metrics uses `parameter_selection_set=train`, `evaluation_protocol=train_selected_reused_test`, and `historical_test_exposure=true`: these TEST recordings were seen during earlier development. The eight-file manifest retains WAV/LAB hashes and split provenance.")
     code(LOCK_MODEL)
     code(LOAD_TEST)
     md("## Computed algorithm illustration\n\nThe illustration uses the features and statistics calculated in this run.")
     code({"tt1": TT1_ILLUSTRATION, "tt2": TT2_ILLUSTRATION, "tt3": TT3_ILLUSTRATION}[algorithm])
     md("## Four TEST results\n\nThe main table scores the final confirmed regions. START/END columns are in seconds; MAE/RMSE are in milliseconds.")
     code(EVALUATION)
     md("### TEST summary\n\nMean, median, minimum, maximum, count correctness and highest-error files describe only the four TEST recordings.")
     code(SUMMARY_DISPLAY)
     md("## All eight input files\n\nThis separate table includes TRAIN and TEST with explicit split labels. TRAIN results reuse the model fitted from TRAIN and therefore describe its training fit.")
     code('display_table(ALL_METRIC_ROWS, METRIC_COLUMNS, "All eight files: TRAIN and TEST shown explicitly")')
-    md("## Four inline TEST figures\n\nRed indicates LAB ground truth, blue indicates final predicted regions. Waveform and normalized STE share the same time axis. LOW/HIGH are the actual final confirmation thresholds. Each recording has its own figure cell.")
+    md("## Four inline TEST figures\n\nRed indicates LAB ground truth, blue indicates final predicted regions. Waveform and normalized STE share the same time axis. Enhanced LOW/HIGH are actual confirmation thresholds; core plots native T and exports LOW/HIGH as null. Each recording has its own figure cell.")
     code(PLOTTING)
     for filename in ("phone_F2", "phone_M2", "studio_F2", "studio_M2"):
         md(f"### {filename}.wav")
         code(f'plot_record(TEST_RECORDS_BY_FILE["{filename}"], TEST_RESULTS_BY_FILE["{filename}"])')
     md("## Optional single-file demonstration\n\nAfter running all previous cells, call `demo_one_file` with a dataset stem or WAV path. It uses the current model and performs no parameter tuning.")
     code(OPTIONAL_DEMO)
     return dict(nbformat=4, nbformat_minor=5,
                 metadata=dict(kernelspec=dict(display_name="Python 3", language="python", name="python3"),
diff --git a/tools/check_endpoint_robustness.py b/tools/check_endpoint_robustness.py
index 8bc8819..c03581b 100644
--- a/tools/check_endpoint_robustness.py
+++ b/tools/check_endpoint_robustness.py
@@ -1,13 +1,13 @@
 """Bounded synthetic characterization and four-arm TRAIN endpoint ablation.
 
-Run: python tools/check_endpoint_robustness.py
+Run: python tools/check_endpoint_robustness.py [--timing-research]
 Reads only TRAIN WAV/LABs. Writes diagnostic CSV/JSON only beneath
-outputs/tables/endpoint_robustness; never changes fitted production artifacts.
+outputs/tables/endpoint_robustness (legacy) or endpoint_modes_oct07/timing_research; never changes fitted production artifacts.
 Support gaps are estimates: true 200/210ms zero intervals can still be merged.
 """
 from __future__ import annotations
 
 import csv
 import hashlib
 import json
 import sys
@@ -265,10 +265,310 @@ def main():
     write_diagnostics(payload)
     known = sum(r['status']=='known_limitation' for r in payload['waveforms'])
     print(f"Synthetic: {len(payload['waveforms'])} gap cases; {known} known true200/210ms limitations.")
     print(f"TRAIN: {len(payload['ablation'])} fixed-model rows; W={models['tt2']['W']:g}; "
           f"invalid counts remain explicit. Diagnostics: {DESTINATION}")
     return payload
 
 
+
+
+# Task 4 diagnostic branches: one factor at a time, never production policy.
+from copy import deepcopy
+from core.decision_timing import decision_cells
+from app.pipeline import algorithm_decision
+from app.weight_selection import select_final_weight
+
+TIMING_DESTINATION = OUTPUT_DIR / 'tables' / 'endpoint_modes_oct07' / 'timing_research'
+TIMING_TRIALS = [
+    dict(trial_id=trial_id,endpoint_mode=mode,geometry=geometry,minimum_speech_ms=minimum,
+         low_rule=low_rule,algorithms=ALGORITHMS if low_rule=='native' else ('tt1',))
+    for trial_id,mode,geometry,minimum,low_rule in (
+        ('core_support_0','core','support',0.,'native'),
+        ('core_cells_0','core','cells',0.,'native'),
+        ('core_support_100','core','support',100.,'native'),
+        ('enhanced_support_100','enhanced','support',100.,'native'),
+        ('enhanced_cells_100','enhanced','cells',100.,'native'),
+        ('enhanced_support_0','enhanced','support',0.,'native'),
+        ('enhanced_tt1_t1_support_100','enhanced','support',100.,'T1'))]
+
+
+def timing_predictor(algorithm, record, params):
+    """Same LAB-free experimental detector for fit W candidates and held-out scores.
+
+    Geometry controls every start/end, merge, duration filter and final mask.
+    Labels enter only the scorer after final detection. Native TT2 is unpadded.
+    """
+    f,duration=record['features'],record['duration']
+    geometry=params['geometry']; mode=params['endpoint_mode']
+    if geometry not in ('support','cells') or mode not in ('core','enhanced'):
+        raise ValueError('Unknown research geometry or endpoint mode')
+    starts,ends=decision_cells(f,duration) if geometry=='cells' else (f['starts'],f['ends'])
+    seed,diag=algorithm_decision(algorithm,f,params)
+    minimum=params['minimum_speech_ms']/1000
+    candidate=[(s,e) for s,e,k in mask_segments(seed,starts,duration,ends) if k]
+    low=high=None
+    if mode=='core':
+        merged=[]
+        for start,end in candidate:
+            if merged and start-merged[-1][1]<.2-1e-12:merged[-1]=(merged[-1][0],end)
+            else:merged.append((start,end))
+        final=[(s,e) for s,e in merged if e-s>=minimum-1e-12]
+    else:
+        if algorithm=='tt3' and params.get('speech_direction','high')!='high':
+            raise ValueError('Enhanced requires speech-high TT3')
+        if algorithm=='tt2':
+            peak=max(f['energy'],default=0.)
+            base=diag['energy_threshold']/peak if peak else 0.
+        else:base=params['threshold']
+        if params.get('low_rule')=='T1':
+            low=base; high=max(1.5*base,params['endpoint_noise']['noise_upper'])
+            if not 0<low<high:raise ValueError('unsupported LOW=T1: invalid hysteresis thresholds')
+        else:low,high=endpoint_thresholds(base,params['endpoint_noise'],histogram=algorithm=='tt2')
+        final=hysteresis_regions(f['ste_norm'],starts,ends,duration,low,high,.2,minimum,seed_mask=seed)
+    # Passing the chosen timing arrays provides whole-cell containment for cells.
+    mask=regions_to_mask(final,starts,ends)
+    diag.update(endpoint_mode=mode,geometry=geometry,boundary_convention=params.get('boundary_convention','nearest-frame centered decision cells' if geometry=='cells' else 'union of active frame supports'),
+        minimum_speech_ms=params['minimum_speech_ms'],minimum_silence_ms=200.,
+        padding_stage=params.get('padding_stage','excluded from core FINAL' if mode=='core' else 'none'),low_ste_threshold=low,high_ste_threshold=high,
+        candidate_regions=candidate,raw_speech_frames=sum(seed),final_regions=final,
+        last_native_active_end_s=_last_support(seed,ends))
+    reference=ground_truth_regions(record['intervals'])
+    return dict(mask=mask,final_regions=final,diagnostic=diag,metrics=region_endpoint_metrics(reference,final),
+                frame_metrics=frame_metrics(record['labels'],mask))
+
+
+def _branch_params(native,trial):
+    params=deepcopy(native)
+    # Native calibration digest and support W provenance are preliminary only.
+    params.pop('calibration_digest',None)
+    params.pop('W_selection_train',None)
+    params.update({k:v for k,v in trial.items() if k!='algorithms'})
+    params.update(boundary_convention='nearest-frame centered decision cells' if trial['geometry']=='cells'
+                  else 'union of active frame supports',minimum_silence_ms=200.,
+                  endpoint_policy='diagnostic native/hysteresis branch; merge estimated gaps below 200 ms',
+                  padding_stage='excluded from core FINAL' if trial['endpoint_mode']=='core'
+                  else 'candidate diagnostics only' if native.get('variant')=='source' else 'none')
+    return params
+
+
+def _digest(value):
+    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False).encode('utf-8')).hexdigest()
+
+
+def timing_training_study(records):
+    """Four deterministic TRAIN folds; separate W=1..50 selection per branch."""
+    require_train(records)
+    records=sorted(records,key=lambda r:r['name'])
+    if len(records)!=4 or len({r['name'] for r in records})!=4:
+        raise ValueError('Exactly four distinct TRAIN records required')
+    heldout_rows=[]; sweep_rows=[]; models=[]
+    for fold,heldout in enumerate(records,1):
+        fit=[r for r in records if r is not heldout]
+        native={(mode,a):fit_training_model(a,fit,endpoint_mode=mode)[0]
+                for mode in ('core','enhanced') for a in ALGORITHMS}
+        for trial in TIMING_TRIALS:
+            for algorithm in trial['algorithms']:
+                params=_branch_params(native[trial['endpoint_mode'],algorithm],trial)
+                selection=None
+                if algorithm=='tt2':
+                    branch_rows=[]
+                    for w in range(1,51):
+                        candidate_params=dict(params,W=float(w),finalW=float(w))
+                        for record in fit:
+                            result=timing_predictor(algorithm,record,candidate_params)
+                            metrics=result['metrics']
+                            branch_rows.append(dict(filename=record['name'],W=float(w),
+                                endpoint_mode=trial['endpoint_mode'],boundary_convention=params['boundary_convention'],
+                                minimum_speech_ms=trial['minimum_speech_ms'],minimum_silence_ms=200.,
+                                padding_stage=params['padding_stage'],final_region_mae_ms=metrics['mae_ms'],
+                                ground_truth_region_count=metrics['ground_truth_region_count'],
+                                predicted_region_count=metrics['predicted_region_count'],status=metrics['status']))
+                    selection=select_final_weight(branch_rows)
+                    selection.update(trial_id=trial['trial_id'],geometry=trial['geometry'],low_rule=trial['low_rule'],
+                                     branch_predictor='tools.check_endpoint_robustness.timing_predictor',
+                                     selection_scorer='core.metrics.region_endpoint_metrics',evaluated_files=[r['name'] for r in fit])
+                    params.update(W=selection['selected_W'],finalW=selection['selected_W'],
+                                  W_selection_train=selection,parameter_rule=selection['selection_rule'])
+                    sweep_rows.extend(dict(fold=fold,trial_id=trial['trial_id'],geometry=trial['geometry'],**r) for r in branch_rows)
+                params.update(training_files=[r['name'] for r in fit],evaluation_protocol='four_fold_train_holdout',
+                              branch_predictor='tools.check_endpoint_robustness.timing_predictor',selection_scorer='core.metrics.region_endpoint_metrics')
+                digest=_digest(params)
+                models.append(dict(fold=fold,algorithm=algorithm,trial_id=trial['trial_id'],heldout_file=heldout['name'],
+                    fit_files=params['training_files'],model_sha256=digest,model=params,
+                    preliminary_native_W=native[trial['endpoint_mode'],algorithm].get('W'),
+                    preliminary_native_digest=native[trial['endpoint_mode'],algorithm].get('calibration_digest')))
+                try:
+                    result=timing_predictor(algorithm,heldout,params)
+                    scores=result['metrics']
+                    row=dict(**scores,final_regions=result['final_regions'],diagnostic=result['diagnostic'],
+                             **{f'frame_{k}':v for k,v in result['frame_metrics'].items()})
+                    if trial['trial_id'] in ('core_support_0','enhanced_support_100'):
+                        production=detect_regions(algorithm,heldout['features'],heldout['duration'],params)
+                        if production['final_regions']!=result['final_regions'] or production['mask']!=result['mask']:
+                            raise AssertionError('Matching support baseline differs from production')
+                except ValueError as error:
+                    if 'unsupported LOW=T1' not in str(error):raise
+                    row=dict(status=str(error),mae_ms=None,rmse_ms=None,missing_region_count=0,
+                             extra_region_count=0,signed_endpoint_errors_ms=[],region_pairs=[],final_regions=None)
+                heldout_rows.append(dict(fold=fold,file=heldout['name'],algorithm=algorithm,
+                    trial_id=trial['trial_id'],arm=trial['trial_id'],geometry=trial['geometry'],endpoint_mode=trial['endpoint_mode'],
+                    low_rule=trial['low_rule'],minimum_speech_ms=trial['minimum_speech_ms'],W=params.get('W'),
+                    model_sha256=digest,fit_files=params['training_files'],**row))
+        print(f'Timing TRAIN fold {fold}/4 complete',flush=True)
+    if len(heldout_rows)!=76 or len(sweep_rows)!=3600:raise AssertionError('Declared evaluation budget changed')
+    comparisons=[]
+    for row in heldout_rows:
+        baseline_id='core_support_0' if row['endpoint_mode']=='core' else 'enhanced_support_100'
+        if row['trial_id']==baseline_id:continue
+        baseline=next(r for r in heldout_rows if r['fold']==row['fold'] and r['algorithm']==row['algorithm'] and r['trial_id']==baseline_id)
+        a,b=row['mae_ms'],baseline['mae_ms']
+        comparisons.append(dict(fold=row['fold'],file=row['file'],algorithm=row['algorithm'],trial_id=row['trial_id'],
+            baseline_trial_id=baseline_id,baseline_status=baseline['status'],status=row['status'],
+            baseline_mae_ms=b,mae_ms=a,delta_mae_ms=a-b if a is not None and b is not None else None,
+            baseline_rmse_ms=baseline['rmse_ms'],rmse_ms=row['rmse_ms'],
+            delta_rmse_ms=row['rmse_ms']-baseline['rmse_ms'] if row['rmse_ms'] is not None and baseline['rmse_ms'] is not None else None,
+            validity_transition=f'{"valid" if b is not None else "undefined"}->{"valid" if a is not None else "undefined"}',
+            count_regression=row['missing_region_count']+row['extra_region_count']>baseline['missing_region_count']+baseline['extra_region_count'],
+            metric_regression=a is not None and b is not None and a>b+1e-8,
+            rmse_regression=row['rmse_ms'] is not None and baseline['rmse_ms'] is not None and row['rmse_ms']>baseline['rmse_ms']+1e-8))
+    return dict(heldout=heldout_rows,sweep=sweep_rows,models=models,comparisons=comparisons,summary=ablation_summary(heldout_rows))
+
+
+def _synthetic_record(samples,fs,speech,name):
+    duration=len(samples)/fs
+    intervals=[];cursor=0.
+    for a,b in speech:
+        start,end=a/fs,b/fs
+        if start>cursor:intervals.append((cursor,start,'sil'))
+        intervals.append((start,end,'v'));cursor=end
+    if cursor<duration:intervals.append((cursor,duration,'sil'))
+    return prepare_records([dict(name=name,split='train',samples=samples,sample_rate=fs,
+                                 duration=duration,intervals=intervals)])[0]
+
+
+def synthetic_branch_configs(native_models, trials=TIMING_TRIALS):
+    """Resolve waveform row hashes directly while retaining native calibration sources.
+
+    Reconstruction is deterministic and needs neither audio, fitting nor scoring.
+    Stored branch parameters are exactly those hashed by synthetic waveform rows.
+    """
+    native={(entry['mode'],entry['algorithm']):entry for entry in native_models}
+    configs={}
+    for trial in trials:
+        for algorithm in trial['algorithms']:
+            source=native[trial['endpoint_mode'],algorithm]
+            params=_branch_params(source['model'],trial)
+            digest=_digest(params)
+            entry=dict(model_sha256=digest,algorithm=algorithm,trial_id=trial['trial_id'],
+                       source_native_model_sha256=source['model_sha256'],model=params)
+            if digest in configs and configs[digest] != entry:
+                raise ValueError('Synthetic branch model hash has ambiguous algorithm/trial provenance')
+            configs[digest]=entry
+    return configs
+
+def timing_waveform_study(records):
+    """Characterize physical GT separately using locked four-TRAIN models."""
+    require_train(records)
+    native={(mode,a):fit_training_model(a,records,endpoint_mode=mode)[0]
+            for mode in ('core','enhanced') for a in ALGORITHMS}
+    rows=[];oracle_cells=[];fixtures=[]
+    for fs in (16000,44100):
+        hop=round(fs*.01)
+        for gap in (190,200,210,250):
+            for phase in (0,1,hop//4,hop//2,3*hop//4,hop-1):
+                samples,speech=rectangular_case(fs,phase,gap)
+                record=_synthetic_record(samples,fs,speech,f'gap_{fs}_{gap}_{phase}')
+                metadata=dict(case='physical_gap',sample_rate_hz=fs,phase_samples=phase,
+                              true_gap_ms=(speech[1][0]-speech[0][1])/fs*1000)
+                fixtures.append((record,metadata))
+                f=record['features'];starts,ends=decision_cells(f,record['duration'])
+                values,supports=_overlap_oracle(speech,len(starts),f['frame_size'],f['hop_size'],fs)
+                # Independent cell LOW gap from literal integer-overlap active indices.
+                runs=[]
+                for i in range(len(starts)):
+                    count=sum(max(0,min(i*f['hop_size']+f['frame_size'],b)-max(i*f['hop_size'],a)) for a,b in speech)
+                    if count*10>=f['frame_size']:
+                        if runs and i==runs[-1][1]+1:runs[-1]=(runs[-1][0],i)
+                        else:runs.append((i,i))
+                left=runs[0][1];right=runs[1][0]
+                left_edge=((left+.5)*f['hop_size']+f['frame_size']/2)/fs
+                right_edge=((right-.5)*f['hop_size']+f['frame_size']/2)/fs
+                final=hysteresis_regions(values,starts,ends,record['duration'],.1,.5,.2,.1)
+                oracle_cells.append(dict(**metadata,geometry='cells',threshold_source='fixed diagnostic LOW=.1 HIGH=.5',
+                    estimated_cell_gap_ms=(right_edge-left_edge)*1000,support_gap_ms=(supports[1][0]-supports[0][1])*1000,
+                    low=.1,high=.5,final_regions=final,**region_endpoint_metrics(ground_truth_regions(record['intervals']),final)))
+        for burst in (75,95,100,105):
+            a=round(fs*.1);b=a+round(fs*burst/1000)
+            samples=[0.]*a+[1.]*(b-a)+[0.]*round(fs*.3)
+            fixtures.append((_synthetic_record(samples,fs,[(a,b)],f'burst_{fs}_{burst}'),
+                dict(case='physical_burst',sample_rate_hz=fs,true_speech_ms=(b-a)/fs*1000)))
+        for edge in ('start','end','both','weak_tail'):
+            n=round(fs*.6);a=0 if edge in ('start','both') else round(fs*.1)
+            b=n if edge in ('end','both','weak_tail') else round(fs*.4)
+            samples=[0.]*n
+            samples[a:b]=[1.]*(b-a)
+            if edge=='weak_tail':samples[round(fs*.4):b]=[.05]*(b-round(fs*.4))
+            fixtures.append((_synthetic_record(samples,fs,[(a,b)],f'edge_{fs}_{edge}'),
+                dict(case='physical_edge_or_tail',sample_rate_hz=fs,edge=edge,weak_tail_amplitude=.05 if edge=='weak_tail' else None)))
+    for record,metadata in fixtures:
+        for trial in TIMING_TRIALS:
+            for a in trial['algorithms']:
+                params=_branch_params(native[trial['endpoint_mode'],a],trial)
+                try:
+                    result=timing_predictor(a,record,params)
+                    extra=dict(final_regions=result['final_regions'],diagnostic=result['diagnostic'],**result['metrics'])
+                except ValueError as error:
+                    if 'unsupported LOW=T1' not in str(error):raise
+                    extra=dict(status=str(error),mae_ms=None,rmse_ms=None,final_regions=None)
+                rows.append(dict(**metadata,trial_id=trial['trial_id'],algorithm=a,geometry=trial['geometry'],
+                    endpoint_mode=trial['endpoint_mode'],minimum_speech_ms=trial['minimum_speech_ms'],
+                    model_sha256=_digest(params),threshold_source='locked four-TRAIN calibration; synthetic characterization only',
+                    ground_truth_regions=ground_truth_regions(record['intervals']),**extra))
+    synthetic_models=[dict(mode=mode,algorithm=a,model=model,model_sha256=_digest(model))
+                      for (mode,a),model in native.items()]
+    return dict(waveforms=rows,oracle_cells=oracle_cells,synthetic_models=synthetic_models,
+                synthetic_branch_configs=synthetic_branch_configs(synthetic_models))
+
+
+def _write_research_table(name,rows):
+    fields=list(dict.fromkeys(k for row in rows for k in row))
+    with (TIMING_DESTINATION/f'{name}.csv').open('w',encoding='utf-8-sig',newline='') as handle:
+        writer=csv.DictWriter(handle,fieldnames=fields);writer.writeheader()
+        for row in rows:writer.writerow({k:_json_value(v) if v is None or isinstance(v,(tuple,list,dict)) else v for k,v in row.items()})
+
+
+def timing_research_main():
+    """Run Task 4 diagnostics explicitly; no TEST reads or automatic selection."""
+    TIMING_DESTINATION.mkdir(parents=True,exist_ok=True)
+    records=prepare_records(load_audio_folder(TRAIN_DIR));require_train(records)
+    hashes={str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest()
+        for r in records for path in (Path(r['wav_path']),Path(r['wav_path']).with_suffix('.lab'))}
+    payload=timing_training_study(records)
+    synthetic=timing_waveform_study(records)
+    old_oracle=waveform_characterization()
+    for name,rows in (('heldout_scores',payload['heldout']),('tt2_branch_fit_sweep',payload['sweep']),
+                      ('fold_comparisons',payload['comparisons']),('heldout_summary',payload['summary']),
+                      ('locked_model_waveforms',synthetic['waveforms']),('fixed_oracle_support',old_oracle),
+                      ('fixed_oracle_cells',synthetic['oracle_cells'])):
+        _write_research_table(name,rows)
+    manifest=dict(parameter_selection_set='train',historical_test_exposure=True,
+        evaluation_protocol='four_fold_train_holdout',input_sha256=hashes,trials=TIMING_TRIALS,
+        heldout_rows=len(payload['heldout']),tt2_fit_branch_evaluations=len(payload['sweep']),
+        declared_TT2_W_candidates=list(range(1,51)),heldout_used_for_selection=False,
+        preliminary_native_support_sweeps_are_not_branch_selection=True,
+        branch_predictor='tools.check_endpoint_robustness.timing_predictor',selection_scorer='core.metrics.region_endpoint_metrics',
+        models=payload['models'],synthetic_models=synthetic['synthetic_models'],
+        synthetic_branch_configs=synthetic['synthetic_branch_configs'],
+        limitations=['Cells extend nearest decisions to audio edges and unanalysed tail.',
+            'Full analysis windows remain 25 ms (1102 samples at 44.1 kHz).',
+            'Cells do not guarantee preservation of physical 200 ms silence.',
+            'Physical GT has not been changed; estimated gaps below 200 ms still merge.',
+            'Primary full mean remains undefined whenever any held-out score is undefined.',
+            'Four TRAIN folds and historically exposed data do not create an independent TEST set.',
+            'No default/convention/LOW automatically selected or applied.'])
+    (TIMING_DESTINATION/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
+    print(f"Research: {len(payload['heldout'])} heldout rows; {len(payload['sweep'])} branch W fit evaluations; {len(synthetic['waveforms'])} locked-model synthetic rows",flush=True)
+    return dict(**payload,**synthetic,manifest=manifest)
+
 if __name__ == '__main__':
-    main()
+    timing_research_main() if '--timing-research' in sys.argv else main()
diff --git a/tools/run_notebooks.py b/tools/run_notebooks.py
index 4731174..79fdc15 100644
--- a/tools/run_notebooks.py
+++ b/tools/run_notebooks.py
@@ -2,16 +2,18 @@
 
 This runs notebooks in fresh kernels and retains genuine output in each .ipynb.
 The audit is performed outside their submitted code; no saved results are fed
 into inference. Existing Python benchmark artifacts are read only for comparison.
 """
 from __future__ import annotations
 
 import argparse
+import copy
+import os
 import ast
 import base64
 import csv
 import hashlib
 import json
 import math
 import re
 import sys
@@ -22,30 +24,38 @@ import nbformat
 from jupyter_client import KernelManager
 from nbclient import NotebookClient
 
 ROOT = Path(__file__).resolve().parents[1]
 # External auditing uses the current Python selection helper. Direct script
 # launch otherwise places only tools/ on sys.path, unlike module launch.
 if str(ROOT) not in sys.path:
     sys.path.insert(0, str(ROOT))
+from app.config import endpoint_mode_root
 NOTEBOOK_DIR = ROOT / 'notebooks'
 TEST_NAMES = ('phone_F2', 'phone_M2', 'studio_F2', 'studio_M2')
 TRAIN_NAMES = ('phone_F1', 'phone_M1', 'studio_F1', 'studio_M1')
 AUDIT_PREFIX = '__ENDPOINT_NOTEBOOK_AUDIT__'
 
 AUDIT_CELL = r'''
 import json
 assert_model_locked()
 def _compact_result(result):
     return {key: result[key] for key in (
         'file', 'algorithm', 'metrics', 'final_regions', 'ground_truth_regions',
         'predicted_boundaries', 'ground_truth_boundaries', 'diagnostic')}
 _audit = {
     'algorithm': ALGORITHM,
+    'selected_mode': MODE,
+    'models': MODELS,
+    'model_lock_digests': MODEL_LOCK_DIGESTS,
+    'tt2_w_sweeps': TT2W_SWEEPS,
+    'test_results_by_mode': {mode: [_compact_result(result) for result in results] for mode, results in TEST_RESULTS_BY_MODE.items()},
+    'all_results_by_mode': {mode: [_compact_result(result) for result in results] for mode, results in ALL_RESULTS_BY_MODE.items()},
+    'test_summaries_by_mode': TEST_SUMMARIES_BY_MODE,
     'model': MODEL,
     'model_lock_digest': MODEL_LOCK_DIGEST,
     'tt2_w_sweep_rows': TT2W_SWEEP_ROWS,
     'test_results': [_compact_result(result) for result in TEST_RESULTS],
     'all_results': [_compact_result(result) for result in ALL_RESULTS],
     'test_summary': TEST_SUMMARY,
     'dataset_manifest': DATASET_MANIFEST,
 }
@@ -78,24 +88,61 @@ def code_source_digest(notebook):
     return hashlib.sha256(payload.encode('utf-8')).hexdigest()
 
 
 def audit_metric_keys(scores, label, require_primary=True):
     if len(scores) != len({key.casefold() for key in scores}):
         raise ValueError(f'{label}: duplicate casefold metric keys')
     if (require_primary and 'mae_ms' not in scores) or 'boundary_MAE_ms' in scores:
         raise ValueError(f'{label}: PRIMARY MAE must use mae_ms without a boundary alias')
-    if any(key.startswith('boundary_') and not key.startswith('boundary_inside_') for key in scores):
+    if any(key.startswith('boundary_') and key != 'boundary_convention' and not key.startswith('boundary_inside_') for key in scores):
         raise ValueError(f'{label}: tolerance metrics must use tolerance_boundary_ prefix')
 
 
 def audit_model_protocol(model, locked_digest):
     if 'W_selection_test' in model:
         raise ValueError('New models cannot contain legacy TEST W selection')
-    expected = dict(schema_version=2, metrics_schema_version=2,
+    if model.get('schema_version') not in (2, 3):
+        raise ValueError('Model schema_version: expected schema2/3 TRAIN protocol')
+    if model['schema_version'] == 3:
+        mode = model.get('endpoint_mode')
+        if mode not in ('core', 'enhanced'):
+            raise ValueError('Model endpoint_mode: unknown endpoint mode')
+        expected_policy = dict(minimum_speech_ms=0. if mode == 'core' else 100.,
+                               minimum_silence_ms=200., boundary_convention='union of active frame supports')
+        if any(model.get(key) != value for key, value in expected_policy.items()):
+            raise ValueError('Model endpoint policy fields disagree with mode')
+        if mode == 'core' and (model.get('endpoint_noise') is not None or
+                                model.get('padding_stage') != 'excluded from core FINAL'):
+            raise ValueError('Core endpoint policy cannot apply noise or padding')
+        if mode == 'enhanced' and (model.get('endpoint_noise') is None or
+                                    model.get('padding_stage') not in ('none', 'candidate diagnostics only')):
+            raise ValueError('Enhanced endpoint policy requires TRAIN noise and candidate-only padding')
+        if 'W_selection_train' in model:
+            selection = model['W_selection_train']
+            policy_keys = ('endpoint_mode', 'boundary_convention', 'minimum_speech_ms',
+                           'minimum_silence_ms', 'padding_stage')
+            if any(selection.get(key) != model.get(key) for key in policy_keys):
+                raise ValueError('TRAIN W selection policy differs from model policy')
+            if any(model.get(key) != selection.get('selected_W') for key in ('W', 'finalW')):
+                raise ValueError('TRAIN selected W differs from locked model')
+            if selection.get('calibration_digest') != model.get('calibration_digest'):
+                raise ValueError('TRAIN selection calibration digest differs from model')
+        declared = model.get('calibration_digest')
+        if not isinstance(declared, str) or not re.fullmatch('[0-9a-f]{64}', declared):
+            raise ValueError('Model calibration digest must be a nonempty SHA256')
+        payload = copy.deepcopy(model)
+        payload.pop('calibration_digest', None)
+        if 'W_selection_train' in payload:
+            payload['W_selection_train'].pop('calibration_digest', None)
+        computed = hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False,
+                                             allow_nan=False).encode('utf-8')).hexdigest()
+        if computed != declared:
+            raise ValueError('Model calibration digest differs from self-excluded calibration')
+    expected = dict(metrics_schema_version=2,
                     parameter_selection_set='train', evaluation_protocol='train_selected_reused_test',
                     historical_test_exposure=True)
     for key, value in expected.items():
         if model.get(key) != value:
             raise ValueError(f'Model {key}: expected schema2 TRAIN protocol ({value})')
     if set(model.get('training_files', [])) != set(TRAIN_NAMES) or len(model.get('training_files', [])) != 4:
         raise ValueError('Model training_files must contain exactly four TRAIN names')
     if model_digest(model) != locked_digest:
@@ -133,17 +180,18 @@ def audit_train_sweep(audit):
             or set(selection.get('evaluated_files', [])) != set(TRAIN_NAMES)
             or len(selection.get('evaluated_files', [])) != 4):
         raise ValueError('TT2 selection must use exactly four TRAIN files and TRAIN FINAL calibration')
     if selection.get('candidate_W') != list(range(1, 51)) or selection.get('tie_preference_W') != 20:
         raise ValueError('TT2 selection requires integer W1…50 and declared tie preference W20')
     keys = {(row['filename'], row['W']) for row in rows}
     if keys != {(name, float(w)) for name in TRAIN_NAMES for w in range(1, 51)} or len(keys) != 200:
         raise ValueError('TT2 TRAIN sweep rows must be unique and cover all 200 file/W pairs')
-    target = ROOT / 'outputs/tables/tt2_w_selection'
+    target = ((endpoint_mode_root(model['endpoint_mode'], ROOT / 'outputs') / 'tables/tt2_w_selection')
+              if model.get('schema_version') == 3 else ROOT / 'outputs/tables/tt2_w_selection')
     reference = read_csv(target / 'sweep.csv')
     if len(reference) != 200:
         raise ValueError('Python TRAIN sweep benchmark needs 200 rows; regenerate schema2 artifacts')
     reference = {(row['filename'], float(row['W'])): row for row in reference}
     if set(reference) != keys:
         raise ValueError('Python TRAIN sweep file/W manifest differs')
     for row in rows:
         baseline = reference[row['filename'], row['W']]
@@ -184,16 +232,22 @@ def audit_test_summary(algorithm, results, summary_rows):
     summary = summary_rows[0]
     audit_metric_keys(summary, f'{algorithm}/TEST summary', require_primary=False)
     if (summary.get('metrics_schema_version') != 2
             or summary.get('evaluation_protocol') != 'train_selected_reused_test'
             or summary.get('historical_test_exposure') is not True):
         raise ValueError(f'{algorithm}: TEST summary must disclose schema2 reused TEST protocol')
     if summary.get('algorithm') != algorithm:
         raise ValueError(f'{algorithm}: wrong algorithm in TEST summary')
+    if 'endpoint_mode' in summary:
+        from app.pipeline import summarize
+        mode = summary['endpoint_mode']
+        expected = summarize([dict(file=result['file'],algorithm=algorithm,**result['metrics']) for result in results])
+        compare_structure(summary, expected[0], 'TEST summary')
+        return
     scores = [result['metrics'] for result in results]
     valid = [score for score in scores if score['mae_ms'] is not None]
     ordered = sorted(score['mae_ms'] for score in valid)
     count = len(valid)
     correct = sum(score['ground_truth_region_count'] == score['predicted_region_count']
                   for score in scores)
     expected_counts = {
         'files': len(scores), 'evaluated_files': count,
@@ -226,31 +280,56 @@ def audit_test_summary(algorithm, results, summary_rows):
     highest = sorted((result for result in results if result['metrics']['mae_ms'] is not None),
                      key=lambda result: result['metrics']['mae_ms'], reverse=True)[:3]
     expected_top = '; '.join(f"{result['file']}:{result['metrics']['mae_ms']:.2f}ms" for result in highest)
     if summary.get('top_mae_files') != expected_top:
         raise ValueError(f'{algorithm}: highest-error TEST list differs from actual results')
 
 
 def audit_results(audit):
+    if 'models' in audit:
+        required = {'core', 'enhanced'}
+        for key in ('models', 'model_lock_digests', 'tt2_w_sweeps', 'test_results_by_mode', 'all_results_by_mode', 'test_summaries_by_mode'):
+            if set(audit.get(key, {})) != required:
+                raise ValueError('Both endpoint modes must have independent model/result evidence')
+        selected = audit.get('selected_mode')
+        if selected not in required:
+            raise ValueError('Invalid selected endpoint mode')
+        means = {}
+        for mode in ('core', 'enhanced'):
+            if audit['models'][mode].get('endpoint_mode') != mode:
+                raise ValueError('Model mode index disagrees with model')
+            item = dict(audit)
+            item.pop('models')
+            item.update(model=audit['models'][mode],model_lock_digest=audit['model_lock_digests'][mode],
+                        tt2_w_sweep_rows=audit['tt2_w_sweeps'][mode],test_results=audit['test_results_by_mode'][mode],
+                        all_results=audit['all_results_by_mode'][mode],test_summary=audit['test_summaries_by_mode'][mode])
+            means[mode] = audit_results(item)
+        for key, expected in (('model',audit['models'][selected]),('model_lock_digest',audit['model_lock_digests'][selected]),
+                              ('test_results',audit['test_results_by_mode'][selected]),('all_results',audit['all_results_by_mode'][selected]),
+                              ('test_summary',audit['test_summaries_by_mode'][selected]),('tt2_w_sweep_rows',audit['tt2_w_sweeps'][selected])):
+            compare_structure(audit.get(key),expected,'Selected mode alias/'+key)
+        return means[selected]
     algorithm = audit['algorithm']
     if algorithm not in ('tt1', 'tt2', 'tt3'):
         raise ValueError('Only three primary algorithms are submitted')
     model = audit['model']
     audit_model_protocol(model, audit.get('model_lock_digest'))
+    mode = model.get('endpoint_mode', 'enhanced')
+    output_root = endpoint_mode_root(mode, ROOT / 'outputs') if model.get('schema_version') == 3 else ROOT / 'outputs'
     test = audit['test_results']
     all_results = audit['all_results']
     if tuple(result['file'] for result in test) != TEST_NAMES:
         raise ValueError('Notebook must evaluate all four test WAVs in the declared order')
     expected_names = {path.stem for split in ('train', 'test')
                       for path in (ROOT / 'data' / split).glob('*.wav')}
     if len(all_results) != 8 or {result['file'] for result in all_results} != expected_names:
         raise ValueError('All-dataset evaluation must include eight unique WAVs')
     reference = {row['file']: row for row in read_csv(
-        ROOT / 'outputs/tables/all_all_dataset/test_metrics.csv') if row['algorithm'] == algorithm}
+        output_root / 'tables/all_all_dataset/test_metrics.csv') if row['algorithm'] == algorithm}
     for result in all_results + test:
         name = result['file']
         row = reference[name]
         if result['algorithm'] != algorithm:
             raise ValueError('Wrong algorithm in notebook result')
         scores = result['metrics']
         audit_metric_keys(scores, f'{algorithm}/{name}')
         if set(scores) != set(row) - {'file', 'split', 'algorithm'}:
@@ -260,25 +339,29 @@ def audit_results(audit):
                 raise ValueError(f'{algorithm}/{name}: missing schema2 benchmark metric {key}')
             if isinstance(value, bool):
                 if str(value).casefold() != row[key].casefold():
                     raise ValueError(f'{algorithm}/{name}/{key} differs')
             elif value is None or isinstance(value, (int, float)):
                 close_number(value, row[key], f'{algorithm}/{name}/{key}')
             elif str(value) != row[key]:
                 raise ValueError(f'{algorithm}/{name}/{key} differs')
-        diagnostic = json.loads((ROOT / f'outputs/diagnostics/{algorithm}/{name}.json').read_text(encoding='utf-8'))
+        if model.get('schema_version') == 3 and result['diagnostic'].get('endpoint_mode') != mode:
+            raise ValueError('Result endpoint mode disagrees with model')
+        diagnostic = json.loads((output_root / f'diagnostics/{algorithm}/{name}.json').read_text(encoding='utf-8'))
         compare_structure(result['final_regions'], diagnostic['final_regions'],
                           f'{algorithm}/{name}/final regions')
         compare_structure(result['predicted_boundaries'],
                           [edge for region in diagnostic['final_regions'] for edge in region],
                           f'{algorithm}/{name}/predicted boundaries')
+        if model.get('schema_version') == 3:
+            compare_structure(result['diagnostic'], diagnostic, f'{algorithm}/{name}/mode diagnostic')
         for key in ('low_ste_threshold', 'high_ste_threshold'):
             close_number(result['diagnostic'][key], diagnostic[key], f'{algorithm}/{name}/{key}', 1e-12)
-    original = json.loads((ROOT / f'outputs/models/{algorithm}.json').read_text(encoding='utf-8'))
+    original = json.loads((output_root / f'models/{algorithm}.json').read_text(encoding='utf-8'))
     audit_model_protocol(original, model_digest(original))
     compare_structure(model, original, f'{algorithm}/model/source/framing/noise')
     if algorithm == 'tt2':
         audit_train_sweep(audit)
     elif audit.get('tt2_w_sweep_rows') != []:
         raise ValueError('Non-histogram notebooks cannot contain a W sweep')
     manifest = audit['dataset_manifest']
     if len(manifest) != 8:
@@ -287,17 +370,17 @@ def audit_results(audit):
             {('train', name) for name in TRAIN_NAMES} | {('test', name) for name in TEST_NAMES}):
         raise ValueError('Input provenance must contain eight unique correctly split files')
     for entry in manifest:
         for extension, key in (('wav', 'wav_sha256'), ('lab', 'lab_sha256')):
             path = ROOT / 'data' / entry['split'] / f"{entry['file']}.{extension}"
             if hashlib.sha256(path.read_bytes()).hexdigest() != entry[key]:
                 raise ValueError(f'Input fingerprint differs: {path.name}')
     audit_test_summary(algorithm, test, audit.get('test_summary'))
-    saved_summary = [row for row in read_csv(ROOT / 'outputs/tables/all/summary.csv')
+    saved_summary = [row for row in read_csv(output_root / 'tables/all/summary.csv')
                      if row['algorithm'] == algorithm]
     if len(saved_summary) != 1:
         raise ValueError('Python TEST benchmark needs one summary per algorithm')
     if set(audit['test_summary'][0]) != set(saved_summary[0]):
         raise ValueError('TEST saved summary metric keys differ')
     for key, value in audit['test_summary'][0].items():
         expected = saved_summary[0][key]
         if isinstance(value, bool):
@@ -377,16 +460,17 @@ def audit_notebook(notebook, filename):
 def execute_notebook(path):
     notebook = nbformat.read(path, as_version=4)
     # Re-execution always starts empty; a failed run does not overwrite the file.
     for cell in notebook.cells:
         if cell.cell_type == 'code':
             cell.outputs = []
             cell.execution_count = None
     notebook.cells.append(nbformat.v4.new_code_cell(AUDIT_CELL))
+    os.environ.pop('MPLBACKEND', None)  # fresh notebook kernels must render inline PNGs
     manager = KernelManager(kernel_name='python3')
     manager.kernel_spec.argv = [sys.executable, '-m', 'ipykernel_launcher', '-f', '{connection_file}']
     client = NotebookClient(notebook, km=manager, timeout=600,
                             resources={'metadata': {'path': str(path.parent)}},
                             allow_errors=False, record_timing=False)
     print(f'Executing {path.name} in a fresh kernel...', flush=True)
     try:
         notebook = client.execute()
@@ -402,17 +486,17 @@ def execute_notebook(path):
     if marker < 0:
         raise ValueError('Execution completed without auditable numerical results')
     evidence = json.loads(output_text[marker + len(AUDIT_PREFIX):].strip())
     notebook.cells.pop()  # Do not submit the external verification cell.
     evidence['code_source_sha256'] = code_source_digest(notebook)
     notebook.metadata['endpoint_execution'] = evidence
     images, mean = audit_notebook(notebook, path.name)
     nbformat.write(notebook, path)
-    print(f'{path.name}: 8/8 benchmark matches; {images} embedded plots; test mean MAE {mean:.2f} ms.', flush=True)
+    print(f'{path.name}: 16/16 mode/file benchmark matches; {images} embedded plots; test mean MAE {mean if mean is not None else 'N/A'} ms.', flush=True)
 
 
 def package_notebooks(group_number=None):
     """Use documented STTNhom placeholder until the actual group index is supplied."""
     notebooks = [NOTEBOOK_DIR / f'THUAT_TOAN_{number}.ipynb' for number in range(1, 4)]
     for path in notebooks:
         audit_notebook(nbformat.read(path, as_version=4), path.name)
     group = f'{int(group_number):02d}' if group_number is not None else 'STTNhom'
@@ -439,16 +523,16 @@ def main():
     parser.add_argument('--group-number', type=int, help='Optional actual group index for STTnhom-TenDeTai folder naming')
     arguments = parser.parse_args()
     if arguments.group_number is not None and not 1 <= arguments.group_number <= 999:
         parser.error('--group-number must be between 1 and 999')
     for number in range(1, 4):
         path = NOTEBOOK_DIR / f'THUAT_TOAN_{number}.ipynb'
         if arguments.validate_only:
             images, mean = audit_notebook(nbformat.read(path, as_version=4), path.name)
-            print(f'{path.name}: saved outputs valid, {images} figures, test mean MAE {mean:.2f} ms.')
+            print(f'{path.name}: saved outputs valid, {images} figures, test mean MAE {mean if mean is not None else 'N/A'} ms.')
         else:
             execute_notebook(path)
     package_notebooks(arguments.group_number)
 
 
 if __name__ == '__main__':
     main()
Actual generated artifacts: outputs/endpoint_modes/*; outputs/tables/endpoint_modes_oct07/{baseline.json,final_verification.json,final_*.csv,timing_research/*}; notebook ZIP. Numeric/image/base64 serialization omitted from this source review package. Notebook codecell diffs below are ordered exact source text; inspect saved JSON/CSV/notebook/ZIP via bounded checks if needed.
diff --git "a/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\final-THUAT_TOAN_1.ipynb.oldcode.txt" "b/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\final-THUAT_TOAN_1.ipynb.newcode.txt"
index 23ea100..8e35fb9 100644
--- "a/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\final-THUAT_TOAN_1.ipynb.oldcode.txt"
+++ "b/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\final-THUAT_TOAN_1.ipynb.newcode.txt"
@@ -4,16 +4,17 @@ import hashlib
 import json
 import html
 from pathlib import Path
 
 import matplotlib.pyplot as plt
 from IPython.display import HTML, display
 
 ALGORITHM = 'tt1'
+MODE = "enhanced"  # selected mode for the four plots and illustration
 FRAME_MS = 25.0
 HOP_MS = 10.0
 SAMPLE_ROUNDING = "nearest_integer_samples_python_round_ties_to_even"
 MIN_SILENCE_SECONDS = 0.200
 MIN_SPEECH_SECONDS = 0.100
 BOUNDARY_TOLERANCE_SECONDS = 0.100
 HISTOGRAM_W_TIE_PREFERENCE = 20.0
 PADDING_MS = 250.0
@@ -748,41 +749,68 @@ def prepare_records(audio_records):
         features = compute_features(base["samples"], base["sample_rate"],
                                     FRAME_MS, HOP_MS)
         record = dict(base, features=features,
                       labels=frame_labels(features["centers"], base["intervals"]))
         records.append(record)
     return records
 
 
+def algorithm_decision(algorithm: str, features: dict, params: dict) -> tuple[list[int], dict]:
+    """Return native unpadded decisions and thresholds without LAB or endpoint policy.
+
+    TT1/high TT3 include equality; low TT3 includes equality in the opposite
+    direction. TT2 uses strict raw Energy > threshold (context uses STE).
+    Existing TT2 padding diagnostics describe its candidate stage only.
+    """
+    if algorithm != ALGORITHM:
+        raise ValueError('This notebook contains only ' + ALGORITHM)
+    mask, diagnostic = (predict(features, params), dict(threshold=params['threshold']))
+    source_histogram = False and diagnostic.get('variant') == 'source'
+    diagnostic.update(native_threshold=params['threshold'], native_threshold_units='mean squared sample amplitude' if source_histogram else 'normalized STE')
+    return (mask, diagnostic)
+
 def detect_regions(algorithm, features, duration, params):
     """Detect FINAL regions from features, duration and a fitted model."""
     # Input: frame features/supports, duration and fitted model; Output: FINAL regions, mask and diagnostics.
     if algorithm != ALGORITHM:
         raise ValueError('This notebook contains only ' + ALGORITHM)
-    # TT1 compares normalized STE with the TRAIN binary-search threshold. Require TRAIN noise before inference.
-    noise = params.get('endpoint_noise')
-    if noise is None:
+    # The enhanced 100 ms support-span filter is a heuristic; core keeps native speech supports.
+    mode = params.get('endpoint_mode', 'enhanced')
+    if mode not in ('core', 'enhanced'):
+        raise ValueError(f'Unknown endpoint_mode: {mode}')
+    # TT1 compares normalized STE with the TRAIN binary-search threshold. Enhanced requires TRAIN noise; core uses native decisions.
+    noise = params.get('endpoint_noise') if mode == 'enhanced' else None
+    if mode == 'enhanced' and noise is None:
         raise ValueError('Fitted model requires endpoint_noise; call fit_training_model on TRAIN before inference')
-    if False and params.get('speech_direction', 'high') != 'high':
+    if mode == 'enhanced' and False and (params.get('speech_direction', 'high') != 'high'):
         raise ValueError("FINAL endpoint detection requires TT3 speech_direction='high'; inverted/unknown directions are not supported by energy hysteresis")
-    mask, diagnostic = (predict(features, params), {'threshold': params['threshold']})
+    seed, diagnostic = algorithm_decision(algorithm, features, params)
+    source_histogram = False and params.get('variant', 'source') == 'source'
+    mask = pad_speech(seed, diagnostic['padding_frames']) if mode == 'enhanced' and source_histogram else seed
     # Retain candidate supports for inspection; only FINAL regions produce endpoint scores.
     candidate_regions = [(s, e) for s, e, state in mask_segments(mask, features['starts'], duration, features['ends']) if state]
-    source_histogram = False and params.get('variant', 'source') == 'source'
+    if mode == 'core':
+        final_regions = []
+        for start, end in candidate_regions:
+            if final_regions and start - final_regions[-1][1] < MIN_SILENCE_SECONDS - 1e-12:
+                final_regions[-1] = (final_regions[-1][0], end)
+            else:
+                final_regions.append((start, end))
+        mask = regions_to_mask(final_regions, features['starts'], features['ends'])
+        diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, low_ste_threshold=None, high_ste_threshold=None, endpoint_noise=None, minimum_speech_ms=0.0, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_mode=mode, geometry='union of active frame supports', final_padding_ms=0.0, padding_stage='excluded from core FINAL', endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding')
+        return dict(mask=mask, final_regions=final_regions, diagnostic=diagnostic, predicted_boundaries=[b for region in final_regions for b in region])
     # Use the TRAIN normalized STE threshold and raw classifier seed.
     base_threshold = params['threshold']
-    seed = mask
+    # Confirm with HIGH and continue above LOW; merge estimated support gaps below 200 ms.
     # Derive LOW/HIGH from the threshold and TRAIN silence noise statistics.
     low, high = endpoint_thresholds(base_threshold, noise, histogram=False)
-    # Confirm with HIGH and continue above LOW; merge estimated support gaps below 200 ms.
     final_regions = hysteresis_regions(features['ste_norm'], features['starts'], features['ends'], duration, low, high, MIN_SILENCE_SECONDS, MIN_SPEECH_SECONDS, seed_mask=seed)
     mask = regions_to_mask(final_regions, features['starts'], features['ends'])
-    diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, low_ste_threshold=low, high_ste_threshold=high, endpoint_noise=noise, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_policy='raw STE hysteresis; candidates/debug excluded; no fixed final padding')
-    # The 100 ms support-span filter is a heuristic; support bounds do not guarantee physical silence.
+    diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, endpoint_mode=mode, geometry='union of active frame supports', final_padding_ms=0.0, padding_stage='candidate diagnostics only' if source_histogram else 'none', low_ste_threshold=low, high_ste_threshold=high, endpoint_noise=noise, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_policy='raw STE hysteresis; candidates/debug excluded; no fixed final padding')
     return dict(mask=mask, final_regions=final_regions, diagnostic=diagnostic, predicted_boundaries=[b for region in final_regions for b in region])
 
 def predict_and_score(algorithm, record, params):
     """Invoke LAB-free detection, then score complete regions and frames.
 
     Input: algorithm, prepared annotated record, fitted TRAIN parameters.
     Output: detection plus reference regions, metrics and scoring status.
     LAB and filename enter only after detect_regions has returned.
@@ -825,97 +853,115 @@ def predict_and_score(algorithm, record, params):
     frames = frame_metrics(record['labels'], mask)
     events = boundary_metrics(expected_boundaries, predicted_boundaries, BOUNDARY_TOLERANCE_SECONDS)
     scores.update({f'frame_{key}': value for key, value in frames.items()})
     scores.update({f'tolerance_boundary_{key}': value for key, value in events.items() if key != 'pairs'})
     scores.update(gt_start_s=reference[0] if reference else None, gt_end_s=reference[1] if reference else None, predicted_start_s=predicted[0] if predicted else None, predicted_end_s=predicted[1] if predicted else None)
     # Retain provenance for imported historical models; fresh fits record TRAIN selection.
     legacy_test_tuned = False and 'W_selection_test' in params
     scores.update(metrics_schema_version=2, model_schema_version=params.get('schema_version', 1), parameter_selection_set='test' if legacy_test_tuned else params.get('parameter_selection_set', 'train'), evaluation_protocol='test_tuned_not_independent' if legacy_test_tuned else params.get('evaluation_protocol', 'train_selected_reused_test'), historical_test_exposure=True if legacy_test_tuned else params.get('historical_test_exposure', True))
+    scores.update(endpoint_mode=params.get('endpoint_mode', 'enhanced'), boundary_convention=params.get('boundary_convention', diagnostic.get('geometry')), minimum_speech_ms=diagnostic.get('minimum_speech_ms'), minimum_silence_ms=diagnostic.get('minimum_silence_ms'), padding_stage=diagnostic.get('padding_stage'), final_padding_ms=diagnostic.get('final_padding_ms'), frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, actual_frame_ms=record['features'].get('frame_ms'), actual_hop_ms=record['features'].get('hop_ms'), frame_samples=record['features'].get('frame_size'), hop_samples=record['features'].get('hop_size'))
     # Output: FINAL detection, reference regions, scores, status and original detector diagnostics.
     return dict(file=record['name'], algorithm=algorithm, mask=mask, metrics=scores, final_regions=final_regions, ground_truth_regions=expected_regions, region_pairs=region_scores['region_pairs'], predicted_boundaries=predicted_boundaries, ground_truth_boundaries=expected_boundaries, diagnostic=diagnostic)
 
-def fit_training_model(algorithm, train_records):
+def fit_training_model(algorithm, train_records, *, endpoint_mode='enhanced'):
     """Fit and lock parameters and FINAL W from supplied prepared TRAIN only.
 
     Input: prepared records with explicit split=train; array records need no
     path and support future folds. Known TEST/external paths are rejected.
-    Output: (schema-v2 model, FINAL W sweep rows), empty rows for other methods.
+    Output: (schema-v3 model, FINAL W sweep rows), empty rows for other methods.
     No files are loaded here, including during the histogram calibration.
-    TT3 must fit speech-high for the current FINAL energy hysteresis.
+    Enhanced TT3 must fit speech-high for FINAL energy hysteresis; core
+    retains either native Gaussian decision direction.
     """
     # Validate supplied TRAIN provenance before fitting; TEST reads occur after model locking.
     if algorithm != ALGORITHM:
         raise ValueError('This notebook contains only ' + ALGORITHM)
+    if endpoint_mode not in ('core', 'enhanced'):
+        raise ValueError(f'Unknown endpoint_mode: {endpoint_mode}')
     if not train_records:
         raise ValueError('fit_training_model requires TRAIN records')
     for record in train_records:
         if record.get('split') != 'train':
             raise ValueError('Training records require explicit TRAIN provenance (split=train)')
         if 'wav_path' in record and Path(record['wav_path']).resolve().parent != (DATA_ROOT / 'train').resolve():
             raise ValueError('Training record path must belong to TRAIN, never TEST/external')
     # Fit the normalized STE binary-search threshold from labeled TRAIN frames.
     model = fit(train_records)
-    model.update(schema_version=2, metrics_schema_version=2, parameter_selection_set='train', evaluation_protocol='train_selected_reused_test', historical_test_exposure=True, training_files=[record['name'] for record in train_records], frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, endpoint_noise=fit_noise_floor(train_records), endpoint_policy='hysteresis final regions; no fixed final padding', boundary_convention='union of active frame supports')
-    # Output: schema-v2 model with TRAIN silence noise and provenance; no W sweep for this method.
+    model.update(schema_version=3, metrics_schema_version=2, endpoint_mode=endpoint_mode, parameter_selection_set='train', evaluation_protocol='train_selected_reused_test', historical_test_exposure=True, training_files=[record['name'] for record in train_records], frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000, minimum_speech_ms=0.0 if endpoint_mode == 'core' else MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_noise=fit_noise_floor(train_records) if endpoint_mode == 'enhanced' else None, endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding' if endpoint_mode == 'core' else 'hysteresis final regions; no fixed final padding', feature_rule='normalized STE', decision_rule='STE <= threshold' if model.get('speech_direction') == 'low' else 'STE >= threshold', padding_stage='excluded from core FINAL' if endpoint_mode == 'core' else 'none', boundary_convention='union of active frame supports')
+    # Output: schema-v3 model with mode policy and TRAIN provenance; no W sweep for this method.
     sweep_rows = []
+    digest = hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False, allow_nan=False).encode('utf-8')).hexdigest()
+    model['calibration_digest'] = digest
     return (model, sweep_rows)
 
 def summarize(metrics):
     """Tổng hợp metric từng thuật toán, phân biệt mean file và pooled RMSE.
 
     Input: metrics là rows endpoint/frame của từng file. Output: rows mean
     MAE/RMSE, pooled endpoint RMSE, F1 và số file có metric không xác định;
-    metric không xác định được loại khỏi mean và được đếm rõ.
+    primary mean chỉ xác định khi mọi file hợp lệ; mean subset được ghi riêng.
     """
     rows = []
-    for algorithm in dict.fromkeys(row["algorithm"] for row in metrics):
-        selected = [row for row in metrics if row["algorithm"] == algorithm]
-        valid = [row for row in selected if row["mae_ms"] is not None]
+    for algorithm, mode in dict.fromkeys((row["algorithm"], row.get("endpoint_mode", "enhanced")) for row in metrics):
+        selected = [row for row in metrics if row["algorithm"] == algorithm and row.get("endpoint_mode", "enhanced") == mode]
+        valid = [row for row in selected if row["mae_ms"] is not None
+                 and row.get("ground_truth_region_count") == row.get("predicted_region_count")]
         squared=sum(row.get('endpoint_squared_error_ms2',(row['rmse_ms']**2)*2) for row in valid)
         error_count=sum(row.get('endpoint_error_count',2) for row in valid)
         ordered=sorted(row['mae_ms'] for row in valid)
         median=(ordered[len(ordered)//2] if len(ordered)%2 else (ordered[len(ordered)//2-1]+ordered[len(ordered)//2])/2) if ordered else None
         count_correct=sum(row.get('ground_truth_region_count')==row.get('predicted_region_count') for row in selected)
-        rows.append(dict(algorithm=algorithm, metrics_schema_version=2,
+        rows.append(dict(algorithm=algorithm, endpoint_mode=mode, metrics_schema_version=2,
                          files=len(selected), evaluated_files=len(valid),
                          missing_speech_files=len(selected) - len(valid),
-                         mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,
-                         mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,
-                         pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,
+                         mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,
+                         valid_files_mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,
+                         mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,
+                         valid_files_mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,
+                         pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count and len(valid)==len(selected) else None,
+                         valid_files_pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,
                          median_file_mae_ms=median,min_file_mae_ms=min(ordered) if ordered else None,max_file_mae_ms=max(ordered) if ordered else None,
                          region_count_correct_files=count_correct,region_count_incorrect_files=len(selected)-count_correct,
                          top_mae_files='; '.join(f"{r['file']}:{r['mae_ms']:.2f}ms" for r in sorted(valid,key=lambda r:r['mae_ms'],reverse=True)[:3]),
                          parameter_selection_set=selected[0].get('parameter_selection_set','train'),
                          evaluation_protocol=selected[0].get('evaluation_protocol','train_selected_reused_test'),
                          historical_test_exposure=selected[0].get('historical_test_exposure', True),
                          mean_frame_f1=sum(row["frame_f1"] for row in selected) / len(selected)))
     return rows
 
 DATA_ROOT = find_data_root(DATA_DIR)
 TRAIN_RECORDS = prepare_records(load_dataset_folder(DATA_ROOT, "train"))
 
-MODEL, TT2W_SWEEP_ROWS = fit_training_model(ALGORITHM, TRAIN_RECORDS)
+MODELS, TT2W_SWEEPS = {}, {}
+for endpoint_mode in ("core", "enhanced"):
+    MODELS[endpoint_mode], TT2W_SWEEPS[endpoint_mode] = fit_training_model(
+        ALGORITHM, TRAIN_RECORDS, endpoint_mode=endpoint_mode)
+MODEL, TT2W_SWEEP_ROWS = MODELS[MODE], TT2W_SWEEPS[MODE]
 
 parameter_names = ['threshold', 'silence_count', 'speech_count', 'overlap_low', 'overlap_high', 'iterations', 'stop_reason', 'area_residual', 'overlap_silence_count', 'overlap_speech_count']
 parameter_rows = [dict(parameter=key, value=MODEL.get(key)) for key in parameter_names]
 parameter_rows.extend(dict(parameter=key, value=value)
-                      for key, value in MODEL["endpoint_noise"].items())
+                      for key, value in (MODEL["endpoint_noise"] or {}).items())
 display_table(parameter_rows, [("parameter", "Parameter"), ("value", "Freshly computed value")],
               "Training parameters and train-only noise calibration")
 
 def model_digest(model):
     return hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False,
                                      allow_nan=False, separators=(",", ":")).encode("utf-8")).hexdigest()
 
-MODEL_LOCK_DIGEST = model_digest(MODEL)
+MODEL_LOCK_DIGESTS = {mode: model_digest(model) for mode, model in MODELS.items()}
+MODEL_LOCK_DIGEST = MODEL_LOCK_DIGESTS[MODE]
 
 def assert_model_locked():
-    if model_digest(MODEL) != MODEL_LOCK_DIGEST:
-        raise ValueError("Frozen TRAIN model digest changed after calibration")
+    for mode, model in MODELS.items():
+        if model.get("endpoint_mode") != mode or model_digest(model) != MODEL_LOCK_DIGESTS[mode]:
+            raise ValueError("Frozen TRAIN model digest or mode changed after calibration")
+    if MODEL is not MODELS[MODE] or model_digest(MODEL) != MODEL_LOCK_DIGEST:
+        raise ValueError("Selected model alias changed after calibration")
 
 print("MODEL locked before TEST reads:", MODEL_LOCK_DIGEST)
 
 assert_model_locked()
 TEST_RECORDS = prepare_records(load_dataset_folder(DATA_ROOT, "test"))
 TEST_RECORDS.sort(key=lambda r: FILE_ORDER.index(r["name"]) if r["name"] in FILE_ORDER else len(FILE_ORDER))
 ALL_RECORDS = TRAIN_RECORDS + TEST_RECORDS
 DATASET_MANIFEST = [dict(file=r["name"], split=r["split"],
@@ -974,41 +1020,53 @@ if BINARY_TRACE:
     axes[0].legend()
     axes[1].plot(iterations, [row["area_before"] for row in BINARY_TRACE], "o-")
     axes[1].axhline(0, color="black", linewidth=0.7)
     axes[1].set(xlabel="Iteration", ylabel="Silence area - speech area", title="Confusion-area residual")
     figure.tight_layout()
     plt.show()
     plt.close(figure)
 
-TEST_RESULTS = [predict_and_score(ALGORITHM, record, MODEL) for record in TEST_RECORDS]
+TEST_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in TEST_RECORDS]
+                        for mode, model in MODELS.items()}
 assert_model_locked()
-ALL_RESULTS = [predict_and_score(ALGORITHM, record, MODEL) for record in ALL_RECORDS]
+ALL_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in ALL_RECORDS]
+                       for mode, model in MODELS.items()}
 assert_model_locked()
+TEST_RESULTS, ALL_RESULTS = TEST_RESULTS_BY_MODE[MODE], ALL_RESULTS_BY_MODE[MODE]
 
 def metric_rows(records, results):
     return [dict(file=record["name"], split=record["split"], algorithm=ALGORITHM,
                  **result["metrics"])
             for record, result in zip(records, results)]
 
-TEST_METRIC_ROWS = metric_rows(TEST_RECORDS, TEST_RESULTS)
-ALL_METRIC_ROWS = metric_rows(ALL_RECORDS, ALL_RESULTS)
-TEST_SUMMARY = summarize(TEST_METRIC_ROWS)
+TEST_METRICS_BY_MODE = {mode: metric_rows(TEST_RECORDS, results) for mode, results in TEST_RESULTS_BY_MODE.items()}
+ALL_METRICS_BY_MODE = {mode: metric_rows(ALL_RECORDS, results) for mode, results in ALL_RESULTS_BY_MODE.items()}
+TEST_SUMMARIES_BY_MODE = {mode: summarize(rows) for mode, rows in TEST_METRICS_BY_MODE.items()}
+TEST_METRIC_ROWS = [row for rows in TEST_METRICS_BY_MODE.values() for row in rows]
+ALL_METRIC_ROWS = [row for rows in ALL_METRICS_BY_MODE.values() for row in rows]
+TEST_SUMMARY = TEST_SUMMARIES_BY_MODE[MODE]
 METRIC_COLUMNS = [
-    ("file", "File"), ("split", "Split"),
+    ("file", "File"), ("split", "Split"), ("endpoint_mode", "Mode"),
     ("ground_truth_region_count", "GT regions"), ("predicted_region_count", "Pred regions"),
     ("mae_ms", "Final MAE (ms)"), ("rmse_ms", "RMSE (ms)"), ("status", "Status"),
     ("start_error_ms", "Signed START error (ms)"), ("end_error_ms", "Signed END error (ms)"),
     ("gt_start_s", "GT START (s)"), ("gt_end_s", "GT END (s)"),
     ("predicted_start_s", "Pred START (s)"), ("predicted_end_s", "Pred END (s)")
 ]
-display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings: final confirmed boundaries")
+display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings in each mode: FINAL-region endpoints")
+THRESHOLD_ROWS = [dict(file=result["file"], endpoint_mode=mode,
+                      **{key:result["diagnostic"].get(key) for key in
+                         ("native_threshold", "native_threshold_units", "low_ste_threshold", "high_ste_threshold",
+                          "geometry", "minimum_speech_ms", "padding_stage")})
+                  for mode, results in ALL_RESULTS_BY_MODE.items() for result in results]
+display_table(THRESHOLD_ROWS, [(key,key) for key in THRESHOLD_ROWS[0]], "Both-mode threshold and geometry diagnostics")
 
-display_table(TEST_SUMMARY,
-              [("algorithm", "Algorithm"), ("files", "Files"),
+display_table([row for rows in TEST_SUMMARIES_BY_MODE.values() for row in rows],
+              [("algorithm", "Algorithm"), ("endpoint_mode", "Mode"), ("files", "Files"),
                ("evaluated_files", "Defined MAE files"), ("mean_file_mae_ms", "Mean MAE (ms)"),
                ("median_file_mae_ms", "Median (ms)"), ("min_file_mae_ms", "Min (ms)"),
                ("max_file_mae_ms", "Max (ms)"), ("mean_file_rmse_ms", "Mean file RMSE (ms)"),
                ("pooled_endpoint_rmse_ms", "Pooled endpoint RMSE (ms)"),
                ("region_count_correct_files", "Correct counts"),
                ("region_count_incorrect_files", "Incorrect counts"),
                ("mean_frame_f1", "Mean frame F1"), ("top_mae_files", "Highest MAE files"),
                ("evaluation_protocol", "Protocol")],
@@ -1024,37 +1082,42 @@ def plot_record(record, result):
     mae_text = f"{mae:.2f} ms" if mae is not None else "N/A"
     figure, axes = plt.subplots(2, 1, figsize=(12.5, 5.5), sharex=True,
                                gridspec_kw={"height_ratios": [1, 1.25]})
     time = [index / record["sample_rate"] for index in range(len(record["samples"]))]
     axes[0].plot(time, record["samples"], color="#444444", linewidth=0.6)
     axes[0].set_ylabel("PCM amplitude")
     axes[1].plot(features["centers"], features["ste_norm"], color="#263238",
                  linewidth=1, label="Normalized STE")
-    axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060",
-                   linestyle="--", linewidth=1.2, label="LOW")
-    axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700",
-                   linestyle=":", linewidth=1.4, label="HIGH")
+    if diagnostic["endpoint_mode"] == "core":
+        native = diagnostic["native_threshold"]
+        if diagnostic["native_threshold_units"] == "mean squared sample amplitude":
+            peak = max(features["energy"], default=0.)
+            native = native / peak if peak else 0.
+        axes[1].axhline(native, color="#9b6700", linestyle=":", label="Native T (display normalized)")
+    else:
+        axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060", linestyle="--", label="LOW")
+        axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700", linestyle=":", label="HIGH")
     for axis in axes:
         for index, (start, end) in enumerate(result["ground_truth_regions"]):
             axis.axvspan(start, end, color="red", alpha=0.05)
             axis.axvline(start, color="red", linestyle="--", linewidth=1.25,
                         label="GT boundary" if index == 0 else None)
             axis.axvline(end, color="red", linestyle="--", linewidth=1.25)
         for index, (start, end) in enumerate(result["final_regions"]):
             axis.axvspan(start, end, color="#1769d2", alpha=0.11)
             axis.axvline(start, color="#1769d2", linewidth=1.4,
                         label="FINAL predicted boundary" if index == 0 else None)
             axis.axvline(end, color="#1769d2", linewidth=1.4)
         axis.grid(alpha=0.16)
         axis.set_xlim(0, record["duration"])
     axes[1].set_ylabel("Normalized STE")
     axes[1].set_xlabel("Time (s)")
     axes[1].legend(loc="upper right", fontsize=8, ncol=3)
-    figure.suptitle(f"{record['name']}.wav | Outer boundary MAE: {mae_text} | "
+    figure.suptitle(f"{record['name']}.wav | {MODE} | FINAL-region endpoint MAE: {mae_text} | "
                    f"{len(result['final_regions'])} speech regions")
     figure.tight_layout()
     plt.show()
     plt.close(figure)
 
 
 TEST_RECORDS_BY_FILE = {record["name"]: record for record in TEST_RECORDS}
 TEST_RESULTS_BY_FILE = {result["file"]: result for result in TEST_RESULTS}
diff --git "a/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\final-THUAT_TOAN_2.ipynb.oldcode.txt" "b/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\final-THUAT_TOAN_2.ipynb.newcode.txt"
index 65a9525..ef99c83 100644
--- "a/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\final-THUAT_TOAN_2.ipynb.oldcode.txt"
+++ "b/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\final-THUAT_TOAN_2.ipynb.newcode.txt"
@@ -4,16 +4,17 @@ import hashlib
 import json
 import html
 from pathlib import Path
 
 import matplotlib.pyplot as plt
 from IPython.display import HTML, display
 
 ALGORITHM = 'tt2'
+MODE = "enhanced"  # selected mode for the four plots and illustration
 FRAME_MS = 25.0
 HOP_MS = 10.0
 SAMPLE_ROUNDING = "nearest_integer_samples_python_round_ties_to_even"
 MIN_SILENCE_SECONDS = 0.200
 MIN_SPEECH_SECONDS = 0.100
 BOUNDARY_TOLERANCE_SECONDS = 0.100
 HISTOGRAM_W_TIE_PREFERENCE = 20.0
 PADDING_MS = 250.0
@@ -899,42 +900,71 @@ def prepare_records(audio_records):
         features = compute_features(base["samples"], base["sample_rate"],
                                     FRAME_MS, HOP_MS)
         record = dict(base, features=features,
                       labels=frame_labels(features["centers"], base["intervals"]))
         records.append(record)
     return records
 
 
+def algorithm_decision(algorithm: str, features: dict, params: dict) -> tuple[list[int], dict]:
+    """Return native unpadded decisions and thresholds without LAB or endpoint policy.
+
+    TT1/high TT3 include equality; low TT3 includes equality in the opposite
+    direction. TT2 uses strict raw Energy > threshold (context uses STE).
+    Existing TT2 padding diagnostics describe its candidate stage only.
+    """
+    if algorithm != ALGORITHM:
+        raise ValueError('This notebook contains only ' + ALGORITHM)
+    mask, diagnostic = predict(features, params)
+    if diagnostic['variant'] == 'source':
+        mask = [int(e > diagnostic['energy_threshold']) for e in features['energy']]
+    source_histogram = True and diagnostic.get('variant') == 'source'
+    diagnostic.update(native_threshold=diagnostic['energy_threshold'], native_threshold_units='mean squared sample amplitude' if source_histogram else 'normalized STE')
+    return (mask, diagnostic)
+
 def detect_regions(algorithm, features, duration, params):
     """Detect FINAL regions from features, duration and a fitted model."""
     # Input: frame features/supports, duration and fitted model; Output: FINAL regions, mask and diagnostics.
     if algorithm != ALGORITHM:
         raise ValueError('This notebook contains only ' + ALGORITHM)
-    # TT2 estimates raw energy threshold per file; padded masks remain candidate diagnostics. Require TRAIN noise before inference.
-    noise = params.get('endpoint_noise')
-    if noise is None:
+    # The enhanced 100 ms support-span filter is a heuristic; core keeps native speech supports.
+    mode = params.get('endpoint_mode', 'enhanced')
+    if mode not in ('core', 'enhanced'):
+        raise ValueError(f'Unknown endpoint_mode: {mode}')
+    # TT2 estimates raw energy threshold per file; padded masks remain candidate diagnostics. Enhanced requires TRAIN noise; core uses native decisions.
+    noise = params.get('endpoint_noise') if mode == 'enhanced' else None
+    if mode == 'enhanced' and noise is None:
         raise ValueError('Fitted model requires endpoint_noise; call fit_training_model on TRAIN before inference')
-    if False and params.get('speech_direction', 'high') != 'high':
+    if mode == 'enhanced' and False and (params.get('speech_direction', 'high') != 'high'):
         raise ValueError("FINAL endpoint detection requires TT3 speech_direction='high'; inverted/unknown directions are not supported by energy hysteresis")
-    mask, diagnostic = predict(features, params)
+    seed, diagnostic = algorithm_decision(algorithm, features, params)
+    source_histogram = True and params.get('variant', 'source') == 'source'
+    mask = pad_speech(seed, diagnostic['padding_frames']) if mode == 'enhanced' and source_histogram else seed
     # Retain candidate supports for inspection; only FINAL regions produce endpoint scores.
     candidate_regions = [(s, e) for s, e, state in mask_segments(mask, features['starts'], duration, features['ends']) if state]
-    source_histogram = True and params.get('variant', 'source') == 'source'
+    if mode == 'core':
+        final_regions = []
+        for start, end in candidate_regions:
+            if final_regions and start - final_regions[-1][1] < MIN_SILENCE_SECONDS - 1e-12:
+                final_regions[-1] = (final_regions[-1][0], end)
+            else:
+                final_regions.append((start, end))
+        mask = regions_to_mask(final_regions, features['starts'], features['ends'])
+        diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, low_ste_threshold=None, high_ste_threshold=None, endpoint_noise=None, minimum_speech_ms=0.0, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_mode=mode, geometry='union of active frame supports', final_padding_ms=0.0, padding_stage='excluded from core FINAL', endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding')
+        return dict(mask=mask, final_regions=final_regions, diagnostic=diagnostic, predicted_boundaries=[b for region in final_regions for b in region])
     peak = max(features['energy'], default=0.0)
     # Normalize TT2 raw energy threshold and seed from unpadded raw energy decisions.
     base_threshold = diagnostic['energy_threshold'] / peak if source_histogram and peak > 0 else diagnostic['energy_threshold'] if not source_histogram else 0.0
-    seed = [int(e > diagnostic['energy_threshold']) for e in features['energy']] if source_histogram else mask
+    # Confirm with HIGH and continue above LOW; merge estimated support gaps below 200 ms.
     # Derive LOW/HIGH from the threshold and TRAIN silence noise statistics.
     low, high = endpoint_thresholds(base_threshold, noise, histogram=True)
-    # Confirm with HIGH and continue above LOW; merge estimated support gaps below 200 ms.
     final_regions = hysteresis_regions(features['ste_norm'], features['starts'], features['ends'], duration, low, high, MIN_SILENCE_SECONDS, MIN_SPEECH_SECONDS, seed_mask=seed)
     mask = regions_to_mask(final_regions, features['starts'], features['ends'])
-    diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, low_ste_threshold=low, high_ste_threshold=high, endpoint_noise=noise, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_policy='raw STE hysteresis; candidates/debug excluded; no fixed final padding')
-    # The 100 ms support-span filter is a heuristic; support bounds do not guarantee physical silence.
+    diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, endpoint_mode=mode, geometry='union of active frame supports', final_padding_ms=0.0, padding_stage='candidate diagnostics only' if source_histogram else 'none', low_ste_threshold=low, high_ste_threshold=high, endpoint_noise=noise, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_policy='raw STE hysteresis; candidates/debug excluded; no fixed final padding')
     return dict(mask=mask, final_regions=final_regions, diagnostic=diagnostic, predicted_boundaries=[b for region in final_regions for b in region])
 
 def predict_and_score(algorithm, record, params):
     """Invoke LAB-free detection, then score complete regions and frames.
 
     Input: algorithm, prepared annotated record, fitted TRAIN parameters.
     Output: detection plus reference regions, metrics and scoring status.
     LAB and filename enter only after detect_regions has returned.
@@ -977,96 +1007,111 @@ def predict_and_score(algorithm, record, params):
     frames = frame_metrics(record['labels'], mask)
     events = boundary_metrics(expected_boundaries, predicted_boundaries, BOUNDARY_TOLERANCE_SECONDS)
     scores.update({f'frame_{key}': value for key, value in frames.items()})
     scores.update({f'tolerance_boundary_{key}': value for key, value in events.items() if key != 'pairs'})
     scores.update(gt_start_s=reference[0] if reference else None, gt_end_s=reference[1] if reference else None, predicted_start_s=predicted[0] if predicted else None, predicted_end_s=predicted[1] if predicted else None)
     # Retain provenance for imported historical models; fresh fits record TRAIN selection.
     legacy_test_tuned = True and 'W_selection_test' in params
     scores.update(metrics_schema_version=2, model_schema_version=params.get('schema_version', 1), parameter_selection_set='test' if legacy_test_tuned else params.get('parameter_selection_set', 'train'), evaluation_protocol='test_tuned_not_independent' if legacy_test_tuned else params.get('evaluation_protocol', 'train_selected_reused_test'), historical_test_exposure=True if legacy_test_tuned else params.get('historical_test_exposure', True))
+    scores.update(endpoint_mode=params.get('endpoint_mode', 'enhanced'), boundary_convention=params.get('boundary_convention', diagnostic.get('geometry')), minimum_speech_ms=diagnostic.get('minimum_speech_ms'), minimum_silence_ms=diagnostic.get('minimum_silence_ms'), padding_stage=diagnostic.get('padding_stage'), final_padding_ms=diagnostic.get('final_padding_ms'), frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, actual_frame_ms=record['features'].get('frame_ms'), actual_hop_ms=record['features'].get('hop_ms'), frame_samples=record['features'].get('frame_size'), hop_samples=record['features'].get('hop_size'))
     # Output: FINAL detection, reference regions, scores, status and original detector diagnostics.
     return dict(file=record['name'], algorithm=algorithm, mask=mask, metrics=scores, final_regions=final_regions, ground_truth_regions=expected_regions, region_pairs=region_scores['region_pairs'], predicted_boundaries=predicted_boundaries, ground_truth_boundaries=expected_boundaries, diagnostic=diagnostic)
 
-def fit_training_model(algorithm, train_records):
+def fit_training_model(algorithm, train_records, *, endpoint_mode='enhanced'):
     """Fit and lock parameters and FINAL W from supplied prepared TRAIN only.
 
     Input: prepared records with explicit split=train; array records need no
     path and support future folds. Known TEST/external paths are rejected.
-    Output: (schema-v2 model, FINAL W sweep rows), empty rows for other methods.
+    Output: (schema-v3 model, FINAL W sweep rows), empty rows for other methods.
     No files are loaded here, including during the histogram calibration.
-    TT3 must fit speech-high for the current FINAL energy hysteresis.
+    Enhanced TT3 must fit speech-high for FINAL energy hysteresis; core
+    retains either native Gaussian decision direction.
     """
     # Validate supplied TRAIN provenance before fitting; TEST reads occur after model locking.
     if algorithm != ALGORITHM:
         raise ValueError('This notebook contains only ' + ALGORITHM)
+    if endpoint_mode not in ('core', 'enhanced'):
+        raise ValueError(f'Unknown endpoint_mode: {endpoint_mode}')
     if not train_records:
         raise ValueError('fit_training_model requires TRAIN records')
     for record in train_records:
         if record.get('split') != 'train':
             raise ValueError('Training records require explicit TRAIN provenance (split=train)')
         if 'wav_path' in record and Path(record['wav_path']).resolve().parent != (DATA_ROOT / 'train').resolve():
             raise ValueError('Training record path must belong to TRAIN, never TEST/external')
     # Fit the candidate-frame histogram W proposal from TRAIN only.
     model = fit(train_records, variant='source')
-    model.update(schema_version=2, metrics_schema_version=2, parameter_selection_set='train', evaluation_protocol='train_selected_reused_test', historical_test_exposure=True, training_files=[record['name'] for record in train_records], frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, endpoint_noise=fit_noise_floor(train_records), endpoint_policy='hysteresis final regions; no fixed final padding', boundary_convention='union of active frame supports')
+    model.update(schema_version=3, metrics_schema_version=2, endpoint_mode=endpoint_mode, parameter_selection_set='train', evaluation_protocol='train_selected_reused_test', historical_test_exposure=True, training_files=[record['name'] for record in train_records], frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000, minimum_speech_ms=0.0 if endpoint_mode == 'core' else MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_noise=fit_noise_floor(train_records) if endpoint_mode == 'enhanced' else None, endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding' if endpoint_mode == 'core' else 'hysteresis final regions; no fixed final padding', feature_rule='Energy (mean squared sample amplitude)', decision_rule='Energy > threshold', padding_stage='excluded from core FINAL' if endpoint_mode == 'core' else 'candidate diagnostics only', boundary_convention='union of active frame supports')
     sweep_rows = []
-    # Preserve candidate F1 diagnostics beside schema-v2 TRAIN noise and provenance.
+    # Preserve candidate F1 diagnostics beside schema-v3 mode policy, enhanced TRAIN noise and provenance.
     model['candidate_frame_selected_W'] = model['W']
     model['candidate_frame_f1'] = model.pop('train_frame_f1')
     model['candidate_frame_selection_scores'] = [dict(W=row['W'], candidate_frame_f1=row['train_frame_f1'], **{key: value for key, value in row.items() if key not in ('W', 'train_frame_f1')}) for row in model.pop('selection_scores')]
     model['candidate_cleanup_records'] = {key: model.pop(key) for key in ('full_pipeline_records', 'predict_only_fallback_records')}
     model['candidate_frame_selection_applicable'] = True
     # Calibrate shared W on TRAIN FINAL regions; candidate F1 remains a separate diagnostic.
     selection, sweep_rows = sweep_final_weights(train_records, model, predict_and_score, tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE)
     model.update(W=selection['selected_W'], finalW=selection['selected_W'], tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE, W_selection_train=selection, parameter_rule=selection['selection_rule'])
+    digest = hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False, allow_nan=False).encode('utf-8')).hexdigest()
+    model['calibration_digest'] = digest
+    model['W_selection_train']['calibration_digest'] = digest
     # Return the TRAIN-selected reusable model and all 200 W/file calibration rows.
     return (model, sweep_rows)
 
 def summarize(metrics):
     """Tổng hợp metric từng thuật toán, phân biệt mean file và pooled RMSE.
 
     Input: metrics là rows endpoint/frame của từng file. Output: rows mean
     MAE/RMSE, pooled endpoint RMSE, F1 và số file có metric không xác định;
-    metric không xác định được loại khỏi mean và được đếm rõ.
+    primary mean chỉ xác định khi mọi file hợp lệ; mean subset được ghi riêng.
     """
     rows = []
-    for algorithm in dict.fromkeys(row["algorithm"] for row in metrics):
-        selected = [row for row in metrics if row["algorithm"] == algorithm]
-        valid = [row for row in selected if row["mae_ms"] is not None]
+    for algorithm, mode in dict.fromkeys((row["algorithm"], row.get("endpoint_mode", "enhanced")) for row in metrics):
+        selected = [row for row in metrics if row["algorithm"] == algorithm and row.get("endpoint_mode", "enhanced") == mode]
+        valid = [row for row in selected if row["mae_ms"] is not None
+                 and row.get("ground_truth_region_count") == row.get("predicted_region_count")]
         squared=sum(row.get('endpoint_squared_error_ms2',(row['rmse_ms']**2)*2) for row in valid)
         error_count=sum(row.get('endpoint_error_count',2) for row in valid)
         ordered=sorted(row['mae_ms'] for row in valid)
         median=(ordered[len(ordered)//2] if len(ordered)%2 else (ordered[len(ordered)//2-1]+ordered[len(ordered)//2])/2) if ordered else None
         count_correct=sum(row.get('ground_truth_region_count')==row.get('predicted_region_count') for row in selected)
-        rows.append(dict(algorithm=algorithm, metrics_schema_version=2,
+        rows.append(dict(algorithm=algorithm, endpoint_mode=mode, metrics_schema_version=2,
                          files=len(selected), evaluated_files=len(valid),
                          missing_speech_files=len(selected) - len(valid),
-                         mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,
-                         mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,
-                         pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,
+                         mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,
+                         valid_files_mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,
+                         mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,
+                         valid_files_mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,
+                         pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count and len(valid)==len(selected) else None,
+                         valid_files_pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,
                          median_file_mae_ms=median,min_file_mae_ms=min(ordered) if ordered else None,max_file_mae_ms=max(ordered) if ordered else None,
                          region_count_correct_files=count_correct,region_count_incorrect_files=len(selected)-count_correct,
                          top_mae_files='; '.join(f"{r['file']}:{r['mae_ms']:.2f}ms" for r in sorted(valid,key=lambda r:r['mae_ms'],reverse=True)[:3]),
                          parameter_selection_set=selected[0].get('parameter_selection_set','train'),
                          evaluation_protocol=selected[0].get('evaluation_protocol','train_selected_reused_test'),
                          historical_test_exposure=selected[0].get('historical_test_exposure', True),
                          mean_frame_f1=sum(row["frame_f1"] for row in selected) / len(selected)))
     return rows
 
 W_CANDIDATES = tuple(float(w) for w in range(1, 51))
 ERROR_EPS_MS = 1e-8
+POLICY_FIELDS = ("endpoint_mode", "boundary_convention", "minimum_speech_ms", "minimum_silence_ms", "padding_stage")
 
 def select_final_weight(rows,tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE):
     """Input: one MAE/count row per (W,file). Output: shared W and audit tables.
 
     Prefer valid region counts, then minimize the worst per-file loss relative
     to that file's own optimum, then mean MAE. Ties use the declared preference;
     if unavailable, choose the smallest W. No candidate/debug boundary is scored.
     """
     if not rows:raise ValueError('W selection needs evaluation rows')
+    policy={key:rows[0][key] for key in POLICY_FIELDS if key in rows[0]}
+    if any({key:row[key] for key in POLICY_FIELDS if key in row} != policy for row in rows):
+        raise ValueError('Each candidate W must use the same endpoint policy')
     grouped={}
     for row in rows:
         w=row['W'];name=row['filename'];mae=row['final_region_mae_ms']
         if not math.isfinite(w) or w<0 or (mae is not None and (not math.isfinite(mae) or mae<0)):
             raise ValueError('Invalid W or endpoint MAE')
         files=grouped.setdefault(w,{})
         if name in files:raise ValueError('Duplicate (W,filename) in selection')
         files[name]=row
@@ -1100,90 +1145,116 @@ def select_final_weight(rows,tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE):
         better=False;tied=True
         for left,right in zip(objectives,best_objectives):
             if left==right or (math.isfinite(left) and math.isfinite(right) and abs(left-right)<=ERROR_EPS_MS):continue
             better=left<right;tied=False;break
         if tied:
             better=(candidate['W']!=tie_preference_W,candidate['W'])<(chosen['W']!=tie_preference_W,chosen['W'])
         if better:chosen=candidate;best_objectives=objectives
     shared=set.intersection(*(set(v['optimal_W']) for v in best_by_file.values()))
-    return dict(selected_W=chosen['W'],tie_preference_W=tie_preference_W,selected_summary=chosen,
+    return dict(**policy,selected_W=chosen['W'],tie_preference_W=tie_preference_W,selected_summary=chosen,
         summaries=summaries,best_by_file=best_by_file,shared_optimal_W=sorted(shared),
         candidate_W=sorted(grouped),selection_set='train',evaluation_protocol='train_final_calibration',
         selection_rule='valid regions; minimum worst per-file regret; mean MAE; declared W preference on ties; smallest W otherwise')
 
 
 def sweep_final_weights(records,model,predictor,candidates=W_CANDIDATES,
                         tie_preference_W=HISTOGRAM_W_TIE_PREFERENCE):
     """Evaluate every W on all calibration files with the real endpoint pipeline.
 
     Input: annotated TRAIN records, fitted TRAIN/noise model, real predictor.
     Output: selection manifest and rows. Does not mutate records or model.
     """
     if not records:raise ValueError('W sweep needs annotated TRAIN recordings')
     if any(record.get('split')!='train' for record in records):
         raise ValueError('W sweep requires explicit TRAIN provenance (split=train)')
+    mode=model.get('endpoint_mode','enhanced')
+    if mode not in ('core','enhanced'):raise ValueError('Unknown endpoint_mode')
+    policy=dict(endpoint_mode=mode,
+        boundary_convention=model.get('boundary_convention','union of active frame supports'),
+        minimum_speech_ms=model.get('minimum_speech_ms',0. if mode=='core' else 100.),
+        minimum_silence_ms=model.get('minimum_silence_ms',model.get('minimum_internal_silence_ms',200.)),
+        padding_stage=model.get('padding_stage','excluded from core FINAL' if mode=='core' else 'candidate diagnostics only'))
     rows=[]
     for w in candidates:
         params=dict(model,W=float(w))
         for record in records:
             result=predictor('tt2',record,params);metrics=result['metrics'];diag=result['diagnostic']
-            rows.append(dict(filename=record['name'],W=float(w),
+            if diag.get('endpoint_mode','enhanced') != mode:
+                raise ValueError('Predictor endpoint_mode disagrees with calibration model')
+            if diag.get('geometry', policy['boundary_convention']) != policy['boundary_convention']:
+                raise ValueError('Predictor geometry disagrees with calibration boundary_convention')
+            for key in ('minimum_speech_ms','minimum_silence_ms','padding_stage'):
+                if key in diag and diag[key] != policy[key]:
+                    raise ValueError(f'Predictor {key} disagrees with calibration model')
+            rows.append(dict(**policy,filename=record['name'],W=float(w),
                 ground_truth_region_count=metrics['ground_truth_region_count'],predicted_region_count=metrics['predicted_region_count'],
                 final_region_mae_ms=metrics['mae_ms'],status=metrics['status'],
                 start_error_ms=metrics['start_error_ms'],end_error_ms=metrics['end_error_ms'],
                 energy_threshold=diag['energy_threshold'],
                 low_ste_threshold=diag['low_ste_threshold'],high_ste_threshold=diag['high_ste_threshold'],
                 raw_speech_frames=diag['raw_speech_frames'],candidate_region_count=len(diag['candidate_regions']),
                 final_regions=str(result['final_regions'])))
     result=select_final_weight(rows,tie_preference_W)
     result.update(evaluated_files=[record['name'] for record in records],
-                  endpoint_policy='fixed raw STE hysteresis; final START/END only; no padding endpoints',
+                  endpoint_policy=model.get('endpoint_policy','fixed raw STE hysteresis; final START/END only; no padding endpoints'),
                   note='W was calibrated using these TRAIN LABs; TEST has historical exposure and is reused for scoring, so no holdout independence is claimed.')
     return result,rows
 
 DATA_ROOT = find_data_root(DATA_DIR)
 TRAIN_RECORDS = prepare_records(load_dataset_folder(DATA_ROOT, "train"))
 
-MODEL, TT2W_SWEEP_ROWS = fit_training_model(ALGORITHM, TRAIN_RECORDS)
+MODELS, TT2W_SWEEPS = {}, {}
+for endpoint_mode in ("core", "enhanced"):
+    MODELS[endpoint_mode], TT2W_SWEEPS[endpoint_mode] = fit_training_model(
+        ALGORITHM, TRAIN_RECORDS, endpoint_mode=endpoint_mode)
+MODEL, TT2W_SWEEP_ROWS = MODELS[MODE], TT2W_SWEEPS[MODE]
 
-# fit_training_model has selected FINAL W from supplied TRAIN records only.
-W_SELECTION = MODEL["W_selection_train"]
-display_table(MODEL["candidate_frame_selection_scores"],
-              [("W", "TRAIN candidate W"), ("candidate_frame_f1", "Candidate frame F1"),
-               ("tp", "TP"), ("fp", "FP"), ("fn", "FN")],
-              f"TRAIN candidate-frame proposal: W={MODEL['candidate_frame_selected_W']:g}")
-display_table(W_SELECTION["summaries"],
-              [("W", "W"), ("invalid_files", "Invalid files"),
-               ("mean_MAE_ms", "Mean final MAE (ms)"), ("max_MAE_ms", "Max MAE (ms)"),
-               ("max_regret_ms", "Worst per-file regret (ms)")],
-              f"TRAIN FINAL calibration: all W=1…50; selected W={MODEL['W']:g}; tie preference W20")
-display_table(TT2W_SWEEP_ROWS,
-              [("filename", "TRAIN file"), ("W", "W"),
-               ("final_region_mae_ms", "FINAL region MAE (ms)"),
-               ("ground_truth_region_count", "GT regions"),
-               ("predicted_region_count", "FINAL regions"), ("status", "Status")],
-              "200 TRAIN FINAL calibration rows; PRIMARY MAE is separate from tolerance diagnostics")
+for mode in ('core', 'enhanced'):
+    MODEL, TT2W_SWEEP_ROWS = MODELS[mode], TT2W_SWEEPS[mode]
+    # fit_training_model has selected FINAL W from supplied TRAIN records only.
+    W_SELECTION = MODEL["W_selection_train"]
+    display_table(MODEL["candidate_frame_selection_scores"],
+                  [("W", "TRAIN candidate W"), ("candidate_frame_f1", "Candidate frame F1"),
+                   ("tp", "TP"), ("fp", "FP"), ("fn", "FN")],
+                  f"TRAIN candidate-frame proposal: W={MODEL['candidate_frame_selected_W']:g}")
+    display_table(W_SELECTION["summaries"],
+                  [("W", "W"), ("invalid_files", "Invalid files"),
+                   ("mean_MAE_ms", "Mean final MAE (ms)"), ("max_MAE_ms", "Max MAE (ms)"),
+                   ("max_regret_ms", "Worst per-file regret (ms)")],
+                  f"TRAIN FINAL calibration: all W=1…50; selected W={MODEL['W']:g}; tie preference W20")
+    display_table(TT2W_SWEEP_ROWS,
+                  [("filename", "TRAIN file"), ("W", "W"),
+                   ("final_region_mae_ms", "FINAL region MAE (ms)"),
+                   ("ground_truth_region_count", "GT regions"),
+                   ("predicted_region_count", "FINAL regions"), ("status", "Status")],
+                  "200 TRAIN FINAL calibration rows; PRIMARY MAE is separate from tolerance diagnostics")
+
+MODEL, TT2W_SWEEP_ROWS = MODELS[MODE], TT2W_SWEEPS[MODE]
 
 parameter_names = ['candidate_frame_selected_W', 'candidate_frame_f1', 'candidate_cleanup_records', 'W', 'finalW', 'tie_preference_W', 'bins', 'smooth_radius', 'padding_ms', 'padding_frames']
 parameter_rows = [dict(parameter=key, value=MODEL.get(key)) for key in parameter_names]
 parameter_rows.extend(dict(parameter=key, value=value)
-                      for key, value in MODEL["endpoint_noise"].items())
+                      for key, value in (MODEL["endpoint_noise"] or {}).items())
 display_table(parameter_rows, [("parameter", "Parameter"), ("value", "Freshly computed value")],
               "Training parameters and train-only noise calibration")
 
 def model_digest(model):
     return hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False,
                                      allow_nan=False, separators=(",", ":")).encode("utf-8")).hexdigest()
 
-MODEL_LOCK_DIGEST = model_digest(MODEL)
+MODEL_LOCK_DIGESTS = {mode: model_digest(model) for mode, model in MODELS.items()}
+MODEL_LOCK_DIGEST = MODEL_LOCK_DIGESTS[MODE]
 
 def assert_model_locked():
-    if model_digest(MODEL) != MODEL_LOCK_DIGEST:
-        raise ValueError("Frozen TRAIN model digest changed after calibration")
+    for mode, model in MODELS.items():
+        if model.get("endpoint_mode") != mode or model_digest(model) != MODEL_LOCK_DIGESTS[mode]:
+            raise ValueError("Frozen TRAIN model digest or mode changed after calibration")
+    if MODEL is not MODELS[MODE] or model_digest(MODEL) != MODEL_LOCK_DIGEST:
+        raise ValueError("Selected model alias changed after calibration")
 
 print("MODEL locked before TEST reads:", MODEL_LOCK_DIGEST)
 
 assert_model_locked()
 TEST_RECORDS = prepare_records(load_dataset_folder(DATA_ROOT, "test"))
 TEST_RECORDS.sort(key=lambda r: FILE_ORDER.index(r["name"]) if r["name"] in FILE_ORDER else len(FILE_ORDER))
 ALL_RECORDS = TRAIN_RECORDS + TEST_RECORDS
 DATASET_MANIFEST = [dict(file=r["name"], split=r["split"],
@@ -1229,41 +1300,53 @@ for label, value in (("M1", histogram_details["first_peak"]), ("M2", histogram_d
 axis.axvline(energy_threshold, color="blue", linewidth=1.5, label=f"Energy T={energy_threshold:.6g}")
 axis.set(xlabel="Mean square energy = STE / frame_size", ylabel="Smoothed frame count",
          title=f"phone_F2.wav | First two peaks by energy | W={MODEL['W']:g}")
 axis.legend(fontsize=8)
 figure.tight_layout()
 plt.show()
 plt.close(figure)
 
-TEST_RESULTS = [predict_and_score(ALGORITHM, record, MODEL) for record in TEST_RECORDS]
+TEST_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in TEST_RECORDS]
+                        for mode, model in MODELS.items()}
 assert_model_locked()
-ALL_RESULTS = [predict_and_score(ALGORITHM, record, MODEL) for record in ALL_RECORDS]
+ALL_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in ALL_RECORDS]
+                       for mode, model in MODELS.items()}
 assert_model_locked()
+TEST_RESULTS, ALL_RESULTS = TEST_RESULTS_BY_MODE[MODE], ALL_RESULTS_BY_MODE[MODE]
 
 def metric_rows(records, results):
     return [dict(file=record["name"], split=record["split"], algorithm=ALGORITHM,
                  **result["metrics"])
             for record, result in zip(records, results)]
 
-TEST_METRIC_ROWS = metric_rows(TEST_RECORDS, TEST_RESULTS)
-ALL_METRIC_ROWS = metric_rows(ALL_RECORDS, ALL_RESULTS)
-TEST_SUMMARY = summarize(TEST_METRIC_ROWS)
+TEST_METRICS_BY_MODE = {mode: metric_rows(TEST_RECORDS, results) for mode, results in TEST_RESULTS_BY_MODE.items()}
+ALL_METRICS_BY_MODE = {mode: metric_rows(ALL_RECORDS, results) for mode, results in ALL_RESULTS_BY_MODE.items()}
+TEST_SUMMARIES_BY_MODE = {mode: summarize(rows) for mode, rows in TEST_METRICS_BY_MODE.items()}
+TEST_METRIC_ROWS = [row for rows in TEST_METRICS_BY_MODE.values() for row in rows]
+ALL_METRIC_ROWS = [row for rows in ALL_METRICS_BY_MODE.values() for row in rows]
+TEST_SUMMARY = TEST_SUMMARIES_BY_MODE[MODE]
 METRIC_COLUMNS = [
-    ("file", "File"), ("split", "Split"),
+    ("file", "File"), ("split", "Split"), ("endpoint_mode", "Mode"),
     ("ground_truth_region_count", "GT regions"), ("predicted_region_count", "Pred regions"),
     ("mae_ms", "Final MAE (ms)"), ("rmse_ms", "RMSE (ms)"), ("status", "Status"),
     ("start_error_ms", "Signed START error (ms)"), ("end_error_ms", "Signed END error (ms)"),
     ("gt_start_s", "GT START (s)"), ("gt_end_s", "GT END (s)"),
     ("predicted_start_s", "Pred START (s)"), ("predicted_end_s", "Pred END (s)")
 ]
-display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings: final confirmed boundaries")
+display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings in each mode: FINAL-region endpoints")
+THRESHOLD_ROWS = [dict(file=result["file"], endpoint_mode=mode,
+                      **{key:result["diagnostic"].get(key) for key in
+                         ("native_threshold", "native_threshold_units", "low_ste_threshold", "high_ste_threshold",
+                          "geometry", "minimum_speech_ms", "padding_stage")})
+                  for mode, results in ALL_RESULTS_BY_MODE.items() for result in results]
+display_table(THRESHOLD_ROWS, [(key,key) for key in THRESHOLD_ROWS[0]], "Both-mode threshold and geometry diagnostics")
 
-display_table(TEST_SUMMARY,
-              [("algorithm", "Algorithm"), ("files", "Files"),
+display_table([row for rows in TEST_SUMMARIES_BY_MODE.values() for row in rows],
+              [("algorithm", "Algorithm"), ("endpoint_mode", "Mode"), ("files", "Files"),
                ("evaluated_files", "Defined MAE files"), ("mean_file_mae_ms", "Mean MAE (ms)"),
                ("median_file_mae_ms", "Median (ms)"), ("min_file_mae_ms", "Min (ms)"),
                ("max_file_mae_ms", "Max (ms)"), ("mean_file_rmse_ms", "Mean file RMSE (ms)"),
                ("pooled_endpoint_rmse_ms", "Pooled endpoint RMSE (ms)"),
                ("region_count_correct_files", "Correct counts"),
                ("region_count_incorrect_files", "Incorrect counts"),
                ("mean_frame_f1", "Mean frame F1"), ("top_mae_files", "Highest MAE files"),
                ("evaluation_protocol", "Protocol")],
@@ -1279,37 +1362,42 @@ def plot_record(record, result):
     mae_text = f"{mae:.2f} ms" if mae is not None else "N/A"
     figure, axes = plt.subplots(2, 1, figsize=(12.5, 5.5), sharex=True,
                                gridspec_kw={"height_ratios": [1, 1.25]})
     time = [index / record["sample_rate"] for index in range(len(record["samples"]))]
     axes[0].plot(time, record["samples"], color="#444444", linewidth=0.6)
     axes[0].set_ylabel("PCM amplitude")
     axes[1].plot(features["centers"], features["ste_norm"], color="#263238",
                  linewidth=1, label="Normalized STE")
-    axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060",
-                   linestyle="--", linewidth=1.2, label="LOW")
-    axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700",
-                   linestyle=":", linewidth=1.4, label="HIGH")
+    if diagnostic["endpoint_mode"] == "core":
+        native = diagnostic["native_threshold"]
+        if diagnostic["native_threshold_units"] == "mean squared sample amplitude":
+            peak = max(features["energy"], default=0.)
+            native = native / peak if peak else 0.
+        axes[1].axhline(native, color="#9b6700", linestyle=":", label="Native T (display normalized)")
+    else:
+        axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060", linestyle="--", label="LOW")
+        axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700", linestyle=":", label="HIGH")
     for axis in axes:
         for index, (start, end) in enumerate(result["ground_truth_regions"]):
             axis.axvspan(start, end, color="red", alpha=0.05)
             axis.axvline(start, color="red", linestyle="--", linewidth=1.25,
                         label="GT boundary" if index == 0 else None)
             axis.axvline(end, color="red", linestyle="--", linewidth=1.25)
         for index, (start, end) in enumerate(result["final_regions"]):
             axis.axvspan(start, end, color="#1769d2", alpha=0.11)
             axis.axvline(start, color="#1769d2", linewidth=1.4,
                         label="FINAL predicted boundary" if index == 0 else None)
             axis.axvline(end, color="#1769d2", linewidth=1.4)
         axis.grid(alpha=0.16)
         axis.set_xlim(0, record["duration"])
     axes[1].set_ylabel("Normalized STE")
     axes[1].set_xlabel("Time (s)")
     axes[1].legend(loc="upper right", fontsize=8, ncol=3)
-    figure.suptitle(f"{record['name']}.wav | Outer boundary MAE: {mae_text} | "
+    figure.suptitle(f"{record['name']}.wav | {MODE} | FINAL-region endpoint MAE: {mae_text} | "
                    f"{len(result['final_regions'])} speech regions")
     figure.tight_layout()
     plt.show()
     plt.close(figure)
 
 
 TEST_RECORDS_BY_FILE = {record["name"]: record for record in TEST_RECORDS}
 TEST_RESULTS_BY_FILE = {result["file"]: result for result in TEST_RESULTS}
diff --git "a/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\final-THUAT_TOAN_3.ipynb.oldcode.txt" "b/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\final-THUAT_TOAN_3.ipynb.newcode.txt"
index 190da2c..bf2704c 100644
--- "a/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\final-THUAT_TOAN_3.ipynb.oldcode.txt"
+++ "b/.superpowers\\sdd\\2026-10-07-algorithm-baseline-and-endpoint-review\\final-THUAT_TOAN_3.ipynb.newcode.txt"
@@ -4,16 +4,17 @@ import hashlib
 import json
 import html
 from pathlib import Path
 
 import matplotlib.pyplot as plt
 from IPython.display import HTML, display
 
 ALGORITHM = 'tt3'
+MODE = "enhanced"  # selected mode for the four plots and illustration
 FRAME_MS = 25.0
 HOP_MS = 10.0
 SAMPLE_ROUNDING = "nearest_integer_samples_python_round_ties_to_even"
 MIN_SILENCE_SECONDS = 0.200
 MIN_SPEECH_SECONDS = 0.100
 BOUNDARY_TOLERANCE_SECONDS = 0.100
 HISTOGRAM_W_TIE_PREFERENCE = 20.0
 PADDING_MS = 250.0
@@ -757,41 +758,70 @@ def prepare_records(audio_records):
         features = compute_features(base["samples"], base["sample_rate"],
                                     FRAME_MS, HOP_MS)
         record = dict(base, features=features,
                       labels=frame_labels(features["centers"], base["intervals"]))
         records.append(record)
     return records
 
 
+def algorithm_decision(algorithm: str, features: dict, params: dict) -> tuple[list[int], dict]:
+    """Return native unpadded decisions and thresholds without LAB or endpoint policy.
+
+    TT1/high TT3 include equality; low TT3 includes equality in the opposite
+    direction. TT2 uses strict raw Energy > threshold (context uses STE).
+    Existing TT2 padding diagnostics describe its candidate stage only.
+    """
+    if algorithm != ALGORITHM:
+        raise ValueError('This notebook contains only ' + ALGORITHM)
+    if params.get('speech_direction', 'high') not in ('high', 'low'):
+        raise ValueError('Unknown TT3 speech_direction')
+    mask, diagnostic = (predict(features, params), dict(threshold=params['threshold']))
+    source_histogram = False and diagnostic.get('variant') == 'source'
+    diagnostic.update(native_threshold=params['threshold'], native_threshold_units='mean squared sample amplitude' if source_histogram else 'normalized STE')
+    return (mask, diagnostic)
+
 def detect_regions(algorithm, features, duration, params):
     """Detect FINAL regions from features, duration and a fitted model."""
     # Input: frame features/supports, duration and fitted model; Output: FINAL regions, mask and diagnostics.
     if algorithm != ALGORITHM:
         raise ValueError('This notebook contains only ' + ALGORITHM)
-    # TT3 raw classification supports both directions; FINAL rejects explicit low/unknown models. Require TRAIN noise before inference.
-    noise = params.get('endpoint_noise')
-    if noise is None:
+    # The enhanced 100 ms support-span filter is a heuristic; core keeps native speech supports.
+    mode = params.get('endpoint_mode', 'enhanced')
+    if mode not in ('core', 'enhanced'):
+        raise ValueError(f'Unknown endpoint_mode: {mode}')
+    # TT3 raw classification supports both directions; enhanced FINAL rejects low/unknown models; core retains native high/low direction. Enhanced requires TRAIN noise; core uses native decisions.
+    noise = params.get('endpoint_noise') if mode == 'enhanced' else None
+    if mode == 'enhanced' and noise is None:
         raise ValueError('Fitted model requires endpoint_noise; call fit_training_model on TRAIN before inference')
-    if True and params.get('speech_direction', 'high') != 'high':
+    if mode == 'enhanced' and True and (params.get('speech_direction', 'high') != 'high'):
         raise ValueError("FINAL endpoint detection requires TT3 speech_direction='high'; inverted/unknown directions are not supported by energy hysteresis")
-    mask, diagnostic = (predict(features, params), {'threshold': params['threshold']})
+    seed, diagnostic = algorithm_decision(algorithm, features, params)
+    source_histogram = False and params.get('variant', 'source') == 'source'
+    mask = pad_speech(seed, diagnostic['padding_frames']) if mode == 'enhanced' and source_histogram else seed
     # Retain candidate supports for inspection; only FINAL regions produce endpoint scores.
     candidate_regions = [(s, e) for s, e, state in mask_segments(mask, features['starts'], duration, features['ends']) if state]
-    source_histogram = False and params.get('variant', 'source') == 'source'
+    if mode == 'core':
+        final_regions = []
+        for start, end in candidate_regions:
+            if final_regions and start - final_regions[-1][1] < MIN_SILENCE_SECONDS - 1e-12:
+                final_regions[-1] = (final_regions[-1][0], end)
+            else:
+                final_regions.append((start, end))
+        mask = regions_to_mask(final_regions, features['starts'], features['ends'])
+        diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, low_ste_threshold=None, high_ste_threshold=None, endpoint_noise=None, minimum_speech_ms=0.0, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_mode=mode, geometry='union of active frame supports', final_padding_ms=0.0, padding_stage='excluded from core FINAL', endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding')
+        return dict(mask=mask, final_regions=final_regions, diagnostic=diagnostic, predicted_boundaries=[b for region in final_regions for b in region])
     # Use the TRAIN normalized STE threshold and raw classifier seed.
     base_threshold = params['threshold']
-    seed = mask
+    # Confirm with HIGH and continue above LOW; merge estimated support gaps below 200 ms.
     # Derive LOW/HIGH from the threshold and TRAIN silence noise statistics.
     low, high = endpoint_thresholds(base_threshold, noise, histogram=False)
-    # Confirm with HIGH and continue above LOW; merge estimated support gaps below 200 ms.
     final_regions = hysteresis_regions(features['ste_norm'], features['starts'], features['ends'], duration, low, high, MIN_SILENCE_SECONDS, MIN_SPEECH_SECONDS, seed_mask=seed)
     mask = regions_to_mask(final_regions, features['starts'], features['ends'])
-    diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, low_ste_threshold=low, high_ste_threshold=high, endpoint_noise=noise, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_policy='raw STE hysteresis; candidates/debug excluded; no fixed final padding')
-    # The 100 ms support-span filter is a heuristic; support bounds do not guarantee physical silence.
+    diagnostic.update(candidate_regions=candidate_regions, final_regions=final_regions, endpoint_mode=mode, geometry='union of active frame supports', final_padding_ms=0.0, padding_stage='candidate diagnostics only' if source_histogram else 'none', low_ste_threshold=low, high_ste_threshold=high, endpoint_noise=noise, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_policy='raw STE hysteresis; candidates/debug excluded; no fixed final padding')
     return dict(mask=mask, final_regions=final_regions, diagnostic=diagnostic, predicted_boundaries=[b for region in final_regions for b in region])
 
 def predict_and_score(algorithm, record, params):
     """Invoke LAB-free detection, then score complete regions and frames.
 
     Input: algorithm, prepared annotated record, fitted TRAIN parameters.
     Output: detection plus reference regions, metrics and scoring status.
     LAB and filename enter only after detect_regions has returned.
@@ -834,99 +864,117 @@ def predict_and_score(algorithm, record, params):
     frames = frame_metrics(record['labels'], mask)
     events = boundary_metrics(expected_boundaries, predicted_boundaries, BOUNDARY_TOLERANCE_SECONDS)
     scores.update({f'frame_{key}': value for key, value in frames.items()})
     scores.update({f'tolerance_boundary_{key}': value for key, value in events.items() if key != 'pairs'})
     scores.update(gt_start_s=reference[0] if reference else None, gt_end_s=reference[1] if reference else None, predicted_start_s=predicted[0] if predicted else None, predicted_end_s=predicted[1] if predicted else None)
     # Retain provenance for imported historical models; fresh fits record TRAIN selection.
     legacy_test_tuned = False and 'W_selection_test' in params
     scores.update(metrics_schema_version=2, model_schema_version=params.get('schema_version', 1), parameter_selection_set='test' if legacy_test_tuned else params.get('parameter_selection_set', 'train'), evaluation_protocol='test_tuned_not_independent' if legacy_test_tuned else params.get('evaluation_protocol', 'train_selected_reused_test'), historical_test_exposure=True if legacy_test_tuned else params.get('historical_test_exposure', True))
+    scores.update(endpoint_mode=params.get('endpoint_mode', 'enhanced'), boundary_convention=params.get('boundary_convention', diagnostic.get('geometry')), minimum_speech_ms=diagnostic.get('minimum_speech_ms'), minimum_silence_ms=diagnostic.get('minimum_silence_ms'), padding_stage=diagnostic.get('padding_stage'), final_padding_ms=diagnostic.get('final_padding_ms'), frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, actual_frame_ms=record['features'].get('frame_ms'), actual_hop_ms=record['features'].get('hop_ms'), frame_samples=record['features'].get('frame_size'), hop_samples=record['features'].get('hop_size'))
     # Output: FINAL detection, reference regions, scores, status and original detector diagnostics.
     return dict(file=record['name'], algorithm=algorithm, mask=mask, metrics=scores, final_regions=final_regions, ground_truth_regions=expected_regions, region_pairs=region_scores['region_pairs'], predicted_boundaries=predicted_boundaries, ground_truth_boundaries=expected_boundaries, diagnostic=diagnostic)
 
-def fit_training_model(algorithm, train_records):
+def fit_training_model(algorithm, train_records, *, endpoint_mode='enhanced'):
     """Fit and lock parameters and FINAL W from supplied prepared TRAIN only.
 
     Input: prepared records with explicit split=train; array records need no
     path and support future folds. Known TEST/external paths are rejected.
-    Output: (schema-v2 model, FINAL W sweep rows), empty rows for other methods.
+    Output: (schema-v3 model, FINAL W sweep rows), empty rows for other methods.
     No files are loaded here, including during the histogram calibration.
-    TT3 must fit speech-high for the current FINAL energy hysteresis.
+    Enhanced TT3 must fit speech-high for FINAL energy hysteresis; core
+    retains either native Gaussian decision direction.
     """
     # Validate supplied TRAIN provenance before fitting; TEST reads occur after model locking.
     if algorithm != ALGORITHM:
         raise ValueError('This notebook contains only ' + ALGORITHM)
+    if endpoint_mode not in ('core', 'enhanced'):
+        raise ValueError(f'Unknown endpoint_mode: {endpoint_mode}')
     if not train_records:
         raise ValueError('fit_training_model requires TRAIN records')
     for record in train_records:
         if record.get('split') != 'train':
             raise ValueError('Training records require explicit TRAIN provenance (split=train)')
         if 'wav_path' in record and Path(record['wav_path']).resolve().parent != (DATA_ROOT / 'train').resolve():
             raise ValueError('Training record path must belong to TRAIN, never TEST/external')
-    # Fit robust centered/scaled Gaussian crossings; reject a non-high model before FINAL reuse.
+    # Fit robust centered/scaled Gaussian crossings; enhanced rejects non-high models; core preserves native direction.
     model = fit(train_records)
-    if model.get('speech_direction', 'high') != 'high':
+    if endpoint_mode == 'enhanced' and model.get('speech_direction', 'high') != 'high':
         raise ValueError("FINAL endpoint detection requires TT3 speech_direction='high'; TRAIN speech mean is below silence mean")
-    model.update(schema_version=2, metrics_schema_version=2, parameter_selection_set='train', evaluation_protocol='train_selected_reused_test', historical_test_exposure=True, training_files=[record['name'] for record in train_records], frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000, minimum_speech_ms=MIN_SPEECH_SECONDS * 1000, endpoint_noise=fit_noise_floor(train_records), endpoint_policy='hysteresis final regions; no fixed final padding', boundary_convention='union of active frame supports')
-    # Output: schema-v2 model with TRAIN silence noise and provenance; no W sweep for this method.
+    model.update(schema_version=3, metrics_schema_version=2, endpoint_mode=endpoint_mode, parameter_selection_set='train', evaluation_protocol='train_selected_reused_test', historical_test_exposure=True, training_files=[record['name'] for record in train_records], frame_ms=FRAME_MS, hop_ms=HOP_MS, sample_rounding=SAMPLE_ROUNDING, minimum_internal_silence_ms=MIN_SILENCE_SECONDS * 1000, minimum_speech_ms=0.0 if endpoint_mode == 'core' else MIN_SPEECH_SECONDS * 1000, minimum_silence_ms=MIN_SILENCE_SECONDS * 1000, endpoint_noise=fit_noise_floor(train_records) if endpoint_mode == 'enhanced' else None, endpoint_policy='native decisions; merge internal support gaps below 200 ms; no duration filter or final padding' if endpoint_mode == 'core' else 'hysteresis final regions; no fixed final padding', feature_rule='normalized STE', decision_rule='STE <= threshold' if model.get('speech_direction') == 'low' else 'STE >= threshold', padding_stage='excluded from core FINAL' if endpoint_mode == 'core' else 'none', boundary_convention='union of active frame supports')
+    # Output: schema-v3 model with mode policy and TRAIN provenance; no W sweep for this method.
     sweep_rows = []
+    digest = hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False, allow_nan=False).encode('utf-8')).hexdigest()
+    model['calibration_digest'] = digest
     return (model, sweep_rows)
 
 def summarize(metrics):
     """Tổng hợp metric từng thuật toán, phân biệt mean file và pooled RMSE.
 
     Input: metrics là rows endpoint/frame của từng file. Output: rows mean
     MAE/RMSE, pooled endpoint RMSE, F1 và số file có metric không xác định;
-    metric không xác định được loại khỏi mean và được đếm rõ.
+    primary mean chỉ xác định khi mọi file hợp lệ; mean subset được ghi riêng.
     """
     rows = []
-    for algorithm in dict.fromkeys(row["algorithm"] for row in metrics):
-        selected = [row for row in metrics if row["algorithm"] == algorithm]
-        valid = [row for row in selected if row["mae_ms"] is not None]
+    for algorithm, mode in dict.fromkeys((row["algorithm"], row.get("endpoint_mode", "enhanced")) for row in metrics):
+        selected = [row for row in metrics if row["algorithm"] == algorithm and row.get("endpoint_mode", "enhanced") == mode]
+        valid = [row for row in selected if row["mae_ms"] is not None
+                 and row.get("ground_truth_region_count") == row.get("predicted_region_count")]
         squared=sum(row.get('endpoint_squared_error_ms2',(row['rmse_ms']**2)*2) for row in valid)
         error_count=sum(row.get('endpoint_error_count',2) for row in valid)
         ordered=sorted(row['mae_ms'] for row in valid)
         median=(ordered[len(ordered)//2] if len(ordered)%2 else (ordered[len(ordered)//2-1]+ordered[len(ordered)//2])/2) if ordered else None
         count_correct=sum(row.get('ground_truth_region_count')==row.get('predicted_region_count') for row in selected)
-        rows.append(dict(algorithm=algorithm, metrics_schema_version=2,
+        rows.append(dict(algorithm=algorithm, endpoint_mode=mode, metrics_schema_version=2,
                          files=len(selected), evaluated_files=len(valid),
                          missing_speech_files=len(selected) - len(valid),
-                         mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,
-                         mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,
-                         pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,
+                         mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,
+                         valid_files_mean_file_mae_ms=sum(row["mae_ms"] for row in valid) / len(valid) if valid else None,
+                         mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid and len(valid)==len(selected) else None,
+                         valid_files_mean_file_rmse_ms=sum(row["rmse_ms"] for row in valid) / len(valid) if valid else None,
+                         pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count and len(valid)==len(selected) else None,
+                         valid_files_pooled_endpoint_rmse_ms=math.sqrt(squared/error_count) if error_count else None,
                          median_file_mae_ms=median,min_file_mae_ms=min(ordered) if ordered else None,max_file_mae_ms=max(ordered) if ordered else None,
                          region_count_correct_files=count_correct,region_count_incorrect_files=len(selected)-count_correct,
                          top_mae_files='; '.join(f"{r['file']}:{r['mae_ms']:.2f}ms" for r in sorted(valid,key=lambda r:r['mae_ms'],reverse=True)[:3]),
                          parameter_selection_set=selected[0].get('parameter_selection_set','train'),
                          evaluation_protocol=selected[0].get('evaluation_protocol','train_selected_reused_test'),
                          historical_test_exposure=selected[0].get('historical_test_exposure', True),
                          mean_frame_f1=sum(row["frame_f1"] for row in selected) / len(selected)))
     return rows
 
 DATA_ROOT = find_data_root(DATA_DIR)
 TRAIN_RECORDS = prepare_records(load_dataset_folder(DATA_ROOT, "train"))
 
-MODEL, TT2W_SWEEP_ROWS = fit_training_model(ALGORITHM, TRAIN_RECORDS)
+MODELS, TT2W_SWEEPS = {}, {}
+for endpoint_mode in ("core", "enhanced"):
+    MODELS[endpoint_mode], TT2W_SWEEPS[endpoint_mode] = fit_training_model(
+        ALGORITHM, TRAIN_RECORDS, endpoint_mode=endpoint_mode)
+MODEL, TT2W_SWEEP_ROWS = MODELS[MODE], TT2W_SWEEPS[MODE]
 
 parameter_names = ['muSil', 'stdSil', 'muSp', 'stdSp', 'silence_count', 'speech_count', 'threshold', 'threshold_rule', 'speech_direction', 'sigma_floor', 'sigma_was_floored']
 parameter_rows = [dict(parameter=key, value=MODEL.get(key)) for key in parameter_names]
 parameter_rows.extend(dict(parameter=key, value=value)
-                      for key, value in MODEL["endpoint_noise"].items())
+                      for key, value in (MODEL["endpoint_noise"] or {}).items())
 display_table(parameter_rows, [("parameter", "Parameter"), ("value", "Freshly computed value")],
               "Training parameters and train-only noise calibration")
 
 def model_digest(model):
     return hashlib.sha256(json.dumps(model, sort_keys=True, ensure_ascii=False,
                                      allow_nan=False, separators=(",", ":")).encode("utf-8")).hexdigest()
 
-MODEL_LOCK_DIGEST = model_digest(MODEL)
+MODEL_LOCK_DIGESTS = {mode: model_digest(model) for mode, model in MODELS.items()}
+MODEL_LOCK_DIGEST = MODEL_LOCK_DIGESTS[MODE]
 
 def assert_model_locked():
-    if model_digest(MODEL) != MODEL_LOCK_DIGEST:
-        raise ValueError("Frozen TRAIN model digest changed after calibration")
+    for mode, model in MODELS.items():
+        if model.get("endpoint_mode") != mode or model_digest(model) != MODEL_LOCK_DIGESTS[mode]:
+            raise ValueError("Frozen TRAIN model digest or mode changed after calibration")
+    if MODEL is not MODELS[MODE] or model_digest(MODEL) != MODEL_LOCK_DIGEST:
+        raise ValueError("Selected model alias changed after calibration")
 
 print("MODEL locked before TEST reads:", MODEL_LOCK_DIGEST)
 
 assert_model_locked()
 TEST_RECORDS = prepare_records(load_dataset_folder(DATA_ROOT, "test"))
 TEST_RECORDS.sort(key=lambda r: FILE_ORDER.index(r["name"]) if r["name"] in FILE_ORDER else len(FILE_ORDER))
 ALL_RECORDS = TRAIN_RECORDS + TEST_RECORDS
 DATASET_MANIFEST = [dict(file=r["name"], split=r["split"],
@@ -969,41 +1017,53 @@ for axis, (lower, upper) in zip(axes, ranges):
     axis.grid(alpha=0.2)
     axis.legend(fontsize=8)
 axes[0].set_title("Fitted TRAIN Gaussian densities")
 axes[1].set_title("Threshold detail")
 figure.tight_layout()
 plt.show()
 plt.close(figure)
 
-TEST_RESULTS = [predict_and_score(ALGORITHM, record, MODEL) for record in TEST_RECORDS]
+TEST_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in TEST_RECORDS]
+                        for mode, model in MODELS.items()}
 assert_model_locked()
-ALL_RESULTS = [predict_and_score(ALGORITHM, record, MODEL) for record in ALL_RECORDS]
+ALL_RESULTS_BY_MODE = {mode: [predict_and_score(ALGORITHM, record, model) for record in ALL_RECORDS]
+                       for mode, model in MODELS.items()}
 assert_model_locked()
+TEST_RESULTS, ALL_RESULTS = TEST_RESULTS_BY_MODE[MODE], ALL_RESULTS_BY_MODE[MODE]
 
 def metric_rows(records, results):
     return [dict(file=record["name"], split=record["split"], algorithm=ALGORITHM,
                  **result["metrics"])
             for record, result in zip(records, results)]
 
-TEST_METRIC_ROWS = metric_rows(TEST_RECORDS, TEST_RESULTS)
-ALL_METRIC_ROWS = metric_rows(ALL_RECORDS, ALL_RESULTS)
-TEST_SUMMARY = summarize(TEST_METRIC_ROWS)
+TEST_METRICS_BY_MODE = {mode: metric_rows(TEST_RECORDS, results) for mode, results in TEST_RESULTS_BY_MODE.items()}
+ALL_METRICS_BY_MODE = {mode: metric_rows(ALL_RECORDS, results) for mode, results in ALL_RESULTS_BY_MODE.items()}
+TEST_SUMMARIES_BY_MODE = {mode: summarize(rows) for mode, rows in TEST_METRICS_BY_MODE.items()}
+TEST_METRIC_ROWS = [row for rows in TEST_METRICS_BY_MODE.values() for row in rows]
+ALL_METRIC_ROWS = [row for rows in ALL_METRICS_BY_MODE.values() for row in rows]
+TEST_SUMMARY = TEST_SUMMARIES_BY_MODE[MODE]
 METRIC_COLUMNS = [
-    ("file", "File"), ("split", "Split"),
+    ("file", "File"), ("split", "Split"), ("endpoint_mode", "Mode"),
     ("ground_truth_region_count", "GT regions"), ("predicted_region_count", "Pred regions"),
     ("mae_ms", "Final MAE (ms)"), ("rmse_ms", "RMSE (ms)"), ("status", "Status"),
     ("start_error_ms", "Signed START error (ms)"), ("end_error_ms", "Signed END error (ms)"),
     ("gt_start_s", "GT START (s)"), ("gt_end_s", "GT END (s)"),
     ("predicted_start_s", "Pred START (s)"), ("predicted_end_s", "Pred END (s)")
 ]
-display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings: final confirmed boundaries")
+display_table(TEST_METRIC_ROWS, METRIC_COLUMNS, "Four TEST recordings in each mode: FINAL-region endpoints")
+THRESHOLD_ROWS = [dict(file=result["file"], endpoint_mode=mode,
+                      **{key:result["diagnostic"].get(key) for key in
+                         ("native_threshold", "native_threshold_units", "low_ste_threshold", "high_ste_threshold",
+                          "geometry", "minimum_speech_ms", "padding_stage")})
+                  for mode, results in ALL_RESULTS_BY_MODE.items() for result in results]
+display_table(THRESHOLD_ROWS, [(key,key) for key in THRESHOLD_ROWS[0]], "Both-mode threshold and geometry diagnostics")
 
-display_table(TEST_SUMMARY,
-              [("algorithm", "Algorithm"), ("files", "Files"),
+display_table([row for rows in TEST_SUMMARIES_BY_MODE.values() for row in rows],
+              [("algorithm", "Algorithm"), ("endpoint_mode", "Mode"), ("files", "Files"),
                ("evaluated_files", "Defined MAE files"), ("mean_file_mae_ms", "Mean MAE (ms)"),
                ("median_file_mae_ms", "Median (ms)"), ("min_file_mae_ms", "Min (ms)"),
                ("max_file_mae_ms", "Max (ms)"), ("mean_file_rmse_ms", "Mean file RMSE (ms)"),
                ("pooled_endpoint_rmse_ms", "Pooled endpoint RMSE (ms)"),
                ("region_count_correct_files", "Correct counts"),
                ("region_count_incorrect_files", "Incorrect counts"),
                ("mean_frame_f1", "Mean frame F1"), ("top_mae_files", "Highest MAE files"),
                ("evaluation_protocol", "Protocol")],
@@ -1019,37 +1079,42 @@ def plot_record(record, result):
     mae_text = f"{mae:.2f} ms" if mae is not None else "N/A"
     figure, axes = plt.subplots(2, 1, figsize=(12.5, 5.5), sharex=True,
                                gridspec_kw={"height_ratios": [1, 1.25]})
     time = [index / record["sample_rate"] for index in range(len(record["samples"]))]
     axes[0].plot(time, record["samples"], color="#444444", linewidth=0.6)
     axes[0].set_ylabel("PCM amplitude")
     axes[1].plot(features["centers"], features["ste_norm"], color="#263238",
                  linewidth=1, label="Normalized STE")
-    axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060",
-                   linestyle="--", linewidth=1.2, label="LOW")
-    axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700",
-                   linestyle=":", linewidth=1.4, label="HIGH")
+    if diagnostic["endpoint_mode"] == "core":
+        native = diagnostic["native_threshold"]
+        if diagnostic["native_threshold_units"] == "mean squared sample amplitude":
+            peak = max(features["energy"], default=0.)
+            native = native / peak if peak else 0.
+        axes[1].axhline(native, color="#9b6700", linestyle=":", label="Native T (display normalized)")
+    else:
+        axes[1].axhline(diagnostic["low_ste_threshold"], color="#008060", linestyle="--", label="LOW")
+        axes[1].axhline(diagnostic["high_ste_threshold"], color="#9b6700", linestyle=":", label="HIGH")
     for axis in axes:
         for index, (start, end) in enumerate(result["ground_truth_regions"]):
             axis.axvspan(start, end, color="red", alpha=0.05)
             axis.axvline(start, color="red", linestyle="--", linewidth=1.25,
                         label="GT boundary" if index == 0 else None)
             axis.axvline(end, color="red", linestyle="--", linewidth=1.25)
         for index, (start, end) in enumerate(result["final_regions"]):
             axis.axvspan(start, end, color="#1769d2", alpha=0.11)
             axis.axvline(start, color="#1769d2", linewidth=1.4,
                         label="FINAL predicted boundary" if index == 0 else None)
             axis.axvline(end, color="#1769d2", linewidth=1.4)
         axis.grid(alpha=0.16)
         axis.set_xlim(0, record["duration"])
     axes[1].set_ylabel("Normalized STE")
     axes[1].set_xlabel("Time (s)")
     axes[1].legend(loc="upper right", fontsize=8, ncol=3)
-    figure.suptitle(f"{record['name']}.wav | Outer boundary MAE: {mae_text} | "
+    figure.suptitle(f"{record['name']}.wav | {MODE} | FINAL-region endpoint MAE: {mae_text} | "
                    f"{len(result['final_regions'])} speech regions")
     figure.tight_layout()
     plt.show()
     plt.close(figure)
 
 
 TEST_RECORDS_BY_FILE = {record["name"]: record for record in TEST_RECORDS}
 TEST_RESULTS_BY_FILE = {result["file"]: result for result in TEST_RESULTS}
